/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <filters.h>
#include <conf_parse.h>

struct aligner {
	struct stream *output;
	struct stream_destination *input;
	struct frame *left;
	int size;
};

static void do_align( struct frame *in, void *d )
{
	struct aligner *en = (struct aligner *)d;
	struct frame *out;
	int i = 0, t;

	while( i < in->length )
	{
		if( ! en->left )
		{
			if( ! ( en->left = new_frame( en->size ) ) )
				break;
			en->left->format = in->format;
			en->left->width = en->left->height = 0;
			en->left->key = 1;
			en->left->length = 0;
		}
		t = in->length - i;
		if( t + en->left->length > en->size )
			t = en->size - en->left->length;
		memcpy( en->left->d + en->left->length, in->d + i, t );
		i += t;
		en->left->length += t;
		if( en->left->length == en->size )
		{
			out = en->left;
			en->left = NULL;
			deliver_frame_to_stream( out, en->output );
		}
	}
	unref_frame( in );
}

static void get_framerate( struct stream *s, int *fincr, int *fbase )
{
	struct aligner *en = (struct aligner *)s->src_private;

	en->input->stream->get_framerate( en->input->stream, fincr, fbase );
}

static void set_running( struct stream *s, int running )
{
	struct aligner *en = (struct aligner *)s->src_private;

	if( ! running && en->left )
	{
		unref_frame( en->left );
		en->left = NULL;
	}
	set_waiting( en->input, running );
}

/************************ CONFIGURATION DIRECTIVES ************************/

static void *start_block(void)
{
	struct aligner *en;

	en = (struct aligner *)malloc( sizeof( struct aligner ) );
	en->input = NULL;
	en->output = NULL;
	en->left = NULL;
	en->size = 0;

	return en;
}

static int end_block( void *d )
{
	struct aligner *en = (struct aligner *)d;

	if( ! en->input )
	{
		spook_log( SL_ERR,
			"align: missing input stream name" );
		return -1;
	}
	if( ! en->output )
	{
		spook_log( SL_ERR,
			"align: missing output stream name" );
		return -1;
	}
	if( en->size < 1 )
	{
		spook_log( SL_ERR, "align: missing target frame size" );
		return -1;
	}

	return 0;
}

static int set_input( int num_tokens, struct token *tokens, void *d )
{
	struct aligner *en = (struct aligner *)d;
	int format = FORMAT_ALAW;

	if( ! ( en->input = connect_to_stream( tokens[1].v.str, do_align,
						en, &format, 1 ) ) )
	{
		spook_log( SL_ERR,
			"align: unable to connect to stream \"%s\"\n",
				tokens[1].v.str );
		return -1;
	}
	return 0;
}

static int set_output( int num_tokens, struct token *tokens, void *d )
{
	struct aligner *en = (struct aligner *)d;

	if( ! en->input )
	{
		spook_log( SL_ERR,
			"align: input must be specified before output" );
		return -1;
	}
	en->output = new_stream( tokens[1].v.str,
					en->input->stream->format, en );
	if( ! en->output )
	{
		spook_log( SL_ERR,
			"align: unable to create stream \"%s\"",
			tokens[1].v.str );
		return -1;
	}
	en->output->get_framerate = get_framerate;
	en->output->set_running = set_running;
	return 0;
}

static int set_size( int num_tokens, struct token *tokens, void *d )
{
	struct aligner *en = (struct aligner *)d;

	if( tokens[1].v.num < 1 )
	{
		spook_log( SL_ERR,
			"align: target frame size cannot be less than 1!" );
		return -1;
	}
	en->size = tokens[1].v.num;
	return 0;
}

static struct statement config_statements[] = {
	/* directive name, process function, min args, max args, arg types */
	{ "input", set_input, 1, 1, { TOKEN_STR } },
	{ "output", set_output, 1, 1, { TOKEN_STR } },
	{ "size", set_size, 1, 1, { TOKEN_NUM } },

	/* empty terminator -- do not remove */
	{ NULL, NULL, 0, 0, {} }
};

int align_init(void)
{
	register_config_context( "filter", "align", start_block, end_block,
					config_statements );
	return 0;
}
