/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <config.h>

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <pthread.h>

#include <libraw1394/raw1394.h>
#include <libdc1394/dc1394_control.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <inputs.h>
#include <conf_parse.h>

#define WIDTH	320
#define HEIGHT	240

struct dc1394_input {
	struct stream *output;
	struct frame_exchanger *ex;
	raw1394handle_t handle;
	dc1394_cameracapture camera;
	pthread_t thread;
	int running;
};

static void *capture_loop( void *d )
{
	struct dc1394_input *conf = (struct dc1394_input *)d;
	struct frame *f;
	int frames = 0;

	for(;;)
	{
		if( conf->running )
		{
			++frames;
			f = get_next_frame( conf->ex, 0 );
		} else
		{
			frames = 0;
			f = NULL;
		}
		if( ! f )
		{
			if( conf->running )
				spook_log( SL_WARN, "dc1394: dropping frame" );
			dc1394_dma_multi_capture( &conf->camera, 1 );
			dc1394_dma_done_with_buffer( &conf->camera );
			continue;
		}

		f->length = HEIGHT * WIDTH * 2;
		f->format = FORMAT_RAW_UYVY;
		f->width = WIDTH;
		f->height = HEIGHT;
		f->key = 1;
		frames = 0;

		dc1394_dma_multi_capture( &conf->camera, 1 );
		memcpy( f->d, conf->camera.capture_buffer, f->length );
		dc1394_dma_done_with_buffer( &conf->camera );

		deliver_frame( conf->ex, f );
	}
	return NULL;
}

static void get_back_frame( struct frame *f, void *d )
{
	struct dc1394_input *conf = (struct dc1394_input *)d;

	exchange_frame( conf->ex, new_frame( HEIGHT * WIDTH * 2 ) );
	deliver_frame_to_stream( f, conf->output );
}

static int dc1394_setup( struct dc1394_input *conf )
{
	raw1394handle_t raw_handle;
	int numPorts;
	struct raw1394_portinfo ports[4];
	nodeid_t *camera_nodes = NULL;
	unsigned int channel;
	unsigned int speed;
	int i;

	raw_handle = raw1394_new_handle();
	if( ! raw_handle )
	{
		spook_log( SL_ERR,
			"dc1394: unable to acquire a raw1394 handle" );
		return -1;
	}

	numPorts = raw1394_get_port_info( raw_handle, ports, 4 );
	raw1394_destroy_handle( raw_handle );
	spook_log( SL_VERBOSE, "dc1394: we found %d 1394 port(s)", numPorts );
	for( i = 0; i < numPorts; ++i )
	{
		int camCount = 0;

		raw_handle = raw1394_new_handle();
		raw1394_set_port( raw_handle, i );
		camera_nodes = dc1394_get_camera_nodes( raw_handle, &camCount, 1 );
		raw1394_destroy_handle( raw_handle );
		if( camCount > 0 )
		{
			spook_log( SL_INFO,
				"dc1394: using camera on port %d", i );
			break;
		}
	}

	if( i == numPorts )
	{
		spook_log( SL_ERR, "dc1394: did not find any IIDC cameras" );
		return -1;
	}

	conf->handle = dc1394_create_handle( i );
	if( ! conf->handle )
	{
		spook_log( SL_ERR, "dc1394: unable to create a camera handle" );
		return -1;
	}
	conf->camera.node = *camera_nodes;
	if( dc1394_get_iso_channel_and_speed( conf->handle, conf->camera.node, &channel, &speed ) != DC1394_SUCCESS )
	{
		spook_log( SL_ERR, "dc1394: unable to create an ISO channel" );
		return -1;
	}

	if( dc1394_dma_setup_capture( conf->handle, conf->camera.node, 1 /* iso channel */, FORMAT_VGA_NONCOMPRESSED, MODE_320x240_YUV422, SPEED_400, FRAMERATE_30, 8 /* num buffers */,
#ifdef DC1394_EXTRA_BUFFERING_FLAG
				0 /* do_extra_buffering */,
#endif
				1 /* drop frames */, NULL /* device name */, &conf->camera ) != DC1394_SUCCESS )
	{
		spook_log( SL_ERR, "dc1394: unable to set up DMA for camera" );
		return -1;
	}
	if( dc1394_start_iso_transmission( conf->handle, conf->camera.node ) != DC1394_SUCCESS )
	{
		spook_log( SL_ERR,
			"dc1394: unable to start ISO transfer from camera" );
		return -1;
	}
	// this doesn't work, fix later (just a li'l memory leak...)
	//dc1394_free_camera_nodes( camera_nodes );

	return 0;
}

static void get_framerate( struct stream *s, int *fincr, int *fbase )
{
	struct dc1394_input *conf = (struct dc1394_input *)s->private;

	*fincr = 1;
	*fbase = 30;
}

static void set_running( struct stream *s, int running )
{
	struct dc1394_input *conf = (struct dc1394_input *)s->private;

	conf->running = running;
}

#if 0
void dc1394_close(void)
{
	fprintf( stderr, "closing down..." );
	dc1394_dma_unlisten( handle, &camera );
	dc1394_dma_release_camera( handle, &camera );
	dc1394_destroy_handle( handle );
	fprintf( stderr, "done!\n" );
}
#endif

/************************ CONFIGURATION DIRECTIVES ************************/

static void *start_block(void)
{
	struct dc1394_input *conf;

	conf = (struct dc1394_input *)malloc( sizeof( struct dc1394_input ) );
	conf->output = NULL;
	conf->running = 0;

	return conf;
}

static int end_block( void *d )
{
	struct dc1394_input *conf = (struct dc1394_input *)d;
	int i;

	if( ! conf->output )
	{
		spook_log( SL_ERR, "dc1394: missing output stream name" );
		return -1;
	}
	if( dc1394_setup( conf ) < 0 )
	{
		spook_log( SL_ERR, "dc1394: unable to initialize video input" );
		return -1;
	}
	conf->ex = new_exchanger( 8, get_back_frame, conf );
	for( i = 0; i < 8; ++i )
		exchange_frame( conf->ex, new_frame( HEIGHT * WIDTH * 2 ) );
	pthread_create( &conf->thread, NULL, capture_loop, conf );

	return 0;
}

static int set_output( int num_tokens, struct token *tokens, void *d )
{
	struct dc1394_input *conf = (struct dc1394_input *)d;

	conf->output = new_stream( tokens[1].v.str, FORMAT_RAW_UYVY, conf );
	if( ! conf->output )
	{
		spook_log( SL_ERR, "dc1394: unable to create stream \"%s\"",
				tokens[1].v.str );
		return -1;
	}
	conf->output->get_framerate = get_framerate;
	conf->output->set_running = set_running;
	return 0;
}

static struct statement config_statements[] = {
	/* directive name, process function, min args, max args, arg types */
	{ "output", set_output, 1, 1, { TOKEN_STR } },

	/* empty terminator -- do not remove */
	{ NULL, NULL, 0, 0, {} }
};

void dc1394_init(void)
{
	register_config_context( "input", "dc1394", start_block, end_block,
					config_statements );
}
