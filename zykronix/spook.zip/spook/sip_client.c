/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <pmsg.h>
#include <rtp.h>
#include <sip.h>
#include <conf_parse.h>

int sip_hangup( struct dialog *d )
{
	struct pmsg *msg;
	struct transaction *x;
	char tmp[64];

	if( ! d ) return -1;

	if( ! ( msg = new_pmsg( 2048 ) ) ) return -1;
	msg->type = PMSG_REQ;
	msg->sl.req.method = add_pmsg_string( msg, "BYE" );
	msg->sl.req.uri = add_pmsg_string( msg, d->target );
	sip_get_my_addr( tmp + sprintf( tmp, "SIP/2.0/UDP " ) );
	add_header( msg, "Via", tmp );
	add_header( msg, "From", d->local_uri );
	add_header( msg, "To", d->remote_uri );
	add_header( msg, "Call-Id", d->callid );
	sprintf( tmp, "%d BYE", d->local_cseq++ );
	add_header( msg, "CSeq", tmp );

	//update_msg_dest( msg );

	x = transaction_start( msg, NULL, 0, NULL );
	x->dialog = d;
	/* Note: Don't ref_dialog; ref_count is already 1 because of
	 * persistant ref, so when this transaction terminates the dialog
	 * will go away */
	return 0;
}

int sip_register( struct dialog *d, transaction_callback cb )
{
	struct pmsg *msg;
	struct transaction *x;
	char tmp[256], *c;

	if( ! ( msg = new_pmsg( 2048 ) ) ) return -1;
	msg->type = PMSG_REQ;
	msg->sl.req.method = add_pmsg_string( msg, "REGISTER" );

	/* Construct the URI from the host:port part of the local URI only */
	strcpy( tmp, "sip:" );
	strcpy( tmp + 4, strchr( d->local_uri, '@' ) + 1 );
	if( ( c = strchr( tmp, '>' ) ) || ( c = strchr( tmp, ';' ) ) ) *c = 0;
	msg->sl.req.uri = add_pmsg_string( msg, tmp );

	sip_get_my_addr( tmp + sprintf( tmp, "SIP/2.0/UDP " ) );
	add_header( msg, "Via", tmp );
	add_header( msg, "From", d->local_uri );
	add_header( msg, "To", d->remote_uri );
	add_header( msg, "Call-Id", d->callid );
	sprintf( tmp, "%d REGISTER", d->local_cseq++ );
	add_header( msg, "CSeq", tmp );
	add_header( msg, "Contact", d->target );
	add_header( msg, "Expires", "600" );

	//update_msg_dest( msg );

	x = transaction_start( msg, NULL, 0, cb );
	x->dialog = d;
	ref_dialog( d );
	return 0;
}

int sip_start_call( char *uri, transaction_callback cb )
{
	struct pmsg *msg;
	struct transaction *x;
	char tmp[256];

	if( ! ( msg = new_pmsg( 2048 ) ) ) return -1;
	msg->type = PMSG_REQ;
	msg->sl.req.method = add_pmsg_string( msg, "INVITE" );
	msg->sl.req.uri = add_pmsg_string( msg, uri );
	sip_get_my_addr( tmp + sprintf( tmp, "SIP/2.0/UDP " ) );
	add_header( msg, "Via", tmp );
	sprintf( tmp, "sip:1@" );
	sip_get_my_addr( tmp + strlen( tmp ) );
	add_header( msg, "From", tmp );
	add_header( msg, "To", uri );
	random_bytes( tmp, 32 );
	add_header( msg, "Call-Id", tmp );
	sprintf( tmp, "%d REGISTER", 1 ); // XXX something random
	add_header( msg, "CSeq", tmp );
	add_header( msg, "Contact", get_header( msg, "From" ) );

	//update_msg_dest( msg );

	x = transaction_start( msg, NULL, 0, cb );
	return 0;
}
