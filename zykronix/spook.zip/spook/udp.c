/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <pmsg.h>
#include <rtp.h>
#include <sip.h>
#include <conf_parse.h>

// #define SIP_PRINT_ALL

struct udp_port {
	int fd;
};

static struct udp_port *mainport;
static char my_addr[64] = "";

int udp_send_pmsg( struct pmsg *msg, unsigned char *d, int len )
{
	char buf[1300];
	int i, f;

	if( msg->type == PMSG_REQ )
		i = sprintf( buf, "%s %s SIP/2.0\r\n",
				msg->sl.req.method, msg->sl.req.uri );
	else
		i = sprintf( buf, "SIP/2.0 %d %s\r\n",
				msg->sl.stat.code, msg->sl.stat.reason );
	for( f = 0; f < msg->header_count; ++f )
		i += sprintf( buf + i, "%s: %s\r\n",
				msg->fields[f].name, msg->fields[f].value );
	i += sprintf( buf + i, "Content-Length: %d\r\n", len );
	strcpy( buf + i, "\r\n" );
	i += 2;
	if( len > 0 )
	{
		memcpy( buf + i, d, len );
		i += len;
	}
#ifdef SIP_PRINT_ALL
	buf[i] = 0;
	printf( "Sending:\n%s\n", buf );
#endif
//	sendto( mainport->fd, buf, i, 0, (struct sockaddr *)&msg->remote,
//			sizeof( struct sockaddr_in ) );
	send( mainport->fd, buf, i, 0 );
	return 0;
}

static void udp_receive( struct event_info *ei, void *d )
{
	struct udp_port *up = d;
	int len, body_offset, addrlen;
	struct pmsg *msg;
	struct sockaddr_in remote;

	if( ! ( msg = new_pmsg( 2048 ) ) ) return;
	addrlen = sizeof( remote );
#ifdef SIP_PRINT_ALL
	--msg->max_len; /* Make room for terminating \0 */
#endif
	len = recvfrom( up->fd, msg->msg, msg->max_len, 0,
			     (struct sockaddr *)&(remote), &addrlen );
	if( len < 0 && errno != EAGAIN )
	{
		spook_log( SL_DEBUG, "SIP UDP error: %s", strerror( errno ) );
		free_pmsg( msg );
		return;
	}
	if( len == 0 )
	{
		free_pmsg( msg );
		return;
	}
	msg->msg_len = len;

#ifdef SIP_PRINT_ALL
	msg->msg[msg->msg_len] = 0;
	printf( "Received:\n%s\n", msg->msg );
#endif

	body_offset = parse_pmsg( msg );
	if( body_offset < 0 )
		spook_log( SL_VERBOSE, "received malformed SIP request" );
	else if( msg->type == PMSG_REQ )
	{
		if( process_msg_request( msg, msg->msg + body_offset,
						msg->msg_len - body_offset ) )
			return;
	} else if( msg->type == PMSG_RESP )
	{
		if( process_msg_response( msg, msg->msg + body_offset,
						msg->msg_len - body_offset ) )
			return;
	}

	free_pmsg( msg );
}

int udp_listen( int port )
{
	struct sockaddr_in addr;

	mainport = malloc( sizeof( *mainport ) );

	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = 0;
	addr.sin_port = htons( port );
	if( ( mainport->fd = socket( PF_INET, SOCK_DGRAM, 0 ) ) < 0 )
	{
		perror( "socket" );
		return -1;
	}
	if( bind( mainport->fd, (struct sockaddr *)&addr, sizeof( addr ) ) < 0 )
		perror( "bind" );

	add_fd_event( mainport->fd, 0, 0, udp_receive, mainport );

	return 0;
}

void sip_set_proxy( char *ip )
{
	struct sockaddr_in addr;
	int addrlen;

	addr.sin_family = AF_INET;
	inet_aton( ip, &addr.sin_addr );
	addr.sin_port = htons( 5060 );

	if( connect( mainport->fd, (struct sockaddr *)&addr, sizeof( addr ) ) < 0 )
	{
		perror( "connect" );
		return;
	}
	addrlen = sizeof( addr );
	if( getsockname( mainport->fd, (struct sockaddr *)&addr, &addrlen ) < 0 )
	{
		perror( "connect" );
		return;
	}
	if( ntohs( addr.sin_port ) == 5060 )
		sprintf( my_addr, "%s", inet_ntoa( addr.sin_addr ) );
	else
		sprintf( my_addr, "%s:%d",
			inet_ntoa( addr.sin_addr ), ntohs( addr.sin_port ) );
}

void sip_get_my_addr( char *dest )
{
	strcpy( dest, my_addr );
}
