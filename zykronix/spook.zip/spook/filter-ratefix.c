/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <filters.h>
#include <conf_parse.h>

struct fixer {
	struct stream *output;
	struct stream_destination *input;
	int checking;
	int rate;
	int sample_size;
	time_ref last_check;
	int sample_count;
	int adjust;
	int avg_slip;
	int precomp;
};

static void do_ratefix( struct frame *in, void *d )
{
	struct fixer *fix = (struct fixer *)d;
	struct frame *out;
	int samples, msec, j;
	time_ref now;

	time_now( &now );
	msec = time_diff( &fix->last_check, &now );
	samples = in->length / fix->sample_size;
	if( fix->sample_count == 0 )
	{
		fix->adjust = 0;
		fix->avg_slip = 0;
		fix->precomp = 0;
		fix->sample_count = samples;
		fix->last_check = now;
		deliver_frame_to_stream( in, fix->output );
		return;
	} else if( msec < 30000 )
	{
		fix->sample_count += samples;
	} else
	{
		int slip = fix->rate * msec / 1000 - fix->sample_count;

		fix->adjust += slip - fix->precomp;
		fix->avg_slip = ( fix->avg_slip + slip ) / 2;
		/* Pre-compensate by 1/2 the average slip */
		fix->precomp = fix->avg_slip / 2;
		fix->adjust += fix->precomp;
		fix->sample_count = samples;
		fix->last_check = now;
	}

	if( fix->adjust == 0 ||
		! ( out = new_frame( in->length + in->length / 100 ) ) )
	{
		deliver_frame_to_stream( in, fix->output );
		return;
	}

	out->format = in->format;
	out->step = in->step;
	out->width = out->height = 0;
	out->key = 1;
	j = 0;

	if( fix->adjust < 0 )
	{
		int i, slot;

		/* Don't correct by more than 0.5%, so if we need to delete a
		 * sample more often than every 200 samples, cap it at 200. */
		if( samples / -fix->adjust < 200 ) slot = 200;
		else slot = samples / -fix->adjust;
		for( i = 0; i < in->length; i += fix->sample_size )
		{
			if( ( i / fix->sample_size ) % slot != slot - fix->sample_size )
			{
				out->d[j] = in->d[i];
				out->d[j + 1] = in->d[i + 1];
				if( fix->sample_size > 2 )
				{
					out->d[j + 2] = in->d[i + 2];
					out->d[j + 3] = in->d[i + 3];
				}
				j += fix->sample_size;
			} else ++fix->adjust;
		}
	} else if( fix->adjust > 0 )
	{
		int i, slot;

		/* Don't correct by more than 0.5%, so if we need to insert a
		 * sample more often than every 200 samples, cap it at 200. */
		if( samples / fix->adjust < 200 ) slot = 200;
		else slot = samples / fix->adjust;
		for( i = 0; i < in->length; i += fix->sample_size )
		{
			out->d[j] = in->d[i];
			out->d[j + 1] = in->d[i + 1];
			if( fix->sample_size > 2 )
			{
				out->d[j + 2] = in->d[i + 2];
				out->d[j + 3] = in->d[i + 3];
			}
			j += fix->sample_size;
			if( ( i / fix->sample_size ) % slot == slot - fix->sample_size )
			{
				out->d[j] = in->d[i];
				out->d[j + 1] = in->d[i + 1];
				if( fix->sample_size > 2 )
				{
					out->d[j + 2] = in->d[i + 2];
					out->d[j + 3] = in->d[i + 3];
				}
				j += fix->sample_size;
				--fix->adjust;
			}
		}
	}
	out->length = j;
	unref_frame( in );
	deliver_frame_to_stream( out, fix->output );
}

static void get_framerate( struct stream *s, int *fincr, int *fbase )
{
	struct fixer *fix = (struct fixer *)s->src_private;

	fix->input->stream->get_framerate( fix->input->stream, fincr, fbase );
}

static void set_running( struct stream *s, int running )
{
	struct fixer *fix = (struct fixer *)s->src_private;

	fix->checking = running;
	if( ! running ) fix->sample_count = 0;
	set_waiting( fix->input, running );
}

/************************ CONFIGURATION DIRECTIVES ************************/

static void *start_block(void)
{
	struct fixer *fix;

	fix = (struct fixer *)malloc( sizeof( struct fixer ) );
	fix->input = NULL;
	fix->output = NULL;
	fix->checking = 0;

	return fix;
}

static int end_block( void *d )
{
	struct fixer *fix = (struct fixer *)d;
	int chans, rate;

	if( ! fix->input )
	{
		spook_log( SL_ERR,
			"ratefix: missing input stream name" );
		return -1;
	}
	if( ! fix->output )
	{
		spook_log( SL_ERR,
			"ratefix: missing output stream name" );
		return -1;
	}
	fix->input->stream->get_framerate( fix->input->stream, &chans, &rate );
	fix->checking = 0;
	fix->rate = rate / chans;
	fix->sample_size = 2 * chans;

	return 0;
}

static int set_input( int num_tokens, struct token *tokens, void *d )
{
	struct fixer *fix = (struct fixer *)d;
	int format = FORMAT_PCM;

	if( ! ( fix->input = connect_to_stream( tokens[1].v.str, do_ratefix,
						fix, &format, 1 ) ) )
	{
		spook_log( SL_ERR,
			"ratefix: unable to connect to stream \"%s\"\n",
				tokens[1].v.str );
		return -1;
	}
	return 0;
}

static int set_output( int num_tokens, struct token *tokens, void *d )
{
	struct fixer *fix = (struct fixer *)d;

	if( ! fix->input )
	{
		spook_log( SL_ERR,
			"ratefix: input must be specified before output" );
		return -1;
	}
	fix->output = new_stream( tokens[1].v.str,
					fix->input->stream->format, fix );
	if( ! fix->output )
	{
		spook_log( SL_ERR, "ratefix: unable to create stream \"%s\"",
			tokens[1].v.str );
		return -1;
	}
	fix->output->get_framerate = get_framerate;
	fix->output->set_running = set_running;
	return 0;
}

static struct statement config_statements[] = {
	/* directive name, process function, min args, max args, arg types */
	{ "input", set_input, 1, 1, { TOKEN_STR } },
	{ "output", set_output, 1, 1, { TOKEN_STR } },

	/* empty terminator -- do not remove */
	{ NULL, NULL, 0, 0, {} }
};

int ratefix_init(void)
{
	register_config_context( "filter", "ratefix", start_block, end_block,
					config_statements );
	return 0;
}
