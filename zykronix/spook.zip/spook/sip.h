#define TIME_T1		500
#define TIME_T2		4000
#define TIME_T4		5000

struct transaction;

struct dialog {
	struct dialog *prev;
	struct dialog *next;
	int ref_count;
	int confirmed;
	int local_cseq;
	int remote_cseq;
	char local_tag[32];
	char remote_tag[128];
	char callid[192];
	char local_uri[128];
	char remote_uri[192];
	char target[128];
	char **route_set;
};

enum transaction_type { XT_SERV_N, XT_SERV_I, XT_CLIENT_N, XT_CLIENT_I };
enum transaction_state
		{ XS_TRYING, XS_PROCEED, XS_COMPLETE, XS_CONFIRM, XS_TERM };

typedef void (*transaction_callback)( struct transaction *x );

struct transaction {
	struct transaction *prev;
	struct transaction *next;
	void *app_data;
	enum transaction_type type;
	enum transaction_state state;
	transaction_callback callback;
	struct pmsg *req;
	struct pmsg *resp;
	char branch[64];
	struct dialog *dialog;
	struct event *retry_timer;
	struct event *timeout_timer;
	int rexmit_count;
	unsigned char *body;
	int bodylen;
};

/* sip_spook.c */
void new_sip_line( char *line, open_func open, void *private );
void event_new_call( struct transaction *x, char *d, int len );
void hangup_event( struct dialog *d );
int get_sip_credentials( char *realm, char **user, char **pass );

/* sip_dialog.c */
void ref_dialog( struct dialog *d );
void unref_dialog( struct dialog *d );
int find_dialog( char *local, char *remote, char *callid, struct dialog **dptr );
struct dialog *new_dialog( struct transaction *x, int is_uas );
struct dialog *register_dialog( char *line, char *domain );

/* sip_trans.c */
int process_msg_request( struct pmsg *msg, unsigned char *body, int bodylen );
int process_msg_response( struct pmsg *msg, unsigned char *d, int len );
int transaction_reply( struct transaction *x );
int simple_reply( struct transaction *x, int code, char *reason );
struct transaction *transaction_start( struct pmsg *req,
					unsigned char *body, int bodylen,
					transaction_callback cb );

/* sip_server.c */
int handle_server_transaction( struct transaction *x,
					unsigned char *body, int bodylen );
int handle_ack( struct pmsg *msg, unsigned char *body, int bodylen );
struct dialog *sip_answer_call( struct transaction *x,
					int code, char *reason, char *sdp );

/* sip_client.c */
int sip_hangup( struct dialog *d );
int sip_register( struct dialog *d, transaction_callback cb );

/* udp.c */
int udp_send_pmsg( struct pmsg *msg, unsigned char *d, int len );
int udp_listen( int port );
void sip_set_proxy( char *ip );
void sip_get_my_addr( char *dest );

/* sip_util.c */
int get_cseq( struct pmsg *msg, char *method );
struct pmsg *create_sip_reply( struct pmsg *req, struct dialog *d,
					int code, char *reply );
void sip_send( struct pmsg *msg, unsigned char *d, int len );
