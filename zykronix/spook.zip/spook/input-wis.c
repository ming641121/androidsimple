/*
 * Copyright (C) 2004 James F Dougherty <jfd@wischip.com>
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * WIS MPEG Encoder Input Module for GO7007SB
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <config.h>
#include <signal.h>
#include <bits/signum.h>
#include <sys/types.h>
#include <inttypes.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <linux/videodev.h>

#include <bswap.h>
#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <inputs.h>
#include <conf_parse.h>
#include "../../../wismedia/include/motion_detection_api.h"

#define DEF_WIDTH               720
#define DEF_HEIGHT              480

#define GET_16(p) (((p)[0]<<8)|(p)[1])
#define GET_32(p) (((p)[0]<<24)|((p)[1]<<16)|((p)[2]<<8)|(p)[3])

struct v4l_input;

struct v4l_frame_data {
	struct v4l_input *conf;
	int index;
	struct frame *f;
};

struct v4l_input {
	struct stream *vout;
	struct stream *aout;
	struct soft_queue *vq;
	struct soft_queue *aq;
	char device[256];
	int width;
	int height;
	int fps;
	int fincr;
	int fbase;
	int norm;
	int audiorate;
	int audiochannels;
	int format;
	int fd;
	struct video_mbuf vm;
	pthread_mutex_t ring_mutex;
	struct v4l_frame_data *frames;
	int *wait_ring;
	int wait_ring_r;
	int wait_ring_w;
	unsigned char *mmap_buf;
	pthread_t video_thread;
	pthread_t audio_thread;
	int video_running;
	int audio_running;
};

char *cmd_args[100];
int cmd_argc;
extern void MDInit(char *res);

#define IN_TV                   0
#define IN_COMPOSITE            1
#define IN_COMPOSITE2           2
#define IN_SVIDEO               3
#define IN_DEFAULT              1

#define NORM_PAL                0
#define NORM_NTSC               1
#define NORM_SECAM              2
#define NORM_CAMERA             3

/* various additional definitions for the ioctl interface */
typedef struct encoder_io_packet_s {

    unsigned char buf[2048];
    unsigned int  buffer_length;

} encoder_io_packet_t;

typedef struct _framecopy {
    void * usrbuf;
    int len;  /* length of usrbuf, returns length of frame */
    int frameindex;
} wis_framecopy_t;

/* various additional definitions for the ioctl interface */
#define AUDIO_GET_FRAME                         0x10000
#define MD_SET_THRESHOLDS_AND_SENSITIVITIES     0x10100
#define MD_SET_REGIONS                          0x10101
#define MD_STOP                                 0x10102
#define SET_VIDEO_BLOCKING                      0x10103
#define SET_AUDIO_BLOCKING                      0x10104
#define AUDIO_GET_FRAME_COPY                    0x10105
#define GET_VIDEO_MEMBASE                       0x10106
#define AV_SYNCH_CORRECTION                     0x10107
#define AV_SYNCH_CONFIG                         0x10108
#define INSERT_VIDEO_FRAME                      0x10109
#define DROP_VIDEO_FRAME                        0x1010a
#define VIDIOCMCOPY                             0x1010f
#define GET_AND_RESET_AUDIO_CORRECTION_COUNT    0x10110
#define SET_AUDIO_CORRECTION_RATE               0x10111
#define SET_AUDIO_BIG_ENDIAN                    0x10112

int _devfd;
int md_enabled = 0;

/*
 * Audio buffer type.
 */
typedef struct audio_buf_s
{
    void*   addr;
    int     len;
} audio_buf_t;

struct meter {
	int started;
	int downstream;
	time_ref last_check;
	int rate;
	int ticks;
	double slip;
	double avg_slip;
	int precomp;
	int correction_rate;
	int corrected;
};


#ifdef NO_MM
#define MAP_FLAGS                   MAP_SHARED
#define VMADDR                      0
#define PROT_FLAGS                  PROT_READ
#else
#define PROT_FLAGS                  PROT_READ|PROT_WRITE
#define MAP_FLAGS           MAP_SHARED
#define VMADDR                      0
#endif

static void *audio_loop( void *d );

// #define AUDIO_DEBUG

/*
 * Start encoder.
 */
int
v4l_start(int dev)
{
    int state = 1;
    int audio_nonblocking = 0;
    int video_nonblocking = 0;
    int do_avs = 0;
    int big_endian = 1;

    if (ioctl (dev, AV_SYNCH_CONFIG, &do_avs) == -1){
      printf("v4l_start: VIDIOCCAPTURE - avsynch disable failed \n");
      return -1;
    }

    if (ioctl (dev, SET_AUDIO_BIG_ENDIAN, &big_endian) == -1){
      printf("v4l_start: VIDIOCCAPTURE - set audio to big endian failed \n");
      return -1;
    }

    if (ioctl (dev, SET_AUDIO_BLOCKING, &audio_nonblocking) == -1){
      printf("v4l_start: VIDIOCCAPTURE - blocking audio failed \n");
      return -1;
    }

    if (ioctl (dev, SET_VIDEO_BLOCKING, &video_nonblocking) == -1){
      printf("v4l_start: VIDIOCCAPTURE -blocking video failed \n");
      return -1;
    }

    if (ioctl (dev, VIDIOCCAPTURE, &state) == -1){
      printf("v4l_start: VIDIOCCAPTURE -start failed \n");
      return -1;
    }
    return 0;
}

/*
 * Stop encoder.
 */
int
v4l_stop(int dev)
{
    int state = 0;
    if (ioctl (dev, VIDIOCCAPTURE, &state) == -1){
      printf("v4l_stop: VIDIOCCAPTURE -stop failed \n");
      return -1;
    }
    return 0;
}

int
v4l_open(char *device)
{
    int dev = -1;
    int max_try = 5;
    /* we try 5 seconds/times to open the device */
    /* open the video4linux device */
    while (max_try) {
	dev = open (device, O_RDWR);
	if (dev == -1) {
	    if (!--max_try) {
		fprintf (stderr, "Can't open device %s\n", device);
		exit (0);
	    }
	    sleep (1);
	}
	else {
	    break;
	}
    }
    _devfd = dev;
    return dev;
}

void v4l_close(int dev)
{
    if (dev > 0)
      close(dev);
}

/*
 * Stop the Encoder if the user presses Ctrl-C
 */
void
sig_handler(int signal)
{
    int i;
    psignal(signal,"Signal:");
    v4l_stop(_devfd);
    v4l_close(_devfd);
    exit(0);
}

void
wis_report_audio_slip( int offset )
{
	if( ioctl( _devfd, AV_SYNCH_CORRECTION, &offset ) < 0 )
	{
		spook_log( SL_WARN,
			"v4l: unable to report audio slip to WIS driver" );
	}
}

static void meter_init( struct meter *m, int fbase, int downstream )
{
	m->started = 0;
	m->downstream = downstream;
	m->rate = fbase;
	m->ticks = 0;
	m->slip = 0;
	m->avg_slip = 0;
	m->precomp = 0;
	m->correction_rate = 0;
	m->corrected = 0;
}

static int meter_count( struct meter *m, int ticks, int *rate )
{
	int msec;
	time_ref now;
	double expected;

	if( ! m->started )
	{
		time_now( &m->last_check );
		m->started = 1;
		m->ticks = ticks;
		return 0;
	}
	time_now( &now );
	msec = time_diff( &m->last_check, &now );
	if( msec < 30000 )
	{
		m->ticks += ticks;
		return 0;
	}
	expected = m->rate * (double)msec / 1000.0;
	if( ! m->downstream ) expected -= m->corrected;
#if 0
	printf( "meter: expected %.3f (%d) in %d msec, got %d\n",
			expected, m->corrected, msec, m->ticks );
#endif
	m->slip += expected - (double)m->ticks - (double)m->precomp;
	m->slip += m->corrected;
	m->avg_slip = m->avg_slip / 2.0 +
		( expected - (double)m->ticks ) * 1000.0 / (double)msec / 2.0;
	/* Pre-compensate by 1/2 the average slip */
	m->precomp = 30 * m->avg_slip / 2;
#if 0
	printf( "meter: total slip = %.3f avg slip = %.3f/sec precomp = %d\n",
			m->slip, m->avg_slip, m->precomp );
#endif
	m->slip += m->precomp;
	m->correction_rate = m->ticks / m->slip;
	if( rate ) *rate = m->correction_rate;
	m->ticks = ticks;
	m->last_check = now;
	m->corrected = 0;
	return rate != NULL;
}

static int meter_get_correction( struct meter *m )
{
	int msec;

	if( m->slip == 0 ) return 0;
	msec = time_ago( &m->last_check );
	return m->slip * msec / 30000 + m->corrected;
}

static void meter_corrected( struct meter *m, int ticks )
{
	m->corrected -= ticks;
	//printf( "meter: total slip = %f correction = %d\n",
	//		m->slip, m->corrected );
}

int
set_regions(int fd, char **args)
{
	char *ptr,vname[20];
	int i,r,cor_xul,cor_yul,cor_xlr,cor_ylr,sensitivity,mv_thr,sad_thr;

	for(i=0; i < MAX_REGIONS_OF_INTEREST-1;i++)
	{
#if 0
	    printf("args: %s %s %s %s %s %s %s %s\n",
		   args[i*8+2],
		   args[i*8+3],
		   args[i*8+4],
		   args[i*8+5],
		   args[i*8+6],
		   args[i*8+7],
		   args[i*8+8],
		   args[i*8+9]);
#endif		   
	    if(atoi(args[i*8+2])==0) {
		printf("MD : region %d disabled\n", i);
		continue;
	    }

	    cor_xul=atoi(args[i*8+3]);
	    
	    cor_yul=atoi(args[i*8+4]);
	    
	    cor_xlr=atoi(args[i*8+5]);
	    
	    cor_ylr=atoi(args[i*8+6]);
	    
	    sensitivity=atoi(args[i*8+7]);

	    mv_thr=atoi(args[i*8+8]);
	    
	    sad_thr=atoi(args[i*8+9]);
	    
	    printf("Region%d: xul=%d, yul=%d, xlr=%d, "
		   "ylr=%d, sen=%d, mv=%d, sad=%d\n",
		   i, cor_xul, cor_yul, cor_xlr, cor_ylr, sensitivity,
		   mv_thr, sad_thr);

	    r = MDSetRegion( fd, cor_yul, cor_xul, cor_ylr,
			     cor_xlr, sensitivity, mv_thr, sad_thr,i+1);
	    if(r!=0)
		return(-1);
	}

	printf("----region set succeed----\n");

	return(0);

}

static encoder_io_packet_t io_packet;

int md_set_regions(int dev,
                   unsigned char *motion_coordinates,
                   unsigned int max_x_coordinate,
                   unsigned int max_y_coordinate)
{   
    io_packet.buffer_length =  2*sizeof(max_x_coordinate) +
	(max_x_coordinate * max_y_coordinate * sizeof(unsigned char));

    memcpy(io_packet.buf, &max_x_coordinate, sizeof(max_x_coordinate));

    memcpy(io_packet.buf+sizeof(max_x_coordinate), &max_y_coordinate,
           sizeof(max_y_coordinate));

    memcpy(io_packet.buf+2*sizeof(max_x_coordinate),
           motion_coordinates,
           max_x_coordinate*max_y_coordinate);

    if (ioctl(dev, MD_SET_REGIONS, &io_packet) != 0) {
        printf("set motion detection region failure\n");
        return(-1);
    }

    return 0;
}

int md_set_thresholds_and_sensitivities(int dev,
                                        unsigned short motion_thresholds[MAX_REGIONS_OF_INTEREST][NUM_MOTION_TYPES],
                                        unsigned short *motion_sensitivity)
{   
    io_packet.buffer_length = (MAX_REGIONS_OF_INTEREST*(1+NUM_MOTION_TYPES)*sizeof(unsigned short));

    memcpy(io_packet.buf, motion_sensitivity, MAX_REGIONS_OF_INTEREST*sizeof(unsigned short));

    memcpy(io_packet.buf+MAX_REGIONS_OF_INTEREST*sizeof(unsigned short),
           motion_thresholds,
           sizeof(unsigned short)*MAX_REGIONS_OF_INTEREST*NUM_MOTION_TYPES);

    if (ioctl(dev, MD_SET_THRESHOLDS_AND_SENSITIVITIES, &io_packet) != 0) {
        printf("set motion detection thresholds failure\n");
        return(-1);
    }

    return 0;
}

static int v4l_submit_buffer( struct frame *f, void *d )
{
	struct v4l_frame_data *frd = (struct v4l_frame_data *)d;
	struct v4l_input *conf = frd->conf;
	struct video_mmap mm;

	mm.frame = frd->index;
	if( ioctl( conf->fd, VIDIOCMCAPTURE, &mm ) < 0 )
	{
		spook_log( SL_ERR,
			"v4l: aborting on error in VIDIOCMCAPTURE for frame %d: %s",
			frd->index, strerror( errno ) );
	}

	/* The only reason for this stupid mutex is that this destructor
	 * function might get called from more than one thread.  There's no
	 * need for locking between destruction and the main capture loop. */
	pthread_mutex_lock( &conf->ring_mutex );
	conf->wait_ring[conf->wait_ring_w] = frd->index;
	conf->wait_ring_w = ( conf->wait_ring_w + 1 ) % ( conf->vm.frames + 1 );
	pthread_mutex_unlock( &conf->ring_mutex );

	return 1;
}

static void *video_loop( void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;
	struct video_mmap mm;
	struct timeval now, start;
	struct video_capability vc;
	struct video_picture pict;
	struct video_window win;
	struct meter meter;
	unsigned char *video_buf;
	int i, video_len, regionMap;
	static int md_init_done;
        int frame_cnt = 0, drained = 0;
	double scf = (double)conf->fincr * (double)conf->audiorate /
							(double)conf->fbase;
	start.tv_sec = 0;

	v4l_start(conf->fd);

	meter_init( &meter, conf->fbase, conf->format == FORMAT_JPEG );

	if( ioctl( conf->fd, VIDIOCGMBUF, &conf->vm ) < 0 )
	{
		spook_log( SL_ERR, "v4l: error configuring driver shared memory: %s",
				strerror( errno ) );
		exit( 1 );
	}

#ifdef NO_MM
	if( ioctl( conf->fd, GET_VIDEO_MEMBASE, &conf->mmap_buf ) < 0 )
	{
		spook_log( SL_ERR, "v4l: unable to get video memory base address: %s",
				strerror( errno ) );
		exit( 1 );
	}
#else
	if( ! ( conf->mmap_buf = (unsigned char *)mmap( NULL, conf->vm.size, PROT_READ, MAP_SHARED, conf->fd, 0 ) ) )
	{
		spook_log( SL_ERR, "v4l: error mapping driver memory" );
		exit( 1 );
	}
#endif

	if( ! ( conf->frames = (struct v4l_frame_data *)
				    malloc( conf->vm.frames *
					sizeof( struct v4l_frame_data ) ) ) )
	{
		spook_log( SL_ERR,
			"v4l: out of memory in malloc v4l_frame_data (%d)",
			conf->vm.frames );
		exit( 1 );
	}

	if( ! ( conf->wait_ring = calloc( conf->vm.frames + 1, sizeof( int ) ) ) )
	{
		spook_log( SL_ERR,
			"v4l: out of memory in malloc int (%d)",
			conf->vm.frames + 1 );
		exit( 1 );
	}

	for( i = 0; i < conf->vm.frames; ++i )
	{
		conf->frames[i].conf = conf;
		conf->frames[i].index = i;
		conf->frames[i].f = new_frame( 0 );
		if( ! conf->frames[i].f ) exit( 1 );
		conf->frames[i].f->destructor = v4l_submit_buffer;
		conf->frames[i].f->destructor_data = &conf->frames[i];
	}
	conf->wait_ring_r = conf->wait_ring_w = 0;

	if( ioctl( conf->fd, VIDIOCGCAP, &vc ) < 0 )
	{
		fprintf( stderr, "input v4l: error on ioctl(VIDIOCGCAP)\n" );
		return NULL;
	}

	printf( "v4l input: using capture device \"%s\"\n", vc.name );

	if( conf->width > vc.maxwidth )
		printf( "input v4l: device supports a maximum frame width of %d; %d is too large\n", vc.maxwidth, conf->width );
	if( conf->height > vc.maxheight )
		printf( "input v4l: device supports a maximum frame height of %d; %d is too large\n", vc.maxheight, conf->height );
	if( conf->width > vc.maxwidth || conf->height > vc.maxheight )
		return NULL;


	conf->width = vc.maxwidth;
	conf->height = vc.maxheight;

#if 0	
	/* FIX: from Yong, signal handling doesn't work on uCLinux */
	/* Always shutdown kernel thread, irregardless of how
	 * this application terminates. sig_handler() does ioctl() to halt.
	 */
	signal(SIGINT, sig_handler);
	signal(SIGQUIT, sig_handler);
	signal(SIGABRT, sig_handler);
	signal(SIGSEGV, sig_handler);
	signal(SIGKILL, sig_handler);
	signal(SIGBUS, sig_handler);
	signal(SIGALRM, sig_handler);
	signal(SIGTERM, sig_handler);
	signal(SIGHUP, sig_handler);
	signal(SIGILL, sig_handler);
	signal(SIGUSR1, sig_handler);    
#endif

	/*
	 * Setup MD
	 */
	if (md_enabled) {
	    MDInit(cmd_args[0]); /* Pass resolution */
	    md_init_done = 0;
	} else md_init_done = 1;

	pthread_mutex_init( &conf->ring_mutex, NULL );
	for( i = 0; i < conf->vm.frames; ++i )
		v4l_submit_buffer( conf->frames[i].f, &conf->frames[i] );

	if( conf->aout )
		pthread_create( &conf->audio_thread, NULL, audio_loop, conf );

	for(;;)
	{
		if( conf->wait_ring_w == conf->wait_ring_r )
		{
			if( ! drained )
				printf( "************v4l: out of free frame buffers!!!\n" );
			drained = 1;
			usleep( 100000 );
			continue;
		}
		drained = 0;
		i = conf->wait_ring[conf->wait_ring_r];
		conf->wait_ring_r = ( conf->wait_ring_r + 1 ) %
							( conf->vm.frames + 1 );

		/* Set regions,make sure encoder has been started */
		++frame_cnt;
		if ((!md_init_done)&&(frame_cnt>=10)) { 

		    if(set_regions(conf->fd, &cmd_args[0])!=0)
		    {
			printf("region set failed\n");
			break;
		    }
		    md_init_done++;
		    
		}

		if( ioctl( conf->fd, VIDIOCSYNC, &i ) < 0 )
		{
			spook_log( SL_ERR,
				"v4l: aborting on error in VIDIOCSYNC for frame %d: %s",
				i, strerror( errno ) );
			exit( 1 );
		}
		if( conf->format != FORMAT_H263 )
		{
			meter_count( &meter, conf->fincr, NULL );
			if( conf->format != FORMAT_JPEG )
			{
				int slip = meter_get_correction( &meter );

				if( slip < -conf->fincr )
				{
					wis_report_audio_slip( scf );
					meter_corrected( &meter, -conf->fincr );
				} else if( slip > conf->fincr )
				{
					wis_report_audio_slip( -scf );
					meter_corrected( &meter, conf->fincr );
				}
			}
		}

		video_buf = conf->mmap_buf + conf->vm.offsets[i];
		video_len = *((unsigned int *)video_buf);
		video_buf += 4;

		if( video_len > 212 &&
			GET_32( video_buf + video_len - 212 ) == 0x000001F8 )
		{
			regionMap = GET_16( video_buf + video_len - 2 );
			printf("Motion Detected: region map state: "
				"region(1):%d ; region(2):%d; region(3):%d \n",
				(regionMap&0x2)>>1, (regionMap&0x4)>>2,
				(regionMap&0x8)>>3);
			video_len -= 212;
		}

		conf->frames[i].f->d = video_buf;
		conf->frames[i].f->length = video_len;
		conf->frames[i].f->format = conf->format;
		conf->frames[i].f->width = conf->width;
		conf->frames[i].f->height = conf->height;
		conf->frames[i].f->key = 1;

		if( conf->format == FORMAT_JPEG )
		{
			int slip = meter_get_correction( &meter );

			if( slip < -conf->fincr )
			{
				unref_frame( conf->frames[i].f );
				meter_corrected( &meter, -conf->fincr );
				continue;
			}
			else if( slip > conf->fincr )
			{
				struct frame *clone;

				clone = clone_frame( conf->frames[i].f );
				if( soft_queue_add( conf->vq, clone ) < 0 )
					unref_frame( clone );
				else meter_corrected( &meter, conf->fincr );
			}
		}

		if( soft_queue_add( conf->vq, conf->frames[i].f ) < 0 )
			unref_frame( conf->frames[i].f );
	}
	return NULL;
}

static void *audio_loop( void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;
	audio_buf_t aud_buf;
	struct frame *f;
	struct meter meter;
	int i;
	unsigned short *s;
	int audio_frame_len = conf->audiorate * conf->audiochannels * 2 * .11;
	void *last_frame;
	
	meter_init( &meter, conf->audiochannels * conf->audiorate, 0 );

	for(;;)
	{
#ifdef NO_MM
		f = new_frame( 0 );
#else
		f = new_frame( audio_frame_len );
#endif
		if( ! f )
		{
			spook_log( SL_WARN, "audio: no frames available" );
			usleep( 100000 );
			continue;
		}

		aud_buf.addr = f->d;
		aud_buf.len = f->size;

#ifdef NO_MM
		if (ioctl(conf->fd, AUDIO_GET_FRAME, &aud_buf) != 0)
#else
		if (ioctl(conf->fd, AUDIO_GET_FRAME_COPY, &aud_buf) != 0)
#endif
		{
			printf("get frame failure\n");
			exit( 1 );
		}

#ifdef NO_MM
		if( aud_buf.len == 0 || last_frame == aud_buf.addr )
#else
		if( aud_buf.len == 0 )
#endif
		{
			unref_frame( f );
			continue;
		}

		last_frame = f->d = aud_buf.addr;
		f->length = aud_buf.len;

		ioctl( _devfd, GET_AND_RESET_AUDIO_CORRECTION_COUNT, &i );
		meter_corrected( &meter, i << 1 );
		if( meter_count( &meter, f->length >> 1, &i ) )
			ioctl( _devfd, SET_AUDIO_CORRECTION_RATE, &i );

		if( ! conf->audio_running )
		{
			unref_frame( f );
			continue;
		}

		f->format = FORMAT_PCM;
		f->width = 0;
		f->height = 0;
		f->key = 1;
		f->step = conf->audiochannels << 1;
		if( soft_queue_add( conf->aq, f ) < 0 ) unref_frame( f );
	}
	return NULL;
}

static void get_back_video_frame( struct event_info *ei, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;
	struct frame *f = (struct frame *)ei->data;

	deliver_frame_to_stream( f, conf->vout );
}

static void get_back_audio_frame( struct event_info *ei, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;
	struct frame *f = (struct frame *)ei->data;

	deliver_frame_to_stream( f, conf->aout );
}

static int v4l_setup( struct v4l_input *conf )
{
	if( ( conf->fd = v4l_open( conf->device ) ) < 0 )
	{
		fprintf( stderr, "input v4l: unable to open %s: %s\n",
				conf->device, strerror( errno ) );
		return -1;
	}

	return 0;
}

static void video_get_framerate( struct stream *s, int *fincr, int *fbase )
{
	struct v4l_input *conf = (struct v4l_input *)s->src_private;

	*fincr = conf->fincr;
	*fbase = conf->fbase;
}

static void video_set_running( struct stream *s, int running )
{
	struct v4l_input *conf = (struct v4l_input *)s->src_private;

	printf("video_set_running: was %s, now %s\n",
	       conf->video_running ? "on" : "off",
	       running ? "on" : "off");
	
	conf->video_running = running;

}

static void audio_get_framerate( struct stream *s, int *fincr, int *fbase )
{
	struct v4l_input *conf = (struct v4l_input *)s->src_private;

	*fincr = conf->audiochannels;
	*fbase = conf->audiorate * conf->audiochannels;
}

static void audio_set_running( struct stream *s, int running )
{
	struct v4l_input *conf = (struct v4l_input *)s->src_private;

	printf("audio_set_running: was %s, now %s\n",
	       conf->audio_running ? "on" : "off",
	       running ? "on" : "off");
	
	conf->audio_running = running;

}

/************************ CONFIGURATION DIRECTIVES ************************/

static void *start_block(void)
{
	struct v4l_input *conf;

	conf = (struct v4l_input *)malloc( sizeof( struct v4l_input ) );
	conf->vout = NULL;
	conf->aout = NULL;
	conf->device[0] = 0;
	conf->width = 0;
	conf->height = 0;
	conf->format = FORMAT_MPEG4;
	conf->norm = -1;
	conf->fps = 0;
	conf->audiorate = 0;
	conf->audiochannels = 0;
	conf->fd = -1;
	conf->video_running = 0;
	conf->audio_running = 0;

	return conf;
}

static int end_block( void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;
	int i;

	if( ! conf->vout )
	{
		printf( "input v4l: missing video stream name\n" );
		return -1;
	}
	if( ! conf->device[0] )
	{
		printf( "input v4l: missing V4L device name\n" );
		return -1;
	}
	if( conf->fps == 0 )
	{
		printf( "input v4l: missing framerate\n" );
		return -1;
	}
	if( conf->norm < 0 )
	{
		printf( "input v4l: missing input type\n" );
		return -1;
	}
	if( conf->aout )
	{
		if( conf->audiorate == 0 )
		{
			printf( "input v4l: missing audiorate\n" );
			return -1;
		}
		if( conf->audiochannels == 0 )
		{
			printf( "input v4l: missing audiochannels\n" );
			return -1;
		}
	}

	switch( conf->norm )
	{
	case NORM_PAL:
	case NORM_SECAM:
		conf->fbase = 25;
		conf->fincr = 25 / conf->fps;
		break;
	case NORM_NTSC:
		conf->fbase = 30000;
		conf->fincr = 1001 * 30 / conf->fps;
		break;
	case NORM_CAMERA:
		conf->fbase = 30;
		conf->fincr = 30 / conf->fps;
		break;
	}

	if( v4l_setup( conf ) < 0 )
	{
		printf( "input v4l: unable to initialize capture device\n" );
		return -1;
	}
	
	conf->vq = new_soft_queue( 30 );
	add_softqueue_event( conf->vq, 0, get_back_video_frame, conf );
	conf->aq = new_soft_queue( 10 );
	add_softqueue_event( conf->aq, 0, get_back_audio_frame, conf );

	pthread_create( &conf->video_thread, NULL, video_loop, conf );

	return 0;
}

static int set_device( int num_tokens, struct token *tokens, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;

	strcpy( conf->device, tokens[1].v.str );
	return 0;
}

static int set_vout( int num_tokens, struct token *tokens, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;

	conf->vout = new_stream( tokens[1].v.str, conf->format, conf );
	if( ! conf->vout )
	{
		printf( "input v4l: unable to create stream \"%s\"\n",
				tokens[1].v.str );
		return -1;
	}
	conf->vout->get_framerate = video_get_framerate;
	conf->vout->set_running = video_set_running;
	return 0;
}

static int set_aout( int num_tokens, struct token *tokens, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;

	conf->aout = new_stream( tokens[1].v.str, FORMAT_PCM, conf );
	if( ! conf->aout )
	{
		printf( "input v4l: unable to create stream \"%s\"\n",
				tokens[1].v.str );
		return -1;
	}
	conf->aout->get_framerate = audio_get_framerate;
	conf->aout->set_running = audio_set_running;
	return 0;
}

static int set_framesize( int num_tokens, struct token *tokens, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;

	conf->width = tokens[1].v.num;
	conf->height = tokens[2].v.num;

	return 0;
}

static int set_inputtype( int num_tokens, struct token *tokens, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;

	if( ! strcasecmp( tokens[1].v.str, "ntsc" ) )
		conf->norm = NORM_NTSC;
	else if( ! strcasecmp( tokens[1].v.str, "pal" ) )
		conf->norm = NORM_PAL;
	else if( ! strcasecmp( tokens[1].v.str, "camera" ) )
		conf->norm = NORM_CAMERA;
	else
	{
		printf( "input v4l: video mode \"%s\" is unsupported; try NTSC, PAL or CAMERA\n", tokens[1].v.str );
		return -1;
	}

	return 0;
}

static int set_audiorate( int num_tokens, struct token *tokens, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;

	if( conf->audiorate > 0 )
	{
		printf( "input v4l: audio rate has already been set!\n" );
		return -1;
	}
	conf->audiorate = tokens[1].v.num;

	return 0;
}

static int set_audiochannels( int num_tokens, struct token *tokens, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;

	if( conf->audiochannels > 0 )
	{
		printf( "input v4l: audio channels have already been set!\n" );
		return -1;
	}
	conf->audiochannels = tokens[1].v.num;

	return 0;
}

static int set_framerate_num( int num_tokens, struct token *tokens, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;

	if( conf->fps > 0 )
	{
		printf( "input v4l: frame rate has already been set!\n" );
		return -1;
	}
	conf->fps = tokens[1].v.num;

	return 0;
}

static int set_videoformat( int num_tokens, struct token *tokens, void *d )
{
	struct v4l_input *conf = (struct v4l_input *)d;

	if( ! strcasecmp( tokens[1].v.str, "mpeg1" ) )
		conf->format = FORMAT_MPV;
	else if( ! strcasecmp( tokens[1].v.str, "mpeg2" ) )
		conf->format = FORMAT_MPV;
	else if( ! strcasecmp( tokens[1].v.str, "mpeg4" ) )
		conf->format = FORMAT_MPEG4;
	else if( ! strcasecmp( tokens[1].v.str, "mjpeg" ) )
		conf->format = FORMAT_JPEG;
	else if( ! strcasecmp( tokens[1].v.str, "h263" ) )
		conf->format = FORMAT_H263;
	else
	{
		spook_log( SL_ERR, "input-wis: format \"%s\" is unsupported!",
				tokens[1].v.str );
		return -1;
	}

	return 0;
}

static struct statement config_statements[] = {
	/* directive name, process function, min args, max args, arg types */
	{ "device", set_device, 1, 1, { TOKEN_STR } },
	{ "videooutput", set_vout, 1, 1, { TOKEN_STR } },
	{ "audiooutput", set_aout, 1, 1, { TOKEN_STR } },
	{ "framesize", set_framesize, 2, 2, { TOKEN_NUM, TOKEN_NUM } },
	{ "inputtype", set_inputtype, 1, 1, { TOKEN_STR } },
	{ "framerate", set_framerate_num, 1, 1, { TOKEN_NUM } },
	{ "audiorate", set_audiorate, 1, 1, { TOKEN_NUM } },
	{ "audiochannels", set_audiochannels, 1, 1, { TOKEN_NUM } },
	{ "videoformat", set_videoformat, 1, 1, { TOKEN_STR } },

	/* empty terminator -- do not remove */
	{ NULL, NULL, 0, 0, {} }
};

void wis_init(int argc, char *argv[])
{
    int i;
#ifdef NO_MM
    if (argc > 0) {
	/* args: resolution, enabled, md1_ena, md1_ulc, md1_ulr ... */
	md_enabled = atoi(argv[1]);
	printf("MD: %s\n", md_enabled ? "enabled" : "disabled");
	cmd_argc = argc;
	for ( i = 0; i < cmd_argc; i++) {
	    cmd_args[i] = argv[i];
	    //	    printf("%s\n", cmd_args[i]);
	}
    } 
#endif

    
    register_config_context( "input", "wis", start_block, end_block,
			     config_statements );
}
