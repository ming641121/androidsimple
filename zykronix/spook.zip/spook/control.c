/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/un.h>

#include <event.h>
#include <log.h>
#include <control.h>
#include <frame.h>
#include <stream.h>
#include <rtp.h>
#include <conf_parse.h>

struct {
	command_func input;
	command_func disconnect;
	void *d;
} commands[256];

struct ctl_sock {
	int fd;
	struct event *read_event;
	int disconnect_vector[8];
};

struct listener {
	int fd;
};

static void drop_sock( struct ctl_sock *cs )
{
	int i;

	spook_log( SL_DEBUG, "closed control connection" );
	for( i = 0; i < 256; ++i )
		if( commands[i].disconnect &&
				( cs->disconnect_vector[i >> 5] &
					( 1 << ( i & 0x1F ) ) ) )
			commands[i].disconnect( cs->fd, commands[i].d );
			
	remove_event( cs->read_event );
	close( cs->fd );
	free( cs );
}

static int command_active_sessions( int fd, void *d )
{
	unsigned char output[2048];

	if( write( fd, output,
			print_session_list( output, sizeof( output ) ) ) < 0 )
		return -1;
	return write( fd, ".\n", 2 ) < 0 ? -1 : 0;
}

static int command_view_log( int fd, void *d )
{
	send_log_buffer( fd );
	return write( fd, ".\n", 2 ) < 0 ? -1 : 0;
}

static void do_read( struct event_info *ei, void *d )
{
	struct ctl_sock *cs = (struct ctl_sock *)d;
	unsigned char c;
	int ret;

	if( read( cs->fd, &c, 1 ) < 1 )
	{
		drop_sock( cs );
		return;
	}
	if( ! commands[c].input )
	{
		drop_sock( cs );
		return;
	}
	cs->disconnect_vector[c >> 5] &= ~( 1 << ( c & 0x1F ) );
	ret = commands[c].input( cs->fd, commands[c].d );
	if( ret < 0 )
	{
		drop_sock( cs );
		return;
	}
	if( ret > 0 ) cs->disconnect_vector[c >> 5] |= 1 << ( c & 0x1F );
}

static void do_accept( struct event_info *ei, void *d )
{
	struct listener *listener = (struct listener *)d;
	int fd, addrlen, i;
	struct sockaddr_un addr;
	struct ctl_sock *cs;

	addrlen = sizeof( addr );
	if( ( fd = accept( listener->fd, (struct sockaddr *)&addr, &addrlen ) ) < 0 )
	{
		spook_log( SL_WARN, "error accepting control connection: %s",
				strerror( errno ) );
		return;
	}
	spook_log( SL_DEBUG, "accepted control connection" );

	cs = (struct ctl_sock *)malloc( sizeof( struct ctl_sock ) );
	if( ! cs )
	{
		spook_log( SL_ERR, "out of memory on malloc ctl_sock" );
		close( fd );
		return;
	}
	cs->fd = fd;
	cs->read_event = add_fd_event( fd, 0, 0, do_read, cs );
	for( i = 0; i < 8; ++i ) cs->disconnect_vector[i] = 0;
}

int register_command( int cmdnum, command_func input,
			command_func disconnect, void *d )
{
	if( cmdnum < 0 || cmdnum > 255 )
	{
		spook_log( SL_ERR,
			"error: call number %d is invalid!",
			cmdnum );
		return -1;
	}
	if( commands[cmdnum].input )
	{
		spook_log( SL_ERR,
			"error: call number %d is already registered!",
			cmdnum );
		return -1;
	}
	commands[cmdnum].input = input;
	commands[cmdnum].disconnect = disconnect;
	commands[cmdnum].d = d;
	return 0;
}

int control_init(void)
{
	struct sockaddr_un addr;
	struct listener *listener;
	int fd, i;

	for( i = 0; i < 256; ++i )
	{
		commands[i].input = NULL;
		commands[i].disconnect = NULL;
		commands[i].d = NULL;
	}
	commands['a'].input = command_active_sessions;
	commands['l'].input = command_view_log;

	addr.sun_family = AF_UNIX;
	strcpy( addr.sun_path, "/tmp/spook.sock" );

	unlink( addr.sun_path );
	if( ( fd = socket( PF_UNIX, SOCK_STREAM, 0 ) ) < 0 )
	{
		spook_log( SL_ERR, "error creating control socket: %s",
				strerror( errno ) );
		return -1;
	}
	if( bind( fd, (struct sockaddr *)&addr, sizeof( addr ) ) < 0 )
	{
		spook_log( SL_ERR, "unable to bind control socket: %s",
				strerror( errno ) );
		close( fd );
		return -1;
	}
	if( listen( fd, 5 ) < 0 )
	{
		spook_log( SL_ERR,
			"error attempting to listen on control socket: %s",
			strerror( errno ) );
		close( fd );
		return -1;
	}

	listener = (struct listener *)malloc( sizeof( struct listener ) );
	listener->fd = fd;

	add_fd_event( fd, 0, 0, do_accept, listener );

	spook_log( SL_INFO, "listening on control socket %s", addr.sun_path );

	return 0;
}
