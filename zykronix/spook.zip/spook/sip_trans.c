/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <pmsg.h>
#include <rtp.h>
#include <sip.h>
#include <conf_parse.h>

/* md5.h must be enclosed in quotes to avoid including OS-bundled headers */
#include "md5.h"

static struct transaction *x_list = NULL;

static void transaction_retry( struct event_info *ei, void *d );
static void transaction_timeout( struct event_info *ei, void *d );

static void free_transaction( struct transaction *x )
{
	if( x->next ) x->next->prev = x->prev;
	if( x->prev ) x->prev->next = x->next;
	else x_list = x->next;
	if( x->req ) free_pmsg( x->req );
	if( x->resp ) free_pmsg( x->resp );
	if( x->dialog ) unref_dialog( x->dialog );
	if( x->retry_timer ) remove_event( x->retry_timer );
	if( x->timeout_timer ) remove_event( x->timeout_timer );
	if( x->body ) free( x->body );
	free( x );
}

static void set_retry( struct transaction *x, int msec )
{
	time_ref tr;

	if( msec == 0 )
	{
		if( x->retry_timer ) remove_event( x->retry_timer );
		x->retry_timer = NULL;
	} else
	{
		time_future( &tr, msec );
		if( x->retry_timer ) resched_event( x->retry_timer, &tr );
		else x->retry_timer = add_alarm_event( &tr, EVENT_F_ONESHOT,
				transaction_retry, x );
	}
}

static void set_timeout( struct transaction *x, int msec )
{
	time_ref tr;

	if( msec == 0 )
	{
		if( x->retry_timer ) remove_event( x->retry_timer );
		x->retry_timer = NULL;
		if( x->timeout_timer ) remove_event( x->timeout_timer );
		x->timeout_timer = NULL;
	} else
	{
		time_future( &tr, msec );
		if( x->timeout_timer ) resched_event( x->timeout_timer, &tr );
		else x->timeout_timer = add_alarm_event( &tr, 0,
						transaction_timeout, x );
	}
}

static struct transaction *new_transaction( struct pmsg *req,
		enum transaction_type type, enum transaction_state state )
{
	struct transaction *x;
	char branch[64];

	if( ! ( x = malloc( sizeof( struct transaction ) ) ) )
	{
		spook_log( SL_ERR, "out of memory on malloc transaction" );
		return NULL;
	}
	x->next = x_list;
	x_list = x;
	x->prev = NULL;
	if( x->next ) x->next->prev = x;
	x->app_data = NULL;
	x->type = type;
	x->state = state;
	x->callback = NULL;
	x->req = req;
	x->resp = NULL;
	if( get_param( get_header( req, "via" ), "branch",
				branch, sizeof( branch ) ) > 0
			&& ! strncmp( branch, "z9hG4bK", 7 ) )
		strncpy( x->branch, branch, sizeof( x->branch ) );
	else x->branch[0] = 0;
	x->dialog = NULL;
	x->retry_timer = NULL;
	x->timeout_timer = NULL;
	x->rexmit_count = 0;
	x->body = NULL;
	x->bodylen = 0;

	return x;
}

static void transaction_retry( struct event_info *ei, void *d )
{
	struct transaction *x = d;
	int t;

	switch( x->type )
	{
	case XT_CLIENT_I:
		switch( x->state )
		{
		case XS_TRYING:
			sip_send( x->req, x->body, x->bodylen );
			set_retry( x, TIME_T1 << ++x->rexmit_count );
			break;
		default:
			break;
		}
		break;
	case XT_CLIENT_N:
		switch( x->state )
		{
		case XS_TRYING:
			sip_send( x->req, x->body, x->bodylen );
			t = TIME_T1 << ++x->rexmit_count;
			if( t > TIME_T2 ) t = TIME_T2;
			set_retry( x, t );
			break;
		case XS_PROCEED:
			sip_send( x->req, x->body, x->bodylen );
			set_retry( x, TIME_T2 );
			break;
		default:
			break;
		}
		break;
	case XT_SERV_I:
		switch( x->state )
		{
		case XS_COMPLETE:
			++x->rexmit_count;
			sip_send( x->resp, x->body, x->bodylen );
			t = TIME_T1 << x->rexmit_count;
			if( t > TIME_T2 ) t = TIME_T2;
			set_retry( x, t );
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
}

static void transaction_timeout( struct event_info *ei, void *d )
{
	struct transaction *x = d;

	x->timeout_timer = NULL;
	switch( x->type )
	{
	case XT_CLIENT_I:
		switch( x->state )
		{
		case XS_TRYING:
		case XS_COMPLETE:
		default:
			free_transaction( x );
			break;
		}
		break;
	case XT_CLIENT_N:
		switch( x->state )
		{
		case XS_TRYING:
		case XS_PROCEED:
			if( x->resp )
			{
				free_pmsg( x->resp );
				x->resp = NULL;
			}
			if( x->callback ) x->callback( x );
			/* fall-through */
		default:
			free_transaction( x );
			break;
		}
		break;
	case XT_SERV_I:
		switch( x->state )
		{
		case XS_COMPLETE:
			//printf( "transaction timed out\n" );
		default:
			free_transaction( x );
			break;
		}
		break;
	case XT_SERV_N:
		free_transaction( x );
		break;
	default:
		break;
	}
}

int transaction_reply( struct transaction *x )
{
	sip_send( x->resp, x->body, x->bodylen );

	if( x->type == XT_SERV_I )
	{
		if( x->resp->sl.stat.code >= 300 )
		{
			x->state = XS_COMPLETE;
			set_retry( x, TIME_T1 );
			set_timeout( x, 64 * TIME_T1 );
		} else if( x->resp->sl.stat.code < 200 )
			x->state = XS_PROCEED;
		else /* code == 2XX */
		{
			/* RFC 3261 section 13.3.1.4 says a 2XX response
			 * to an INVITE terminates the transaction and that
			 * the UAS core should retransmit the 2XX until
			 * receiving the ACK.  We currently implement half.
			 */
			free_transaction( x );
		}
	} else
	{
		if( x->resp->sl.stat.code >= 200 )
		{
			x->state = XS_COMPLETE;
			set_timeout( x, 64 * TIME_T1 );
		} else x->state = XS_PROCEED;
	}
	return 0;
}

int simple_reply( struct transaction *x, int code, char *reason )
{
	x->resp = create_sip_reply( x->req, x->dialog, code, reason );
	return transaction_reply( x );
}

struct transaction *transaction_start( struct pmsg *req,
					unsigned char *body, int bodylen,
					transaction_callback cb )
{
	struct transaction *x;

	x = new_transaction( req, ! strcasecmp( req->sl.req.method, "INVITE" )
			? XT_CLIENT_I : XT_CLIENT_N, XS_TRYING );
	x->callback = cb;
	if( bodylen > 0 )
	{
		x->body = (unsigned char *)malloc( bodylen );
		memcpy( x->body, body, bodylen );
	}
	x->bodylen = bodylen;
	sip_send( x->req, x->body, x->bodylen );

	if( x->type == XT_CLIENT_I )
	{
	} else
	{
		set_retry( x, TIME_T1 );
		set_timeout( x, 64 * TIME_T1 );
	}

	return x;
}

static struct transaction *find_server_transaction( struct pmsg *msg )
{
	struct transaction *x;
	char *via, *callid, branch[64];
	int via_len;

	if( ! ( via = get_header( msg, "via" ) ) ) return NULL;

	if( get_param( via, "branch", branch, sizeof( branch ) ) <= 0
			|| strncmp( branch, "z9hG4bK", 7 ) )
	{
		callid = get_header( msg, "call-id" );
		branch[0] = 0;
	}
	for( via_len = 0; via[via_len] && via[via_len] != ';'; ++via_len );

	for( x = x_list; x; x = x->next )
	{
		if( x->type != XT_SERV_I && x->type != XT_SERV_N ) continue;
		if( strcasecmp( x->req->sl.req.method, msg->sl.req.method ) )
			if( strcasecmp( x->req->sl.req.method, "INVITE" ) ||
				     strcasecmp( msg->sl.req.method, "ACK" ) )
				continue;
		if( branch[0] == 0 )
		{
			char *x_callid;

			if( x->branch[0] ) continue;
			if( strcmp( x->req->sl.req.uri, msg->sl.req.uri ) )
				continue;
			x_callid = get_header( x->req, "call-id" );
			if( ! callid != ! x_callid ||
					( callid && x_callid &&
						strcmp( callid, x_callid ) ) )
				continue;
			if( get_cseq( x->req, NULL ) != get_cseq( msg, NULL ) )
				continue;
			if( strcasecmp( get_header( x->req, "via" ), via ) )
				continue;
			return x;
		} else
		{
			if( ! x->branch[0] ) continue;
			/* Branches match? */
			if( strcmp( x->branch, branch ) ) continue;
			/* Host and port in Via headers match? */
			if( strncasecmp( get_header( x->req, "via" ),
						via, via_len ) )
				continue;
			return x;
		}
	}
	return NULL;
}

int process_msg_request( struct pmsg *msg, unsigned char *body, int bodylen )
{
	struct transaction *x;

	// XXX verify that URI doesn't contain any illegal characters

	x = find_server_transaction( msg );

	if( ! strcasecmp( msg->sl.req.method, "ACK" ) )
	{
		if( x )
		{
			if( x->state == XS_COMPLETE )
			{
				x->state = XS_CONFIRM;
				set_retry( x, 0 );
				set_timeout( x, TIME_T4 );
			}
		} else handle_ack( msg, body, bodylen );
	} else
	{
		if( ! x )
		{
			x = new_transaction( msg,
				! strcasecmp( msg->sl.req.method, "INVITE" )
					? XT_SERV_I : XT_SERV_N,
				XS_TRYING );
			handle_server_transaction( x, body, bodylen );
			return 1;
		}
		//printf( "received duplicate %s\n", msg->sl.req.method );
		if( x->state == XS_PROCEED )
			sip_send( x->resp, x->body, x->bodylen );
#if 0
	} else
	{
		struct pmsg *rep;

		rep = create_sip_reply( msg, 405, "Method not allowed" );
		add_header( rep, "Allow", "INVITE ACK BYE" );
		send_pmsg( rep, NULL, 0 );
#endif
	}
	return 0;
}

void md5_hash( char **v, int count, char *hash )
{
	struct MD5Context md5;
	int i;
	unsigned char bin[16];

	MD5Init( &md5 );
	for( i = 0; i < count; ++i )
	{
		if( i > 0 ) MD5Update( &md5, ":", 1 );
		MD5Update( &md5, v[i], strlen( v[i] ) );
	}
	MD5Final( bin, &md5 );
	for( i = 0; i < 16; ++i ) sprintf( hash + (i<<1), "%02x", bin[i] );
	hash[32] = 0;
}

static int retry_with_auth( struct transaction *x, struct pmsg *reply )
{
	char *auth, *user, *pass, *nonce, *realm, *c;
	char *elem[3];
	char ha1[33], ha2[33], response[33], tmp[512];
	int i;
	struct transaction *nx;

	if( get_header( x->req, "authorization" ) ) return 0;

	if( ! ( auth = get_header( reply, "www-authenticate" ) ) ) return 0;

	if( ! ( c = strstr( auth, "nonce=\"" ) ) ) return 0;
	nonce = c + 7;
	for( i = 0; nonce[i] != '"' && nonce[i]; ++i );
	if( nonce[i] != '"' ) return 0;
	nonce[i] = 0;

	if( ! ( c = strstr( auth, "realm=\"" ) ) ) return 0;
	realm = c + 7;
	for( i = 0; realm[i] != '"' && realm[i]; ++i );
	if( realm[i] != '"' ) return 0;
	realm[i] = 0;

	if( ! get_sip_credentials( realm, &user, &pass ) ) return 0;

	if( x->dialog ) i = x->dialog->local_cseq++;
	else i = get_cseq( x->req, NULL ) + 1;
	sprintf( tmp, "%d %s", i, x->req->sl.req.method );
	replace_header( x->req, "cseq", tmp );

	elem[0] = user;
	elem[1] = realm;
	elem[2] = pass;
	md5_hash( elem, 3, ha1 );
	elem[0] = x->req->sl.req.method;
	elem[1] = x->req->sl.req.uri;
	md5_hash( elem, 2, ha2 );
	elem[0] = ha1;
	elem[1] = nonce;
	elem[2] = ha2;
	md5_hash( elem, 3, response );
	sprintf( tmp, "Digest username=\"%s\",realm=\"%s\",uri=\"%s\",response=\"%s\",nonce=\"%s\",algorithm=md5", user, realm, x->req->sl.req.uri, response, nonce );
	add_header( x->req, "Authorization", tmp );

	nx = transaction_start( x->req, x->body, x->bodylen, x->callback );
	x->req = NULL;
	/* no need to ref/unref here */
	nx->dialog = x->dialog;
	x->dialog = NULL;

	return 1;
}

int process_msg_response( struct pmsg *msg, unsigned char *d, int len )
{
	struct transaction *x;

	/* XXX THIS IS WRONG */
	for( x = x_list; x; x = x->next )
		if( x->type == XT_CLIENT_N ) break;
	if( ! x ) return 0;
	if( x->resp ) free_pmsg( x->resp );
	x->resp = msg;
	if( msg->sl.stat.code < 200 )
	{
		x->state = XS_PROCEED;
		/* Reseting the timer is not in the RFC, but it makes sense */
		set_retry( x, TIME_T2 );
		if( x->callback ) x->callback( x );
	} else
	{
		if( msg->sl.stat.code != 401 || ! retry_with_auth( x, msg ) )
			if( x->callback ) x->callback( x );
		x->state = XS_COMPLETE;
		set_retry( x, 0 );
		set_timeout( x, TIME_T4 );
	}
	return 1;
}
