/***WIS***********************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
******************************************************************************
*
*   FILE: 
* 	MotionDetector.c
*
*   DESCRIPTION:
* 	WIS GO7007SB MotionDetection API interface.	
*
*  AUTHOR:
*	Yong Wang, Dan Meyer,James Dougherty
*
* $Id: MotionDetector.c
*
*****************************************************************************/
	

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#include "motion_detection_api.h"

#define MV_UPPER     		4650
#define MV_LOWER    		3750
#define SAD_UPPER    		150
#define SAD_LOWER   		20
#define SENSITIVITY_RANGE       100

/*
    int motion_detection_set = 0;
  */                                                                              
    unsigned short thresholds[MAX_REGIONS_OF_INTEREST][NUM_MOTION_TYPES],
        SavedThresholds[MAX_REGIONS_OF_INTEREST][NUM_MOTION_TYPES];
    unsigned char macroblock_coords[MAX_NUM_MACROBLOCKS];
    unsigned short sensitivity[MAX_REGIONS_OF_INTEREST],
        SavedSensitivity[MAX_REGIONS_OF_INTEREST];
    unsigned int Pic_MB_Width;
    unsigned int Pic_MB_Height; 
    int md_state=0;



int
MDSetEnable(int bEnable,int dev)
{
    int i,j;

    if(bEnable==0)
    {

	for(i=0;i<MAX_REGIONS_OF_INTEREST;i++) {
	    for (j=0;j<NUM_MOTION_TYPES;j++)
		thresholds[i][j]=0x7fff;  
	    sensitivity[i]=0x7fff;    
	}

	if(md_set_thresholds_and_sensitivities(dev,thresholds,sensitivity)!=0)
	    return(-1);         

    }
    else if (bEnable==1)
    {
	
	if(md_set_regions(dev,macroblock_coords,Pic_MB_Width,Pic_MB_Height) != 0)
	    return(-1);
      
	if(md_set_thresholds_and_sensitivities(dev,thresholds,sensitivity)!=0)
            return(-1);

    }
    return(0);
}

		
int
MDSetOff(int dev) 
{
	int i,j;

	for(i=0;i<MAX_REGIONS_OF_INTEREST;i++)
	{
	    /* set MV and SAD thresholds to MAX value */
	    /* set sensitivity value to MAX value */
	    for (j=0;j<NUM_MOTION_TYPES;j++)
		SavedThresholds[i][j]=thresholds[i][j]=0x7fff;  
	    SavedSensitivity[i]=sensitivity[i]=0x7fff;    
	}
	if ( md_set_thresholds_and_sensitivities(dev,thresholds,sensitivity)!= 0)
	    return (-1);

	for(i=0;i<MAX_NUM_MACROBLOCKS;i++)
	    macroblock_coords[i]=0;

	return(0);
}



int
SetPicSize(char *ptr)
{
    if(!strncasecmp(ptr,"QCIF",4)){
    	Pic_MB_Width = 176 / 16;         
    	Pic_MB_Height = 144 / 16;
	}
    else if(!strncasecmp(ptr,"QVGA",4)){
        Pic_MB_Width = 320 / 16;
        Pic_MB_Height = 240 / 16;
        }
    else  if(!strncasecmp(ptr,"CIF",3)){
        Pic_MB_Width = 352/ 16;
        Pic_MB_Height = 288/ 16;
        }
    else  if(!strncasecmp(ptr,"VGA",3)){
        Pic_MB_Width = 640 / 16;
        Pic_MB_Height = 480 / 16;
        }
   else  if(!strncasecmp(ptr,"D1",2)){
        Pic_MB_Width = 720 / 16;
        Pic_MB_Height = 576 / 16;
        }
   else{
	printf("Invalid resolution value\n");
        return (-1);
	}
   return (0);
}

/***WIS_API*******************************************************************
*   Procedure Name:
*       void MDInit(char *res)
*
*   Description:
*       This procedure initializes the parameters for motion dection, including  the width and 
*       height of macro block, MV and SAD thresholds and sensitivity
*
*   Arguments:
*       char *res - [in] a string pointer for resolution type and this function uses it to set the 
*                        macro block's width and height. The valid resolution types are: QCIF, 
*                        QVGA, CIF, VGA and D1
*
*   Returns:
*       None
*
*   Notes:
*       This function shall be called before any other MD operation functions.
*
*****************************************************************************/

void MDInit(char *res)
{
	int i,j;
	SetPicSize(res);
	for(i=0;i<MAX_REGIONS_OF_INTEREST;i++)
        {
            /* set MV and SAD thresholds to MAX value */
            /* set sensitivity value to MAX value */
            for (j=0;j<NUM_MOTION_TYPES;j++)
                SavedThresholds[i][j]=thresholds[i][j]=0x7fff;
            SavedSensitivity[i]=sensitivity[i]=0x7fff;
        }
        for(i=0;i<MAX_NUM_MACROBLOCKS;i++)
            macroblock_coords[i]=0;
}

/***WIS_API*******************************************************************
*   Procedure Name:
*       int MDSetRegion(int dev, int p_ulrow, int p_ulcol, int p_brrow, int p_brcol, 
*                               int sensitivity, int mv_thr, int sad_thr)
*
*   Description:
*       This procedure sets the motion detection region and its thresholds value.
*
*   Arguments:
*       int dev - [in] device ID with the opened device "/dev/video0"
*
*       int p_ulrow - [in] the top left coordinate for row
*
*       int p_ulcol - [in] the top left coordinate for column
*
*       int p_brrow - [in] the bottom right coordinate for row.  The range of p_ulrow and p_brrow
*                          is from 0 to 16*Pic_MB_Width. The Macro Pic_MB_Width depends on the 
*                          resolution type: QCIF: 176, QVGA: 320, CIF: 352, VGA: 640, D1: 720
*
*       int p_brcol - [in] the bottom right coordinate for column  The range of p_ulcol and p_brcol 
*                         is from 0 to 16*Pic_MB_Height.  The Macro Pic_MB_Height depends on the 
*                         resolution type: 
*                      + QCIF: 144 
*                      + QVGA: 240  
*                      + CIF: 288 
*                      + VGA: 480  
*                      + D1: 480
*
*       int sens - [in] motion detection sensitivity for this region
*
*       int mv_thr - [in] MV threshold for this region
*
*       int sad_thr - [in] SAD treshold for this region
*
*   Returns:
*       int - status of setting motion detection region. 0 on Success and -1 on failure
*
*   Notes:
*       The origin of the coordinate is at the top left corner; the row arrow is from left to right 
*       and the column arrow is from top to down.
*
*****************************************************************************/

int
MDSetRegion(int dev,
	    int p_ulrow,
	    int p_ulcol,
	    int p_brrow,
            int p_brcol,
            int sens,
            int mv_thr,
            int sad_thr,
            int roi) 
{
        int row,col,ulRow, ulCol, brRow, brCol;
        ulRow=p_ulrow/16;
	ulCol=p_ulcol/16;
	brRow=p_brrow/16+((p_brrow%16>0)?1:0);
	brCol=p_brcol/16+((p_brcol%16>0)?1:0);

	/* since we have one region reserved for un-judged region*/
    
	if( (ulRow<0) || (ulRow>Pic_MB_Height) ||
	    (brRow<0) || (brRow>Pic_MB_Height) )
	    return (-1);
    
    
	if( ( ulCol<0) || (ulCol>Pic_MB_Width) ||
	    ( brCol<0) || (brCol>Pic_MB_Width) )
	    return (-1);  
    
    
	for(row=ulRow;row<brRow;row++) 
	    for(col=ulCol;col<brCol;col++) 
	        	macroblock_coords[col+row*Pic_MB_Width]=roi;


	SavedThresholds[roi][MOTION_VECTOR_THRESHOLD]=mv_thr;

	SavedThresholds[roi][SAD_THRESHOLD]=sad_thr;

	SavedSensitivity[roi]=(100-sens)*(brRow-ulRow)*(brCol-ulCol)/100;

	if(md_set_thresholds_and_sensitivities(dev,SavedThresholds,SavedSensitivity)!=0)
	{
	    printf("Set Thresholds and Sensitivities failed\n");
	    return (-1);      
	}

#if 0
	for(col=0;col<MAX_NUM_MACROBLOCKS;col++)
	{
		printf("%d ",macroblock_coords[col]);
		if(col==Pic_MB_Width-1)
			printf("\n");
	}
#endif

	if(md_set_regions(dev,macroblock_coords,Pic_MB_Width,Pic_MB_Height)!=0)
	{
	    printf("Set Regions failed\n");
	    return (-1);    
	}

	return 0;
}

