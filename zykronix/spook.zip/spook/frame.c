/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>

#include <event.h>
#include <log.h>
#include <frame.h>

struct frame_heap {
	int size;
	struct frame_slot *take;
	struct frame_slot *put;
	pthread_mutex_t mutex;
};

#define	MAX_HEAPS	4
static struct frame_heap heaps[MAX_HEAPS];
static int heap_count = 0;
static int max_frame_size = 0;

void init_frame_heap( int size, int count )
{
	struct frame_slot *f = NULL, *prev = NULL;
	int i;

	if( heap_count == MAX_HEAPS )
	{
		spook_log( SL_DEBUG, "too many heaps specified" );
		exit( 1 );
	}
	i = heap_count;

	if( max_frame_size < size ) max_frame_size = size;

	pthread_mutex_init( &heaps[i].mutex, NULL );
	heaps[i].size = size;

	while( count-- > 0 )
	{
		f = (struct frame_slot *)
				malloc( sizeof( struct frame_slot ) );
		f->f = (struct frame *)malloc( sizeof( struct frame ) + size );
		if( ! f->f )
		{
			spook_log( SL_ERR, "out of memory for frames!" );
			exit( 1 );
		}
		f->f->size = size;
		pthread_mutex_init( &f->f->mutex, NULL );
		f->prev = prev;
		if( prev ) prev->next = f;
		else heaps[i].take = f;
		prev = f;
	}
	heaps[i].take->prev = f;
	f->next = heaps[i].take;
	heaps[i].put = heaps[i].take;
	++heap_count;
}

int get_max_frame_size(void)
{
	return max_frame_size;
}

struct frame *new_frame( int size )
{
	struct frame *f;
	int i;

	for( i = 0; i < heap_count; ++i )
		if( heaps[i].size >= size ) break;
	if( i == heap_count )
	{
		spook_log( SL_WARN,
			"frame size %d too large for configured heap!", size );
		return NULL;
	}

	pthread_mutex_lock( &heaps[i].mutex );

	if( heaps[i].take->f )
	{
		f = heaps[i].take->f;
		heaps[i].take->f = NULL;
		heaps[i].take = heaps[i].take->next;
		f->ref_count = 1;
		f->destructor = NULL;
		f->destructor_data = NULL;
		if( f->size > 0 )
			f->d = (unsigned char *)f + sizeof( struct frame );
		else
			f->d = NULL;
		f->format = FORMAT_EMPTY;
		f->width = 0;
		f->height = 0;
		f->length = 0;
		f->key = 0;
	} else
	{
		spook_log( SL_WARN,
			"Ack!  Out of frame buffers of size %d!", size );
		f = NULL;
	}

	pthread_mutex_unlock( &heaps[i].mutex );

	return f;
}

static int clone_destructor( struct frame *f, void *d )
{
	unref_frame( (struct frame *)d );
	return 0;
}

struct frame *clone_frame( struct frame *orig )
{
	struct frame *f;

	if( ! ( f = new_frame( 0 ) ) ) return NULL;
	f->destructor = clone_destructor;
	f->destructor_data = orig;
	f->format = orig->format;
	f->width = orig->width;
	f->height = orig->height;
	f->length = orig->length;
	f->key = orig->key;
	f->d = orig->d;
	ref_frame( orig );
	return f;
}

void ref_frame( struct frame *f )
{
	pthread_mutex_lock( &f->mutex );
	++f->ref_count;
	pthread_mutex_unlock( &f->mutex );
}

void unref_frame( struct frame *f )
{
	int i;

	pthread_mutex_lock( &f->mutex );
	i = --f->ref_count;
	pthread_mutex_unlock( &f->mutex );
	if( i > 0 ) return;

	if( f->destructor )
	{
		++f->ref_count;
		if( f->destructor( f, f->destructor_data ) ) return;
	}

	for( i = 0; i < heap_count; ++i )
		if( heaps[i].size == f->size ) break;
	if( i == heap_count )
	{
		spook_log( SL_ERR,
			"frame size %d does not match any heaps!!!", f->size );
		return;
	}

	pthread_mutex_lock( &heaps[i].mutex );
	if( ! heaps[i].put->f )
	{
		heaps[i].put->f = f;
		heaps[i].put = heaps[i].put->next;
	} else spook_log( SL_WARN,
				"Ack!  There is a frame at frame_heap_put!" );
	pthread_mutex_unlock( &heaps[i].mutex );
}

static void exchanger_read( struct event_info *ei, void *d )
{
	struct frame_exchanger *ex = (struct frame_exchanger *)d;
	unsigned char c;
	int ret;
	struct frame *f;

	for(;;)
	{
		ret = read( ex->master_fd, &c, 1 );
		if( ret <= 0 )
		{
			if( ret < 0 && errno == EAGAIN ) return;
			spook_log( SL_ERR, "We lost an exchanger fd!" );
			exit( 1 );
		}
		pthread_mutex_lock( &ex->mutex );
		f = ex->master_read->f;
		ex->master_read->f = NULL;
		ex->master_read = ex->master_read->next;
		pthread_mutex_unlock( &ex->mutex );
		ex->f( f, ex->d );
	}
}

struct frame_exchanger *new_exchanger( int slots,
					frame_deliver_func func, void *d )
{
	struct frame_slot *f = NULL, *prev = NULL;
	struct frame_exchanger *ex;
	int fds[2];

	ex = (struct frame_exchanger *)
			malloc( sizeof( struct frame_exchanger ) );

	while( slots-- > 0 )
	{
		f = (struct frame_slot *)
				malloc( sizeof( struct frame_slot ) );
		f->f = NULL;
		f->pending = 0;
		f->prev = prev;
		if( prev ) prev->next = f;
		else ex->slave_cur = f;
		prev = f;
	}
	ex->slave_cur->prev = f;
	f->next = ex->slave_cur;
	ex->master_read = ex->master_write = ex->slave_cur;

	pipe( fds );
	ex->master_fd = fds[0];
	ex->slave_fd = fds[1];

	fcntl( ex->master_fd, F_SETFL, O_NONBLOCK );
	ex->master_event = add_fd_event( ex->master_fd, 0, 0,
						exchanger_read, ex );

	pthread_mutex_init( &ex->mutex, NULL );
	pthread_cond_init( &ex->slave_wait, NULL );

	ex->f = func;
	ex->d = d;

	return ex;
}

int exchange_frame( struct frame_exchanger *ex, struct frame *frame )
{
	pthread_mutex_lock( &ex->mutex );
	if( ex->master_write->f )
	{
		spook_log( SL_WARN, "Exchanger is full, dropping frame!" );
		pthread_mutex_unlock( &ex->mutex );
		return -1;
	}
	ex->master_write->f = frame;
	ex->master_write->pending = 1;
	ex->master_write = ex->master_write->next;
	pthread_cond_signal( &ex->slave_wait );
	pthread_mutex_unlock( &ex->mutex );

	return 0;
}

struct frame *get_next_frame( struct frame_exchanger *ex, int wait )
{
	struct frame *f = NULL;

	pthread_mutex_lock( &ex->mutex );
	if( ex->slave_cur->pending ) f = ex->slave_cur->f;
	if( ! f && wait )
	{
		pthread_cond_wait( &ex->slave_wait, &ex->mutex );
		if( ex->slave_cur->pending ) f = ex->slave_cur->f;
		if( ! f ) spook_log( SL_WARN, "Slave signalled but no frame??" );
	}
	pthread_mutex_unlock( &ex->mutex );
	return f;
}

void deliver_frame( struct frame_exchanger *ex, struct frame *f )
{
	unsigned char c = 0;

	ex->slave_cur->f = f;
	ex->slave_cur->pending = 0;
	if( write( ex->slave_fd, &c, 1 ) <= 0 ) exit( 0 );
	ex->slave_cur = ex->slave_cur->next;
}
