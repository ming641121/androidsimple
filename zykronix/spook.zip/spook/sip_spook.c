/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <pmsg.h>
#include <rtp.h>
#include <sip.h>
#include <conf_parse.h>

struct sip_call {
	struct sip_call *next;
	struct sip_call *prev;
	struct dialog *dialog;
	struct session *sess;
};

struct sip_line {
	open_func open;
	void *private;
};

struct sip_line *line = NULL;
struct sip_call *call_list = NULL;
char sip_name[256], sip_domain[256], sip_username[256], sip_password[256];
struct dialog *reg_dialog = NULL;
int registered = -1;

void new_sip_line( char *linename, open_func open, void *private )
{
	line = (struct sip_line *)malloc( sizeof( struct sip_line ) );
	line->open = open;
	line->private = private;
}

static void call_closed( struct session *sess )
{
	struct sip_call *c = (struct sip_call *)sess->control_private;

	if( c->dialog ) sip_hangup( c->dialog );
	if( c->next ) c->next->prev = c->prev;
	if( c->prev ) c->prev->next = c->next;
	else call_list = c->next;
	free( c );
}

struct sip_call *create_call( struct dialog *d, struct session *s )
{
	struct sip_call *c;

	c = (struct sip_call *)malloc( sizeof( struct sip_call ) );
	if( ! c )
	{
		spook_log( SL_ERR, "out of memory on malloc sip_call" );
		return NULL;
	}
	c->next = call_list;
	if( c->next ) c->next->prev = c;
	c->prev = NULL;
	call_list = c;
	c->sess = s;
	c->dialog = d;
	s->control_private = c;
	s->control_close = call_closed;
	return c;
}

void event_new_call( struct transaction *x, char *d, int len )
{
	unsigned char tmp[2048];
	int sdp_len, i, j;
	char *c;
	struct session *sess;
	struct in_addr addr;
	int cport, server_port;

	if( ! line )
	{
		spook_log( SL_VERBOSE, "refusing call to %s", x->req->sl.req.uri );
		sip_answer_call( x, 404, "Not found", NULL );
		return;
	}

	j = sprintf( tmp, "incoming call on line \"" );
	/* get the user part of the URI */
	c = x->req->sl.req.uri;
	if( ! strncasecmp( c, "sip:", 4 ) ) c += 4;
	for( i = 0; c[i] && c[i] != '@'; ++i ) tmp[j++] = c[i];
	j += sprintf( tmp + j, "\" from: " );
	/* get the text and URI from the From: field */
	if( ! ( c = get_header( x->req, "from" ) ) ) return;
	for( i = 0; c[i] && c[i] != ';'; ++i ) tmp[j++] = c[i];
	tmp[j] = 0;

	spook_log( SL_VERBOSE, tmp );

	if( ! ( c = strstr( d, "m=audio " ) ) ) return;
	cport = atoi( c + 8 );
	if( ! ( c = strstr( d, "c=IN IP4 " ) ) ) return;
	inet_aton( c + 9, &addr );

	spook_log( SL_DEBUG,
		"sending media to %s:%d", inet_ntoa( addr ), cport );

	if( ! ( sess = line->open( "", line->private ) ) ||
			sess->setup( sess, 0 ) < 0  ||
			connect_udp_endpoint( sess->ep[0],
				addr, cport, &server_port ) < 0 )
	{
		if( sess ) sess->teardown( sess, NULL );
		sip_answer_call( x, 404, "Not found", NULL );
		return;
	}

	sdp_len = sizeof( tmp ) - 1;
	if( sess->get_sdp( sess, tmp, &sdp_len, "" ) > 0 )
	{
		tmp[sdp_len] = 0;
		strcpy( sess->addr, sess->ep[0]->trans.udp.sdp_addr );
		create_call( sip_answer_call( x, 200, "OK", tmp ), sess );
		sess->play( sess, NULL );
	} else 
	{
		sess->teardown( sess, NULL );
		sip_answer_call( x, 404, "Not found", NULL );
	}
}

void hangup_event( struct dialog *d )
{
	struct sip_call *c;

	spook_log( SL_VERBOSE, "caller hung up" );

	for( c = call_list; c; c = c->next )
		if( c->dialog == d ) break;
	if( ! c ) return;

	c->dialog = NULL;
	c->sess->teardown( c->sess, NULL );
}

int get_sip_credentials( char *realm, char **user, char **pass )
{
	if( strcasecmp( realm, sip_domain ) ) return 0;

	*user = sip_username;
	*pass = sip_password;
	return 1;
}

static void do_sip_register( struct event_info *ei, void *d );

static void register_callback( struct transaction *x )
{
	if( ! x->resp )
	{
		spook_log( registered == 0 ? SL_VERBOSE : SL_INFO,
			"SIP registration timed out" );
		registered = 0;
	} else if( x->resp->sl.stat.code < 200 )
		return;
	else if( x->resp->sl.stat.code < 300 )
	{
		spook_log( registered == 1 ? SL_DEBUG : SL_INFO,
			"SIP registration succeeded" );
		registered = 1;
	} else
	{
		spook_log( registered == 0 ? SL_VERBOSE : SL_INFO,
			"SIP registration failed: %d %s",
			x->resp->sl.stat.code, x->resp->sl.stat.reason );
		registered = 0;
	}
	add_timer_event( registered ? 20000 : 300000, EVENT_F_ONESHOT,
				do_sip_register, NULL );
}

static void do_sip_register( struct event_info *ei, void *d )
{
	sip_register( reg_dialog, register_callback );
}

void sip_init(void)
{
	if( udp_listen( 5060 ) < 0 )
	{
		spook_log( SL_ERR, "unable to bind UDP port" );
		return;
	}
}

/********************* GLOBAL CONFIGURATION DIRECTIVES ********************/

int config_sip_proxy( int num_tokens, struct token *tokens, void *d )
{
	sip_set_proxy( tokens[1].v.str );
	spook_log( SL_DEBUG, "SIP proxy is %s", tokens[1].v.str );
	return 0;
}

int config_sip_name( int num_tokens, struct token *tokens, void *d )
{
	strcpy( sip_name, tokens[1].v.str );
	spook_log( SL_DEBUG, "SIP name is %s", sip_name );
	return 0;
}

int config_sip_domain( int num_tokens, struct token *tokens, void *d )
{
	strcpy( sip_domain, tokens[1].v.str );
	spook_log( SL_DEBUG, "SIP domain is %s", sip_domain );
	return 0;
}

int config_sip_username( int num_tokens, struct token *tokens, void *d )
{
	strcpy( sip_username, tokens[1].v.str );
	spook_log( SL_DEBUG, "SIP username is %s", sip_username );
	return 0;
}

int config_sip_password( int num_tokens, struct token *tokens, void *d )
{
	strcpy( sip_password, tokens[1].v.str );
	spook_log( SL_DEBUG, "SIP password is %s", sip_password );
	return 0;
}

int config_sip_register( int num_tokens, struct token *tokens, void *d )
{
	if( ! strcasecmp( tokens[1].v.str, "on" ) )
	{
		reg_dialog = register_dialog( sip_name, sip_domain );
		do_sip_register( NULL, NULL );
	} else if( strcasecmp( tokens[1].v.str, "off" ) )
	{
		spook_log( SL_ERR,
			"valid values for SIPRegister are \"on\" and \"off\"" );
		return -1;
	}
	return 0;
}
