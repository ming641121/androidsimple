/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <filters.h>
#include <conf_parse.h>

struct resampler {
	struct stream *output;
	struct stream_destination *input;
	int old_rate;
	int new_rate;
	int old_channels;
	int new_channels;
	int scale;
	unsigned char leftover[32];
	int leftover_len;
};

static void do_resample( struct frame *in, void *d )
{
	struct resampler *en = (struct resampler *)d;
	struct frame *out;
	int i, samples;

	out = new_frame( ( en->leftover_len + in->length ) / en->scale / 2 );
	if( ! out )
	{
		unref_frame( in );
		return;
	}
	out->format = in->format;
	out->width = out->height = 0;
	out->key = 1;
	out->length = ( en->leftover_len + in->length ) / en->scale / 2;
	samples = out->length / 2;
	for( i = 0; i < samples; ++i )
	{
		int p = ( i * en->scale ) << 2;

		if( p < en->leftover_len )
			*((unsigned short *)(out->d + (i<<1))) =
				*((unsigned short *)(en->leftover + p));
		else
			*((unsigned short *)(out->d + (i<<1))) =
				*((unsigned short *)(in->d +
							p - en->leftover_len));
	}
	en->leftover_len = ( en->leftover_len + in->length ) %
							( en->scale << 2 );
	memcpy( en->leftover, in->d + in->length - en->leftover_len,
			en->leftover_len );
	unref_frame( in );
	deliver_frame_to_stream( out, en->output );
}

static void get_framerate( struct stream *s, int *fincr, int *fbase )
{
	struct resampler *en = (struct resampler *)s->src_private;

	en->input->stream->get_framerate( en->input->stream, fincr, fbase );
	*fbase /= en->scale;
	*fbase /= 2;
	*fincr /= 2;
	//printf( "fincr = %d, fbase = %d\n", *fincr, *fbase );
}

static void set_running( struct stream *s, int running )
{
	struct resampler *en = (struct resampler *)s->src_private;

	set_waiting( en->input, running );
}

/************************ CONFIGURATION DIRECTIVES ************************/

static void *start_block(void)
{
	struct resampler *en;

	en = (struct resampler *)malloc( sizeof( struct resampler ) );
	en->input = NULL;
	en->output = NULL;
	en->old_rate = 0;
	en->new_rate = 0;
	en->old_channels = 0;
	en->new_channels = 0;
	en->scale = 0;
	en->leftover_len = 0;

	return en;
}

static int end_block( void *d )
{
	struct resampler *en = (struct resampler *)d;

	if( ! en->input )
	{
		spook_log( SL_ERR,
			"resample: missing input stream name" );
		return -1;
	}
	if( ! en->output )
	{
		spook_log( SL_ERR,
			"resample: missing output stream name" );
		return -1;
	}
	if( en->new_rate < 1 )
	{
		spook_log( SL_ERR,
			"resample: missing target sample rate" );
		return -1;
	}

	en->input->stream->get_framerate( en->input->stream,
					&en->old_channels, &en->old_rate );
	en->scale = ( en->old_rate / en->old_channels ) / en->new_rate;
	spook_log( SL_DEBUG, "resample factor is %d", en->scale );

	return 0;
}

static int set_input( int num_tokens, struct token *tokens, void *d )
{
	struct resampler *en = (struct resampler *)d;
	int format = FORMAT_PCM;

	if( ! ( en->input = connect_to_stream( tokens[1].v.str, do_resample,
						en, &format, 1 ) ) )
	{
		spook_log( SL_ERR,
			"resample: unable to connect to stream \"%s\"\n",
				tokens[1].v.str );
		return -1;
	}
	return 0;
}

static int set_output( int num_tokens, struct token *tokens, void *d )
{
	struct resampler *en = (struct resampler *)d;

	if( ! en->input )
	{
		spook_log( SL_ERR,
			"resample: input must be specified before output" );
		return -1;
	}
	en->output = new_stream( tokens[1].v.str,
					en->input->stream->format, en );
	if( ! en->output )
	{
		spook_log( SL_ERR,
			"resample: unable to create stream \"%s\"",
			tokens[1].v.str );
		return -1;
	}
	en->output->get_framerate = get_framerate;
	en->output->set_running = set_running;
	return 0;
}

static int set_rate( int num_tokens, struct token *tokens, void *d )
{
	struct resampler *en = (struct resampler *)d;

	if( tokens[1].v.num < 1 )
	{
		spook_log( SL_ERR,
			"resample: scale factor cannot be less than 1!" );
		return -1;
	}
	en->new_rate = tokens[1].v.num;
	return 0;
}

static int set_channels( int num_tokens, struct token *tokens, void *d )
{
	struct resampler *en = (struct resampler *)d;

	if( tokens[1].v.num < 1 )
	{
		spook_log( SL_ERR,
			"resample: output must have at least 1 channel" );
		return -1;
	}
	en->new_channels = tokens[1].v.num;
	return 0;
}

static struct statement config_statements[] = {
	/* directive name, process function, min args, max args, arg types */
	{ "input", set_input, 1, 1, { TOKEN_STR } },
	{ "output", set_output, 1, 1, { TOKEN_STR } },
	{ "rate", set_rate, 1, 1, { TOKEN_NUM } },
	{ "channels", set_channels, 1, 1, { TOKEN_NUM } },

	/* empty terminator -- do not remove */
	{ NULL, NULL, 0, 0, {} }
};

int resample_init(void)
{
	register_config_context( "filter", "resample", start_block, end_block,
					config_statements );
	return 0;
}
