/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <pmsg.h>
#include <rtp.h>
#include <sip.h>
#include <conf_parse.h>

int handle_server_transaction( struct transaction *x,
					unsigned char *body, int bodylen )
{
	if( find_dialog( get_header( x->req, "to" ),
				get_header( x->req, "from" ),
				get_header( x->req, "call-id" ),
				&x->dialog ) < 0 )
	{
		simple_reply( x, 481, "Call/Transaction Does Not Exist" );
		return 0;
	}

	if( ! strcasecmp( x->req->sl.req.method, "INVITE" ) )
	{
		if( x->dialog )
		{
			simple_reply( x, 488, "Not Acceptable Here" );
		} else
		{
			struct dialog *d;

			/* Verify that this isn't a retransmitted INVITE */
			if( find_dialog( NULL, get_header( x->req, "from" ),
						get_header( x->req, "call-id" ),
						&d ) < 0 )
				event_new_call( x, body, bodylen );
			//else printf( "got retransmitted INVITE!\n" );
		}
	} else if( ! strcasecmp( x->req->sl.req.method, "BYE" ) )
	{
		if( x->dialog )
		{
			hangup_event( x->dialog );
			simple_reply( x, 200, "OK" );
		} else 
			simple_reply( x, 481,
					"Call/Transaction Does Not Exist" );
	} else if( ! strcasecmp( x->req->sl.req.method, "OPTIONS" ) )
		simple_reply( x, 405, "Method not implemented" );
	return 0;
}

int handle_ack( struct pmsg *msg, unsigned char *body, int bodylen )
{
	struct dialog *d;

	if( find_dialog( get_header( msg, "to" ), get_header( msg, "from" ),
				get_header( msg, "call-id" ), &d ) <= 0 )
	{
		spook_log( SL_VERBOSE, "received ACK for unknown call" );
		return 0;
	}
	spook_log( SL_DEBUG, "received ACK for good call" );

	return 0;
}

struct dialog *sip_answer_call( struct transaction *x,
					int code, char *reason, char *sdp )
{
	struct dialog *d = NULL;

	if( x->dialog )
	{
		if( code >= 300 ) unref_dialog( x->dialog );
		else d = x->dialog;
		x->dialog = NULL;
	} else if( code < 300 ) d = new_dialog( x, 1 );
	x->resp = create_sip_reply( x->req, d, code, reason );
	if( code == 200 )
	{
		add_header( x->resp, "Content-Type", "application/sdp" );
		x->bodylen = strlen( sdp );
		x->body = (unsigned char *)malloc( x->bodylen );
		memcpy( x->body, sdp, x->bodylen );
	}
	transaction_reply( x );
	return d;
}
