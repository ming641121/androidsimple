/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <pmsg.h>
#include <rtp.h>
#include <sip.h>
#include <conf_parse.h>

static struct dialog *d_list = NULL;

void ref_dialog( struct dialog *d )
{
	++d->ref_count;
	//printf( "refing %08x, ref_count is %d\n",
	//		(unsigned int)d, d->ref_count );
}

void unref_dialog( struct dialog *d )
{
	//printf( "unrefing %08x, ref_count is %d\n",
	//		(unsigned int)d, d->ref_count - 1 );
	if( --d->ref_count > 0 ) return;
	if( d->next ) d->next->prev = d->prev;
	if( d->prev ) d->prev->next = d->next;
	else d_list = d->next;
	if( d->route_set ) free( d->route_set );
	free( d );
}

int find_dialog( char *local, char *remote, char *callid, struct dialog **dptr )
{
	struct dialog *d;
	char remote_tag[256], local_tag[256];
	int i;

	if( ! callid ) return -1;
	/* We can optionally look up dialogs without considering the local
	 * tag, so we can verify that INVITEs aren't retransmissions. */
	if( local )
	{
		i = get_param( local, "tag", local_tag, sizeof(local_tag) );
		if( i < 0 ) return -1;
		if( i == 0 )
		{
			*dptr = NULL;
			return 0;
		}
	} else local_tag[0] = 0;
	i = get_param( remote, "tag", remote_tag, sizeof(remote_tag) );
	if( i < 0 ) return -1;
	if( i == 0 ) remote_tag[0] = 0;

	//printf( "searching for dialog local=%s remote=%s\n", local_tag, remote_tag );

	for( d = d_list; d; d = d->next )
	{
		//printf( "checking %08x...", (unsigned int)d );
		if( ( ! local || ! strcmp( local_tag, d->local_tag ) )
			&& ! strcmp( callid, d->callid )
			&& ! strcmp( remote_tag, d->remote_tag ) )
		{
			//printf( "got it!\n" );
			*dptr = d;
			return 1;
		}
		//printf( "nope\n" );
	}
	/* We're in trouble here.  The UAC has asserted that a dialog exists
	 * because he has included a To tag, but we have no matching dialog.
	 * This means (a) we were restarted mid-dialog, (b) we got a message
	 * for somebody else's dialog, or (c) somebody's buggy.  Regardless,
	 * there's not much we can do about it besides indicate an error. */
	return -1;
}

struct dialog *new_dialog( struct transaction *x, int is_uas )
{
	struct dialog *d;
	int i, f, count;
	char *field;

	if( ! ( d = malloc( sizeof( struct dialog ) ) ) )
	{
		spook_log( SL_ERR, "out of memory on malloc dialog" );
		return NULL;
	}

	d->prev = NULL;
	d->next = d_list;
	if( d->next ) d->next->prev = d;
	d_list = d;

	d->ref_count = 1;
	d->confirmed = 1;
	d->local_cseq = 1; /* something random */
	d->remote_cseq = get_cseq( x->req, NULL );

	if( ( field = get_header( is_uas ? x->req : x->resp,
					is_uas ? "from" : "to" ) ) )
	{
		strncpy( d->remote_uri, field, sizeof( d->remote_uri ) );
		if( get_param( field, "tag", d->remote_tag,
				sizeof( d->remote_tag ) ) <= 0 )
			d->remote_tag[0] = 0;
	} else
	{
		free( d );
		return NULL;
	}

	if( ( field = get_header( x->req, is_uas ? "to" : "from" ) ) )
	{
		strncpy( d->local_uri, field, sizeof( d->local_uri ) );
		if( get_param( field, "tag", d->local_tag,
				sizeof( d->local_tag ) ) <= 0 )
			random_id( d->local_tag, 16 );
	} else
	{
		free( d );
		return NULL;
	}

	if( ( field = get_header( x->req, "call-id" ) ) )
		strncpy( d->callid, field, sizeof( d->callid ) );
	else
	{
		free( d );
		return NULL;
	}

	if( ( field = get_header( is_uas ? x->req : x->resp, "contact" ) ) )
		strncpy( d->target, field, sizeof( d->target ) );
	else d->target[0] = 0;

	/* Route-set stuff disabled until we figure out how to do it right */
#if 0
	i = 0;
	count = 0;
	/* Figure out total length of record-route headers */
	for( f = 0; f < x->req->header_count; ++f )
		if( ! strcasecmp( x->req->fields[f].name,
					"record-route" ) )
		{
			++count;
			i += strlen( x->req->fields[f].value ) + 1;
		}

	if( count > 0 )
	{
		char **rs, *c;

		++count; /* One extra slot for NULL */

		/* Allocate memory for header values and array of pointers */
		if( ! ( rs = malloc( count * sizeof( *rs ) + i ) ) )
		{
			spook_log( SL_ERR,
				"out of memory on malloc route-set" );
			return NULL;
		}
		c = (char*)rs + count * sizeof( *rs );
		i = 0;
		/* Copy headers into new block of memory */
		for( f = 0; f < x->req->header_count; ++f )
			if( ! strcasecmp( x->req->fields[f].name,
						"record-route" ) )
			{
				rs[i] = c;
				strcpy( rs[i], x->req->fields[f].value );
				c += strlen( rs[i] ) + 1;
				++i;
			}
		rs[i] = NULL;
		d->route_set = rs;
	} else d->route_set = NULL;
#else
	d->route_set = NULL;
#endif

#if 0
	printf( "Created new dialog 0x%08X:\n    Local CSeq: %d\n"
		"    Remote CSeq: %d\n    Remote URI: %s\n    Remote Tag: %s\n"
		"    Local URI: %s\n    Local Tag: %s\n    Call ID: %s\n"
		"    Target: %s\n", (unsigned int)d,
		d->local_cseq, d->remote_cseq, d->remote_uri, d->remote_tag,
		d->local_uri, d->local_tag, d->callid, d->target );
#endif

	return d;
}

struct dialog *register_dialog( char *line, char *domain )
{
	struct dialog *d;

	if( ! ( d = malloc( sizeof( struct dialog ) ) ) )
	{
		spook_log( SL_ERR, "out of memory on malloc dialog" );
		return NULL;
	}
	d->prev = NULL;
	d->next = d_list;
	if( d->next ) d->next->prev = d;
	d_list = d;
	d->ref_count = 1;
	d->confirmed = 1;
	d->local_cseq = 1; /* something random */
	d->remote_cseq = 0;
	random_id( d->callid, 64 );
	d->remote_tag[0] = 0;
	random_id( d->local_tag, 16 );
	sprintf( d->remote_uri, "sip:%s@%s", line, domain );
	sprintf( d->local_uri, "%s;tag=%s", d->remote_uri, d->local_tag );
	sip_get_my_addr( d->target + sprintf( d->target, "sip:%s@", line ) );
	d->route_set = NULL; // XXX necessary for registration?
	return d;
}
