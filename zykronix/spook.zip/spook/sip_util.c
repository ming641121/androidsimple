/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <event.h>
#include <log.h>
#include <frame.h>
#include <stream.h>
#include <pmsg.h>
#include <rtp.h>
#include <sip.h>
#include <conf_parse.h>

int get_cseq( struct pmsg *msg, char *method )
{
	char *val, *c;
	long cseq;

	if( ! ( val = get_header( msg, "cseq" ) ) ) return -1;
	cseq = strtol( val, &c, 10 );
	if( cseq == LONG_MIN || cseq == LONG_MAX ) return -1;
	if( *c != ' ' && *c != '\t' ) return -1;
	while( *c == ' ' || *c == '\t' ) ++c;
	if( ! method ) return cseq;
	if( strncasecmp( c, method, strlen( method ) ) ) return -1;
	c += strlen( method );
	if( *c == 0 || *c == ' ' || *c == '\t' ) return cseq;
	return -1;
}

struct pmsg *create_sip_reply( struct pmsg *req, struct dialog *d,
					int code, char *reply )
{
	struct pmsg *msg;
	char *to;
	char tmp[256];

	if( ! ( msg = new_pmsg( 2048 ) ) ) return NULL;
	msg->type = PMSG_RESP;
	msg->sl.stat.code = code;
	msg->sl.stat.reason = add_pmsg_string( msg, reply );
	copy_headers( msg, req, "via" );
	copy_headers( msg, req, "from" );
	to = get_header( req, "to" );
	if( get_param( to, "tag", NULL, 0 ) == 0 )
	{
		if( d ) sprintf( tmp, "%s;tag=%s", to, d->local_tag );
		else random_id( tmp + sprintf( tmp, "%s;tag=", to ), 16 );
		add_header( msg, "To", tmp );
	} else copy_headers( msg, req, "to" );
	copy_headers( msg, req, "cseq" );
	copy_headers( msg, req, "call-id" );

	//update_msg_dest( msg );

	return msg;
}

void sip_send( struct pmsg *msg, unsigned char *d, int len )
{
	udp_send_pmsg( msg, d, len );
}
