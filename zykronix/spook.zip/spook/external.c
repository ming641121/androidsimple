/*
 * Copyright (C) 2004 Nathan Lutchansky <lutchann@litech.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */

#include <sys/types.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <errno.h>
#include <pthread.h>

#include <event.h>
#include <log.h>
#include <control.h>
#include <frame.h>
#include <stream.h>
#include <inputs.h>
#include <conf_parse.h>

struct shared_frame_tag;

struct ext_input {
	pthread_mutex_t mutex;
	struct stream *output;
	int format;
	int fincr;
	int fbase;
	int callnum;
	int fd;
	int ref_count;
	unsigned char *shared_map;
	int shared_len;
	int shared_is_mmaped;
	struct shared_frame_tag *unused_tag_list;
	int running;
};

struct shared_frame_tag {
	struct shared_frame_tag *next;
	struct ext_input *ext;
	unsigned int tag;
};

static int full_read( int fd, void *dest, int len )
{
	int ret, total = 0;

	while( ( ret = read( fd, dest + total, len - total ) ) > 0 )
		if( ( total += ret ) == len ) return len;
	if( ret < 0 )
		spook_log( SL_WARN,
			"external: error reading %d bytes: %s",
			strerror( errno ) );
	else
		spook_log( SL_WARN,
			"external: connection closed reading %d bytes" );
	return ret;
}

static void get_framerate( struct stream *s, int *fincr, int *fbase )
{
	struct ext_input *ext = (struct ext_input *)s->src_private;

	*fincr = ext->fincr;
	*fbase = ext->fbase;
}

static void set_running( struct stream *s, int running )
{
	struct ext_input *ext = (struct ext_input *)s->src_private;

	pthread_mutex_lock( &ext->mutex );
	spook_log( SL_DEBUG,
		"external: called set_running for %d, was %d, is now %d",
		ext->callnum, ext->running, running );
	ext->running = running;
	if( ext->fd >= 0 )
	{
		char cmd[3];

		cmd[0] = ext->callnum;
		cmd[1] = 1; /* Set running command */
		cmd[2] = running;
		write( ext->fd, cmd, 3 );
	}
	pthread_mutex_unlock( &ext->mutex );
}

/* only call this with the mutex locked! */
static void unref_ext( struct ext_input *ext )
{
	struct shared_frame_tag *tag, *next;

	if( --ext->ref_count > 0 ) return;

	for( tag = ext->unused_tag_list; tag; tag = next )
	{
		next = tag->next;
		free( tag );
	}

	if( ext->shared_is_mmaped ) munmap( ext->shared_map, ext->shared_len );
	ext->shared_len = 0;
	ext->shared_is_mmaped = 0;
	ext->unused_tag_list = NULL;

	spook_log( SL_DEBUG, "external: exchanger %d finalized", ext->callnum );
}

static int process_disconnect( int fd, void *d )
{
	struct ext_input *ext = (struct ext_input *)d;

	spook_log( SL_DEBUG,
		"external: exchanger %d disconnected", ext->callnum );

	pthread_mutex_lock( &ext->mutex );
	ext->fd = -1;
	unref_ext( ext );
	pthread_mutex_unlock( &ext->mutex );

	return 0;
}

static int return_shared_buffer( struct frame *f, void *d )
{
	struct shared_frame_tag *tag = (struct shared_frame_tag *)d;
	char _cmd[8], *cmd;

	pthread_mutex_lock( &tag->ext->mutex );

	/* notify that we are done with this buffer */
	cmd = _cmd + 1; /* align cmd[3] with word boundary */
	cmd[0] = tag->ext->callnum;
	cmd[1] = 3; /* Free shared frame buffer command */
	cmd[2] = 0; /* No flags */
	*((unsigned int *)(cmd + 3)) = tag->tag;
	write( tag->ext->fd, cmd, 7 );

	tag->next = tag->ext->unused_tag_list;
	tag->ext->unused_tag_list = tag;
	unref_ext( tag->ext );

	pthread_mutex_unlock( &tag->ext->mutex );

	return 0;
}

static int process_new_frame( struct ext_input *ext, int fd, int flags )
{
	unsigned char params[32], junk[4096];
	int i, len;
	struct frame *f = NULL;

	/* Figure out the size of the header data and read it */
	i = 4; /* frame length to be read */
	if( flags & 0x80 ) i += 8; /* shared region data to be read */
	if( flags & 0x04 ) i += 4; /* video header to be read */
	if( flags & 0x02 ) i += 1; /* audio header to be read */
	if( full_read( fd, params, i ) < i ) return -1;

	len = *((unsigned int *)params); /* get the frame length */
	if( len == 0 ) return -1;

	/* If we're running, allocate space for the incoming frame */
	if( ext->running )
	{
		if( flags & 0x80 ) /* frame will be sent via shared region */
		{
			/* we can read the frame if we have an unused tag */
			if( ext->unused_tag_list ) f = new_frame( 0 );
		} else f = new_frame( len );
	} else /* Send set_running == 0 so we stop receiving frames */
	{
		char cmd[3];

		cmd[0] = ext->callnum;
		cmd[1] = 1; /* Set running command */
		cmd[2] = 0; /* Running == 0 */
		write( ext->fd, cmd, 3 );
	}

	/* If we're not running or can't allocate a frame, junk it */
	if( ! f )
	{
		if( flags & 0x80 ) /* frame will be sent via shared region */
		{
			char cmd[7];

			/* notify that we are done with this buffer */
			cmd[0] = ext->callnum;
			cmd[1] = 3; /* Free shared frame buffer command */
			cmd[2] = 0; /* No flags */
			memcpy( cmd + 3, params + 8, 4 ); /* Frame tag */
			write( ext->fd, cmd, 7 );
		} else /* frame will be sent over control socket */
		{
			/* read and discard all frame data */
			while( len > 0 )
			{
				i = sizeof( junk );
				if( i > len ) i = len;
				if( full_read( fd, junk, i ) <= 0 ) return -1;
				len -= i;
			}
		}
		pthread_mutex_unlock( &ext->mutex );
		return 0;
	}

	/* Process the frame header */
	f->length = len;
	i = 4;
	if( flags & 0x80 ) /* frame sent via shared region */
	{
		f->destructor = return_shared_buffer;
		f->destructor_data = ext->unused_tag_list;

		/* frame address is shared_map + offset */
		f->d = ext->shared_map + *((unsigned int *)(params + i));
		i += 4;
		/* opaque tag we should pass back with the frame when freed */
		ext->unused_tag_list->tag = *((unsigned int *)(params + i));
		i += 4;
		ext->unused_tag_list = ext->unused_tag_list->next;
		++ext->ref_count;
	} else /* frame sent over control socket */
	{
		if( full_read( fd, f->d, f->length ) < f->length )
		{
			unref_frame( f );
			return -1;
		}
	}

	/* Flag bit 3 -> key frame */
	f->key = flags & 0x08 ? 1 : 0;
	/* Flag bit 2 -> process video header */
	if( flags & 0x04 )
	{
		f->width = *((unsigned short *)(params + i));
		i += 2;
		f->height = *((unsigned short *)(params + i));
		i += 2;
	} else
	{
		f->width = 0;
		f->height = 0;
	}
	/* Flag bit 1 -> process audio header */
	if( flags & 0x02 ) f->step = params[i++];
	else f->step = 0;

	pthread_mutex_unlock( &ext->mutex );
	deliver_frame_to_stream( f, ext->output );
	return 0;
}

static int process_map_shared_region( struct ext_input *ext, int fd, int flags )
{
	unsigned char _params[8], *params;
	int len, max_frames, name_len, tmpfd;
	struct shared_frame_tag *tag;
	char filename[512];

	if( ext->shared_len > 0 )
	{
		spook_log( SL_ERR, "external: call %d trying to map more than one shared region!", ext->callnum );
		return -1;
	}
	params = _params + 3; /* align param[1] on word boundary */
	if( full_read( fd, params, 5 ) < 5 ) return -1;
	max_frames = params[0]; /* max number of frames the region can hold */
	len = *((unsigned int *)(params + 1)); /* get shared region length */
	if( len == 0 || max_frames == 0 ) return -1;
	switch( flags )
	{
	case 0: /* get shared region by physical address (no MMU) */
		params = _params; /* align param[0] on word boundary */
		if( full_read( fd, params, 4 ) < 4 ) return -1;
		ext->shared_map = *((unsigned char **)params);
		ext->shared_len = len;
		spook_log( SL_DEBUG,
			"call %d sharing physical memory %p length %d",
			ext->callnum, ext->shared_map, ext->shared_len );
		break;
	case 1: /* get shared region by mmaping a file/device */
		params = _params; /* align param[0] on word boundary */
		if( full_read( fd, params, 6 ) < 6 ) return -1;
		name_len = *((unsigned short *)(params + 4));
		if( name_len == 0 || name_len >= sizeof( filename ) ) return -1;
		if( full_read( fd, filename, name_len ) < name_len ) return -1;
		filename[name_len] = 0;
		if( ( tmpfd = open( filename, O_RDONLY ) ) < 0 )
		{
			spook_log( SL_WARN,
				"external: unable to open shared region %s for call %d: %s",
				filename, ext->callnum, strerror( errno ) );
			return -1;
		}
		if( ! ( ext->shared_map = (unsigned char *)mmap( NULL, len,
					PROT_READ, MAP_SHARED, tmpfd,
					*((unsigned int *)params) ) ) )
		{
			spook_log( SL_WARN,
				"external: error mapping driver memory: %s",
				strerror( errno ) );
			close( tmpfd );
			return -1;
		}
		close( tmpfd );
		ext->shared_len = len;
		ext->shared_is_mmaped = 1;
		spook_log( SL_DEBUG,
			"call %d sharing file %s mmap offset %d length %d",
			ext->callnum, filename, *((unsigned int *)params),
			ext->shared_len );
		break;
	default:
		/* Nothing else is valid */
		return -1;
	}
	while( max_frames-- > 0 )
	{
		tag = (struct shared_frame_tag *)
			malloc( sizeof( struct shared_frame_tag ) );
		if( ! tag )
		{
			spook_log( SL_ERR,
				"out of memory for struct shared_frame_tag" );
			return -1;
		}
		tag->next = ext->unused_tag_list;
		ext->unused_tag_list = tag;
		tag->ext = ext;
	}
	pthread_mutex_unlock( &ext->mutex );
	return 0;
}

static int process_command( int fd, void *d )
{
	struct ext_input *ext = (struct ext_input *)d;
	unsigned char cmd[2];
	int ret;

	if( full_read( fd, cmd, 2 ) < 2 ) return -1;

	pthread_mutex_lock( &ext->mutex );
	if( ext->fd != fd )
	{
		if( ext->fd >= 0 )
		{
			pthread_mutex_unlock( &ext->mutex );
			spook_log( SL_ERR,
				"attempt to connect to already-connected exchanger %d!",
				ext->callnum );
			return -1;
		}
		if( ext->ref_count > 0 )
		{
			pthread_mutex_unlock( &ext->mutex );
			spook_log( SL_WARN,
				"attempt to connect to exchanger %d before old shared region is unmapped",
				ext->callnum );
			return -1;
		}
		spook_log( SL_DEBUG,
			"external: exchanger %d connected", ext->callnum );
		ext->fd = fd;
		++ext->ref_count;
	}

	switch( cmd[0] )
	{
	case 0: /* New frame */
		ret = process_new_frame( ext, fd, cmd[1] );
		break;
	case 2: /* Map shared buffer */
		ret = process_map_shared_region( ext, fd, cmd[1] );
		break;
	default:
		/* Nothing else is valid */
		ret = -1;
		break;
	}

	if( ret < 0 )
	{
		pthread_mutex_unlock( &ext->mutex );
		process_disconnect( fd, d );
	}

	return ret < 0 ? -1 : 1;
}

/************************ CONFIGURATION DIRECTIVES ************************/

static void *start_block(void)
{
	struct ext_input *ext;

	ext = (struct ext_input *)malloc( sizeof( struct ext_input ) );
	pthread_mutex_init( &ext->mutex, NULL );
	ext->output = NULL;
	ext->format = -1;
	ext->fincr = 0;
	ext->callnum = -1;
	ext->fd = -1;
	ext->shared_len = 0;
	ext->shared_is_mmaped = 0;
	ext->ref_count = 0;
	ext->unused_tag_list = NULL;
	ext->running = 0;

	return ext;
}

static int end_block( void *d )
{
	struct ext_input *ext = (struct ext_input *)d;

	if( ! ext->output )
	{
		spook_log( SL_ERR, "external: missing output stream name" );
		return -1;
	}
	if( ext->format < 0 )
	{
		spook_log( SL_ERR, "external: format unspecified" );
		return -1;
	}
	if( ext->fincr == 0 )
	{
		spook_log( SL_ERR, "external: framerate unspecified" );
		return -1;
	}
	if( ext->callnum < 0 )
	{
		spook_log( SL_ERR, "external: call number unspecified" );
		return -1;
	}
	return 0;
}

static int set_output( int num_tokens, struct token *tokens, void *d )
{
	struct ext_input *ext = (struct ext_input *)d;

	if( ext->format < 0 )
	{
		spook_log( SL_ERR,
			"external: format must be specified before output" );
		return -1;
	}
	ext->output = new_stream( tokens[1].v.str, ext->format, ext );
	if( ! ext->output )
	{
		spook_log( SL_ERR, "external: unable to create stream \"%s\"",
				tokens[1].v.str );
		return -1;
	}
	ext->output->get_framerate = get_framerate;
	ext->output->set_running = set_running;
	return 0;
}

static int set_format( int num_tokens, struct token *tokens, void *d )
{
	struct ext_input *ext = (struct ext_input *)d;

	if( ext->format >= 0 )
	{
		spook_log( SL_ERR,
			"external: format has already been specified" );
		return -1;
	}
	if( ! strcasecmp( tokens[1].v.str, "mpeg4" ) )
		ext->format = FORMAT_MPEG4;
	else if( ! strcasecmp( tokens[1].v.str, "mjpeg" ) )
		ext->format = FORMAT_JPEG;
	else if( ! strcasecmp( tokens[1].v.str, "jpeg" ) )
		ext->format = FORMAT_JPEG;
	else if( ! strcasecmp( tokens[1].v.str, "mpeg1" ) )
		ext->format = FORMAT_MPV;
	else if( ! strcasecmp( tokens[1].v.str, "mpeg2" ) )
		ext->format = FORMAT_MPV;
	else if( ! strcasecmp( tokens[1].v.str, "mpv" ) )
		ext->format = FORMAT_MPV;
	else if( ! strcasecmp( tokens[1].v.str, "h263" ) )
		ext->format = FORMAT_H263;
	else if( ! strcasecmp( tokens[1].v.str, "rgb24" ) )
		ext->format = FORMAT_RAW_RGB24;
	else if( ! strcasecmp( tokens[1].v.str, "pcm" ) )
		ext->format = FORMAT_PCM;
	else if( ! strcasecmp( tokens[1].v.str, "mpa" ) )
		ext->format = FORMAT_MPA;
	else if( ! strcasecmp( tokens[1].v.str, "mp3" ) )
		ext->format = FORMAT_MPA;
	else if( ! strcasecmp( tokens[1].v.str, "mp2" ) )
		ext->format = FORMAT_MPA;
	else
	{
		spook_log( SL_ERR,
			"external: format \"%s\" is unknown", tokens[1].v.str );
		return -1;
	}

	return 0;
}

static int set_framerate( int num_tokens, struct token *tokens, void *d )
{
	struct ext_input *ext = (struct ext_input *)d;

	if( ext->fincr > 0 )
	{
		spook_log( SL_ERR, "external: framerate has already been set" );
		return -1;
	}
	if( tokens[1].v.num == 0 || tokens[2].v.num == 0 )
	{
		spook_log( SL_ERR, "external: fincr and fbase must not be 0" );
		return -1;
	}
	ext->fincr = tokens[1].v.num;
	ext->fbase = tokens[2].v.num;

	return 0;
}

static int set_callnumber( int num_tokens, struct token *tokens, void *d )
{
	struct ext_input *ext = (struct ext_input *)d;

	if( ext->callnum >= 0 )
	{
		spook_log( SL_ERR,
			"external: call number has already been set" );
		return -1;
	}
	ext->callnum = tokens[1].v.num;
	if( register_command( ext->callnum, process_command,
				process_disconnect, ext ) < 0 )
		return -1;

	return 0;
}

static struct statement config_statements[] = {
	/* directive name, process function, min args, max args, arg types */
	{ "output", set_output, 1, 1, { TOKEN_STR } },
	{ "format", set_format, 1, 1, { TOKEN_STR } },
	{ "framerate", set_framerate, 2, 2, { TOKEN_NUM, TOKEN_NUM } },
	{ "callnumber", set_callnumber, 1, 1, { TOKEN_NUM } },

	/* empty terminator -- do not remove */
	{ NULL, NULL, 0, 0, {} }
};

void external_init(void)
{
	register_config_context( "input", "external", start_block, end_block,
					config_statements );
}
