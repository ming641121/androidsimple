//-------------------------------------------------------------------------
//
//	Copyright (c)  2000 - 2004  Streaming21 Inc. All rights reserved.
//
//	ALL RIGHTS RESERVED. NO PART OF THIS CODE AND INFORMATION MAY BE 
//	REUSED, REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY MEANS,
//	WITHOUT WRITTEN PERMISSION FROM THE COMPANY.
//
//	Description : S21 Stream API 
//
//-------------------------------------------------------------------------

#ifndef __S21STREAMAPI_H_
#define __S21STREAMAPI_H_

//---------------------
// Protocol 

enum 
{
	S21_NET_RtspListenPort		= 554,
	S21_NET_HttpListenPort		= 8080,
	S21_NET_ProxyListenPort		= 8080,
	S21_NET_RedirectListenPort	= 8084
};

enum S21_STM_PROTOCOL_TYPE
{
	PT_UNKNOWN=0,
	PT_TCP, // not support in 5.0
	PT_UDP, // not used in 5.0
	PT_RTSP,
	PT_HTTP,
	PT_MULTICAST
};

//---------------------
// File Info

enum 
{
	S21_PATHNAME_LENGTH				= 256,
	S21_FILENAME_LENGTH				= 64,
	S21_FILE_EXTENSION_LENGTH		= 16,
	S21_HOSTNAME_LENGTH				= 128, //32,
	S21_FILE_DESCRIPTION_LENGTH		= 64,
	S21_FILE_TITLE_LENGTH			= 32,
	S21_FILE_AUTHOR_LENGTH			= 32,
	S21_FILE_COPYRIGHT_LENGTH		= 32,
	S21_IP_ADDRESS_LENGTH			= 128, //32,

	S21_USERNAME_LENGTH				= 36,
	S21_PASSWD_LENGTH				= 36,

	S21_URL_LENGTH					= 512,
	S21_URL_OPTIONSTR_LENGTH		= 256,
	S21_URLPROTOCOLNAME_LENGTH		= 12
};

typedef	enum S21_MEDIA_FORMAT_TYPE
{
	MT_UNKNOWN=0,
	MT_MPEG1,	
	MT_MPEG1V,
	MT_VCD,
	MT_MPEG2,
	MT_MPA,
	MT_MP3,
	MT_AVI,
	MT_ASF,
	MT_QT,
	MT_H263,
	MT_MPH,
	MT_MPEG2x,		// MT_MPEG2 data with MT_MPEG1 packages
	MT_MPEG2T,		// MPEG2 Transport
	MT_MPEG2V,		// MPEG2 video
	MT_ASFA,		// ASF audio
	MT_AVX,			// AVX format
	MT_HDTV,
	MT_MPEG4,
	MT_DIVX,
	MT_PLACE_HOLDER_UNDER_OTHERS_LIC_CTRL5,
	MT_PLACE_HOLDER_UNDER_OTHERS_LIC_CTRL4,
	MT_PLACE_HOLDER_UNDER_OTHERS_LIC_CTRL3,
	MT_PLACE_HOLDER_UNDER_OTHERS_LIC_CTRL2,
	MT_PLACE_HOLDER_UNDER_OTHERS_LIC_CTRL1
} S21_MEDIA_FORMAT_TYPE;

#include "s21types.h"
#include <string.h>

struct S21_FILE_STATUS
{					
	Int64					fileSize;
	unsigned long int		bitRate;
	unsigned long int		durationInSec;
	S21_MEDIA_FORMAT_TYPE	mFmtType;

	S21_FILE_STATUS() { memset(this, 0, sizeof(*this)); }
};


//----------------
// API

#include "s21errcode.h"
#include "s21embsdk.h"
#include "s21url.h"
#include "s21netclient.h"

#endif // __S21STREAMAPI_H_


