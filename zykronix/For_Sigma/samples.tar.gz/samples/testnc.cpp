//-------------------------------------------------------------------------
//
//	Copyright (c)    2000 - 2004 Streaming21 Inc. All rights reserved.
//
//	ALL RIGHTS RESERVED. NO PART OF THIS CODE AND INFORMATION MAY BE 
//	REUSED, REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY MEANS,
//	WITHOUT WRITTEN PERMISSION FROM THE COMPANY, UNLESS EXPRESSLY PROVIDED
//  FOR UNDER THE TERMS OF A MUTUALLY EXECUTED WRITTEN LICENSE AGREEMENT
//  FOR THIS SOFTWARE BETWEEN THE END-USER AND STREAMING21, OR OTHERWISE 
//  EXPRESSLY AUTHORIZED IN WRITING BY STREAMING21.
//
//	Description : S21 Net Client SDK Sample Program
//
//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
// -------
//  Usage
// -------
// Syntex :    
//	  testnc -u<S21Url> [-r<ReopenLoopCnt>|-rs<RewindLoopCnt>] [-s] [-tb<Bytes>|-t<Seconds>] [-b<BeginPos>|-bt<BeginPosInSeconds>] [-o<OutputFileName>] [-j<JumpLength>|-jt<JumpBySeconds>]  [-c<StartCmd>] [-a] [-v-]
//
// Description :
// -u<S21URL>: using s21 url to specify the target in a form of 
//		rtsp://<ip>[:<port>][/<filepath>][?user=<username>&pwd=<password>&...]
// -r<Loops>: repeatedly open/close (default to run 2 times)
// -rs<Loops>: repeatedly rewind (default to run 2 times)
// -s: step-by-step mode
// -t<Seconds>: set up a time limit for streaming ( while save stream to local file, this option will be automatically turned on, and set to 60 sec.
// -tb<Bytes>: set up a length limit for streaming
// -b<BeginPos>: set up stream begin position for streaming
// -bt<BeginPosInSecond>: set up stream begin position (in second) for streaming
// -o<FileName>: write received data to file with the FileName, -s option will be turn on automatically
// -j<JumpLength>: set up a length as a jump length for seek command
// -jt<JumpLengthInSecond>: set up a length as a jump length (in second) for seek command
// -c<StartCmd>: to setup the first command to be executed right after stream open.
// -a: to check TS packet sync byte every 188 byte.
// -v-: to disable verbose print for every read.
//
// -------------
//  Description
// -------------
//		This program will demonstrate the usage of API in the SDK, and also
//		a simple tool to try-run streaming services.
//		The calling sequence of these API is :
//
//		S21NetClient->Initialize() // create s21 networking module
//		-- S21NetClient->QuickSetByUrl() // set url for open
//              -- S21NetClient->Open() // open stream
//		---- S21NetClient->GetFileInfo(...) // query file info
//		---- S21NetClient->Read(...) // read data from stream
//		---- S21NetClient->Seek(...) // move read position in stream (option)
//		---- S21NetClient->SetStreamFilter(...) // set stream filter (option)
//		---- S21NetClient->SetStreamScale(...) // set trick play mode (option)
//		-- S21NetClient->Close()  // close stream
//		S21NetClient->Uninitialize() // release s21 networking module
//
//-------------------------------------------------------------------------
#include "main.h" //added by Betta
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <math.h>
//#include <signal.h>
#include "s21streamapi.h"

#ifdef WIN32
#include <conio.h>
#define kbhit() _kbhit()
#include <windows.h>

// handling sleep in microsecond
#define usleep(x)		Sleep(x/1000)

// handling sprintf format of int64
#define SFI64D "%I64d"
#define SPI64D(x) (x)

// file open
#define FILEID FILE *
#define FOPEN(a,b) fopen(a,b)
#define FCLOSE(x) fclose(x)
#define FWRITE(a,b,c, d) fwrite(a,b,c,d)

// psudo decoder
// -- _init(size_t bufsize, size_t bufcnt, int type)
#define SAMPLEDECODER_INIT(bufsize, bufcnt, type)
#define SAMPLEDECODER_UNINIT
#define SAMPLEDECODER_START
#define SAMPLEDECODER_STOP
// -- _mute(bool on)
#define SAMPLEDECODER_MUTE(on)
#define SAMPLEDECODER_FREEZE(on)
#define SAMPLEDECODER_BUFFLUSH
// -- _bufpush(char *bufptr, size_t bufsize)
#define SAMPLEDECODER_BUFPUSH(bufptr, bufsize)
// -- _settrickmode(int mode) : 0x07:normal, 0x03:IP, 0x01:I, 0x10:reverse
#define SAMPLEDECODER_SETTRICKMODE(mode)

#else
#include "platform.h"
#endif

//----------------
// Interface Pointers
//----------------

S21NetClient *g_pS21NC = NULL;

//----------------
// Default Values
//----------------

#define PACKET_SIZE		6000*188 // 188000//1000000  // CONFIG: test audo-pause/play continuously
#define DELAY_TIME		1 //20000 	//5000

#define USERNAME       "guest"		// CONFIG: default username
#define PASSWORD       "guest"		// CONFIG: default password
#define DEFAULT_OUTPUT "output.mpg"
#define PLAYLIMIT_TIME	3600
#define PLAYLIMIT_LENGTH 455000
#define DEFAULT_LOOP	2

S21_FILE_STATUS g_finfo;
char g_userName[16];
char g_password[16];
char g_serverIP[64];
char g_url[10][256];
int  g_urlCnt = 0;
int	 g_loop = 0;
double	g_curSpeed = 1.0;

BOOL g_bQuick = FALSE;
BOOL g_bStep = FALSE;
BOOL g_bSaveContent = FALSE;
char *g_pOutFile = DEFAULT_OUTPUT;
int g_bAutoRewind = FALSE;
int g_bLimitByTime = TRUE;
int g_nMSeconds = -1;
unsigned long g_nMLength = 0;
long g_nStartPos = 0;
int	g_bBeginByTime = FALSE;
unsigned long g_nJumpLength = 16000000;
int g_bJumpByTime = FALSE;
int g_nStartCmd = 0;
int g_bCheck188Align = 0;
int g_bVerbose = 1;

//-----------
// Functions
//-----------

int NextStep(char *msg);
int Parse_Command(int argc, char **argv);

int BrowseMediaInfo();
int OpenStream();

S21_NET_RC Seek(Int64 nPos);
S21_NET_RC SetSpeed(double nSpeed);

double ScaleToSpeed(S21NetClient::S21StreamScale scale);
S21NetClient::S21StreamScale SpeedToScale(double nSpeed);

//---------------
// Function Body
//---------------


int Parse_Command(int argc, char **argv)
{       
	if (argc <= 1)
	{	// print out usage
		printf("S21 Net Client SDK Sample Program\n");
		printf("Usage:\n");
		printf("  test -u<S21Url> [-s] [-c<StartCmd>] [-t<Seconds>|-tb<Bytes>] [-r<LoopCnt>|-rs<LoopAutoRewind>] [-o<OutputFileName>] [-b<BeginPos>|-bt<BeginPosInSecond>] [-j<jumpLength>|-jt<jumpLengthInSecond]\n");
		return 0;
	}
	else
	{
		*g_userName = 0;
		*g_password = 0;
		*g_serverIP = 0;

		int i = 0;
		for (i = 0; i<10; i++)
			g_url[i][0] = 0;

		strcpy(g_userName, USERNAME);
		strcpy(g_password, PASSWORD);

		for(i=1; i<argc; i++)
		{
			// url
			if (!strncmp(argv[i], "-u", 2) && g_urlCnt<10)
			{
				g_bQuick = TRUE;
				strcpy(g_url[g_urlCnt++], argv[i] + 2);
				printf("url%d:%s\n", g_urlCnt, g_url[g_urlCnt-1]);
			}
			// save to local file
			else if (!strncmp(argv[i], "-o", 2))
			{
				g_bSaveContent = TRUE;
				if (*(argv[i]+2) != 0) 
					g_pOutFile = argv[i] + 2;
			}
			// repeatedly open stream
			else if (!strncmp(argv[i], "-r", 2))
			{	if (argv[i][2] != 's')
				{	g_loop = atoi(argv[i]+2);
					if (g_loop == 0)
						g_loop = DEFAULT_LOOP;
				}
				else
				{	g_loop = atoi(argv[i]+3);
					if (g_loop == 0)
						g_loop = DEFAULT_LOOP;
					g_bAutoRewind = TRUE;
				}
			}
			// step by step mode
			else if (!strncmp(argv[i], "-s", 2))
			{
				g_bStep = TRUE;
			}
			// command to set jump length when ever call seek
			else if (!strncmp(argv[i], "-j", 2))
			{
				unsigned long tt = 0;
				if (argv[i][2] != 't') 
				{	sscanf(argv[i]+2, "%lu", &tt);
					if (tt > 0)
						g_nJumpLength = tt;
				}
				else
				{	sscanf(argv[i]+3, "%lu", &tt);
					if (tt > 0)
						g_nJumpLength = tt;
					g_bJumpByTime = TRUE;
				}
			}
			// begin position 
			else if (!strncmp(argv[i], "-b", 2))
			{
				if (argv[i][2] != 't')
				{
					long tt = atoi(argv[i]+2);
					g_nStartPos = tt;
				}
				else
				{
					long tt = atoi(argv[i]+3);
					g_nStartPos = tt;
					g_bBeginByTime = TRUE;
				}
			}
			// command to issue at begining
			else if (!strncmp(argv[i], "-c", 2))
			{
				g_nStartCmd = *(argv[i]+2);
			}
            // force read align to 188 
            else if (!strncmp(argv[i], "-a", 2))
            {
                    g_bCheck188Align = 1;
            }      
            // disable to print every read
            else if (!strncmp(argv[i], "-v-", 2))
            	{
                    g_bVerbose = 0;
           	 }
	// time limit
		else if (!strncmp(argv[i], "-t", 2))
			{	if (argv[i][2] != 'b')
				{	unsigned long tt = atoi(argv[i]+2);
					if (tt > 0 )
						g_nMSeconds = tt;
					else
						g_nMSeconds = PLAYLIMIT_TIME;
				}
				else
				{	unsigned long tt = atoi(argv[i]+3);
					if (tt > 0 )
						g_nMLength = tt;
					else
						g_nMLength = PLAYLIMIT_LENGTH;
					g_bLimitByTime = FALSE;
				}
			}
		}
	}
	return 1;
}

int NextStep(char *msg)
{
	printf("\n%s", msg);
	if (g_bStep)
	{	printf("... Continue(Y/n)?");
		int reply = getchar();
		if (tolower(reply) == 'n')
			return 0;
	}
	else
		printf("...\n");
	return 1;
}

int OpenStream()
{
	FILEID fp = NULL;
	BOOL bIsOpen = FALSE;
	BOOL bIsSeekbaseTrickPlay = FALSE;
	int loops = g_loop;
	char *pBuffer = new char[PACKET_SIZE];
	SAMPLEDECODER_INIT(PACKET_SIZE, 1, 0); // mpeg2-ts only

	do 
	{
		char msg[24];

		// Open Stream
		if (g_bAutoRewind && loops != g_loop)
		{	// Auto rewind
			S21_NET_RC rc;
			SetSpeed(1.0);
			rc = Seek(0);
			if (rc != S21_NET_NoErr)
				break;
			bIsOpen = TRUE;
			SAMPLEDECODER_BUFFLUSH;
		}
		else
		{	// Open stream
			sprintf(msg, "Open Stream %d/%d", g_loop-loops, g_urlCnt/*, g_url[(g_loop-loops)%g_urlCnt]*/);
			if (NextStep(msg))
			{	
				S21_NET_RC rc;

				if (g_urlCnt >1 )
				{
					rc = g_pS21NC->QuickSetByUrl(g_url[(g_loop-loops)%g_urlCnt], "",0 , USERNAME, PASSWORD, TRUE, 1);
					if (rc != S21_NET_NoErr)
					{	printf("ERROR: %d\n", rc);
						break;
					}
				}

				rc = g_pS21NC->Open();

				while (rc == S21_NET_CallInProgress)
				{	usleep(DELAY_TIME);
					rc = g_pS21NC->GetCallStatus();
				}
				if (rc == S21_NET_NoErr)
				{	bIsOpen = TRUE;
					printf("OK\n");
				}
				else
					printf("ERROR: %d\n", rc);

			}
			else
				break;

			if (bIsOpen && NextStep("Get File Info"))
			{	S21_NET_RC rc = S21_NET_NoErr;
				S21_FILE_STATUS finfo;
				rc = g_pS21NC->GetFileInfo(&g_finfo);
				printf("File Info : ");
				while (rc == S21_NET_CallInProgress)
				{       usleep(DELAY_TIME);
						rc = g_pS21NC->GetCallStatus();
				}
				if (rc == S21_NET_NoErr)
				{	printf("OK\n");
					printf("-- type:%d, br:%d, size:"SFI64D", du:%d\n", g_finfo.mFmtType, g_finfo.bitRate, SPI64D(g_finfo.fileSize), g_finfo.durationInSec);
				// PBuffer = malloc(g_info.bitRate/8)
				}
				else
				{	printf("ERROR: %d\n", rc);
					break;
				}
			}

			if (bIsOpen && (g_nStartPos != 0) && NextStep("Seek To StartPos"))
			{	S21_NET_RC rc = S21_NET_NoErr;
				if (g_nStartPos < 0)
					rc = Seek(g_finfo.fileSize); //-(g_finfo.bitRate/8)*1);
				else if (!g_bBeginByTime)
					rc = Seek(g_nStartPos);
				else 
					rc = Seek((Int64 )g_nStartPos*(g_finfo.bitRate/8));
				if (rc == S21_NET_NoErr)
					printf("OK\n");
				else
					printf("ERROR: %d\n", rc);
			}
		}

		if (bIsOpen && g_bSaveContent)
		{	char fname[128];
			sprintf(fname, "%s%d.mpg", g_pOutFile, g_loop-loops);
			fp = FOPEN(fname, "wb");
  			if (fp) 
				printf("\nSave Stream To File '%s'\n", fname); 
		}

		// Streaming
		if (bIsOpen)
		{
			BOOL bPause = FALSE;
			Int64 i64TotalCount = 0;
			time_t nStartTime = time(NULL);
			unsigned long nRead = 0;
			unsigned long nDiscont = 0;
			unsigned long nLostData = 0; 
			Int64 i64CurPosition = 0;
			unsigned long nJumpCnt = 0;
			S21_NET_RC rc = S21_NET_NoErr;
			
			g_curSpeed = 1.0;

			SAMPLEDECODER_START;


			while (TRUE)
			{   
				// check UI
				if (kbhit() || g_nStartCmd != 0)
				{	int c = g_nStartCmd; 
					if (c == 0)
						c = getch();
					if (c == g_nStartCmd)
						g_nStartCmd = 0;
					if (c == 'q')
					{	
						usleep(50);
						break;
					}
					else if (c == 'i')
					{
						// Statistic
						printf("\nTotal bytes read: "SFI64D", pos= "SFI64D", data loss = %ld, jumpcnt = %ld\n", SPI64D(i64TotalCount), SPI64D(i64CurPosition), nLostData, nJumpCnt);
						time_t curtime = time(NULL);
						if (curtime != nStartTime)
							printf("Average bitrate: %u, %u\n", ((unsigned long)(i64TotalCount / (unsigned int)(time(NULL) - nStartTime))*8), g_finfo.bitRate);
						printf("Total time used: %02d:%02d:%02d / ", (curtime-nStartTime)/3600, ((curtime-nStartTime)/60)%60, (curtime-nStartTime)%60);
						unsigned long cliptime = (i64CurPosition/(g_finfo.bitRate/8));
						printf(" Clip time at: %02d:%02d:%02d\n", cliptime/3600 , (cliptime/60)%60, cliptime%60);
					}
					// unicast
					{
						if (c == 'p')
						{	
							if (bIsSeekbaseTrickPlay)
							{	g_pS21NC->SetStreamFilter(); // turn off FW or BW mode
								SAMPLEDECODER_SETTRICKMODE(0x07); // normal play
								SAMPLEDECODER_MUTE(false); // allow audio output
								bIsSeekbaseTrickPlay = FALSE;
							}
							SetSpeed(1.0);
							if (!bPause)
							{	printf(" Pause \n");
								bPause = TRUE;
							}
							else
							{	printf(" Play \n");
								bPause = FALSE;
							}
							g_nStartCmd = 'i';
						}
						else if (c == 'f')
						{	printf(" FF x4 \n");
							g_pS21NC->SetStreamFilter(S21NetClient::S21StreamFilter_SeekFW, (void *)4); // x4 speed 
							/* equal to above call
							unsigned long pdata[3];
							pdata[0] = 0;
							pdata[1] = 4; // speed x4
							pdata[2] = 0;
							g_pS21NC->SetStreamFilter(S21NetClient::S21StreamFilter_SeekFW, pdata); // x4 speed 
							*/
							SAMPLEDECODER_SETTRICKMODE(0x01); // i-frame only
							SAMPLEDECODER_MUTE(true); // disable audio output
							bIsSeekbaseTrickPlay = TRUE;
						}
						else if (c == 'b')
						{	printf(" FB \n");
							/*
							unsigned long pdata[3];
							pdata[0] = 2;
							pdata[1] = 2000000;
							pdata[2] = 2000000;
							g_pS21NC->SetStreamFilter(S21NetClient::S21StreamFilter_SeekBW, pdata); // normal speed
							*/
							g_pS21NC->SetStreamFilter(S21NetClient::S21StreamFilter_SeekBW, (void *)4); // x4 speed
							SAMPLEDECODER_SETTRICKMODE(0x01); // i-frame only
							SAMPLEDECODER_MUTE(true); // disable audio output
							bIsSeekbaseTrickPlay = TRUE;
						}
						else if (c == 'r')
						{	
							SetSpeed(-8.0);
						}
						else if (c == '+')
						{	
							if (g_curSpeed > 0)
								SetSpeed(g_curSpeed*2);
						}
						else if (c == '-')
						{	
							if (g_curSpeed >= 0.5)
								SetSpeed(g_curSpeed/2);
						}
						else if (c == 's')
						{	
							SetSpeed(1.0);
							if (!g_bJumpByTime)
								rc = Seek(i64CurPosition + (Int64)g_nJumpLength);
							else
								rc = Seek(i64CurPosition + (Int64)g_nJumpLength*(g_finfo.bitRate/8));
							if (rc == S21_NET_NoErr)
							{
								SAMPLEDECODER_BUFFLUSH;
							}
						}
						else if (c == 'w')
						{	
							// start from begining.
							SetSpeed(1.0);
							rc = Seek(0);
							if (rc == S21_NET_NoErr)
								SAMPLEDECODER_BUFFLUSH;
						}
						else if (isdigit(c))
						{
							int cv = c - 48;
							if (cv == 0)
							{	// normal play, 
								SetSpeed(1.0);
							}
							else if (cv <= 4 ) 
							{	// forward 1:x2, 2:x4, 3:x8, 4:x16
								SetSpeed(pow(2, cv));
							}
							else if (cv <= 8)
							{	// backward 5:x-2, 6:x-4, 7:x-8, 8:x-16
								SetSpeed(pow(2,(cv-4))*-1);
							}
							else // c == 9
							{	// slow 9:0.5
								SetSpeed(0.5);
							}
						}
					}
					//if (c == g_nStartCmd)
					//	g_nStartCmd = 0;
				}
				if (bPause)
				{	usleep(DELAY_TIME);
					continue;
				}

				unsigned long packet_size = PACKET_SIZE;

				if (g_bLimitByTime)
				{	// check time limit
					if (g_nMSeconds > 0)
					{
						time_t t = time(NULL);
						if (g_nMSeconds && (t - nStartTime > g_nMSeconds))
							break;
					}
				}
				else
				{	// check length limit
					if ((unsigned int)i64TotalCount >= g_nMLength) 
						break;
				}

				// copy data from internal buffer to caller's buffer

				int nTrickMode = 0;
				S21NetClient::S21StreamScale nCurScale;
				rc = g_pS21NC->Read(packet_size, (void *)(pBuffer), &nRead, &nDiscont, &i64CurPosition, &nTrickMode, &nCurScale);
                                if (nDiscont > 1){
                                        nLostData += nDiscont;
                                        printf("datalost %d/%d\n", nDiscont, nLostData);
                                }
				else if (nDiscont == 1)
				{
					nJumpCnt += nDiscont;
					nDiscont = 0;
					printf("JUMP "SFI64D"\n", SPI64D(i64CurPosition));
				}

#define TEST_TIME 1
#ifdef TEST_TIME
        static time_t last_time = 0;
        time_t current_time = time(NULL) - nStartTime - 1 ; //buffer time: 1

        if(current_time > 0 && current_time != last_time)
        {
                printf("\nread/total: "SFI64D" / "SFI64D", total bitrate: "SFI64D" / %d k\n",
                        SPI64D(i64CurPosition), SPI64D(g_finfo.fileSize),
                        i64CurPosition*8/current_time/1024, ((int)g_finfo.bitRate)/1024);
                last_time = current_time;
        }
#endif


				if (rc == S21_NET_NoErr)
				{	
					if (1)//(fp) //modified by Betta 
					{	int writesize = nRead; 
						if (!g_bLimitByTime)
						{	if (writesize > (g_nMLength - (unsigned int)i64TotalCount))
								writesize = g_nMLength - (unsigned int)i64TotalCount;
						}
		                		if (writesize > 0)
                                                {
                                                  tBuffer=pBuffer;
                                                  tLen=writesize;
                                                  sem_post(&Sigma_sem);
                                                  sem_wait(&S21_sem); //added by Betta 
                                                }
                                                else
                                                {
                                                   tLen=0;
                                                   sem_post(&Sigma_sem);
                                                }      


// marked by Betta							FWRITE(pBuffer, 1, writesize, fp);
					}
                                                                                    
					// check trick mode hint 
					if (nTrickMode)
					{
						if (nTrickMode & S21NetClient::S21TrickCmd_FlushBuf)
						{	// hint to flush decoder buffer
							printf(" cmd:FLUSH "); fflush(stdout);
							if (fp) 
							{
								// try to add a mark to tag for flushing point.
								char dummy[188];
								memset(dummy, 0xFF, 188);
								if (i64TotalCount%188)
									FWRITE(dummy, 1, 188-(i64TotalCount%188), fp); // to mend for incomplete packets
								dummy[0] = 0x47;
								dummy[1] = 0x1F;
								dummy[2] = 0xFF;
								dummy[3] = 0x00;
								strcpy(dummy+4, " FLUSH ");
								FWRITE(dummy, 1, 188, fp);
							}
							// flush decoder buffer to drop incompleted frame hold by decoder.
							SAMPLEDECODER_BUFFLUSH;
						}
						if (nTrickMode | S21NetClient::S21TrickCmd_AllFrame)
						{	// hint for frame types contains in this read
							// I:0x01, P:0x02, B:0x04, IP:0x03, IPB:0x07
							// decoder must enter to trick mode for hinted types
							if (g_bVerbose)
								printf("%s%d", ((nTrickMode&S21NetClient::S21TrickCmd_Reverse)?"-":""),  nTrickMode&S21NetClient::S21TrickCmd_AllFrame);

							if (g_bCheck188Align)
							{
								int packetindex = 0;
								int packetstart = 0;
								if (i64CurPosition > 0)
									packetstart = (188 - ((i64CurPosition-nRead)%188))%188;
								packetindex = 0;
								while (packetstart+packetindex*188 < nRead)
								{
									if (((char *)pBuffer)[packetstart + 188*packetindex] != 0x47)
									{	
										printf("TS packet sync byte (%02X) not found at at "SFI64D", abort\n", ((char *)pBuffer)[packetstart+188*packetindex], SPI64D((i64CurPosition-nRead+ packetstart+188*packetindex)) );
										break;
									}
									packetindex++;
								}
							}
							fflush(stdout);
						}
					}   

					// check scale change
					if (ScaleToSpeed(nCurScale) != g_curSpeed)
					{
						printf("\n Speed from %03f to %03f! ", g_curSpeed, ScaleToSpeed(nCurScale));
						g_curSpeed = ScaleToSpeed(nCurScale);

						// mute for trick play
						if (g_curSpeed != 1) 
							SAMPLEDECODER_MUTE(true);
						else
							SAMPLEDECODER_MUTE(false);


						 // decoder enter to trick play mode
						if (g_curSpeed > 0 && g_curSpeed < 1)
							// slow motion, use IBP frame mode, actually, should turn on framerate control to lower frame rate 
							SAMPLEDECODER_SETTRICKMODE(0x07);
						else if ((int )g_curSpeed%8 == 0)
							// x8, x16, x-8, x-16, use I frame mode
							SAMPLEDECODER_SETTRICKMODE((g_curSpeed > 0)? 0x01:0x11);
						else if ((int )g_curSpeed%2 == 0)
							// x2, x4, x-2, x-4, use IP frame mode, better turn on framerate control to control rate at 15~10 fps
							SAMPLEDECODER_SETTRICKMODE((g_curSpeed > 0)? 0x03:0x13);
						else
							// x1, use IBP frame mode
							SAMPLEDECODER_SETTRICKMODE(0x07);
					}

					i64TotalCount = i64TotalCount + (int )nRead;
					if (nDiscont) printf("\nDiscontinue : %d, pos= "SFI64D"\n", nDiscont, SPI64D(i64CurPosition));

					if (nRead)
						SAMPLEDECODER_BUFPUSH(pBuffer, nRead);
					 if (nRead == 0)
					 {
					    printf("Read=0 and Delay:%d\n", DELAY_TIME*4); 
					    usleep(DELAY_TIME*4);
					  }
					  else
					    usleep(DELAY_TIME);
					  continue;
				} 
				else if (rc == S21_NET_StmNotReady || rc == S21_NET_CallInProgress) 
				{
					usleep(DELAY_TIME*4); //usleep(DELAY_TIME*4);
					continue;
				}
				else if (rc == S21_NET_EndOfStream)
				{	
					if (g_curSpeed < 0)
					{
						// reverse play reach to the begining of file, resume nomral play from start
						SetSpeed(1.0);
						Seek(0);
						SAMPLEDECODER_BUFFLUSH;
					}
					else
					{
						//usleep(DELAY_TIME*8);
						break;
					}
				}
				else if (rc != S21_NET_NoErr)
				{
					break;
				}
			}
			if (rc == S21_NET_EndOfStream)
				printf("End Of Stream\n");
			else if (rc == S21_NET_NoErr)
				printf("Time Limit Reached\n");
			else 
				printf("ERROR: %d\n", rc);

			// Statistic
			printf("\nTotal bytes read: "SFI64D", pos= "SFI64D", data loss = %ld, jumpcnt = %ld\n", SPI64D(i64TotalCount), SPI64D(i64CurPosition), nLostData, nJumpCnt);
			time_t curtime = time(NULL);
			if (curtime != nStartTime)
				printf("Average bitrate: %u, %u\n", ((unsigned long)(i64TotalCount / (unsigned int)(time(NULL) - nStartTime))*8), g_finfo.bitRate);
			printf("Total time used: %02d:%02d:%02d / ", (curtime-nStartTime)/3600, ((curtime-nStartTime)/60)%60, (curtime-nStartTime)%60);
			unsigned long cliptime = (i64CurPosition/(g_finfo.bitRate/8));
			printf(" Clip time at: %02d:%02d:%02d\n", cliptime/3600 , (cliptime/60)%60, cliptime%60);
		}

		if (fp)
		{	printf("\nClose File\n"); 
			FCLOSE(fp);
		}

		// Close Stream
		if (bIsOpen)
		{	
			SAMPLEDECODER_STOP;

			if (g_bAutoRewind && loops > 1)
			{	// Auto rewind
				sprintf(msg, "Auto rewind %d/%d", g_loop-loops, g_urlCnt);
				NextStep(msg);
			}
			else
			{	// Close stream
				NextStep("Close Stream");
				S21_NET_RC rc;
				rc = g_pS21NC->Close();
				while (rc == S21_NET_CallInProgress)
				{	usleep(DELAY_TIME);
					rc = g_pS21NC->GetCallStatus();
				}
				if (rc == S21_NET_NoErr)
				{	bIsOpen = FALSE;
					printf("OK\n");
				}
				else
					printf("ERROR: %d\n", rc);
			}
		}
	} while (--loops > 0);

	SAMPLEDECODER_UNINIT;

	if (pBuffer) delete pBuffer;

	return 1;
}

double ScaleToSpeed(S21NetClient::S21StreamScale scale)
{	double speed = 0.0;
	if (scale >= 100)
		speed = (double )scale / 1000;
	else
		speed = (double )scale;
	return speed;
}

S21NetClient::S21StreamScale SpeedToScale(double nSpeed)
{
	int scale = 1;
	if (nSpeed<1 && nSpeed>0)
		scale = (int) (nSpeed*1000);
	else
		scale = (int) nSpeed;
	return (S21NetClient::S21StreamScale )scale;
}

S21_NET_RC SetSpeed(double nSpeed)
{
	if (nSpeed > 0 && (nSpeed < 0.125 || nSpeed > 16))
		return S21_NET_NoErr;
	if (nSpeed <= 0 && (nSpeed > -2 || nSpeed < -16))
		return S21_NET_NoErr;
	if (g_curSpeed == nSpeed)
		return S21_NET_NoErr;
	printf("\nSet Speed %0.3f to %0.3f...", g_curSpeed, nSpeed);

	S21_NET_RC rc = g_pS21NC->SetStreamScale(SpeedToScale(nSpeed));
	if (rc != S21_NET_NoErr)
		printf("ERROR: %d\n", rc);
   return rc;
}

S21_NET_RC Seek(Int64 nPos)
{
	printf("Seek to "SFI64D"...", SPI64D(nPos));
	S21_NET_RC rc = g_pS21NC->Seek(nPos);

	while (rc == S21_NET_CallInProgress)
	{	usleep(DELAY_TIME*4);
		rc = g_pS21NC->GetCallStatus();
	}
	if (rc == S21_NET_NoErr)
		printf("OK\n");
	else
		printf("ERROR: %d\n", rc);
   return rc;
}


int S21_main(int argc, char **argv)
{
	BOOL bIsModule = FALSE;
	BOOL bIsInterface = FALSE;
	BOOL bIsInitial = FALSE;
	BOOL bIsConnect = FALSE;
	BOOL bIsLogin = FALSE; 
	BOOL bIsURLReady = FALSE;

	g_urlCnt = 0;
	g_loop = 0;
	g_curSpeed = 1.0;

	g_bQuick = FALSE;
	g_bStep = FALSE;
 	g_bSaveContent = FALSE;
	g_pOutFile = DEFAULT_OUTPUT;
	g_bAutoRewind = FALSE;
	g_bLimitByTime = TRUE;
	g_nMSeconds = -1;
	g_nMLength = 0;
	g_nStartPos = 0;
	g_bBeginByTime = FALSE;
	g_nJumpLength = 16000000;
	g_bJumpByTime = FALSE;
	g_nStartCmd = 0;
	g_pS21NC = NULL;
	g_bCheck188Align = 0;
	g_bVerbose = 1;

	// Parse CommandLine
	if (!Parse_Command(argc, argv))
		return 0;

	printf("\n***** S21 Net Client SDK 5.0 Sample Program *****\n");


	// Load Module
	if (NextStep("Load Module"))
	{
		if (S21EmbeddedClientModule::Load())
		{	printf("OK\n");
			bIsModule = TRUE;
		}
		else
		{	printf("Cannot load module, please check if module exists\n");
			return 0;
		}
	}
	
	// Get Interface
	if (bIsModule && NextStep("Get S21NetClient Interface"))
	{
		g_pS21NC = S21NetClient::CreateInstance();
		if (g_pS21NC)
		{	printf("OK\n");
			bIsInterface = TRUE;
		}
		else
			printf("Cannot get interface\n");
	}

	// Initialize
	if (bIsInterface && NextStep("Initialize"))
	{
		S21_NET_RC rc = g_pS21NC->Initialize();
		if (rc == S21_NET_NoErr)
		{	printf("OK\n");
			bIsInitial = TRUE;
		}
		else
			printf("ERROR: %d\n", rc);
	}

	// Quick Set by Url
	if (g_bQuick &&  NextStep("Quick Set By Url"))
	{
		S21Url *url = S21Url::CreateInstance();
		//Gavin 2005-12-01
		char sVersion[50];
		url->GetSDKVersion(sVersion);
		printf("\n******S21 SDK Version is:%s********\n",sVersion);
		//Gavin end

		url->SetBackupServer(); // reset
		url->SetDefaultUser(USERNAME, PASSWORD);
		url->Parse(g_url[0], TRUE, TRUE, 1);
		if (!url->IsValid())
			printf("ERROR: url format is invalid\n");
		else
		{	S21_NET_RC rc = g_pS21NC->QuickSetByUrl(url);
			// equal to this API call :
			//		S21_NET_RC rc = g_pS21NC->QuickSetByUrl(g_url, "", 0, USERNAME, PASSWORD, TRUE, 1);
			if (rc == S21_NET_NoErr)
			{	printf("OK\n");
				bIsURLReady =  TRUE;
			}
			else
				printf("ERROR: %d\n", rc);
		}
		S21Url::ReleaseInstance(url);
	}

	if (bIsURLReady)
	{	// Open Stream
		OpenStream();
	}

	// Uninitialize
	if (bIsInitial)
	{	NextStep("Uninitialize");
		S21_NET_RC rc = g_pS21NC->Uninitialize();
		if (rc == S21_NET_NoErr)
			printf("OK\n");
		else
			printf("ERROR: %d\n", rc);
	}

	// Release Interface	
	S21NetClient::ReleaseInstance(g_pS21NC);

	// Release Module 
	S21EmbeddedClientModule::Unload();

	printf("\n***** Enter Any Key To Exit *****\n");
	//getchar();

	return 0;
}

