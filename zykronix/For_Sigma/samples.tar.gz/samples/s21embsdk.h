//-------------------------------------------------------------------------
//
//	Copyright (c)  2000 - 2004  Streaming21 Inc. All rights reserved.
//
//	ALL RIGHTS RESERVED. NO PART OF THIS CODE AND INFORMATION MAY BE 
//	REUSED, REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY MEANS,
//	WITHOUT WRITTEN PERMISSION FROM THE COMPANY.
//
//	Description : S21 Stream API 
//
//-------------------------------------------------------------------------

#ifndef __S21EMBSDK_H_
#define __S21EMBSDK_H_

// [S21EmbeddedClientModule example in psuedo code]
//
// .... // Load S21 SDK Module and setup runtime resource
// S21EmbeddedClientModule::Load();
// .... // check if load is successful
// if (!S21EmbeddedClientModule::IsLoaded())
// { .... // error handling
// }
// else
// { .... // it's valid to use S21 SDK API : S21NetClient, S21Url, ...
//   .... // release module while API is no longer used
//   S21EmbeddedClientModule::Unload();
// }
//

class S21EmbeddedClientModule
{
private :
	static void *mContext;
public :
	static void *GetContext();

public:
	S21EmbeddedClientModule();
	~S21EmbeddedClientModule();

	static BOOL IsLoaded();
	static BOOL Load();
	static BOOL Unload();
};

#endif
