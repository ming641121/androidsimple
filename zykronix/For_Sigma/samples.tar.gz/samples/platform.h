//-------------------------------------------------------------------------
//
//	Copyright (c)    2000 - 2004 Streaming21 Inc. All rights reserved.
//
//	ALL RIGHTS RESERVED. NO PART OF THIS CODE AND INFORMATION MAY BE 
//	REUSED, REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY MEANS,
//	WITHOUT WRITTEN PERMISSION FROM THE COMPANY, UNLESS EXPRESSLY PROVIDED
//  FOR UNDER THE TERMS OF A MUTUALLY EXECUTED WRITTEN LICENSE AGREEMENT
//  FOR THIS SOFTWARE BETWEEN THE END-USER AND STREAMING21, OR OTHERWISE 
//  EXPRESSLY AUTHORIZED IN WRITING BY STREAMING21.

//
//	Description : Sample Program
//
//-------------------------------------------------------------------------

#ifdef _S21OS_LINUX_
#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#ifdef _S21OS_LINUX_
// millisecond usleep
#include <unistd.h>
#ifdef _S21OS_UCLINUX_
#define usleep(x) { struct timespec xt; xt.tv_sec = x/1000; xt.tv_nsec = (x%1000)*1000000; nanosleep(&xt, &xt);}
#endif                          
#endif

#define SFI64D "%lld"
#define SPI64D(x) (x)

int kbhit();
#define getch() fgetc(stdin)

// file open
#define FILEID FILE *
#define FOPEN(a,b) fopen(a,b)
#define FCLOSE(x) fclose(x)
#define FWRITE(a,b,c, d) fwrite(a,b,c,d)

// psudo decoder
// -- _init(size_t bufsize, size_t bufcnt, int type)
#define SAMPLEDECODER_INIT(bufsize, bufcnt, type)
#define SAMPLEDECODER_UNINIT
#define SAMPLEDECODER_START
#define SAMPLEDECODER_STOP
// -- _mute(bool on)
#define SAMPLEDECODER_MUTE(on)
#define SAMPLEDECODER_FREEZE(on)
#define SAMPLEDECODER_BUFFLUSH
// -- _bufpush(char *bufptr, size_t bufsize)
#define SAMPLEDECODER_BUFPUSH(bufptr, bufsize)
// -- _settrickmode(int mode) : 0x07:normal, 0x03:IP, 0x01:I, 0x10:reverse
#define SAMPLEDECODER_SETTRICKMODE(mode)

#endif
#endif
