//-------------------------------------------------------------------------
//
//	Copyright (c)    2000 - 2004 Streaming21 Inc. All rights reserved.
//
//	ALL RIGHTS RESERVED. NO PART OF THIS CODE AND INFORMATION MAY BE 
//	REUSED, REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY MEANS,
//	WITHOUT WRITTEN PERMISSION FROM THE COMPANY, UNLESS EXPRESSLY PROVIDED
//  FOR UNDER THE TERMS OF A MUTUALLY EXECUTED WRITTEN LICENSE AGREEMENT
//  FOR THIS SOFTWARE BETWEEN THE END-USER AND STREAMING21, OR OTHERWISE 
//  EXPRESSLY AUTHORIZED IN WRITING BY STREAMING21.
//
//	Description : Sample Program
//
//-------------------------------------------------------------------------

#ifdef _S21OS_LINUX_
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/time.h>

class dup_stdin
{
public:
	int orgflags;
	dup_stdin() 
	{ 
		orgflags = fcntl(STDIN_FILENO, F_GETFL, 0);
  		// If reading the flags failed, return error indication now.
 		if (orgflags == -1)
    			return;
  		fcntl(STDIN_FILENO, F_SETFL, orgflags|O_NONBLOCK);           
  	}
	~dup_stdin()
	{	if (orgflags >= 0)
			fcntl(STDIN_FILENO, F_SETFL, orgflags);
	}
};

int kbhit()
{
	dup_stdin ADupStdin;
	ssize_t rc = 0;
	char c = 0;
	rc = read(STDIN_FILENO, &c, sizeof(c));
	
	if (rc == 1)
	{	ungetc(c, stdin);
		return 1;
	}
	else
		return 0;
}

#endif
