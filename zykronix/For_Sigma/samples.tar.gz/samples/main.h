#include <pthread.h>
#include <semaphore.h>
extern char *tBuffer;
extern unsigned long tLen;
extern sem_t S21_sem, Sigma_sem;
extern bool fgSigmaReady;
extern int play_demux_TS(int, char **);
extern int  S21_main(int, char **);                                                                                                         
extern void *Sigma_threadfunction(void *arg);

