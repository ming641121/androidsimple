/*****************************************
 Copyright © 2001-2003  
 Sigma Designs, Inc. All Rights Reserved
 Proprietary and Confidential
 *****************************************/
/**
  @file   cmdline_options.h
  @brief  

  Structs, init and parse functions for the options given
  to the sample apps.
  
  @author Oriol Prieto
  @date   2005-03-16
*/

#ifndef __CMDLINE_OPTIONS_H__
#define __CMDLINE_OPTIONS_H__

#ifndef ALLOW_OS_CODE
#define ALLOW_OS_CODE
#endif 
#include "rmdef/rmdef.h"

RM_EXTERN_C_BLOCKSTART

enum OutputChannels_type{
	Channel_C = 0x01,
	Channel_LR = 0x02,
	Channel_LCR = 0x03,
	Channel_LRS = 0x12,
	Channel_LCRS = 0x13,
	Channel_LRLsRs = 0x22,
	Channel_LCRLsRs = 0x23
};

struct osd_picture_info{
	RMbool enable;
	RMascii *filename;
	RMuint32 dramblock;
	RMuint32 alpha;
	RMbool zoom;
	RMuint32 scaler;
	enum DCCRoute route;
	struct EMhwlibDisplayWindow source_window;
	struct EMhwlibDisplayWindow output_window;
	enum PictureOrientation orientation;
	struct EMhwlibNonLinearScalingMode nonlinearmode;
	struct EMhwlibBlackStripMode blackstrip;
};
	

struct display_cmdline {
	enum EMhwlibTVStandard standard;
	enum EMhwlibTVStandard vga_standard;
	enum DCCVideoConnector connector;
	enum EMhwlibComponentMode component;
	enum EMhwlibColorSpace color_space;
	RMuint32 bus_size;
	RMuint8 ar_x;
	RMuint8 ar_y;
	struct EMhwlibDisplayWindow source_window;
	struct EMhwlibDisplayWindow output_window;
	struct osd_picture_info osd_pictures[2];
	RMuint32 agc_level;
	RMuint32 cgmsa;
	RMascii *dump_osd_dir;

	enum EMhwlibComponentOrder component_order;
	enum EMhwlibScalerFieldSelection field_selection;
	enum DH_vendor_parts dvi_hdmi_part;
	enum DH_device_state dvi_hdmi_state;
	RMbool dvi_hdmi_hdcp;
	RMbool dvi_hdmi_display_edid;
	RMuint32 dvi_hdmi_edid_descriptor;
	struct EMhwlibNonLinearScalingMode nonlinearmode;
	struct EMhwlibBlackStripMode blackstrip;
	enum EMhwlibScalingMode scalingmode;
	enum EMhwlibDeinterlacingMode deinterlacingmode;
	RMuint32 color_degradation_boundary;
	RMbool show_hwc;
	enum DCCInitMode init_mode;
	enum EMhwlibDigitalTimingSignal dig_protocol;
	RMbool dig_clk_normal;
	RMbool scart_enable;
	RMuint32 scart_en_pio;
	RMbool scart_widescreen;
	RMuint32 scart_ws_pio;
};

struct capture_cmdline {
	enum EMhwlibTVStandard TVStandard;
	RMbool guess;  // guess the TV standard
	RMuint32 dram;  // number of the DRAM bank to use
	enum EMhwlibColorSpace ColorSpace;
	enum EMhwlibSamplingMode SamplingMode;
	enum EMhwlibColorMode ColorMode;
	enum EMhwlibInputColorFormat InputColorFormat;
	RMuint32 InputModuleID;
	enum EMhwlibDigitalTimingSignal DigitalTimingSignal;
	RMbool UseVideoValid;
	RMuint32 bussize;
	RMbool DualEdge;
	RMbool DualEdgeInvert;
	RMbool InvertVSync;
	RMbool InvertHSync;
	RMint32 over_pos_x;  // shifting of the capture frame on the input field
	RMint32 over_pos_y;
	RMuint32 over_width;  // how much to add for overscan capture
	RMuint32 over_height;
	// intermediate params to calc over_xxx
	RMint32 shift_x;  // shifting of the capture frame on the input field
	RMint32 shift_y;
	RMuint32 ov_top;  // how much to add for overscan capture
	RMuint32 ov_bot;
	RMuint32 ov_lft;
	RMuint32 ov_rgt;
	struct EMhwlibAspectRatio PictureAspectRatio; 
	RMbool DeInt;
	RMuint32 vbi_x;
	RMuint32 vbi_y;
	RMuint32 vbi_w;
	RMuint32 vbi_h;
	RMuint32 vbiraw_topstart;
	RMuint32 vbiraw_topmask;
	RMuint32 vbiraw_botstart;
	RMuint32 vbiraw_botmask;
	RMbool vbianc_enable;
	RMuint32 vbianc_w;
	RMuint32 vbianc_h;
	RMuint32 vbianc_ytop;
	RMuint32 vbianc_ybot;
	RMuint32 vbi_buf;
	RMuint32 vbi_size;
};

struct video_cmdline {
	enum MPEG_Profile MPEGProfile;
	enum VideoDecoder_Codec_type Codec;
	struct VideoDecoder_VopInfo_type VopInfo;
	struct VideoDecoder_VideoTimeScale_type vtimescale;
	RMuint8 dram;
	enum EMhwlibColorSpace input_color_space;
	RMbool force_input_color_space;
	RMbool display_cc;
	RMuint8 use_soft_cc_decoder; /* 0: no soft decoder 1: eia608 2: eia 708 */
};

struct audio_cmdline {
	RMuint32 ae;
	enum AudioDecoder_Codec_type Codec;
	RMuint32 SubCodec;
	RMuint32 SampleRate;
	RMuint32 SamplingFrequency;	/* input frequency of the audio stream. Used only for pcm files */
	RMbool ForceSampleRate;
	RMuint32 CaptureSource;
	RMuint32 CaptureType;
	RMuint32 CaptureDelay;
	RMbool SerialOut;
	RMbool ExternalClk;
 	RMbool AudioIn;
 	RMuint32 AudioInAlign;
 	RMbool AudioInLSBfirst;
 	RMuint32 I2SAlign;
 	RMbool I2SSClkNormal;
 	RMbool I2SFrameNormal;
 	RMbool I2SLSBFirst;
 	RMbool I2S16Bit;
	enum OutputSpdif_type Spdif;	// it should go in every specific Params structure
	enum OutputDualMode_type OutputDualMode;
	enum OutputChannels_type OutputChannels;
	struct AudioDecoder_AACParameters_type AACParams;
	RMbool OutputLfe;
	struct AudioDecoder_Ac3Parameters_type Ac3Params;
	struct AudioDecoder_DtsParameters_type DtsParams;
	struct AudioDecoder_MpegParameters_type MpegParams;
	struct AudioDecoder_LpcmVobParameters_type LpcmVobParams;
	struct AudioDecoder_LpcmAobParameters_type LpcmAobParams;
	struct AudioDecoder_PcmCdaParameters_type PcmCdaParams;
	struct AudioDecoder_WMAParameters_type	WmaParams;
};

struct playback_cmdline {
	RMascii *filename;
	RMuint32 chip_num;
	RMuint32 loop_count;
	RMuint64 duration; /*in ms*/
	RMbool infinite_loop;
	RMbool waitexit;
	RMbool manutest;
	RMbool send_video;
	RMbool send_audio;
	RMbool send_spu;
	RMbool send_video_pts;
	RMbool send_audio_pts;
	RMbool send_spu_pts;
	RMbool save_video;
	int f_video_data;
	int f_video_pts;
	RMuint32 video_byte_count;
	RMbool save_audio;
	int f_audio_data;
	int f_audio_pts;
	RMuint32 audio_byte_count;
	RMbool save_spu;
	int f_spu_data;
	int f_spu_pts;
	RMuint32 spu_byte_count;
	RMint32 speed_N;
	RMuint32 speed_M;
	RMuint8 dram;
	RMuint32 start_ms;
	RMbool start_pause;
	RMascii *bcc_filename;
	RMbool stc_compensation;
	RMuint32 stc_comp_debug;
	RMbool require_video_audio;
	RMint32 audio_delay_ms;
	RMint32 video_delay_ms;
};

struct demux_cmdline {
	RMsystemType system_type;
	RMvdemuxDataType data_type;
	RMbool repack_sample;
	RMuint32 video_pid;
	RMuint32 audio_pid;
	RMuint32 audio_subid;
	RMuint32 spu_subid;
};

RMstatus init_playback_options(struct playback_cmdline *options);
RMstatus init_display_options(struct display_cmdline *options);
RMstatus init_video_options(struct video_cmdline *options);
RMstatus init_audio_options(struct audio_cmdline *options);
RMstatus init_capture_options(struct capture_cmdline *options);

RMstatus parse_playback_cmdline(int argc, char **argv, int *index, struct playback_cmdline *options);
RMstatus parse_display_cmdline (int argc, char **argv, int *index, struct display_cmdline *options);
RMstatus parse_video_cmdline   (int argc, char **argv, int *index, struct video_cmdline *options);
RMstatus parse_audio_cmdline   (int argc, char **argv, int *index, struct audio_cmdline *options);
RMstatus parse_capture_cmdline (int argc, char **argv, int *index, struct capture_cmdline *options);
RMstatus parse_wmapro_intermediate(RMfile file, struct AudioDecoder_WMAParameters_type *options);
enum OutputChannels_type get_channel_mask(const RMascii* szValue);

RM_EXTERN_C_BLOCKEND

#endif // __CMDLINE_OPTIONS_H__
