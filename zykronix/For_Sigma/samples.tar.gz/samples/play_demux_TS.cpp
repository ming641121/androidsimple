/*
 *
 * Copyright (c) Sigma Designs, Inc. 2002. All rights reserved.
 *
 */

/**
	@file dcc_demo.c
	@brief sample application to access the Mambo chip and test DMA transfers
	
	@author Julien Soulier
   	@ingroup dccsamplecode
*/
/************************************************************/
#include "sample_os.h"
                                                                                #include "main.h"                               
extern sem_t S21_sem, Sigma_sem;
/*************************************************************/
#define ALLOW_OS_CODE 1
#include "../dcc/include/dcc.h"
#include "../rmvdemux/include/rmvdemuxapi.h"
#include "common.h"

#define CHECK_HDCP_INTEGRITY		/* defined to check HDCP integrity */

#define PTS_DISCONTINUITY_DETECTION	/* defined for files with pts discontinuities */

#define GETBUFFER_TIMEOUT_US 100000
#define WAIT_EOS_TIMEOUT_US 20000000
#define WAIT_COMMAND_TIMEOUT_US 100000
#define DMA_BUFFER_SIZE_LOG2 15
#define DMA_BUFFER_COUNT     32
#define SENDDATA_TIMEOUT_US 100000
#define REPACK_SIZE (4096)

#define VIDEO_FIFO_SIZE (1024*1024)
#define AUDIO_FIFO_SIZE (128*1024)
#define SPU_FIFO_SIZE   (256*1024)
#define XFER_FIFO_COUNT (32)

#define RM_DEVICES_STC 0x1
#define RM_DEVICES_VIDEO 0x2
#define RM_DEVICES_AUDIO 0x4

#define KEYFLAGS (SET_KEY_DISPLAY | SET_KEY_PLAYBACK | SET_KEY_AUDIO | SET_KEY_DEBUG)

#define PTS_DISCONTINUITY_RANGE	0x20000	// ~1.4sec

#if 0
  #define SENDDBG ENABLE
#else
  #define SENDDBG DISABLE
#endif


#define WAIT_KEY()						\
{								\
	RMascii key;						\
	fprintf(stderr, "press key to continue\n");	        \
	while ( !(RMGetKeyNoWait(&key)) );			\
}							


#define GET_XFER_FIFO_INFO(pRUA, ModuleId)										\
{															\
	struct XferFIFOInfo_type XferFIFOInfo;										\
	fprintf(stderr, "( %lx: 0x%08lx %ld %ld %ld %ld ) ", ModuleId, XferFIFOInfo.StartAddress,          		\
		    XferFIFOInfo.Size, XferFIFOInfo.Writable,  XferFIFOInfo.Readable, XferFIFOInfo.Erasable);		\
	RUAGetProperty(pRUA, ModuleId, RMGenericPropertyID_XferFIFOInfo, &XferFIFOInfo, sizeof(XferFIFOInfo));		\
}														




//end



extern int verbose_stdout;
extern int verbose_stderr;
extern RMbool manutest;

static RMbool enable_spu = FALSE;
static RMuint32 NTimes = 0;
static RMuint32 file_offset = 0;
static RMbool user_data_test = FALSE;

//static RMuint32 trickBuffersToSend = 0; //marked by Betta
//static RMuint32 trickSizeToSend = 0; //marked by Betta
//static RMuint32 trickBuffersSent = 0; //marked by Betta
//static RMuint32 prev_trickmode;

static struct playback_cmdline *play_opt;
static struct video_cmdline *video_opt;
static struct audio_cmdline *audio_opt;
static struct demux_cmdline *demux_opt;



#ifndef WITH_MONO
static struct display_cmdline *disp_opt;
#endif


struct demux_context {
	struct RUA *pRUA;
	struct RUABufferPool *pDMA;
	RMbool FirstSystemTimeStamp;
	RMbool ResumeFromTrickMode;
	RMbool TrickModeTransition;
	RMbool IFrameTrickMode;
	RMuint32 prev_IFrameTrickMode;
	RMuint32 audio_byte_counter;
	RMuint32 video_byte_counter;
	RMbool repack_sample;
	RMuint8 *audio_repack_buf;
	RMuint8 *video_repack_buf;
	RMuint8 *spu_repack_buf;
	RMuint32 audio_repack_offset;
	RMuint32 video_repack_offset;
	RMuint32 spu_repack_offset;
	RMuint32 audio_repack_size;
	RMuint32 video_repack_size;
	RMuint32 spu_repack_size;
	RMuint64 audio_repack_pts;
	RMuint64 video_repack_pts;
	RMuint64 spu_repack_pts;
	RMbool audio_repack_pts_valid;
	RMbool video_repack_pts_valid;
	RMbool spu_repack_pts_valid;
	RMbool enable_spu;

	struct dcc_context *dcc_info;
	struct RM_PSM_Context   *PSMcontext;

	RMbool isTrickMode;
	RMbool isIFrameMode;
	RMbool initVideo;
	RMbool initAudio;

	RMbool waitForValidAudioPTS;

	RMuint32 cmd;
	RMuint32 audio_first_access_unit_pointer;	// a value of 0 is invalid - see DVD VI.5.2.4
	RMbool audio_first_access_unit_pointer_valid;
	
	// Check for HDCP unplugged devices
	RMuint32 hdcp_last_check;

	RMuint32 start_90khz;
	RMint64 file_size;
	// test user data receive
	struct ReceiveObject_type *pReceive;
	struct RUABufferPool *pDmaUserData;
	struct RUAEvent EventUserData;
	FILE *f_record;
	RMuint32 f_record_size;

	RMbool ignoreCallback;
	RMbool fakePrevPts;

	RMbool STCrunning; // for prebuffering
};

static RMstatus SyncTimerWithDecoderPTS(struct demux_context *pSendContext);


#define REPACK_AUDIO  1
#define REPACK_VIDEO  2
#define REPACK_SPU    4
#define REPACK_ALL    7

static void release_repacked_buffers(void *context, RMuint32 flag)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	
	if ((flag & REPACK_VIDEO) & (pSendContext->video_repack_buf != NULL)) {
		RUAReleaseBuffer(pSendContext->pDMA, pSendContext->video_repack_buf);
		pSendContext->video_repack_buf = (RMuint8 *) NULL;
		pSendContext->video_repack_offset = 0;
		pSendContext->video_repack_size = 0;
		pSendContext->video_repack_pts = 0;
		pSendContext->video_repack_pts_valid = FALSE;
	}

	if ((flag & REPACK_AUDIO) && (pSendContext->audio_repack_buf != NULL)) {
		RUAReleaseBuffer(pSendContext->pDMA, pSendContext->audio_repack_buf);
		pSendContext->audio_repack_buf = (RMuint8 *) NULL;
		pSendContext->audio_repack_offset = 0;
		pSendContext->audio_repack_size = 0;
		pSendContext->audio_repack_pts = 0;
		pSendContext->audio_repack_pts_valid = FALSE;
	}

	if ((flag & REPACK_SPU) && (pSendContext->spu_repack_buf != NULL)) {
		RUAReleaseBuffer(pSendContext->pDMA, pSendContext->spu_repack_buf);	
		pSendContext->spu_repack_buf = (RMuint8 *) NULL;
		pSendContext->spu_repack_offset = 0;
		pSendContext->spu_repack_size = 0;
		pSendContext->spu_repack_pts = 0;
		pSendContext->spu_repack_pts_valid = FALSE;
	}
}

enum goto_state {
	LABEL_ERROR = 1,
	LABEL_NONE,
	LABEL_QUIT,
	LABEL_STOP,
	LABEL_STOP_SEEK_ZERO
};

#if 0
static enum goto_state local_process_key(struct demux_context *pSendContext,  RMbool release)
{
	RMstatus err = RM_OK;
	enum goto_state label = LABEL_NONE;

	pSendContext->prev_IFrameTrickMode = pSendContext->IFrameTrickMode;


	pSendContext->cmd = RM_UNKNOWN;
	//err = process_key(pSendContext->dcc_info, &(pSendContext->cmd), KEYFLAGS);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error while processing key %d\n", err));
		label = LABEL_ERROR;
		goto exit_process_key;
	}

	if (pSendContext->cmd == RM_UNKNOWN) {
		label = LABEL_NONE;
		goto exit_process_key;
	}

	if(pSendContext->cmd == RM_DUALMODE_CHANGE) {
		fprintf(stderr, "Changing DualMode to :");
		switch(audio_opt->OutputDualMode) {
		case DualMode_LeftMono:
			fprintf(stderr, " RightMono\n");
			audio_opt->OutputDualMode = DualMode_RightMono;
			break;
		case DualMode_RightMono:
			fprintf(stderr, " MixMono\n");
			audio_opt->OutputDualMode = DualMode_MixMono;
			break;
		case DualMode_MixMono:
			fprintf(stderr, " Stereo\n");
			audio_opt->OutputDualMode = DualMode_Stereo;
			break;
		case DualMode_Stereo:
			fprintf(stderr, " LeftMono\n");
			audio_opt->OutputDualMode = DualMode_LeftMono;
			break;
		default:
			fprintf(stderr, " Unknown dual mode\n");
			break;
		}
		err = apply_audio_decoder_options_onthefly(pSendContext->dcc_info,audio_opt);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error applying audio decoder options on the fly %d\n", err));
			label = LABEL_ERROR;
			goto exit_process_key;
		}
	}
	if (pSendContext->cmd == RM_QUIT) {
		if ((release) && (pSendContext->repack_sample))
			release_repacked_buffers(pSendContext, REPACK_ALL);
		label =  LABEL_QUIT;
		goto exit_process_key;
	}
	if ((manutest == TRUE) && (pSendContext->cmd == RM_MANU_QUIT_OK)) {
		if ((release) && (pSendContext->repack_sample))
			release_repacked_buffers(pSendContext, REPACK_ALL);
		label =  LABEL_QUIT;
		goto exit_process_key;
	}
	if (pSendContext->cmd == RM_STOP) {
		if ((release) && (pSendContext->repack_sample))
			release_repacked_buffers(pSendContext, REPACK_ALL);
		label = LABEL_STOP; 
		goto exit_process_key;
	}
	if (pSendContext->cmd == RM_STOP_SEEK_ZERO) {
		if ((release) && (pSendContext->repack_sample))
			release_repacked_buffers(pSendContext, REPACK_ALL);
		label = LABEL_STOP_SEEK_ZERO; 
		goto exit_process_key;
	}
	if (pSendContext->dcc_info->state == RM_PLAYING) {
		//RMuint64 stc;
		//RMstatus err;

		pSendContext->IFrameTrickMode = FALSE;
		RMDBGLOG((ENABLE, "resume\n"));

		if (prev_trickmode == RM_TRICKMODE_RWD_IFRAME) {
			RMDBGLOG((ENABLE, "stopping video decoder\n"));
			DCCStopVideoSource(pSendContext->dcc_info->pVideoSource, DCCStopMode_LastFrame);
			RMDBGLOG((ENABLE, "starting video decoder\n"));
			DCCPlayVideoSource(pSendContext->dcc_info->pVideoSource, DCCVideoPlayFwd);
		}
		/*
		err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &stc, sizeof(stc));
		if (err == RM_OK)
			DCCSTCSetTime(pSendContext->dcc_info->pStcSource, stc, 45000);
		*/
			
	}
	else if (pSendContext->dcc_info->state == RM_PLAYING_TRICKMODE) {
		if (pSendContext->ResumeFromTrickMode) {
			pSendContext->TrickModeTransition = TRUE;
		}			
		else
			pSendContext->ResumeFromTrickMode = TRUE;
		
		prev_trickmode = pSendContext->dcc_info->trickmode_id;

		switch (pSendContext->dcc_info->trickmode_id) {
		case RM_TRICKMODE_FAST_FWD:
		case RM_TRICKMODE_SLOW_FWD:
			if (pSendContext->repack_sample) 
				release_repacked_buffers(pSendContext, REPACK_AUDIO);
			break;
		case RM_TRICKMODE_NEXT_PIC:
 			pSendContext->TrickModeTransition = FALSE;
			pSendContext->ResumeFromTrickMode = FALSE;
			break;
		case RM_TRICKMODE_FWD_IFRAME:
			if (pSendContext->dcc_info->pVideoSource) {
				err = DCCPlayVideoSource(pSendContext->dcc_info->pVideoSource, DCCVideoPlayIFrame);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error playing video source %d\n", err));
					label = LABEL_ERROR;
					goto exit_process_key;
				}
			}
			if (pSendContext->dcc_info->pAudioSource) {
				err = DCCStopAudioSource(pSendContext->dcc_info->pAudioSource);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
					label = LABEL_ERROR;
					goto exit_process_key;
				}
				if (pSendContext->repack_sample) 
					release_repacked_buffers(pSendContext, REPACK_AUDIO);
			}
			pSendContext->FirstSystemTimeStamp = TRUE;
			pSendContext->IFrameTrickMode = TRUE;
			break;
		case RM_TRICKMODE_RWD_IFRAME: {
			RMint32 N;				
			RMuint32 M;
			DCCSTCGetSpeed(pSendContext->dcc_info->pStcSource, &N, &M);
			if (N < 0)
				N *= -1;
			DCCSTCSetSpeed(pSendContext->dcc_info->pStcSource, (N * -1), M);
			if (pSendContext->dcc_info->pVideoSource) {
				err = DCCPlayVideoSource(pSendContext->dcc_info->pVideoSource, DCCVideoPlayIFrame);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error playing video source %d\n", err));
					label = LABEL_ERROR;
					goto exit_process_key;
				}
			}
			if (pSendContext->dcc_info->pAudioSource) {
				err = DCCStopAudioSource(pSendContext->dcc_info->pAudioSource);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error stopping audio source %d\n", err));
					label = LABEL_ERROR;
					goto exit_process_key;
				}
				if (pSendContext->repack_sample) 
					release_repacked_buffers(pSendContext, REPACK_AUDIO);
			}
			pSendContext->FirstSystemTimeStamp = TRUE;
			pSendContext->IFrameTrickMode = TRUE;
			break;

			/*
			fprintf(stderr, "Unsuported command\n");
			pSendContext->dcc_info->state = RM_PLAYING;
			pSendContext->dcc_info->trickmode_id = RM_NO_TRICKMODE;
			break;
			*/
		}
		}
	}
	if (pSendContext->cmd == RM_SEEK) {
		if (pSendContext->dcc_info->seek_supported) {
			if ((release) && (pSendContext->repack_sample))
				release_repacked_buffers(pSendContext, REPACK_ALL);
			label = LABEL_STOP; 
			goto exit_process_key;
		}
		else {
			fprintf(stderr, "Unsuported command\n");		
			pSendContext->cmd = RM_PLAY;
		}
	}

 exit_process_key:
	return label;
}

#endif

#define KEYDBG DISABLE

static struct RM_PSM_Actions actions;

#define PROCESS_KEY(release, getkey)					\
do {								        \
	RMDBGLOG((KEYDBG, "processkey(%lu, %lu)\n", release, getkey));		\
	if (getkey) {							\
		err = process_command(&PSMContext, &(context.dcc_info), &actions); \
		if (RMFAILED(err)) {					\
			fprintf(stderr, "Error processing key %d\n", err); \
			goto cleanup;					\
		}							\
	}								\
	if (actions.toDoActions & RM_PSM_FLUSH_VIDEO) {			\
		RMDBGLOG((ENABLE, "flushVIDEO\n"));			\
		Stop(&context, RM_DEVICES_VIDEO);			\
		actions.toDoActions &= ~RM_PSM_FLUSH_VIDEO;		\
	}								\
	if (actions.toDoActions & RM_PSM_FIRST_PTS) {			\
		RMDBGLOG((ENABLE, "firstPTS\n"));			\
		context.FirstSystemTimeStamp = TRUE;			\
		actions.toDoActions &= ~RM_PSM_FIRST_PTS;		\
	}								\
	if (actions.performedActions & RM_PSM_VIDEO_STOPPED) {		\
		RMDBGLOG((ENABLE, "video stopped\n"));			\
		context.initVideo = TRUE;				\
		actions.performedActions &= ~RM_PSM_VIDEO_STOPPED;	\
	}								\
	if (actions.performedActions & RM_PSM_AUDIO_STOPPED) {		\
		RMDBGLOG((ENABLE, "audio stopped\n"));			\
		if ((release) && (context.repack_sample)) {		\
			RMDBGLOG((ENABLE, "release audio buffers\n"));	\
			release_repacked_buffers(&context, REPACK_AUDIO); \
		}							\
		else if (release) {					\
			RMDBGLOG((ENABLE, "release a buffer\n"));	\
			RUAReleaseBuffer(pDMA, buf);			\
			buf = NULL;					\
		}							\
		context.initAudio = TRUE;				\
		context.waitForValidAudioPTS = TRUE;			\
		actions.performedActions &= ~RM_PSM_AUDIO_STOPPED;	\
	}								\
	if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "quit\n"));				\
		actions.cmdProcessed = TRUE;				\
		if ((release) && (context.repack_sample)) {		\
			RMDBGLOG((ENABLE, "release buffers\n"));	\
			release_repacked_buffers(&context, REPACK_ALL); \
		}							\
		else if (release) {					\
			RMDBGLOG((ENABLE, "release a buffer\n"));	\
			RUAReleaseBuffer(pDMA, buf);			\
			buf = NULL;					\
		}							\
		goto cleanup;						\
	}								\
	if ((manutest == TRUE) && (actions.cmd == RM_MANU_QUIT_OK) && (!actions.cmdProcessed)) { \
		if ((release) && (demux_opt->repack_sample)) {		\
			RMDBGLOG((ENABLE, "release buffers\n"));	\
			release_repacked_buffers(&context, REPACK_ALL);	\
		}							\
		else if (release) {					\
			RMDBGLOG((ENABLE, "release a buffer\n"));	\
			RUAReleaseBuffer(pDMA, buf);			\
			buf = NULL;					\
		}							\
		goto cleanup;						\
	}								\
	if (((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Slow) || \
	     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Fast) || \
	     (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_NextPic)) && \
	    (actions.cmdProcessed) && (!context.isTrickMode)) {		\
		RMDBGLOG((ENABLE, ">> trick mode all frames\n"));	\
		context.isTrickMode = TRUE;				\
	}								\
	if ((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Playing) && \
	    (context.isTrickMode) &&					\
	    (actions.cmdProcessed)) {					\
		RMDBGLOG((ENABLE, ">> resume from trickmode\n"));	\
		context.isTrickMode = FALSE;				\
	}								\
        if (actions.toDoActions & RM_PSM_DEMUX_NORMAL) {		\
		RMDBGLOG((ENABLE, "demuxNormal\n"));			\
		context.isTrickMode = FALSE;				\
		Play(&context, RM_DEVICES_VIDEO, DCCVideoPlayFwd);	\
		actions.toDoActions &= ~RM_PSM_DEMUX_NORMAL;		\
	}								\
	if (actions.toDoActions & RM_PSM_DEMUX_IFRAME) {		\
		RMDBGLOG((ENABLE, "demuxIFrame\n"));			\
		Play(&context, RM_DEVICES_VIDEO, DCCVideoPlayIFrame);	\
		context.isIFrameMode = TRUE;				\
		if (context.ignoreCallback)				\
			context.ignoreCallback = FALSE;			\
		actions.toDoActions &= ~RM_PSM_DEMUX_IFRAME;		\
	}								\
	if (actions.toDoActions & RM_PSM_RESYNC_TIMER) {		\
		RMDBGLOG((ENABLE, "resyncTimer\n"));			\
		SyncTimerWithDecoderPTS(&context);			\
		actions.toDoActions &= ~RM_PSM_RESYNC_TIMER;		\
	}								\
	if ((RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_Stopped) && (actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE,"Got stop command\n"));		\
		if ((release) && (context.repack_sample)) {		\
			RMDBGLOG((ENABLE, "release buffers\n"));	\
			release_repacked_buffers(&context, REPACK_ALL); \
		}							\
		else if (release) {					\
			RMDBGLOG((ENABLE, "release a buffer\n"));	\
			RUAReleaseBuffer(pDMA, buf);			\
			buf = NULL;					\
		}							\
		context.isIFrameMode = FALSE;				\
		context.FirstSystemTimeStamp = TRUE;			\
		goto mainloop_no_seek;					\
	}								\
        if ((actions.cmd == RM_STOP_SEEK_ZERO) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE,"Got stop seek zero command\n"));	\
		Stop(&context, RM_DEVICES_VIDEO | RM_DEVICES_STC);	\
		RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Stopped); \
		context.isIFrameMode = FALSE;				\
		context.FirstSystemTimeStamp = TRUE;				\
		actions.cmdProcessed = TRUE;				\
		if ((release) && (context.repack_sample)) {		\
			RMDBGLOG((ENABLE, "release buffers\n"));	\
			release_repacked_buffers(&context, REPACK_ALL); \
		}							\
		else if (release) {					\
			RMDBGLOG((ENABLE, "release a buffer\n"));	\
			RUAReleaseBuffer(pDMA, buf);			\
			buf = NULL;					\
		}							\
		goto mainloop;						\
	}								\
	if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "got seek command\n"));		\
		Stop(&context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO | RM_DEVICES_STC); \
		context.isIFrameMode = FALSE;				\
		context.FirstSystemTimeStamp = TRUE;			\
		context.ignoreCallback = FALSE;				\
		if (release) {						\
			RMDBGLOG((ENABLE, "release a buffer\n"));	\
			RUAReleaseBuffer(pDMA, buf);			\
			buf = NULL;					\
		}							\
		goto mainloop_no_seek;					\
	}								\
	if ((actions.cmd == RM_DUALMODE_CHANGE) && (!actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE, "got dualmode change\n"));		\
		fprintf(stderr, "Changing DualMode to :");		\
		switch(audio_opt->OutputDualMode) {								\
		case DualMode_LeftMono:										\
			fprintf(stderr, " RightMono\n");							\
			audio_opt->OutputDualMode = DualMode_RightMono;						\
			break;											\
		case DualMode_RightMono:									\
			fprintf(stderr, " MixMono\n");								\
			audio_opt->OutputDualMode = DualMode_MixMono;						\
			break;											\
		case DualMode_MixMono:										\
			fprintf(stderr, " Stereo\n");								\
			audio_opt->OutputDualMode = DualMode_Stereo;						\
			break;											\
		case DualMode_Stereo:										\
			fprintf(stderr, " LeftMono\n");								\
			audio_opt->OutputDualMode = DualMode_LeftMono;						\
 			break;											\
		default:											\
			fprintf(stderr, " Unknown dual mode\n");						\
			break;											\
		}												\
		err = apply_audio_decoder_options_onthefly(&dcc_info,audio_opt);				\
		if (RMFAILED(err)) {										\
			fprintf(stderr, "Error applying audio decoder options on the fly %d\n", err);		\
		}												\
	}													\
} while (1)


#define PROCESS_KEY_INSIDE_FUNCTION()					\
do	{								\
	RMstatus err;							\
	enum RM_PSM_State PlaybackStatus;				\
									\
	RMDBGLOG((KEYDBG, "processkey_inside_function\n"));		\
	err = process_command(pSendContext->PSMcontext, &(pSendContext->dcc_info), &actions); \
	if (RMFAILED(err)) {						\
		RMDBGLOG((ENABLE, "Error while processing key %d\n", err)); \
		goto return_from_callback;				\
	}								\
	PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info)); \
	if (actions.toDoActions & RM_PSM_RESYNC_TIMER) {		\
		RMDBGLOG((ENABLE, "resyncTimer\n"));			\
		SyncTimerWithDecoderPTS(pSendContext);			\
		actions.toDoActions &= ~RM_PSM_RESYNC_TIMER;		\
	}								\
	if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "quit during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	} 								\
	if ((PlaybackStatus == RM_PSM_Stopped) && (actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE, "stop during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if ((actions.cmd == RM_STOP_SEEK_ZERO) && (!actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE, "seekzero during callback\n"));	\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed)){	\
		RMDBGLOG((ENABLE, "seek during callback\n"));		\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if (((PlaybackStatus == RM_PSM_IForward) ||			\
	    (PlaybackStatus == RM_PSM_IRewind)) && (actions.cmdProcessed)) {	\
		RMDBGLOG((ENABLE, "iframe trick during callback\n"));	\
		pSendContext->ignoreCallback = TRUE;			\
		goto return_from_callback;				\
	}								\
	if (((PlaybackStatus == RM_PSM_Slow) ||		\
	     (PlaybackStatus == RM_PSM_Fast)) && (actions.cmdProcessed)) { \
		RMDBGLOG((ENABLE,"trickmodes during callback\n"));	\
                pSendContext->isTrickMode = TRUE;			\
		pSendContext->ignoreCallback = FALSE;			\
	}								\
} while(0)




#ifndef WITH_MONO


static RMstatus parse_demux_type(char *demuxstr)
{
	if ((bcmp(demuxstr, "mpeg1", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is mpeg1 system\n");
		demux_opt->system_type = RM_SYSTEM_MPEG1;
		return RM_OK;
	}
	
	if ((bcmp(demuxstr, "dvd", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is vob\n");
		demux_opt->system_type = RM_SYSTEM_MPEG2_DVD;
		return RM_OK;
	}

	if ((bcmp(demuxstr, "aob", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is aob\n");
		demux_opt->system_type = RM_SYSTEM_MPEG2_DVD_AUDIO;
		return RM_OK;
	}

	if ((bcmp(demuxstr, "m2t192", 6)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is m2t192\n");
		demux_opt->system_type = RM_SYSTEM_MPEG2_TRANSPORT_192;
		return RM_OK;
	}
	
	if ((bcmp(demuxstr, "m2t", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is m2t\n");
		demux_opt->system_type = RM_SYSTEM_MPEG2_TRANSPORT;
		return RM_OK;
	}
	
	if ((bcmp(demuxstr, "m2p", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is m2p\n");
		demux_opt->system_type = RM_SYSTEM_MPEG2_PROGRAM;
		return RM_OK;
	}

	if ((bcmp(demuxstr, "vbs", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is elementary video\n");
		demux_opt->system_type = RM_SYSTEM_UNKNOWN;
		demux_opt->data_type = RMVDEMUX_VIDEO;
		return RM_OK;
	}
	
	if ((bcmp(demuxstr, "abs", 3)) == 0) {
		if (verbose_stderr != 0)
			fprintf(stderr, "file is elementary audio\n");
		demux_opt->system_type = RM_SYSTEM_UNKNOWN;
		demux_opt->data_type = RMVDEMUX_AUDIO;
		return RM_OK;
	}

	return RM_ERROR;
}

static void show_usage(char *progname)
{
	fprintf(stderr, "DEMUX OPTIONS (default values inside brackets)\n"
		"\t-y <demux type>: Selects the demux type\n"
		"\t\t[mpeg1], m2p, m2t, m2t192, dvd, vbs, abs, aob\n"
		"\t-vpid: video PID (else, first video stream will be played)\n"
		"\t-apid: audio PID (else, first audio stream will be played)\n"
		"\t-asubid: audio substream id (else, first audio substream will be played)\n"
		"\t-ssubid: spu substream id (else, first spu substream will be played)\n"
		"\t-z: Repacketizes packets (needed for transport streams) [FALSE]\n"
		"\t-spu: Enables subpicture [FALSE]\n"
		"\t-dur: Specifies the duration of the stream, on ms. Required for seeking\n");
	
	show_playback_options();
	show_display_options();
	show_video_options();
	show_audio_options();
	
	fprintf(stderr, "--------------------------------\n");
	fprintf(stderr, "Minimum cmd line: %s <file name>\n", progname);
	fprintf(stderr, "--------------------------------\n");
	
	exit(1);
}

static void parse_cmdline(int argc, char *argv[])
{
	int i;
	RMstatus err;
	/* init default demux_opt */
	demux_opt->system_type = RM_SYSTEM_MPEG1;
	demux_opt->data_type = RMVDEMUX_VIDEO;
	demux_opt->repack_sample = FALSE;
	demux_opt->video_pid = 0;
	demux_opt->audio_pid = 0;
	demux_opt->audio_subid = 0;
	demux_opt->spu_subid = 0;
	
	if (argc < 2) 
		show_usage(argv[0]);
	
	i = 1;
	while ((argc > i)) {
		if (argv[i][0] != '-') {
			if (play_opt->filename == NULL) {
				play_opt->filename = argv[i];
				i++;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-y")) {
			if (argc > i+1) { 
				err = parse_demux_type(argv[i+1]);
				if (RMFAILED(err))
					show_usage(argv[0]);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-z")) {
			demux_opt->repack_sample = TRUE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-spu")) {
			enable_spu = TRUE;
			i++;
		}
		else if ( ! strcmp(argv[i], "-vpid")) {
			if (argc > i+1) {
				demux_opt->video_pid = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-apid")) {
			if (argc > i+1) {
				/* permitted values should be 0xC0-0xDF, 0xBD, (decimal 192-223, 189) */
				demux_opt->audio_pid = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-asubid")) {
			if (argc > i+1) {
				demux_opt->audio_subid = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-ssubid")) {
			if (argc > i+1) {
				demux_opt->spu_subid = strtol(argv[i+1], NULL, 0);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else if ( ! strcmp(argv[i], "-dur")) {
			if (argc > i+1) {
				play_opt->duration = strtol(argv[i+1], NULL, 10);
				i+=2;
			}
			else
				show_usage(argv[0]);
		}
		else {
			err = parse_playback_cmdline(argc, argv, &i, play_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_display_cmdline(argc, argv, &i, disp_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_video_cmdline(argc, argv, &i, video_opt);
			if (err == RM_ERROR)
				show_usage(argv[0]);
			if (err != RM_PENDING)
				continue;
			err = parse_audio_cmdline(argc, argv, &i, audio_opt);
			if (RMFAILED(err))
				show_usage(argv[0]);
		}
	}

	if (play_opt->filename == NULL)
		show_usage(argv[0]);

	if (manutest == TRUE) {
		if (demux_opt->data_type == RMVDEMUX_VIDEO) {
			switch(disp_opt->connector) {
				case DCCVideoConnector_COMPOSITE:
					fprintf(stdout, "Please check Composite output ..");
					break;
				case DCCVideoConnector_COMPONENT:
					fprintf(stdout, "Please check Component output ..");
					break;
				case DCCVideoConnector_SVIDEO:
					fprintf(stdout, "Please check S-Video output ..");
					break;
				case DCCVideoConnector_DVI:
					fprintf(stdout, "Please check DVI-A output ..");
					break;
				case DCCVideoConnector_Digital:
					fprintf(stdout, "Please check DVI-D output ..");
					break;
				case DCCVideoConnector_VGA:
					fprintf(stdout, "Please check VGA output ..");
					break;
				case DCCVideoConnector_SCART:
					fprintf(stdout, "Please check SCART output ..");
					break;
				case DCCVideoConnector_LVDS:
					fprintf(stdout, "Please check LVDS output ..");
					break;
				default:
					fprintf(stdout, "Please check default output ..");
					break;
			}
		} else if (demux_opt->data_type == RMVDEMUX_AUDIO) {
			fprintf(stdout, "Please check audio output ..");
		}
	}
}
#endif


static RMstatus Stop(struct demux_context * pSendContext, RMuint32 devices)
{
	RMstatus err = RM_OK;
	struct dcc_context *dcc_info = pSendContext->dcc_info;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "STOP: stc\n"));
		DCCSTCStop(dcc_info->pStcSource);
		pSendContext->STCrunning = FALSE;
	}

	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->dcc_info->pVideoSource) {
			RMDBGLOG((ENABLE, "STOP: video decoder\n"));
			err = DCCStopVideoSource(dcc_info->pVideoSource, DCCStopMode_LastFrame);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE, "Error stopping video source %d\n", err));
				return err;
			}
			pSendContext->initVideo = TRUE;

		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pAudioSource) {
			RMDBGLOG((ENABLE, "STOP: audio decoder\n"));
			err = DCCStopAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)){
				RMDBGLOG((ENABLE,"Error stopping audio source %d\n", err));
				return err;
			}
		}
	}

	if ((devices & RM_DEVICES_AUDIO) && (devices & RM_DEVICES_VIDEO)) {
		pSendContext->FirstSystemTimeStamp = TRUE;
	}

	return err;

}

static RMstatus Play(struct demux_context * pSendContext, RMuint32 devices, enum DCCVideoPlayCommand mode)
{

	RMstatus err = RM_OK;
	struct dcc_context *dcc_info = pSendContext->dcc_info;
	
	if (devices & RM_DEVICES_STC) {
		RMDBGLOG((ENABLE, "PLAY: stc\n"));
		DCCSTCPlay(dcc_info->pStcSource);
		pSendContext->STCrunning = TRUE;
	}

	if (devices & RM_DEVICES_VIDEO) {
		if (pSendContext->dcc_info->pVideoSource) {
			if (pSendContext->initVideo) {
				RMbool keep_sequence = TRUE;
				RMDBGLOG((ENABLE, "PLAY: initDecoder\n"));
				err = RUASetProperty(pSendContext->dcc_info->pRUA, pSendContext->dcc_info->video_decoder, RMVideoDecoderPropertyID_StorePreviousVideoHeader, &keep_sequence, sizeof(keep_sequence), 0);
				if (RMFAILED(err)) {
					RMDBGLOG((ENABLE, "Error setting video decoder to keep sequence header on Stop %d\n", err));
					return err;
				}
				pSendContext->initVideo = FALSE;
			}

			RMDBGLOG((ENABLE, "PLAY: video decoder %s\n", (mode == DCCVideoPlayIFrame ? "(iframe)":"")));
			err = DCCPlayVideoSource(pSendContext->dcc_info->pVideoSource, mode);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", err));
				return err;
			}
		}
	}

	if (devices & RM_DEVICES_AUDIO) {
		if (pSendContext->dcc_info->pAudioSource) {
			RMDBGLOG((ENABLE, "PLAY: audio decoder\n"));
			err = DCCPlayAudioSource(dcc_info->pAudioSource);
			if (RMFAILED(err)) {
				RMDBGLOG((ENABLE, "Cannot play video decoder %d\n", err));
				return err;
			}
		}
	}


	return err;

}

static RMstatus SyncTimerWithDecoderPTS(struct demux_context *pSendContext)
{
	RMuint64 videoPTS;
	RMuint64 CurrentSTC;
	RMstatus err = RM_OK;
	RMuint32 timeScale;

	/* we have to obtain the timeScale because in mpeg4 elementary 
	   streams, the time scale is not guaranteed to be 90KHz 
	*/
	DCCSTCGetTimeResolution(pSendContext->dcc_info->pStcSource, DCC_Video, &timeScale);

	DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &CurrentSTC, timeScale);

	err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &videoPTS, sizeof(videoPTS));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "error %d while getting CurrentDisplayPTS\n", err));
		return err;
	}

	/* for MPEG1/2, timeScale 90000, videoPTS unit is 45000 always,
	   for MPEG4, timeScale is the same than videoPTS unit.
	   Note however, that we're just checking the value of timeScale, so
	   if we're in MPEG4 and timeScale 90000, this wont work. Also note that
	   this happens with elementary streams which are to be handled by
	   play_video not play_demux. 
	*/
	if (timeScale == 90000)
		videoPTS *= 2;
	

	RMDBGLOG((ENABLE, ">> resync timer (%llu) with videoDecoder current PTS (%llu), unit %lu\n", CurrentSTC, videoPTS, timeScale));
	DCCSTCSetTime(pSendContext->dcc_info->pStcSource, videoPTS, timeScale);

#ifdef PTS_DISCONTINUITY_DETECTION
	pSendContext->fakePrevPts = TRUE;
#endif


	return RM_OK;
	
}

static void flush_repacked_sample(void *context)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	RMuint8 *send_buffer = (RMuint8 *) NULL;
	RMuint32 send_length = 0;
	RMuint32 decoder;
 	struct emhwlib_info Info;

	/* flush video data */
	if ( ! play_opt->send_video)
		goto flush_audio;

	if (pSendContext->video_repack_buf == NULL)
		goto flush_audio;

	decoder = pSendContext->dcc_info->video_decoder;
	send_buffer = pSendContext->video_repack_buf + pSendContext->video_repack_offset;
	send_length = pSendContext->video_repack_size;
	Info.ValidFields = (pSendContext->video_repack_pts_valid) ? TIME_STAMP_INFO : 0;
	Info.TimeStamp = pSendContext->video_repack_pts;

	while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
		struct RUAEvent e;

		PROCESS_KEY_INSIDE_FUNCTION();

		e.ModuleID = decoder;
		e.Mask = RUAEVENT_XFER_FIFO_READY;
		RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
	}

	RUAReleaseBuffer(pSendContext->pDMA, send_buffer);
		
 flush_audio:
	/* flush audio data */
	if ( ! play_opt->send_audio)
		goto flush_spu;

	if (pSendContext->audio_repack_buf == NULL)
		goto flush_spu;

	if (pSendContext->dcc_info->state == RM_PLAYING_TRICKMODE)
		goto flush_spu;
	
	decoder = pSendContext->dcc_info->audio_decoder;
	send_buffer = pSendContext->audio_repack_buf + pSendContext->audio_repack_offset;
	send_length = pSendContext->audio_repack_size;
	Info.ValidFields = (pSendContext->audio_repack_pts_valid) ? TIME_STAMP_INFO : 0;
	Info.TimeStamp = pSendContext->audio_repack_pts;

	while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
		struct RUAEvent e;
		
		PROCESS_KEY_INSIDE_FUNCTION();

		e.ModuleID = decoder;
		e.Mask = RUAEVENT_XFER_FIFO_READY;
		RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
	}

	RUAReleaseBuffer(pSendContext->pDMA, send_buffer);
	
 flush_spu:
	/* flush spu data */
	if ( ! play_opt->send_spu)
		return;

	if (! pSendContext->enable_spu) {
		return;
	}

	if (pSendContext->spu_repack_buf == NULL)
		return;

	decoder = pSendContext->dcc_info->spu_decoder;
	send_buffer = pSendContext->spu_repack_buf + pSendContext->spu_repack_offset;
	send_length = pSendContext->spu_repack_size;
	Info.ValidFields = (pSendContext->spu_repack_pts_valid) ? TIME_STAMP_INFO : 0;
	Info.TimeStamp = pSendContext->spu_repack_pts;

	while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
		struct RUAEvent e;

		PROCESS_KEY_INSIDE_FUNCTION();

		e.ModuleID = decoder;
		e.Mask = RUAEVENT_XFER_FIFO_READY;
		RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
	}

	RUAReleaseBuffer(pSendContext->pDMA, send_buffer);

 return_from_callback:
	return;

}

static void PESCallback(RMuint8 *buffer, RMuint32 length, RMuint64 PTS, RMbool isPtsValid,
			RMvdemuxDataType dataType, RMuint64 PESOffset, void *context)
{
	static RMascii *decoder_name[] = {"video", "audio", "spu"};
	RMascii *string;
	struct demux_context *pSendContext = (struct demux_context *) context;
	RMuint32 decoder;
 	struct emhwlib_info Info;
	RMbool send_data = FALSE;
	RMuint8 *send_buffer = (RMuint8 *) NULL;
	RMuint32 send_length = 0;
	RMuint8 *repack_buffer;
	RMuint64 repack_pts;
	RMuint32 repack_offset, repack_size;
	RMbool repack_pts_valid;
	RMuint32 send_pts;
	RMstatus err;
	RMuint32 *pbyte_counter = 0;
	RMuint32 first_access_unit_pointer = 0;
	RMbool isFirstAccessUnitValid = FALSE;

	enum RM_PSM_State PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));


#ifdef PTS_DISCONTINUITY_DETECTION
	static RMuint64 prevVpts = 0xffffffffffffffffll;
	static RMuint64 prevApts = 0xffffffffffffffffll;
#endif

	if (pSendContext->ignoreCallback) {

		if ((actions.cmd == RM_QUIT) && (!actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'quit' command was issued\n"));
			goto return_from_callback;
		}
		if ((PlaybackStatus == RM_PSM_Stopped) && (actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'stop' command was issued\n"));
			goto return_from_callback;
		}
		if ((actions.cmd == RM_STOP_SEEK_ZERO)  && (!actions.cmdProcessed)) {
			RMDBGLOG((ENABLE, "callback called when 'seekzero' command was issued\n"));
			goto return_from_callback;
		}
		if ((actions.cmd == RM_SEEK) && (!actions.cmdProcessed)) {	
			RMDBGLOG((ENABLE, "callback called when 'seek' command was issued\n"));
			goto return_from_callback;
		}
		if (((actions.cmd == RM_IFWD) || (actions.cmd == RM_IRWD)) && (actions.cmdProcessed)) {	
			RMDBGLOG((ENABLE, "callback called when 'iframe' command was issued\n"));
			goto return_from_callback;
		}

		RMDBGLOG((ENABLE, "********** ignoring Callback!! *********, cmd %lu, processed %lu\n", actions.cmd, actions.cmdProcessed));
		goto return_from_callback;
	}

	switch (dataType) {
	case RMVDEMUX_AUDIO:
		if (pSendContext->audio_first_access_unit_pointer_valid) {
			isFirstAccessUnitValid = TRUE;
			first_access_unit_pointer = pSendContext->audio_first_access_unit_pointer;
			pSendContext->audio_first_access_unit_pointer_valid = FALSE;
		}
		break;
	default:
		isFirstAccessUnitValid = FALSE;
		first_access_unit_pointer = 0;
		break;
	}

	/* uncomment to save only when in iframe mode (debug purposes)
	   if (pSendContext->dcc_info->trickmode_id == RM_TRICKMODE_RWD_IFRAME) { */
		err = dump_data_into_file(play_opt, dataType, buffer, length, PTS, isPtsValid, first_access_unit_pointer);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot dump data %d\n", err));
			return;
		}
		/* } */
	
	switch (dataType) {
	case RMVDEMUX_VIDEO:
		if ( ! play_opt->send_video)
			return ;

		decoder = pSendContext->dcc_info->video_decoder;
		string = decoder_name[0];
		send_pts = play_opt->send_video_pts;
		repack_buffer = pSendContext->video_repack_buf;
		repack_offset = pSendContext->video_repack_offset;
		repack_size = pSendContext->video_repack_size;
		repack_pts = pSendContext->video_repack_pts;
		repack_pts_valid = pSendContext->video_repack_pts_valid;
		pbyte_counter = &pSendContext->video_byte_counter;
		break;
	case RMVDEMUX_AUDIO:
		if ( ! play_opt->send_audio)
			return ;

		if ((PlaybackStatus != RM_PSM_Playing) && (PlaybackStatus != RM_PSM_Paused))
 			return;
	       
		decoder = pSendContext->dcc_info->audio_decoder;
		string = decoder_name[1];
		send_pts = play_opt->send_audio_pts;
		repack_buffer = pSendContext->audio_repack_buf;
		repack_offset = pSendContext->audio_repack_offset;
		repack_size = pSendContext->audio_repack_size;
		repack_pts = pSendContext->audio_repack_pts;
		repack_pts_valid = pSendContext->audio_repack_pts_valid;
		pbyte_counter = &pSendContext->audio_byte_counter;
		break;
	case RMVDEMUX_SUBPICTURE:
		if ( ! play_opt->send_spu)
			return ;

		if (! pSendContext->enable_spu) {
			//RMDBGPRINT((ENABLE, "disabled spu\n"));
			return;
		}
		decoder = pSendContext->dcc_info->spu_decoder;
		string = decoder_name[2];
		send_pts = play_opt->send_spu_pts;
		repack_buffer = pSendContext->spu_repack_buf;
		repack_offset = pSendContext->spu_repack_offset;
		repack_size = pSendContext->spu_repack_size;
		repack_pts = pSendContext->spu_repack_pts;
		repack_pts_valid = pSendContext->spu_repack_pts_valid;
		break;
	case RMVDEMUX_NAVIGATION:
		RMDBGPRINT((ENABLE, "navigation\n"));
		return;
	default:
		RMDBGPRINT((ENABLE, "Unknown data type %d\n", dataType));
		return;
	}

 	if ((pSendContext->repack_sample) && (repack_size>0) && 
	    ((isPtsValid) || (repack_offset + length > (1<<DMA_BUFFER_SIZE_LOG2)) || (repack_size + length > REPACK_SIZE))) {
 		send_buffer = repack_buffer + repack_offset;
		send_length = repack_size;
		Info.ValidFields = (repack_pts_valid && send_pts) ? TIME_STAMP_INFO : 0;
		Info.TimeStamp = repack_pts;
		send_data = TRUE;
		
		repack_offset += repack_size;
		repack_size = 0;
		repack_pts = 0;
		repack_pts_valid = FALSE;
	}
	else if (!pSendContext->repack_sample) {
		send_buffer = buffer;
		send_length = length;
		Info.ValidFields = ((isPtsValid && send_pts) ? TIME_STAMP_INFO : 0) | (isFirstAccessUnitValid ? FIRST_ACCESS_UNIT_POINTER_INFO : 0);
 		Info.TimeStamp = PTS;
 		Info.FirstAccessUnitPointer = first_access_unit_pointer;
		send_data = TRUE;
	}

	if (send_data) {
 		if ((PlaybackStatus == RM_PSM_Playing) || (PlaybackStatus == RM_PSM_Paused)) {
			if (pSendContext->FirstSystemTimeStamp) {
				if (Info.ValidFields & TIME_STAMP_INFO) {
					RMDBGPRINT((ENABLE, "FirstSystemTimeStamp from %s = %llu = 0x%llx (0x%llx)\n", string, Info.TimeStamp, Info.TimeStamp, Info.TimeStamp/2));
					
					DCCSTCSetTime(pSendContext->dcc_info->pStcSource, Info.TimeStamp + pSendContext->start_90khz, 90000);
					//DCCSTCPlay(pSendContext->dcc_info->pStcSource);

					pSendContext->FirstSystemTimeStamp = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
					if (dataType == RMVDEMUX_VIDEO)
						prevVpts = Info.TimeStamp;
				
					if (dataType == RMVDEMUX_AUDIO)
						prevApts = Info.TimeStamp;
#endif
				}
				else if (!(play_opt->send_audio_pts || play_opt->send_audio_pts)) {
					Info.TimeStamp = 0;
					RMDBGPRINT((ENABLE, "No PTS -> Init FirstSystemTimeStamp = %llu\n", Info.TimeStamp));

					DCCSTCSetTime(pSendContext->dcc_info->pStcSource, Info.TimeStamp + pSendContext->start_90khz, 90000);
					//DCCSTCPlay(pSendContext->dcc_info->pStcSource);

					pSendContext->FirstSystemTimeStamp = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
					prevVpts = Info.TimeStamp;
					prevApts = Info.TimeStamp;
#endif
				}
				else
					RMDBGLOG((ENABLE, "waiting for valid PTS\n"));
			}
			else if ((pSendContext->ResumeFromTrickMode) || (pSendContext->TrickModeTransition)) {
				RMuint64 stc;
				
				if (pSendContext->dcc_info->SurfaceID != 0) {
					if ((pSendContext->prev_IFrameTrickMode) && !(pSendContext->IFrameTrickMode)) {
						RMDBGLOG((ENABLE, "using last decoded video PTS as STC\n"));
						err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->video_decoder, RMVideoDecoderPropertyID_LastDecodedPTS, &stc, sizeof(stc));
					}
					else
						err = RUAGetProperty(pSendContext->pRUA, pSendContext->dcc_info->SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &stc, sizeof(stc));
						
					if (err == RM_OK) {
						RMDBGPRINT((ENABLE, "Set STC afer trickmode %llu\n", 2*stc));

						DCCSTCSetTime(pSendContext->dcc_info->pStcSource, stc, 45000);
						//DCCSTCPlay(pSendContext->dcc_info->pStcSource);

					}
					else
						RMDBGPRINT((ENABLE, "Cannot get video PTS\n"));
					if (pSendContext->TrickModeTransition)
						pSendContext->TrickModeTransition = FALSE;
					else
						pSendContext->ResumeFromTrickMode = FALSE;
				}
			}
		}

		if ((pSendContext->waitForValidAudioPTS) && (dataType == RMVDEMUX_AUDIO)) {
			if (Info.ValidFields & TIME_STAMP_INFO) {
				RMDBGLOG((ENABLE, "first valid audio PTS %llu(0x%09llx)\n",Info.TimeStamp,Info.TimeStamp));
				pSendContext->waitForValidAudioPTS = FALSE;
#ifdef PTS_DISCONTINUITY_DETECTION
				prevApts = Info.TimeStamp;
#endif
			}
			else {
 				// dont send audio with invalid pts
				RMDBGLOG((ENABLE, "pts not valid\n"));
				if (isPtsValid) {
					repack_pts_valid = TRUE;
					repack_pts = PTS;
				}
				goto end_data_callback;
			}
		}


#ifdef PTS_DISCONTINUITY_DETECTION

		if (Info.ValidFields & TIME_STAMP_INFO) {
			RMint32 diff = 0;

			if ((pSendContext->fakePrevPts) && (dataType == RMVDEMUX_AUDIO)) {
				RMDBGPRINT((ENABLE, "Set prevAPTS to 0x09%llx\n", Info.TimeStamp));
				prevApts = Info.TimeStamp;
				pSendContext->fakePrevPts = FALSE;
			}

			if ((dataType == RMVDEMUX_VIDEO) && (prevVpts != 0xffffffffffffffffll)) {
				diff = Info.TimeStamp - prevVpts;
				prevVpts = Info.TimeStamp;
				RMDBGPRINT((DISABLE, "Vpts = %9llx %8lx (%lx)\n", Info.TimeStamp, pSendContext->video_byte_counter, file_offset));
			} else if ((dataType == RMVDEMUX_AUDIO) && (prevApts != 0xffffffffffffffffll)) {
				diff = Info.TimeStamp - prevApts;
				prevApts = Info.TimeStamp;
				RMDBGPRINT((DISABLE, "Apts = %9llx %8lx (%lx)\n", Info.TimeStamp, pSendContext->audio_byte_counter, file_offset));
			}
			if ((diff < -PTS_DISCONTINUITY_RANGE) || (diff > PTS_DISCONTINUITY_RANGE)) {
				struct InbandCommand_type InbandCmd;

				RMDBGPRINT((ENABLE, "%spts discontinuity = %9llx -> %9llx\n", (dataType == RMVDEMUX_VIDEO)?"V":"A", Info.TimeStamp-diff, Info.TimeStamp));
				DCCSTCSetDiscontinuity(pSendContext->dcc_info->pStcSource, Info.TimeStamp-2*90000, 90000);
				
				InbandCmd.Tag = INBAND_COMMAND_TAG_DISCONTINUITY | INBAND_COMMAND_ACTION_STOP;
				InbandCmd.Coordinate = 0;
				if (dataType == RMVDEMUX_VIDEO)
					RUASetProperty(pSendContext->pRUA, pSendContext->dcc_info->video_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
				if (dataType == RMVDEMUX_AUDIO)
					RUASetProperty(pSendContext->pRUA, pSendContext->dcc_info->audio_decoder, RMGenericPropertyID_InbandCommand, &InbandCmd, sizeof(InbandCmd), 0);
			}
		}
#endif	// PTS_DISCONTINUITY_DETECTION



		{
			RMuint64 stc;
			DCCSTCGetTime(pSendContext->dcc_info->pStcSource, &stc, 90000);
			RMDBGLOG((SENDDBG, "sending %s, %lu, pts %llu(0x%09llx) %s stc %llu(0x%09llx)\n", 
				  dataType == RMVDEMUX_AUDIO ? "audio":"video",
				  send_length,
				  Info.TimeStamp,
				  Info.TimeStamp,
				  Info.ValidFields & TIME_STAMP_INFO ? "valid":"",
				  stc,
				  stc));
		}



		while (RUASendData(pSendContext->pRUA, decoder, pSendContext->pDMA, send_buffer, send_length, (void*)&Info, sizeof(Info)) != RM_OK) {
			struct RUAEvent e;
			enum RM_PSM_State PlaybackStatus;

			if (!pSendContext->STCrunning) {
				RMDBGLOG((ENABLE, "starting stc\n"));
				DCCSTCPlay(pSendContext->dcc_info->pStcSource);
				pSendContext->STCrunning = TRUE;
			}

			PROCESS_KEY_INSIDE_FUNCTION();

			PlaybackStatus = RM_PSM_GetState(pSendContext->PSMcontext, &(pSendContext->dcc_info));

			/* skip audio in trickmode */
			if ((dataType == RMVDEMUX_AUDIO) && 
			    ((PlaybackStatus == RM_PSM_Slow) || (PlaybackStatus == RM_PSM_Fast) || (PlaybackStatus == RM_PSM_NextPic)))
				goto end_data_callback;


			e.ModuleID = decoder;
			e.Mask = RUAEVENT_XFER_FIFO_READY;
			RUAWaitForMultipleEvents(pSendContext->pRUA, &e, 1, SENDDATA_TIMEOUT_US, NULL);
		}
		if ( pbyte_counter )
			*pbyte_counter = *pbyte_counter + send_length;
			
		/* sendind data may fill-up the xfer fifo, so we reset the event */
		{
			struct RUAEvent e;
			
			e.ModuleID = decoder;
			e.Mask = RUAEVENT_XFER_FIFO_READY;
			RUAResetEvent(pSendContext->pRUA, &e);
		}
	}
	
	if (pSendContext->repack_sample) {
		RMuint32 val;

		val = RMmax(length, REPACK_SIZE);
		if ((repack_offset + val) > (1<<DMA_BUFFER_SIZE_LOG2)) {
			RUAReleaseBuffer(pSendContext->pDMA, repack_buffer);
			repack_buffer = (RMuint8 *) NULL;
			repack_offset = 0;
		}

		if (repack_buffer == NULL) {
			while (RUAGetBuffer(pSendContext->pDMA, &repack_buffer,  GETBUFFER_TIMEOUT_US) != RM_OK) {

				PROCESS_KEY_INSIDE_FUNCTION();

				RMDBGLOG((DISABLE, "Wait for a buffer\n"));
			}
		}

		memcpy(repack_buffer + repack_offset + repack_size, buffer, length);
		repack_size += length;
		if (isPtsValid) {
			repack_pts_valid = TRUE;
			repack_pts = PTS;
		}
	}		

 end_data_callback:
	switch (dataType) {
	case RMVDEMUX_VIDEO:
		pSendContext->video_repack_buf = repack_buffer;
		pSendContext->video_repack_offset = repack_offset;
		pSendContext->video_repack_size = repack_size;
		pSendContext->video_repack_pts = repack_pts;
		pSendContext->video_repack_pts_valid = repack_pts_valid;
		break;
	case RMVDEMUX_AUDIO:
		pSendContext->audio_repack_buf = repack_buffer;
		pSendContext->audio_repack_offset = repack_offset;
		pSendContext->audio_repack_size = repack_size;
		pSendContext->audio_repack_pts = repack_pts;
		pSendContext->audio_repack_pts_valid = repack_pts_valid;
		break;
	case RMVDEMUX_SUBPICTURE:
		pSendContext->spu_repack_buf = repack_buffer;
		pSendContext->spu_repack_offset = repack_offset;
		pSendContext->spu_repack_size = repack_size;
		pSendContext->spu_repack_pts = repack_pts;
		pSendContext->spu_repack_pts_valid = repack_pts_valid;
		break;
	default:
		RMDBGLOG((ENABLE, "Invalid data type %d\n", dataType));
		return;
	}

 return_from_callback:	
	return;
}

static void AC3DTSCallback(RMuint8 numberOfFrameHeaders, RMuint16 firstAccessUnitPointer, void *context)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	//RMDBGPRINT((ENABLE, "AC3DTSCallback: firstAccessUnitPointer= %x\n", firstAccessUnitPointer));
	pSendContext->audio_first_access_unit_pointer_valid = TRUE;
	pSendContext->audio_first_access_unit_pointer = firstAccessUnitPointer;
	return;
}

static void LPCMCallback(RMuint8 numberOfFrameHeaders, RMuint16 firstAccessUnitPointer, RMuint32 frequency,
			 RMuint8 numberOfChannels, RMvdemuxQuantization quantizationWordLength, void *context)
{
	struct demux_context *pSendContext = (struct demux_context *) context;
	//RMDBGPRINT((ENABLE, "LPCMCallback: firstAccessUnitPointer= %x\n", firstAccessUnitPointer));
	pSendContext->audio_first_access_unit_pointer_valid = TRUE;
	pSendContext->audio_first_access_unit_pointer = firstAccessUnitPointer;
	return;
}

static void aobPcm_callback (RMuint16 firstAccessUnitPointer, 
			     RMvdemuxQuantization quantizationGr1,
			     RMvdemuxQuantization quantizationGr2,
			     RMuint32 samplingFreqGr1,
			     RMuint32 samplingFreqGr2,
			     RMuint8 bitShift,
			     RMuint8 channelAssign,
			     void * context)
{
}
	
static void mlp_callback (RMuint16 firstAccessUnitPointer, 
			  RMuint8 forwardAUSearchPointer,
			  RMuint8 backwardAUSearchPointer,
			  void *context)
{
}

static RMstatus WaitForEOS(struct demux_context *context, RMuint32 *pcmd)
{
	RMuint32 eos_bit_field = 0;

	NTimes++;
	if (verbose_stderr != 0)
		fprintf(stderr, "File ready %ld times, waiting for EOS\n", NTimes);

	if (context->video_byte_counter > 0) {
		eos_bit_field |= EOS_BIT_FIELD_VIDEO;
	}

	if (context->audio_byte_counter > 0) {
		eos_bit_field |= EOS_BIT_FIELD_AUDIO;
	}
	
	return CommonWaitForEOS(context->dcc_info, pcmd, eos_bit_field, KEYFLAGS);
}



#ifdef WITH_MONO
int main_demux(struct mono_info *mono,
	       struct demux_cmdline *demux_opt_mono)
{
#else
int play_demux_TS(int argc,char *argv[]) /* modified by Betta */
{
	/*for MONO compatibility, always access these variables through the global pointers*/
	struct playback_cmdline playback_options; /*access through play_opt*/
	struct display_cmdline  display_options;/*access through disp_opt*/
	struct video_cmdline video_options; /*access through video_opt*/
	struct audio_cmdline audio_options; /*access through audio_opt*/
	struct demux_cmdline demux_options; /*access through demuxopt*/
	struct display_context disp_info;


#endif
	struct DCCVideoSource *pVideoSource = NULL;
	struct DCCAudioSource *pAudioSource = NULL;
	struct DCCVideoProfile video_profile;
	struct DCCAudioProfile audio_profile;
	struct RUABufferPool *pDMA = NULL;
	ExternalRMvdemux demux;
	struct demux_context context;
	RMstatus err;
	RMfile file = NULL;
	RMuint32 videoscaler_id = 0;
	RMuint8 *repack_buf = (RMuint8 *) NULL;
	
	static struct dcc_context dcc_info = {0,};

	RMint32 error = 0;
	struct RM_PSM_Context PSMContext;

	RMMemset(&context, 0, sizeof(struct demux_context));
        RMuint32 i=0; //added by Betta
       RMuint32 count=0;
       RMuint32 num=0;  
#ifdef WITH_MONO
	/*make the mono arguments global*/
	play_opt = mono->play_opt;
	video_opt = mono->video_opt;
	audio_opt = mono->audio_opt;
	dcc_info.pRUA = mono->pRUA;
	dcc_info.pDCC = mono->pDCC;
	demux_opt = demux_opt_mono;
	dcc_info.disp_info = NULL;
	videoscaler_id = mono->video_scaler;
#else

	play_opt = &playback_options;
	disp_opt = &display_options;
	video_opt = &video_options;
	audio_opt = &audio_options;
	demux_opt = &demux_options;
	dcc_info.disp_info = &disp_info;


	init_display_options(disp_opt);
	init_audio_options(audio_opt);
	init_playback_options(play_opt);
	init_video_options(video_opt);
	video_opt->display_cc = TRUE;
       
	parse_cmdline(argc, argv);

	err = RUACreateInstance(&dcc_info.pRUA, play_opt->chip_num);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error creating RUA instance! %d\n", err));
		goto exit_with_error;
	}

	err = DCCOpen(dcc_info.pRUA, &dcc_info.pDCC);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error Opening DCC! %d\n", err));
		goto exit_with_error;
	}

	err = DCCInitMicroCodeEx(dcc_info.pDCC, disp_opt->init_mode);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot initialize microcode %d\n", err));
		goto exit_with_error;
	}
#endif


	err = open_save_files(play_opt);

	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "cannot open files to save data %d\n", err));
		goto exit_with_error;
	}

	if (demux_opt->system_type != RM_SYSTEM_UNKNOWN) {
		err = RMCreateVdemux(&demux);
		if (RMFAILED(err)) {
                        printf("Cannot create demux\n");//marked and added by Betta
			//RMDBGLOG((ENABLE, "Cannot create demux %d\n", err));
			goto exit_with_error;
		}
		RMvdemuxSetType(demux, demux_opt->system_type);
		RMvdemuxSetCallbackData(demux, PESCallback, &context);
		RMvdemuxSetAudioCallbacks(demux, AC3DTSCallback, LPCMCallback, aobPcm_callback, mlp_callback);
	}
	else {
		demux = (ExternalRMvdemux) NULL;
                printf("demux=NULL\n");//added by Betta
#if 0
		RMDBGLOG((ENABLE, "system unknown, exiting\n"));
		err = RM_ERROR;
		goto exit_with_error;
#endif
	}

	dcc_info.chip_num = play_opt->chip_num;
	dcc_info.pDH = NULL;

	err = apply_playback_options(&dcc_info, play_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set playback options %d\n", err));
		goto exit_with_error;
	}


	{
		// open first stc module
		struct DCCStcProfile stc_profile;
		stc_profile.STCID = 0;
		stc_profile.master = Master_STC;
		
		stc_profile.stc_timer_id = 0;
		stc_profile.stc_time_resolution = 90000;
		
		stc_profile.video_timer_id = 1;
		stc_profile.video_time_resolution = 90000;
		stc_profile.video_offset = -(play_opt->video_delay_ms * (RMint32)stc_profile.video_time_resolution / 1000);
		
		stc_profile.audio_timer_id = 2;
		stc_profile.audio_time_resolution = 90000;
		stc_profile.audio_offset = -(play_opt->audio_delay_ms * (RMint32)stc_profile.audio_time_resolution / 1000);
		
		err = DCCSTCOpen(dcc_info.pDCC, &stc_profile, &dcc_info.pStcSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot open stc module %d\n", err));
			goto exit_with_error;
		}
	}


	video_profile.MPEGProfile = video_opt->MPEGProfile;
	video_profile.BitstreamFIFOSize = VIDEO_FIFO_SIZE;
 	video_profile.XferFIFOCount = XFER_FIFO_COUNT;
	video_profile.DemuxProgramID = 0;
	video_profile.SPUBitstreamFIFOSize = (enable_spu) ? SPU_FIFO_SIZE : 0;
	video_profile.SPUXferFIFOCount = (enable_spu) ? XFER_FIFO_COUNT : 0;

	video_profile.STCID = 0;

	err = DCCOpenVideoDecoderSource(dcc_info.pDCC, &video_profile, &pVideoSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot open video decoder %d\n", err));
		goto exit_with_error;
	}

	err = DCCSetVideoDecoderSourceCodec(pVideoSource, video_opt->Codec);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set video decoder codec %d\n", err));
		goto exit_with_error;
	}

	err = DCCGetScalerModuleID(dcc_info.pDCC, DCCRoute_Main, DCCSurface_Video, videoscaler_id, &(dcc_info.SurfaceID));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot get surface to display video source %d\n", err));
		goto exit_with_error;
	}

	err = DCCSetSurfaceSource(dcc_info.pDCC, dcc_info.SurfaceID, pVideoSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set the surface source %d\n", err));
		goto exit_with_error;
	}

	audio_profile.BitstreamFIFOSize = AUDIO_FIFO_SIZE;
 	audio_profile.XferFIFOCount = XFER_FIFO_COUNT;
	audio_profile.DemuxProgramID = audio_opt->ae * 2;

	audio_profile.STCID = 0;

	err = DCCOpenAudioDecoderSource(dcc_info.pDCC, &audio_profile, &pAudioSource);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot open audio decoder %d\n", err));
		goto exit_with_error;
	}

	/* dmapool must be created after the module open in case we do no copy transfers */
 	err = RUAOpenPool(dcc_info.pRUA, 0, DMA_BUFFER_COUNT, DMA_BUFFER_SIZE_LOG2, RUA_POOL_DIRECTION_SEND, &pDMA);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error cannot open dmapool %d\n", err));
		goto exit_with_error;
	}

	dcc_info.route = DCCRoute_Main;
	dcc_info.pVideoSource = pVideoSource;
	dcc_info.pAudioSource = pAudioSource;
	dcc_info.state = (play_opt->start_pause) ? RM_PAUSED : RM_PLAYING;
	dcc_info.trickmode_id = RM_NO_TRICKMODE;

	dcc_info.seek_supported = FALSE;

	err = DCCGetVideoDecoderSourceInfo(pVideoSource, &(dcc_info.video_decoder), &(dcc_info.spu_decoder), &(dcc_info.video_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting video decoder source information %d\n", err));
		goto exit_with_error;
	}

#if 0	// test for "mpeg4 720p profile". Profile has to be 816P and codec MPEG4_SD
	{
		enum VideoDecoder_Codec_type codec = VideoDecoder_Codec_MPEG4_SD;
		RUASetProperty(dcc_info.pRUA, dcc_info.video_decoder, RMVideoDecoderPropertyID_Codec, &codec, sizeof(codec), 0);
	}
#endif
	err = DCCGetAudioDecoderSourceInfo(pAudioSource, &(dcc_info.audio_decoder), &(dcc_info.audio_engine), &(dcc_info.audio_timer));
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error getting audio decoder source information %d\n", err));
		goto exit_with_error;
	}

	// apply the fixed vop rate if required
	err = apply_video_decoder_options(&dcc_info, video_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error applying video_decoder_options %d\n", err));
		goto exit_with_error;
	}
	
	if (video_opt->VopInfo.FixedVopRate) {
		RMDBGLOG((ENABLE, "fixed vop rate from command line: %ld / %ld frames per second\n",
			video_opt->VopInfo.VopTimeIncrementResolution, video_opt->VopInfo.FixedVopTimeIncrement));
	}
	else if (video_opt->vtimescale.enable) {
		RMDBGLOG((ENABLE, "video time scale from command line: %ld ticks per second\n",
			video_opt->vtimescale.time_resolution));
	}
	else {
		/* time stamps are in 45k, ask the decoder to interpolate the time info from stream.
		For m4v the property will succeed. */
		video_opt->vtimescale.enable = TRUE;
		video_opt->vtimescale.time_resolution = 90000;
		err = RUASetProperty(dcc_info.pRUA, dcc_info.video_decoder, RMVideoDecoderPropertyID_VideoTimeScale,
			&video_opt->vtimescale, sizeof(video_opt->vtimescale), 0 );
		if (RMSUCCEEDED(err)) {
			RMDBGLOG((ENABLE, "set video time scale: %ld ticks per second\n",
				video_opt->vtimescale.time_resolution));
		}
		else {
			/* time scaling is not supported - it happens for NO M4V decoders.
			We have to use fixed vop rate. */
			video_opt->VopInfo.FixedVopRate = TRUE;
			video_opt->VopInfo.VopTimeIncrementResolution = 90000;
			video_opt->VopInfo.FixedVopTimeIncrement = 3000;
		
			err = RUASetProperty(dcc_info.pRUA, dcc_info.video_decoder, RMVideoDecoderPropertyID_VopInfo,
				&video_opt->VopInfo, sizeof(video_opt->VopInfo), 0 );
			if (RMSUCCEEDED(err)) {
				RMDBGLOG((ENABLE, "video time scale not supported. Set fixed vop rate: %ld / %ld frames per second\n",
					video_opt->VopInfo.VopTimeIncrementResolution, video_opt->VopInfo.FixedVopTimeIncrement));
			}
			else {
				RMDBGLOG((ENABLE,"video time scale not supported. Error setting fixed VOP rate : %d !\n", err));
			}
		}
	}

	// apply the sample rate, serial out status
	err = apply_audio_engine_options(&dcc_info, audio_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error applying audio engine options %d\n", err));
		goto exit_with_error;
	}
	// apply the audio format - uninit, set codec, set specific parameters, init
	err = apply_audio_decoder_options(&dcc_info, audio_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Error applying audio_decoder_options %d\n", err));
		goto exit_with_error;
	}
#ifndef WITH_MONO
	set_default_out_window(&(dcc_info.disp_info->out_window));
	set_default_out_window(&(dcc_info.disp_info->osd_window[0]));
	set_default_out_window(&(dcc_info.disp_info->osd_window[1]));
	dcc_info.disp_info->active_window = &(dcc_info.disp_info->out_window);
	dcc_info.disp_info->video_enable = TRUE;

	err = apply_display_options(&dcc_info, disp_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot set display options %d\n", err));
		goto exit_with_error;
	}

	if (manutest == TRUE) {
		if (demux_opt->data_type == RMVDEMUX_VIDEO)
			fprintf(stdout, "\nIs the Video output correctly? <Y/Q> ");
		else if (demux_opt->data_type == RMVDEMUX_AUDIO)
			fprintf(stdout, "\nIs the Audio output correctly? <Y/Q> ");
	}

	display_key_usage(KEYFLAGS);
#endif /*WITH_MONO*/

	// TODO determine NumChannel from options->Codec and options->SubCodec
	apply_dvi_hdmi_audio_options(&dcc_info, audio_opt, 2, FALSE, FALSE, FALSE);

	if(enable_spu){
		RMuint32 spu_decoder = dcc_info.spu_decoder;
		enum SpuDecoder_StreamType_type spu_st = SpuDecoder_StreamType_4by3;  // type according to selected stream from PGC_SPST_CTL
		RMbool spu_disp = TRUE;  // shall sub picture be displayed? may be overridden by forced display from stream. use GetProp_Display to check actual state.
		struct SpuDecoder_Palette_type spu_lut = {{  // DVD format: Y,Cr,Cb
			0x00, 0x28, 0x6d, 0xf0,
			0x00, 0x51, 0xf0, 0x5a,
			0x00, 0x10, 0x80, 0x80,
			0x00, 0xea, 0x80, 0x80,
			
			0x00, 0x66, 0xdb, 0x4e,
			0x00, 0x6a, 0xdd, 0xca,
			0x00, 0xd2, 0x92, 0x10,
			0x00, 0x5b, 0x49, 0x92,
			
			0x00, 0x7b, 0x80, 0x80,
			0x00, 0xc9, 0x98, 0x77,
			0x00, 0x30, 0xb6, 0x6d,
			0x00, 0x4f, 0x51, 0x5b,
			
			0x00, 0x1c, 0x77, 0xb6,
			0x00, 0x61, 0xcf, 0xcf,
			0x00, 0x10, 0x80, 0x80,
			0x00, 0xbf, 0x80, 0x80,
		}};  // dummy ScalerModuleID
		err = RUASetProperty(dcc_info.pRUA, spu_decoder, RMSpuDecoderPropertyID_Palette, &spu_lut, sizeof(spu_lut), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu palette\n"));
			goto exit_with_error;
		}

		err = RUASetProperty(dcc_info.pRUA, spu_decoder, RMSpuDecoderPropertyID_StreamType,&spu_st, sizeof(spu_st), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu type\n"));
			goto exit_with_error;
		}
			
		err = RUASetProperty(dcc_info.pRUA, spu_decoder, RMSpuDecoderPropertyID_SubpictureOn, &spu_disp, sizeof(spu_disp), 0);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot set spu ON\n"));
			goto exit_with_error;
		}
	}

	context.pRUA = dcc_info.pRUA;
	context.pDMA = pDMA;
	context.repack_sample = demux_opt->repack_sample;
	context.enable_spu = enable_spu;
	context.cmd = 0;
	context.start_90khz = play_opt->start_ms * 90;

	context.dcc_info = &dcc_info;

	context.PSMcontext = &PSMContext;
	PSMContext.validPSMContexts = 1;
	PSMContext.currentActivePSMContext = 1;
	PSMContext.keyflags = KEYFLAGS;
/* 
marked by Betta

if (file == NULL) {
open_stream(play_opt->filename, RM_FILE_OPEN_READ, 0);
		RMDBGLOG((ENABLE, "Cannot open file %s\n", play_opt->filename));
		goto exit_with_error;
	}

	err = RMSizeOfOpenFile(file, &(context.file_size));
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "Cannot find file size\n"));
		context.file_size = (RMint64) -1;
	}

	RMDBGLOG((ENABLE, "file: %s, size %llu, duration %llu\n", play_opt->filename, context.file_size, play_opt->duration / 1000));
*/
	dcc_info.RM_PSM_commands = RM_PSM_ENABLE_PLAY;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_STOP;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_PAUSE;

	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SPEED;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_FASTER;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SLOWER;
	dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_NEXTPIC;

	if ((play_opt->duration > 1000) && (context.file_size > 0)) {
		RMDBGLOG((ENABLE, "seek and iframe mode enabled\n"));

		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_SEEK;
		
		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_IFWD;
		dcc_info.RM_PSM_commands |= RM_PSM_ENABLE_IRWD;

		context.dcc_info->seek_supported = TRUE;
		context.dcc_info->iframe_supported = TRUE;
	}


	if (user_data_test) {
		struct Receive_type Receive;
		Receive.pRUA = dcc_info.pRUA;
		Receive.targetModule = EMHWLIB_TARGET_MODULE(VideoDecoder, EMHWLIB_MODULE_INDEX(dcc_info.video_decoder), 1);
		Receive.buffer_count = 4;
		Receive.buffer_size_log2 = 12;	// 4k per buffer -> 16M
		err = DCCOpenReceive(&Receive, &context.pReceive, &context.pDmaUserData);
		err = DCCGetReceiveEvent(context.pReceive, &context.EventUserData);
		context.f_record = fopen("userdata.bin", "wb");
		if (context.f_record == NULL)
			RMDBGLOG((ENABLE, "Error opening userdata.bin"));
	}



	/* correct pids according to audio codec and system type */
	if ((demux_opt->system_type == RM_SYSTEM_MPEG2_DVD) || (demux_opt->system_type == RM_SYSTEM_MPEG2_PROGRAM)) {
		if (demux_opt->audio_pid == 0) {/* If audio PID==PES ID is not provided by user use audio codec option to detect */
			demux_opt->audio_pid = (audio_opt->Codec == AudioDecoder_Codec_MPEG1) ? 0xC0:0xBD;
		}
		if (audio_opt->Codec == AudioDecoder_Codec_MPEG1) {
			if ( demux_opt->audio_pid != (0xC0 + demux_opt->audio_subid)) {
				RMDBGPRINT((ENABLE, "\n***************** audio_pid audio_subid conflict *****************\n"));
				RMDBGPRINT((ENABLE, "*** for mpeg audio select either audio_pid, either audio_subid ***\n"));
				RMDBGPRINT((ENABLE, "******************************************************************\n\n"));
			}
			demux_opt->audio_pid = 0xC0 + demux_opt->audio_subid;
		}
	}
#ifndef WITH_MONO	
	RMTermInit(FALSE);    // don't allow ctrl-C and the like ...
	//RMSignalInit(NULL, NULL);  // ... but catch other termination signals to call RMTermExit()
#endif

	repack_buf = (RMuint8 *) RMMalloc(1<<DMA_BUFFER_SIZE_LOG2);
	if (repack_buf == NULL)
		goto cleanup;

	do {
		 RMuint8 *buf;

	mainloop:
		RMDBGLOG((ENABLE, "mainloop\n"));
                err=RM_OK; //added by Betta
		file_offset = 0;
		//err = RMSeekFile(file, 0, RM_FILE_SEEK_START); //marked by Betta
		if (err != RM_OK) {
			RMDBGLOG((ENABLE, "Error seeking file to beginning %d\n", err));
			goto cleanup;
		}

	mainloop_no_seek:
		RMDBGLOG((ENABLE, "mainloop_noseek\n"));

		if (actions.cmd == RM_SEEK) {
			RMint64 seek_pos;

			seek_pos = (dcc_info.seek_time * context.file_size * 1000) / (play_opt->duration);
			RMDBGLOG((ENABLE, "seeking to %lu s, pos %llu\n", dcc_info.seek_time, seek_pos)); 

			if (RMSeekFile(file, seek_pos, RM_FILE_SEEK_START) != RM_OK) {
				RMDBGLOG((ENABLE, "Error: seeking file to position %lu s, %lld kB\n", dcc_info.seek_time, seek_pos/1024));
				goto cleanup;
			}

		}

		//PROCESS_KEY(FALSE, TRUE); marked by Betta 

		/* required in order to start playing right away, otherwise, if state is stopped, process_command will block
		   until a play is issued */
		RM_PSM_SetState(context.PSMcontext, &(context.dcc_info), RM_PSM_Playing);


		

		context.FirstSystemTimeStamp = TRUE;
		context.ResumeFromTrickMode = FALSE;
		context.audio_byte_counter = 0;
		context.video_byte_counter = 0;
		context.audio_repack_buf = (RMuint8 *) NULL;
		context.video_repack_buf = (RMuint8 *) NULL;
		context.spu_repack_buf = (RMuint8 *) NULL;
		context.audio_repack_offset = 0;
		context.video_repack_offset = 0;
		context.spu_repack_offset = 0;
		context.audio_repack_size = 0;
		context.video_repack_size = 0;
		context.spu_repack_size = 0;
		context.audio_repack_pts = 0;
		context.video_repack_pts = 0;
		context.spu_repack_pts = 0;
		context.audio_repack_pts_valid = FALSE;
		context.video_repack_pts_valid = FALSE;
		context.spu_repack_pts_valid = FALSE;
		context.audio_first_access_unit_pointer_valid = FALSE;
		context.audio_first_access_unit_pointer = 0;
		context.hdcp_last_check	= get_ustime();
		context.IFrameTrickMode = FALSE;
		context.prev_IFrameTrickMode = FALSE;

		context.waitForValidAudioPTS = TRUE;
		context.ignoreCallback = FALSE;
		context.STCrunning = FALSE;

		if (dcc_info.state == RM_PLAYING_TRICKMODE) {
			dcc_info.state = RM_PLAYING;
			dcc_info.trickmode_id = RM_NO_TRICKMODE;
		}

 		if (demux) {
			RMvdemuxReset(demux);
			RMvdemuxSetVideoStream(demux, demux_opt->video_pid, 0);
			RMvdemuxSetSubpictureStream(demux, demux_opt->spu_subid);
			RMvdemuxSetAudioStream(demux, demux_opt->audio_pid, demux_opt->audio_subid);
		}

		DCCSTCSetSpeed(dcc_info.pStcSource, play_opt->speed_N, play_opt->speed_M);
		
		if (NTimes)
			Stop(&context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO);
		
		if (user_data_test)	/* ReceivePool for used data should be cleared every time when Video is stopped */
			RUAPreparePoolForReceiveData(context.pDmaUserData);

		Play(&context, RM_DEVICES_AUDIO | RM_DEVICES_VIDEO, DCCVideoPlayFwd);

#ifdef WITH_MONO
		RMDCCInfo(&dcc_info); // pass DCC context to application
#endif

		while (1) {

//			RMuint32 count=0;

		//	PROCESS_KEY(FALSE, TRUE); //marked by Betta 
			if (demux_opt->repack_sample) {
				buf = repack_buf;
			}
			else {
				if (buf) {
					RMDBGLOG((ENABLE, "******************** unreleased buffer found!\n"));
					RUAReleaseBuffer(pDMA, buf);
					buf = NULL;
				}					
				while (RUAGetBuffer(pDMA, &buf,  GETBUFFER_TIMEOUT_US) != RM_OK) {
					if (!context.STCrunning) {
						RMDBGLOG((ENABLE, "starting stc\n"));
						DCCSTCPlay(dcc_info.pStcSource);
						context.STCrunning = TRUE;
					}

					PROCESS_KEY(FALSE, TRUE);
				}
			}
			
#ifdef CHECK_HDCP_INTEGRITY
			if ((get_ustime() - context.hdcp_last_check) > 500*1000) {
				if (dcc_info.pDH != NULL) {
					DHIntegrityCheck(dcc_info.pDH);
				}
				context.hdcp_last_check = get_ustime();
			}
#endif

			if (RM_PSM_GetState(context.PSMcontext, &(context.dcc_info)) == RM_PSM_IRewind) {
/* marked by Betta
				RMint64 position;
				RMuint64 seekto;


				if (!trickSizeToSend) {
					trickSizeToSend = (RMuint32) (context.file_size / (play_opt->duration / 500)); //there are roughly 2 iframes per second
					trickBuffersToSend = trickSizeToSend / (1<<DMA_BUFFER_SIZE_LOG2);
					RMDBGLOG((ENABLE, "size %llu, duration %lu s, iframeSize %lu, buffers %lu (of %lu bytes)\n", 
						  context.file_size, 
						  (RMuint32)(play_opt->duration / 1000), 
						  trickSizeToSend,
						  trickBuffersToSend,
						  (1<<DMA_BUFFER_SIZE_LOG2)));
					
				}
				if (trickBuffersSent >= trickBuffersToSend)
					trickBuffersSent = 0;
*/ 
/* marked by  Betta
				if (trickBuffersSent == 0) {
					RMGetCurrentPositionOfFile(file, &position);
					seekto = position - (RMuint64) 2 * trickBuffersToSend * (1<<(DMA_BUFFER_SIZE_LOG2));
					RMDBGLOG((ENABLE, "pos %llu, seekto %llu\n", position, seekto));
					status = RMSeekFile(file, seekto, RM_FILE_SEEK_START);
					if (status != RM_OK) {
						perror("error seeking in rwd trickmode, assume EOS\n");
						break;
					}
				}
*/                   /* marked by Betta
				status = RMReadFile(file, buf, (1<<DMA_BUFFER_SIZE_LOG2), &count);
			
            	                trickBuffersSent++;
				RMDBGLOG((ENABLE, "sent buffer %lu\n", trickBuffersSent));
		      */
                 	}
			else {
/*
        	        	status = RMReadFile(file, buf, (1<<DMA_BUFFER_SIZE_LOG2), &count);
	// marked by Betta
           			trickBuffersSent = 0;
*/
			}
                        RMstatus status=RM_OK; //added by Betta
			if (status == RM_ERRORREADFILE) {
				RMDBGLOG((ENABLE, "Error reading file %d\n", status));
				goto cleanup;
			}
	
			if (status == RM_ERRORENDOFFILE) {
				if (demux_opt->repack_sample) 
					flush_repacked_sample(&context);
				else {
					RMDBGLOG((ENABLE, "release a buffer\n"));
					RUAReleaseBuffer(pDMA, buf);
					buf = NULL;
				}
				break;
			}
                        fgSigmaReady=1;
                   
		//	file_offset += count; marked by Betta
			if ( demux ) {
                              do {
                                sem_wait(&Sigma_sem);
                                num=tLen/(1<<DMA_BUFFER_SIZE_LOG2);
                                //(char *)buf= tBuffer;    //modified by Betta

                                for (i=0; i<num; i++ )
                                {  
			
                         
                                   RMvdemuxDemux(demux,(RMuint8 *)tBuffer,1<< DMA_BUFFER_SIZE_LOG2);
                                   tBuffer +=(1<<DMA_BUFFER_SIZE_LOG2);
                                }
                                RMvdemuxDemux(demux,(RMuint8 *)tBuffer, tLen%(1<<DMA_BUFFER_SIZE_LOG2));
                           //     PROCESS_KEY(FALSE, FALSE);
                                sem_post(&S21_sem);
          
                           } while(tLen);//end of while (1)


	/* check if the user pressed a key when we were processing a callback */
			   //RMDBGLOG((KEYDBG, "after callback\n"));
		//	   PROCESS_KEY(FALSE, FALSE);
			}
			else {
 				RMbool pts_valid = FALSE;
				RMuint64 stc;

				/* send only ONCE the PTS, do not use FistSystemTimeStamp which is set on TRICKMODE */
				if ((demux_opt->data_type == RMVDEMUX_AUDIO) && (context.audio_byte_counter == 0))
					pts_valid = TRUE;

				/* send only ONCE the PTS, do not use FistSystemTimeStamp which is set on TRICKMODE */
				if ((demux_opt->data_type == RMVDEMUX_VIDEO) && (context.video_byte_counter == 0))
					pts_valid = TRUE;

				/* fast forward may have been too fast for the decoder. Must set the STC
				   to the current picture in display to avoid skipping frames to catch STC 
				*/
				if (dcc_info.state != RM_PLAYING_TRICKMODE) {
					RMbool stc_valid = FALSE;

					if (context.FirstSystemTimeStamp) {
						stc = 0;
						stc_valid = TRUE;
						context.FirstSystemTimeStamp = FALSE;
					}
					else if (context.ResumeFromTrickMode) {
						err = RUAGetProperty(dcc_info.pRUA, dcc_info.SurfaceID, RMGenericPropertyID_CurrentDisplayPTS, &stc, sizeof(stc));
						if (RMFAILED(err)) {
							RMDBGLOG((ENABLE, "Cannot get video PTS\n"));
						}
						else {
							stc_valid = TRUE;
							RMDBGPRINT((ENABLE, "Set STC afer trickmode %llu\n", stc));
						}
						context.ResumeFromTrickMode = FALSE;
					}
					if ((stc_valid) && (dcc_info.SurfaceID != 0)) {

						DCCSTCSetTime(dcc_info.pStcSource, stc, 45000);
						DCCSTCPlay(dcc_info.pStcSource);

					}
				}
				
				PESCallback(buf, count, 0, pts_valid, demux_opt->data_type, 0, &context);
			}

                        goto cleanup; //added by Betta
			if (user_data_test) {
				RMuint8 *pBuf = NULL;
				RMuint32 size = 0;
				RMuint32 targetModule = EMHWLIB_TARGET_MODULE(VideoDecoder, EMHWLIB_MODULE_INDEX(dcc_info.video_decoder), 1);
				if (RUAWaitForMultipleEvents(dcc_info.pRUA, &context.EventUserData, 1, TIMEOUT_1MS, NULL) == RM_OK ) {
					err = RUAReceiveData(dcc_info.pRUA, targetModule, context.pDmaUserData, &pBuf, &size, NULL, NULL);
					if ( (err == RM_OK) && pBuf ) {
						if ( context.f_record && (size > 0) ) {
							if(context.f_record_size < 0xA00000) {
								fwrite(pBuf, 1, size, context.f_record);
								context.f_record_size += size;
							}
						}
						RMDBGLOG((ENABLE, "user_data receive size=0x%lx\n", size));
						RUAReleaseBuffer(context.pDmaUserData, pBuf);
					}
				}
			}

			PROCESS_KEY(TRUE, TRUE);
			
			if (!demux_opt->repack_sample) {
				RUAReleaseBuffer(pDMA, buf);
				buf = NULL;
			}
		}

		if (!context.STCrunning) {
			RMDBGLOG((ENABLE, "starting stc\n"));
			DCCSTCPlay(dcc_info.pStcSource);
			context.STCrunning = TRUE;
		}

		err = WaitForEOS(&context, &context.cmd);
		if ((err != RM_OK) && (err != RM_KEY_WHILE_WAITING_EOS)) {
			RMDBGLOG((ENABLE, "WaitForEOS returned error\n"));
		}

		if ((context.cmd == RM_QUIT) || (context.cmd == RM_STOP))
			goto cleanup;
		if ((manutest == TRUE) && (context.cmd == RM_MANU_QUIT_OK))
			goto cleanup;
		if  (context.cmd == RM_STOP_SEEK_ZERO)
			goto mainloop;

		if (play_opt->loop_count > 0)
			play_opt->loop_count --;
	} while ((play_opt->infinite_loop) || (play_opt->loop_count > 0));
	
 cleanup:
	error = 0;

 exit_with_error:
#ifndef WITH_MONO	
	RMTermExit();
#endif
	if (err != RM_OK) {
		RMDBGLOG((ENABLE, "exiting due to error %d, %s\n", err, RMstatusToString(err)));
		error = -1; //exit with error
	}

	RMDBGLOG((ENABLE, "closing...\n"));

	if (repack_buf != NULL)
		RMFree(repack_buf);

	if (manutest == TRUE) {
		if (context.cmd == RM_MANU_QUIT_OK)
			fprintf(stdout, "Succeed.\n");
		else 
			fprintf(stdout, "Failed.\n");
	}
	if (file) {
		RMDBGLOG((ENABLE, "closing bitstream %s\n", play_opt->filename));
		RMCloseFile(file);
	}
	err = close_save_files(play_opt);
	if (RMFAILED(err)) {
		RMDBGLOG((ENABLE, "Cannot close files used to save data %d\n", err));
		error = -1;
	}

	if( play_opt->waitexit ) {
		RMascii key;
		fprintf(stderr, "press q key again if you really want to stop & quit\n");
		while ( !(RMGetKeyNoWait(&key) && ((key == 'q') || (key =='Q'))) );
	}
	

	if (dcc_info.pStcSource) {
		RMDBGLOG((ENABLE, "stop STC\n"));
		DCCSTCStop(dcc_info.pStcSource);
	}

	if (pVideoSource) {
		RMDBGLOG((ENABLE, "stop video source\n"));
		err = DCCStopVideoSource(pVideoSource, DCCStopMode_LastFrame);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop video decoder %d\n", err));
			error = -1;
		}
		RMDBGLOG((ENABLE, "close video source\n"));
		err = DCCCloseVideoSource(pVideoSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close video decoder %d\n", err));
		}
	}
	
	if (pAudioSource) {
		RMDBGLOG((ENABLE, "stop audio source\n"));
		err = DCCStopAudioSource(pAudioSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot stop audio decoder %d\n", err));
			error = -1;
		}
		RMDBGLOG((ENABLE, "close audio source\n"));
		err = DCCCloseAudioSource(pAudioSource);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close video decoder %d\n", err));
			error = -1;
		}
	}

	if (pDMA) {
		RMDBGLOG((ENABLE, "close DMA pool\n"));
		err = RUAClosePool(pDMA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Error cannot close dmapool %d\n", err));
			error = -1;
		}
	}


	if (context.f_record) {
		fclose(context.f_record);
		context.f_record = NULL;
	}
	if (context.pReceive)
		DCCCloseReceive (context.pReceive);



	clear_video_options(&dcc_info, video_opt);
#ifndef WITH_MONO	
	clear_display_options(&dcc_info, disp_opt);

	if (dcc_info.pDCC) {
		RMDBGLOG((ENABLE, "close DCC\n"));
		err = DCCClose(dcc_info.pDCC);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot close DCC %d\n", err));
			error = -1;
		}
	}

	if (dcc_info.pRUA) {
		RMDBGLOG((ENABLE, "close RUA\n"));
		err = RUADestroyInstance(dcc_info.pRUA);
		if (RMFAILED(err)) {
			RMDBGLOG((ENABLE, "Cannot destroy RUA instance %d\n", err));
			error = -1;
		}
	}
#endif /*WITH_MONO*/

	if (manutest == TRUE)
		return (context.cmd == RM_MANU_QUIT_OK ? 0 : 1);

//	return error;
        return 0;

}
