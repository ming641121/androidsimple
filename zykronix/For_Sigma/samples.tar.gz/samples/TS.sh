#!/bin/sh

arm-elf-g++ -I.  -D_S21OS_LINUX_ -D_S21OS_UCLINUX_ -c platform.cpp
arm-elf-g++ -I.  -D_S21OS_LINUX_ -D_S21OS_UCLINUX_ -c testnc.cpp

arm-elf-g++ -O2 -DEM86XX_CHIP=EM86XX_CHIPID_TANGOLIGHT \
-DEM86XX_REVISION=67 \
-DEM86XX_MODE=EM86XX_MODEID_STANDALONE -DWITH_AES_CBC=1 \
-D_FILE_OFFSET_BITS=64 \
-DWITH_RM_FILE_JPEG  -DLLAD_DIRECT -D__arm__ \
-I/home/sigma/nfs/mrua_EM8620L_2.5.91.0_dev.arm/MRUA_src/samples/.. \
-I. -D_REENTRANT  -U_DEBUG \
-DRMPLATFORM=RMPLATFORMID_JASPERMAMBO \
-Wundef -Wall -Wchar-subscripts -Wsign-compare \
-Wuninitialized -O \
-I. -D_S21OS_LINUX_ -D_S21OS_UCLINUX_ \
-c   play_demux_TS.cpp

arm-elf-gcc -c main.cpp



arm-elf-g++ play_demux_TS.o  main.o testnc.o platform.o \
dbgimplementation.o rmmmimplementation.o get_time.o get_key.o \
process_key.o parse_display_cmdline.o parse_video_cmdline.o parse_capture_cmdline.o \
parse_audio_cmdline.o parse_playback_cmdline.o osdlib.o dvi_hdmi.o dss_sha.o \
pidfilter.o boot_osd.o rminputstream.o parsemp4dsi.o bitmaps.o rmmemfile.o ccparse.o \
bcc_init.o bcc_feed.o bcc_close.o \
../lib/librua.a ../lib/libllad.a ../lib/libdcc.a ../lib/librmvdemux.a ../lib/librmcore.a \
../lib/librmjpeg.a ../lib/librmungif.a ../lib/librmpng.a ../lib/librmzlib.a ../lib/librmhttp.a \
../lib/librmpidfilter.a ../lib/librmscc.a ../lib/librmaviapi.a ../lib/librmavi.a ../lib/librmmp4api.a \
../lib/librmmp4.a ../lib/librmmp4core.a ../lib/librmdescriptordecoder.a ../lib/librmmpeg4framework.a \
../lib/librmrtk86.a ../lib/librmasfdemux.a ../lib/librmasfdemuxcore.a ../lib/librmdtcp.a \
../lib/librmsymboltable.a ../lib/librmcpputils.a ../lib/librmcw.a ../lib/librmwmaprodecoder.a \
../lib/librmwmaprodecodercore.a ../lib/librmwmdrmnd.a ../lib/librmwmdrmndcore.a -W1, -elf2flt="-s32768" \
-D_S21OS_LINUX_ -D_S21OS_UCLINUX_ \
-ls21nc  -L../lib/  -lpthread -o play_TS
