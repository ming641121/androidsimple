//-------------------------------------------------------------------------
//
//	Copyright (c)  2000 - 2004  Streaming21 Inc. All rights reserved.
//
//	ALL RIGHTS RESERVED. NO PART OF THIS CODE AND INFORMATION MAY BE 
//	REUSED, REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY MEANS,
//	WITHOUT WRITTEN PERMISSION FROM THE COMPANY.
//
//	Description : Error Code Table ( for API user )
//
//-------------------------------------------------------------------------

#ifndef __S21ERRORCODE_H_
#define __S21ERRORCODE_H_

typedef unsigned long S21_NET_RC;

enum 
{
	S21_NET_NoErr						= 0,
	S21_NET_Err							= 1,

	S21_SVR_Err							= 2,

	// S21_SVR : code returned by server

	// General error not related to input parameters
	S21_SVR_InvalidLicenseKey			= 3,
	S21_SVR_LicenseKeyNotFound			= 4,
	S21_SVR_LicenseExpired				= 5,
	S21_SVR_InproperApplication			= 6,
	S21_SVR_InvalidStatus				= 7,
	S21_SVR_ConfigurationNotDone		= 8,
	S21_SVR_InsufficientResource		= 9,
	S21_SVR_FeatureNotApplicable		= 10,
	S21_SVR_FeatureNotImplementedYet	= 11,
	S21_SVR_ServerNotStarted			= 12,
	S21_SVR_ServerAlreadyStarted		= 13,
	S21_SVR_SubSystemDisabled			= 14,
	S21_SVR_FileFormatDisabled			= 15,

	// General error related to input parameters,
	S21_SVR_ObjectNotFound				= 16, // media file object not found
	S21_SVR_ObjectAlreadyExist			= 17,
	S21_SVR_AccessDenied				= 18,
	S21_SVR_InvalidUserHandle			= 19,
	S21_SVR_InvalidInputParams			= 20, // e.g. wrong enum, null ptr

	S21_SVR_UserProfileDbError			= 22,
	S21_SVR_UserProfileNotFound			= 23,
	S21_SVR_InvalidLogin				= 24, // login fail
	S21_SVR_LoginMaxReached				= 25,
	S21_SVR_MemoryAllocation			= 26,
	S21_SVR_InvalidHomeDirectory		= 27,
	S21_SVR_NoEligibleMediaVolume		= 28,
	S21_SVR_UnformattedMediaVolume		= 29,
	S21_SVR_ExceedSystemCapability		= 30,
	S21_SVR_ExceedProductLicense		= 31,
	S21_SVR_ExceedMediaFileLicense		= 32,
	S21_SVR_SchedulingNotSafe			= 33,
	S21_SVR_SessionNotStarted			= 34,
	S21_SVR_ReadDataNotReady			= 35,
	S21_SVR_WriteDataOverflowed			= 36,
	S21_SVR_InaccessibleMediaFile		= 37,	// the object is exclusive locked
	S21_SVR_ReachMaxFileEntries			= 42,
	S21_SVR_ReachMaxDirectoryEntries	= 43,
	S21_SVR_AllocationDiskSpaceFailed	= 44,
	S21_SVR_CreateCancelled				= 45,

	S21_SVR_RtspVersionIncompatible		= 47,

	S21_SVR_FileFormatNotSupported		= 50,   // The media format is not supported

	S21_SVR_NotOperatingSystemAdmin		= 61,
	S21_SVR_RemoteCapDisabled			= 62,
	S21_SVR_InvalidFunctionId			= 63,
	S21_SVR_UserNotActivated			= 64,
	S21_SVR_UserExpired					= 65,
	S21_SVR_UserCannotBrowse			= 66,
 	S21_SVR_UserMultpleLoginExceed		= 67,
	S21_SVR_UserDiskQuotaExceed			= 68,

	S21_SVR_UserProfileHasNoRecord		= 74,
	S21_SVR_CannotUnlinkUserLastGroup	= 77,
	S21_SVR_OnlyOneStmForSameClientSameClip	= 78,
	S21_SVR_UserAccountMaxExceeded		= 79,
	S21_SVR_InvalidPathFileName			= 80,

	// S21_NET : code returned by server or client

	S21_NET_SocketOpenedAlready			= 6001,
	S21_NET_SocketOpenError				= 6002,
	S21_NET_SocketNotOpen				= 6003,
	S21_NET_SocketBindError				= 6004,
	S21_NET_SocketBoundAlready			= 6005,
	S21_NET_SocketNotBound				= 6006,
	S21_NET_SocketConnError				= 6007,
	S21_NET_SocketSendError				= 6008,
	S21_NET_SocketRecvError				= 6009,
	S21_NET_SocketCanNotStart			= 6010,
	S21_NET_SocketIOCtlError			= 6011,
	S21_NET_SocketCanNotCThread			= 6012,
	S21_NET_SocketPortInUse				= 6013,
	S21_NET_SocketNotConnected			= 6014,
	S21_NET_SocketSetOptionsError		= 6015,
	S21_NET_SocketAcceptError			= 6016,
	S21_NET_SocketListenError			= 6017,
	S21_NET_SocketListening				= 6018,
	S21_NET_SocketNotListening			= 6019,

	S21_NET_InvalidMessageSocket		= 6100,
	S21_NET_InvalidFile					= 6101,
	S21_NET_InvalidArgument				= 6102,
	S21_NET_StreamManagerDown			= 6103,
	S21_NET_SessionIDMismatch			= 6104,
	S21_NET_WriteExceedFileSize			= 6105,
	S21_NET_WriteIncomplete				= 6106,
	S21_NET_WriteBufferFull				= 6107,
	S21_NET_InvalidLocalFile			= 6108,
	S21_NET_InvalidRemoteFile			= 6109,
	S21_NET_InvalidRequest				= 6110,
	S21_NET_InvalidResponse				= 6111,
	S21_NET_NoMatchRequest				= 6112,
	S21_NET_InvalidProtocol				= 6113,

	S21_NET_AlreadyConnected			= 7001,
	S21_NET_OutOfResource				= 7002,
	S21_NET_WaitTimeOut					= 7003,
	S21_NET_FileNotFound				= 7004,
	S21_NET_ConnectFail					= 7005,
	S21_NET_IPNotFound					= 7006,
	S21_NET_NotConnected				= 7007,
	S21_NET_ServerDown					= 7008,
	S21_NET_InvalidSocket				= 7009,
	S21_NET_EndOfStream					= 7011,
	S21_NET_RtspListenerDown			= 7012,
	S21_NET_StmNotReadyIn10Seconds		= 7013,
	S21_NET_UnicastNotPermit            = 7014,
	S21_NET_MulticastNotPermit			= 7015,
	S21_NET_TooManyLostPackets			= 7016,

	S21_NET_NotStreaming				= 7101,
	S21_NET_InvalidClient				= 7102,
	S21_NET_InvalidState				= 7104,
	S21_NET_StmNotReady					= 7105,
	S21_NET_CallAsynchronous			= 7106,
	S21_NET_CallInProgress				= 7107,
	S21_NET_RedirectServer				= 7108,
	S21_NET_NotInitialized				= 7109,
	S21_NET_SendingCommand				= 7110,
	S21_NET_SocketInUse					= 7111,
	S21_NET_CommandCancelled			= 7112,
	S21_NET_ServerBusy                  = 7117,
	S21_NET_MethodNotImplemented        = 7118,

	// S21_SM : code returned by server

	S21_SM_OK							= S21_NET_NoErr,
	S21_SM_ERROR						= S21_NET_Err,

	S21_SM_ExceedMaxStreams				= 8000,
	S21_SM_ExceedMaxSessions            = 8001,
	S21_SM_ExceedMaxSockets             = 8002,
	S21_SM_InvalidFSMaster              = 8003,
	S21_SM_InvalidFSManager             = 8004,
	S21_SM_InvalidFSType                = 8005,
	S21_SM_InvalidSessionID             = 8006,
	S21_SM_InvalidSessionPtr            = 8007,
	S21_SM_InvalidStream                = 8008,
	S21_SM_InvalidIPIndex               = 8009,
	S21_SM_InvalidFileHandle            = 8010,
	S21_SM_InvalidParameter             = 8011,
	S21_SM_InvalidState                 = 8012,
	S21_SM_InvalidControlProtocol       = 8013,
	S21_SM_InvalidControlSocket         = 8014,
	S21_SM_InvalidSocket                = 8015,
	S21_SM_SocketListenError            = 8016,
	S21_SM_SocketSendError              = 8017,
	S21_SM_SocketRecvError              = 8018,
	S21_SM_SocketWouldBlock             = 8019,
	S21_SM_SocketNotSock                = 8020,
	S21_SM_SocketConnReset              = 8021,
	S21_SM_NotInitialized               = 8022,
	S21_SM_AlreadyInitialized           = 8023,
	S21_SM_NotStarted                   = 8024,
	S21_SM_AlreadyStarted               = 8025,
	S21_SM_SessionNotFound              = 8026,
	S21_SM_SessionKilled                = 8027,
	S21_SM_InvalidFile                  = 8028,
	S21_SM_ExceedFileSize               = 8029,
	S21_SM_OutOfResource                = 8030,
	S21_SM_ClientInfoNotFound           = 8031,
	S21_SM_SocketPairNotFound           = 8032,
	S21_SM_NegativeReturnLength         = 8033,
	S21_SM_NeedLoginFirst               = 8034,
	S21_SM_SocketError                  = 8035,
	S21_SM_CannotGetHostName            = 8036,
	S21_SM_ExceedNicBandwidth           = 8041,
	S21_SM_SocketConnectError           = 8042,
	S21_SM_TransmitError                = 8043,
	S21_SM_ReachEndOfFile               = 8044,
	S21_SM_MulticastChk                 = 8045,

	S21_NET_RTPUDP_UploadNotAllowed		= 8400,
	S21_NET_RTPUDP_ProtocolIsNotUDP     = 8401
};

#endif // __S21ERRORCODE_H_
