//-------------------------------------------------------------------------
//
//	Copyright (c)  2000 - 2004  Streaming21 Inc. All rights reserved.
//
//	ALL RIGHTS RESERVED. NO PART OF THIS CODE AND INFORMATION MAY BE 
//	REUSED, REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY MEANS,
//	WITHOUT WRITTEN PERMISSION FROM THE COMPANY.
//
//	Description : S21 Data Types 
//
//-------------------------------------------------------------------------

#ifndef __S21TYPES_H_
#define __S21TYPES_H_

#ifndef NULL
#define NULL 0
#endif

//---------------------
// BOOL 
//---------------------

#ifndef BOOL
typedef int BOOL;
#define TRUE 1
#define FALSE 0
#endif

//---------------------
// Int64 
//---------------------

#ifndef _S21_DATA_INT64_

#if (defined(WIN32) || defined(_WIN32_WCE))
#define Int64		__int64
#define UInt64		unsigned __int64
#else
#define Int64 		long long int
#define UInt64 		unsigned long long int
#endif //non-WIN32

#ifndef Int64
#define _S21_DATA_INT64_
#endif

#endif //_S21_DATA_INT64_

#ifdef _S21_DATA_INT64_
#include "s21int64.h"
#define Int64		S21Int64
#define UInt64		S21Uint64
#endif // _S21_DATA_INT64_

#endif