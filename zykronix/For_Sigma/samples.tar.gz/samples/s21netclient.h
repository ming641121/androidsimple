//-------------------------------------------------------------------------
//
//	Copyright (c)  2000 - 2004  Streaming21 Inc. All rights reserved.
//
//	ALL RIGHTS RESERVED. NO PART OF THIS CODE AND INFORMATION MAY BE 
//	REUSED, REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY MEANS,
//	WITHOUT WRITTEN PERMISSION FROM THE COMPANY.
//
//	Description : S21 NetClient API 
//
//-------------------------------------------------------------------------

#ifndef __S21NETCLIENT_H_
#define __S21NETCLIENT_H_

//----------------------------------------------------------------------------------
//	ASYNC : 
//		Those API marked as ASYNC are performed in asynchronous mode. 
//		caller should use GetCallStatus() to query call status after an async function is issued.
//		If status code is S21_NET_CallInProgress, caller should keep on polling the status by using 
//		over and over until the status shows the call is completed (S21_NET_NoErr) or failed.
//		If status code is S21_NET_SendingCommand, the network connection may be down or slow, 
//		please regard S21_NET_SendingCommand as S21_NET_CallInProgress.
//		[NOTE] When a call is in progress status, DO NOT issue another function call!
//	READ : 
//		These API will always return S21_NET_NoErr. 
//		Must calling Read(), and check for discontinue count (outDiscontinue), 
//		or trick mod hint flag (outTrickCmd) to discover the effects.
//----------------------------------------------------------------------------------

class S21Url;
class S21StreamContext;

#define S21_MAX_RETRYSERVER	1

class S21NetClient
{
public :

	enum S21StreamFilter
	{
		S21StreamFilter_None = 0,
		// -- scan thru
		S21StreamFilter_SeekFW = 0x00010000, // forward scan (seek-base)
		S21StreamFilter_SeekBW = 0xFFFF0000  // backward scan (seek-base)
	};

	// NEW : new in 5.0
	enum S21StreamScale
	{
		// -- play forward
		S21StreamScale_Normal = 1,  // =FWx1
		S21StreamScale_FW = 1,  // = FWx1
		S21StreamScale_FWx1 = 1, // normal play, no frame dropping (IBP)
		S21StreamScale_FWx2 = 2, // applied to decoder I/P or I frame mode
		S21StreamScale_FWx4 = 4, // applied to decoder I/P or I frame mode
		S21StreamScale_FWx8 = 8, // applied to decoder I frame mode
		S21StreamScale_FWx16 = 16, // applied to decoder I frame mode
		// -- play backward (reverse play)
		S21StreamScale_BW = -1,	// not available now 
		S21StreamScale_BWx1 = -1, // not available now 
		S21StreamScale_BWx2 = -2, // not available now 
		S21StreamScale_BWx4 = -4, // not available now 
		S21StreamScale_BWx8 = -8, // applied to decoder I frame mode
		S21StreamScale_BWx16 = -16, // applied to decoder I frame mode
		// -- slow motion
		S21StreamScale_SLx0_125 = 125, // 0.125, no frame dropping (IBP)
		S21StreamScale_SLx0_25 = 250, // 0.25, no frame dropping (IBP)
		S21StreamScale_SLx0_5 = 500 // 0.5, no frame dropping (IBP)
	};

	// NEW : new in 5.0
	// These enumations are used in outTrickCmd as S21 hinted trick mode flags returned by Read() API.
	// The S21 hinted trick mod flags are provided for as a decoder trick mode hint.
	enum S21TrickCmd
	{
		S21TrickCmd_None = 0x00,
		// the following value could be "OR" in an integer flag, 
		// or be extracted from an integer flag by "AND".
		S21TrickCmd_IFrame = 0x01, // contain complete I frame
		S21TrickCmd_IPFrame = 0x03, // contain complete I/P frame
		S21TrickCmd_AllFrame = 0x07, // contain complete I/P/B frame
		S21TrickCmd_FlushBuf = 0x08, // decoder shall flush buffer and change mode
		S21TrickCmd_Reverse = 0x10 // decoder shall enter reverse play mode if contains P/B frames
	};
		
	S21NetClient() {};
	virtual ~S21NetClient() {};

	// -----------------
	// Interface Maintenance
	// -----------------

	static S21NetClient *CreateInstance();
	static void ReleaseInstance(S21NetClient *&inoutS21NetClient);

	// -----------------
	// Call Maintenance
	// -----------------

	virtual S21_NET_RC Initialize() = 0;
	virtual S21_NET_RC Uninitialize() = 0;

	virtual S21_NET_RC GetCallStatus() = 0;
	/* CHANGE: disabled in 5.0
	//virtual S21_NET_RC CancelCall() = 0;
	*/

	// ------------------------
	// Connection Manipulation
	// ------------------------

	/* CHANGE : disabled in 5.0
	virtual int AddRetryServer(const char *inServerName, const unsigned short inPort) = 0;
	virtual void ResetAllRetryServer() = 0;
	virtual int GetRetryServerCnt() = 0;
	virtual BOOL EnableRetry(BOOL inEnable) = 0;
	*/

	virtual S21_NET_RC QuickSetByUrl(const S21Url *inUrl) = 0;
	virtual S21_NET_RC QuickSetByUrl(const char *inUrlStr, const char *inBackupServer = "", const unsigned short inBackupPort = 0, const char *inDefUser = "", const char *inDefPasswd = "", int inIsEnableDefaultLogin = 0, int inUseProxy = 0, const char *inProxyServer = "", unsigned short inProxyPort = 0, const char* inProxyUser = "", const char* inProxyPwd = "") = 0;

	/* CHANGE : disabled in 5.0
	// ASYNC
	virtual S21_NET_RC Connect(const char *inServerName, const unsigned short inServerPort, 
			   const S21_STM_PROTOCOL_TYPE inControlProtocol = PT_RTSP, 
			   const char *inProxyServer = "", const unsigned short inProxyPort = 0, 
			   const char* inUser = "", const char* inPwd = "") = 0;

	// ASYNC, QUICK_UTIL
	virtual S21_NET_RC Connect() = 0; 

	// ASYNC
	virtual S21_NET_RC Disconnect() = 0; 
	*/

	// ----------------
	// Authentication
	// ----------------

	/* CHANGE : disabled in 5.0
	// ASYNC
	virtual S21_NET_RC Login(const char *inUsername, const char *inPassword) = 0;

	// ASYNC, QUICK_UTIL
	virtual S21_NET_RC Login() = 0; 

	// ASYNC
	virtual S21_NET_RC Logout() = 0;
	*/

	// --------------------
	// Media File Browsing or Media Info Retrieval
	// --------------------

	/* CHANGE : disabled in 5.0
	// ASYNC
	virtual S21_NET_RC GetFileSystem(S21_SUBSYSTEM *outFileSystemType) = 0; 

	// ASYNC
	virtual S21_NET_RC GetHomeDirectory(const S21_SUBSYSTEM inFileSystemType, char *outHomeDir) = 0;

	// ASYNC
	virtual S21_NET_RC GetFileInfo(const S21_FILE_KEY inFile, S21_FILE_INFO **outFileInfoPtr, int *outFileInfoCnt, const int inUseCache = 0) = 0;

	// ASYNC, QUICK_UTIL
	virtual S21_NET_RC GetFileInfo(S21_FILE_INFO **outFileInfoPtr, int *outFileInfoCnt, const int inUseCache = 0) = 0;
	*/

	// NEW : new in 5.0
	virtual S21_NET_RC GetFileInfo(S21_FILE_STATUS *outFileInfo) = 0;

	// --------------------
	// Stream Manipulation
	// --------------------

	/* CHANGE : disabled in 5.0
	// ASYNC
	// may ask for return streaminfo for reuse for next open
	virtual S21_NET_RC Open(const S21_FILE_KEY inFileKey, const S21_STM_PROTOCOL_TYPE inStreamProtocol, S21StreamContext **outStreamContext = NULL) = 0;

	// ASYNC, QUICK_UTIL
	// use quick set inforamtion, may ask for return streaminfo for reuse for next open
	virtual S21_NET_RC Open(S21StreamContext **outStreamInfo = NULL) = 0;

	// ASYNC, QUICK_UTIL
	// reuse stream info from last sucessful open
	virtual S21_NET_RC Open(const S21StreamContext *inStreamInfo) = 0; 
	*/

	// NEW : new in 5.0
	virtual S21_NET_RC Open() = 0;

	virtual S21_NET_RC Close() = 0;

	// ASYNC
	virtual S21_NET_RC Seek(const Int64 pos) = 0;

	// READ : must call Read() and check (or not check) the outDiscontinue to discover data discontinuity (outDiscontinue==1))
	virtual S21_NET_RC SetStreamFilter(const S21StreamFilter inStmFilter = S21StreamFilter_None, const void *inPdata = NULL) = 0;

	// NEW : new in 5.0
	// READ : must call Read() and check (or not check) the outTrickCmd flag to discover trick mod change)
	virtual S21_NET_RC SetStreamScale(const S21StreamScale inStmScale = S21StreamScale_Normal) = 0;

	// ASYNC
	virtual S21_NET_RC SetStreamSpeed(const double inRate) = 0;

	virtual S21_NET_RC Read(const unsigned long inByteRequest, void* outBuffer, unsigned long *outActualByte,
							unsigned long *outDiscontinue = NULL, Int64 *outCurReadPos = NULL, 
							int *outTrickCmd = NULL, S21StreamScale *outCurScale = NULL) = 0;
};


//=====================
// Other Utility Class
//=====================

// [S21StreamContext example in psuedo code]
// ....
// S21StreamContext *anReuseContext = NULL;
// .... // get reuse context from an Open() call
// anS21NetClient->Open(anFilekey, anProtocol, ..., &anReuseContext);
// .... 
// anS21NetClient->Close();
// ....
// .... // to create the stream of the same setting, just reuse this context
// anS21NetClient->Open(anReuseContext);
// ...
// ... // it's caller's responsibility to release the context, if no longer used
// S21StreamContext::ReleaseInstance(anReuseContext);
// ...

// CHANGE : no use in 5.0
class S21StreamContext
{
public :
	S21StreamContext() {};
	virtual ~S21StreamContext() {};

	static S21StreamContext *CreateInstance();
	static void ReleaseInstance(S21StreamContext *&inoutStreamContext);

	virtual S21_STM_PROTOCOL_TYPE GetProtocol() const { return PT_RTSP; }; 
	virtual void SetProtocol(const S21_STM_PROTOCOL_TYPE inStreamProtocol) {}; 
};

#endif

