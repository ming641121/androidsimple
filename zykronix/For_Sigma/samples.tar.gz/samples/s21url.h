//-------------------------------------------------------------------------
//
//	Copyright (c)  2000 - 2004  Streaming21 Inc. All rights reserved.
//
//	ALL RIGHTS RESERVED. NO PART OF THIS CODE AND INFORMATION MAY BE 
//	REUSED, REPRODUCED OR TRANSMITTED IN ANY FORM OR BY ANY MEANS,
//	WITHOUT WRITTEN PERMISSION FROM THE COMPANY.
//
//	Description : S21 Stream API 
//
//-------------------------------------------------------------------------

#ifndef __S21URL_H_
#define __S21URL_H_

// [S21Url example in psuedo code]
// ....
// S21Url *anS21Url = S21Url::CreateInstance();
// .... // setup default settings if necessary, but not restricted to
// anS21Url->SetDefaultServer(...);
// anS21Url->SetDefaultUser(...);
// anS21Url->SetDefaultProxy(...);
// .... // start to input string and parse
// anS21Url->Parse(...);
// .... // check if the string is an valid S21 formatted url
// if (!anS21Url->IsValid())
// { .... // error handling
// }
// else
// { .... // setup stream source information in this url in S21NetClient object for
//        // later connection/stream activity without specify additional parameters
//   anS21NetClient->QuickSetByUrl(anS21Url);
// }
// .... // release this url object if no longer used
// S21Url::ReleaseInstance(anS21Url);
// .... // start connection/stream activity if the url is successully set
// anS21NetClient->Connect();
// ....
// anS21NetClient->Login();
// .... // get file info of the media object specified in url
// anS21NetClient->GetFileInfo();
// ....
// anS21NetClient->Open();
// ....
// anS21NetClient->Close();
//

#define S21_URL_DEFPROTOROCOLNAME "rtsp"

class S21Url
{
public : 
	S21Url() {};
	virtual ~S21Url() {};

	static S21Url *CreateInstance();
	static void ReleaseInstance(S21Url *&inoutUrl);

	// CHANGE : disabled in 5.0
	// virtual BOOL SetDefaultServer(const char *inServerName, const unsigned short inPort) = 0;
	virtual BOOL SetDefaultUser(const char *inUser, const char *inPassword) = 0;
	// CHANGE : remove proxy user/pwd setting in 5.0
	virtual BOOL SetDefaultProxy(const char *inProxyServer, unsigned short inProxyPort) = 0;
	virtual BOOL SetPrefix(const char *inPrefix = S21_URL_DEFPROTOROCOLNAME) = 0;

	// CHANGE : remove isAllowUseDefaultServer
	//virtual	BOOL Parse(const char *inUrl, BOOL inIgnorePrefix, BOOL inAllowUseDefaultServer, BOOL inAllowUseDefaultUser, BOOL inUseProxy) = 0;
	virtual	BOOL Parse(const char *inUrl, BOOL inIgnorePrefix, BOOL inAllowUseDefaultUser, BOOL inUseProxy) = 0;
	

	// CHANGE : change the name from ChangeXXXX,ChangeXXXX to SetXXXX, and remove "force" argument
	virtual BOOL SetUserInfo(const char *inUserID, const char *inPwd) = 0;
	virtual BOOL SetProxy(const char *inProxyServerName, const unsigned short inProxyPort) = 0;

	// NEW : new in 5.0
	virtual BOOL SetSrcAddr(const char *inServerName, const unsigned short inPort = 0) = 0;
	virtual BOOL SetBackupServer(const char *inServerName = NULL, const unsigned short inPort = 0) = 0;
	virtual BOOL SetProtocol(S21_STM_PROTOCOL_TYPE inProtocolType) = 0;
	virtual BOOL SetFilePath(const char *inFilePath) = 0;

	virtual BOOL IsValid() const = 0;
	virtual BOOL IsUser(const char *username = NULL) const = 0;
	virtual BOOL IsProxyUsed(const char *servername = NULL) const = 0;
	// NEW : new in 5.0
	virtual BOOL IsSrcAddr(const char *inServerName, const unsigned short inPort = 0) const = 0;
	virtual BOOL IsBackupServer(const char *inServerName = NULL, const unsigned short inPort = 0) const = 0;
	virtual BOOL IsProtocol(S21_STM_PROTOCOL_TYPE inProtocolType) const = 0;
	virtual BOOL IsFilePath(const char *inFilePath) const = 0;
	virtual BOOL GetSDKVersion(const char *sdkVersion) = 0;//Gavin 2005-12-02
	virtual BOOL Reset() = 0;
	virtual S21Url &operator = (const S21Url &) = 0;
};

#endif
