
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include "main.h"
sem_t S21_sem, Sigma_sem;
char *tBuffer=NULL;
unsigned long tLen=0;
bool fgSigmaReady=0;
int main(int argc,char *argv[])
{   
   pthread_t Sigma_thread;
   void *thread_result;                                                                                                               
// Initialize semaphore
   if ( sem_init(&S21_sem, 0, 0) !=0 )
   {
     perror("S21_sem initialization failed ");
     exit(EXIT_FAILURE);
   }
                                                                                                               
   if (sem_init(&Sigma_sem, 0, 0) !=0 )
   {
     perror("Sigma_sem initialization failed ");
     exit(EXIT_FAILURE);
   }
  
//Creat threads
   if (pthread_create(&Sigma_thread, NULL, Sigma_threadfunction, NULL)!=0)
   {
        perror("Sigma-thread creation failed ");
        exit(EXIT_FAILURE);
   }
   while( !fgSigmaReady );
   S21_main(argc,argv); 
   sem_post(&Sigma_sem); //added

   pthread_cancel(Sigma_thread);
   //pthread_join(Sigma_thread, &thread_result);
   sem_destroy(&S21_sem); //clean sem1
   sem_destroy(&Sigma_sem);
   
   return 0;
}


void *Sigma_threadfunction(void *arg)
{

   int arg_c=9;
   char *arg_v[]={ "./play_demux","-y","m2t","-c","mpeg","-pv", "2sd","-z","12.mpg" };
/*
   if ( pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL) )
   {
          perror("Fail to set cancel-state");
          exit(EXIT_FAILURE);
   }
   if ( pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED, NULL) )
   {
          perror("Fail to set cancel-type");
          exit(EXIT_FAILURE);
                                                                                
   }
*/

   play_demux_TS(arg_c,arg_v);
   pthread_exit(0);
}

