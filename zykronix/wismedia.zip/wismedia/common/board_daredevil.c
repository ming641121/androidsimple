/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       board_s3c2510.c
*
*   DESCRIPTION:
*       Board specific routines for Daredevil.
*
*  AUTHOR:
*       Daniel Meyer, Jimmy Blair
*
*   $Id: board_daredevil.c,v 1.1 2005/01/11 11:52:25 jblair Exp $ 
*
******************************************************************************/

#include "platform.h"
#include "sal_api.h"

/******************************************************************************
*
*   PROCEDURE:  
*       board_bus_timing_set (unsigned int bus_params)
*
*   DESCRIPTION:
*       Set the bus timings as specified by the bus_params arg
*  
*   ARGUMENTS:
*       unsigned int - bus_params
*
*   RETURNS:
*       0
*
*   NOTES:
*       Since 
*
******************************************************************************/

int
board_bus_timing_set (unsigned int bus_params)
{
    unsigned int val;

    val = * (unsigned int *) MUXBCON;
    val &= ~0x1c;
    val = val | (1<<26) | (2<<6); /* enable bank 2, set 2 bus address cycles */
    *((unsigned int *) MUXBCON) = val;

    if (bus_params == ENCODER_BUS_INIT_MODE)
        *((unsigned int*) B2CON) = 0x8514E488;
    
    if (bus_params == ENCODER_BUS_RUNTIME_MODE)
        *((unsigned int*) B2CON) = 0x85070000;

    return (0);
}

/******************************************************************************
*
*   PROCEDURE:  
*       board_int_clear (unsigned int mask)
*
*   DESCRIPTION:
*       Clear the interrupt to/at the interrupt controller.
*  
*   ARGUMENTS:
*       mask - mask of interrupt bits to clear - see platform.h for masks
*
*   RETURNS:
*       0 
*
*   NOTES:
*       Linux source has some unfortunate naming of interrupt controller
*          registers.  Correct register name is IOPEXTINTPND
*
******************************************************************************/

int
board_int_clear (unsigned int mask)
{
    * ((volatile unsigned int *) IOP4xINT_PEND) = mask;
    return (0);
}

/*****************************************************************************
*
*   PROCEDURE:  
*       board_int_config (unsigned int num, unsigned int type)
*
*   DESCRIPTION:
*       Enable and configure the interrupt for a specific type of operation.
*  
*   ARGUMENTS:
*       num - interrupt number to enable/configure
*       type - interrupt type to use (level sensitive, rising edge, etc.)
*
*   RETURNS:
*       0 for success, -1 for failure
*
*   NOTES:
*       WISchip interrupt lines are active high.  
*       Linux source has some unfortunate naming of interrupt controller
*          registers.  Correct names provided in comments.
*
******************************************************************************/

int
board_int_config (int num, int type)
{
    /* Disable interrupt from GPIO pin */
    *((unsigned int *) IO_Ftn_cont1) |= (1<<(8 + num));

    switch (type)
    {
        case INT_TYPE_LEVEL_LOW:
            return (-1);
            break;
            
        case INT_TYPE_LEVEL_HIGH:
            *((unsigned int *) IOP4xINT) &= ~(0xf << (4*num)); 
            *((unsigned int *) IOP4xINT) |= (8 << (4*num)); 
            break;
            
        case INT_TYPE_EDGE_FALLING:
            return (-1);
            break;
            
        case INT_TYPE_EDGE_RISING:
            *((unsigned int *) IOP4xINT) &= ~(0xf << (4*num)); 
            *((unsigned int *) IOP4xINT) |= (1 << (4*num)); 
            break;
            
        default:
            return (-1);
    }

    /* IOPEXTINT: Tap filtering on*/
    *((unsigned int *) IOP4xINT) |= (1<<(2+(4*num)));   
    
    /* IOPCON1: Enable GPIO pin as an interrupt line */
    *((unsigned int *) IO_Ftn_cont1) &= ~(1<<(8 + num));

    return (0);
}
