/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       sal_ixp425.c
*
*   DESCRIPTION:
*       This is the System Abstraction Layer for ixp425 based systems.
*
*  AUTHOR:
*   Jimmy Blair, Dan Meyer
*
*   $Id: sal_ixp425.c,v 1.6 2005/05/22 01:09:46 jfd Exp $ 
*
******************************************************************************/

#include "wis_types.h"
#include "wis_error.h"
#include "struct.h"

#include "sal_api.h"
#include "platform.h"

/******************************************************************************
*
*   PROCEDURE:  
*       void SAL_IoSetBusTimings(uint32 u32BusType, uint32 u32TimingValues)
*
*   DESCRIPTION:
*       Set the bus timings as specified by the bus type and timing values
*  
*   ARGUMENTS:
*
*       u32BusType - which bus to set - see platform.h
*       u32TimingValues - actual timing values to set - see platform.h
*
*   RETURNS:
*
*    SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/

status_t SAL_IoSetBusTimings(uint32 u32BusType, uint32 u32TimingValues)
{
    
    volatile uint32 *busControl = (uint32 *)ENCODER_BUS_CONTROL;
    
    *busControl=u32TimingValues;
    
    return(SAL_SUCCESS);
    
}

/******************************************************************************
*
*   PROCEDURE:  
*       status_t SAL_IoClearInterrupt(uint32 u32IntNum)
*
*   DESCRIPTION:
*       Clears a single GPIO interrupt
*  
*   ARGUMENTS:
*
*       u32IntNum 
*
*   RETURNS:
*
*    SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/

status_t SAL_IoClearInterrupt(uint32 u32IntNum)
{
    
    unsigned char num = u32IntNum;
    gpio_line_isr_clear (num);
    
    return(SAL_SUCCESS);
    
}

/******************************************************************************
*
*   PROCEDURE:  
*       status_t SAL_DmaInit(void)
*
*   DESCRIPTION:
*       Set the bus timings as specified by the bus type and timing values
*  
*   ARGUMENTS:
*
*       u32IntMask - mask of interrupt bits to clear - see platform.h for masks
*
*   RETURNS:
*
*    SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/

#if !defined(ZAO)  
#include "ixp425.h"
#include "IxNpeDl.h"
#include "ixQMgr.h"
#endif

#ifdef VXWORKS
#include "osl_vx.h"
#else
#include "osl_linux.h"
#include <asm/io.h>
#endif

osl_thread_t dmaDriverTaskId;
extern void DMAD_Task(void);

status_t SAL_DmaInit(uint32 u32IntMask)
{
    
#if !defined(ZAO) && defined(IXDP425) && !defined (HW_J18V035T00) /* ambit uses old BSP */
    OS_INT_CONNECT(IXP425_INT_LVL_QM1, ixQMgrDispatcherLoopRunB0, 0);

    ixNpeDlNpeInitAndStart(IX_NPEDL_NPEIMAGE_NPEA_DMA);

    /***********************************************************************
     * System initialisation done. Now initialise Dma Access component.
    ***********************************************************************/
    if (ixDmaAccInit(0) != IX_SUCCESS)
    {
        printf("\nError initialising Dma access driver!");
        return (IX_FAIL);
    }
#define DMA_DRIVER_TASK_NAME                "tDma"
#define DMA_DRIVER_TASK_PRIORITY            65
#define DMA_DRIVER_TASK_ENTRY_POINT         (FUNCPTR) DMAD_Task
#define DMA_DRIVER_TASK_STACK_SIZE          (10 * 1024)
#define DMA_DRIVER_TASK_OPTIONS             0


    /* start the DMA Task */
    dmaDriverTaskId = OS_CREATE_TASK(DMA_DRIVER_TASK_NAME,
                                     DMA_DRIVER_TASK_PRIORITY,
                                     DMA_DRIVER_TASK_OPTIONS,
                                     DMA_DRIVER_TASK_STACK_SIZE,
                                     DMA_DRIVER_TASK_ENTRY_POINT);

#endif

    return(SAL_SUCCESS);
    
}

status_t SAL_IoConfigureInterrupt(uint32 num, uint32 type)
{
    unsigned int tmp;
    unsigned char intnum;

    intnum = num;

    switch (type)
    {
        case INT_TYPE_LEVEL_LOW:
            tmp = IXP425_GPIO_ACTIVE_LOW;
            break;

        case INT_TYPE_LEVEL_HIGH:
            tmp = IXP425_GPIO_ACTIVE_HIGH;
            break;

        case INT_TYPE_EDGE_FALLING:
            tmp = IXP425_GPIO_FALLING_EDGE;
            break;

        case INT_TYPE_EDGE_RISING:
            tmp = IXP425_GPIO_RISING_EDGE;
            break;

        default:
            return (SAL_FAILURE);
    }

    gpio_line_config (num, tmp |IXP425_GPIO_IN);

    return(SAL_SUCCESS);
}
