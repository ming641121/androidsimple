/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       sal_jasper.c
*
*   DESCRIPTION:
*       This is the System Abstraction Layer for Jasper (Sigma EM8550)
*           based systems.
*
*  AUTHOR:
*       Daniel Meyer
*
*   $Id: sal_jasper.c,v 1.3 2004/03/01 15:42:25 jfd Exp $ 
*
*  NOTES:
*
******************************************************************************/

#include "wis_types.h"
#include "wis_error.h"
#include "struct.h"
#include "platform.h"

#include "sal_api.h"
#include "os.h"

/******************************************************************************
*
*   PROCEDURE:  
*   void SAL_IoSetBusTimings(uint32 u32BusType, uint32 u32TimingValues)
*
*   DESCRIPTION:
*   Set the bus timings as specified by the bus type and timing values
*  
*   ARGUMENTS:
*
*       u32BusType - which bus to set - see platform.h
*       u32TimingValues - actual timing values to set - see platform.h
*
*   RETURNS:
*
*    SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/

status_t
SAL_IoSetBusTimings(uint32 u32BusType, uint32 u32TimingValues)
{
    
    return(SAL_SUCCESS);
    
}


/******************************************************************************
*
*   PROCEDURE:  
*   status_t SAL_IoClearInterrupt(uint32 u32IntMask)
*
*   DESCRIPTION:
*   Clear the interrupt to/at the interrupt controller.
*  
*   ARGUMENTS:
*
*   u32IntMask - mask of interrupt bits to clear - see platform.h for masks
*
*   RETURNS:
*
*    SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/

status_t
SAL_IoClearInterrupt(uint32 u32IntMask)
{
    
    volatile uint32 *interruptStatusRegister = (uint32 *)PLATFORM_INTERRUPT_STATUS_REGISTER;
    
    *interruptStatusRegister = u32IntMask;
    
    return(SAL_SUCCESS);
    
}

/********************** end SAL_IoClearInterrupt *****************************/

/******************************************************************************
*
*   PROCEDURE:  
*   status_t SAL_IoConfigureInterrupt(uint32 u32IntNum, uint32 u32IntType)
*
*   DESCRIPTION:
*   Enable and configure the interrupt for a specific type of operation.
*  
*   ARGUMENTS:
*
*   u32IntNum - interrupt number to enable/configure
*   u32IntType - interrupt type to use (level sensitive, rising edge, etc.)
*
*   RETURNS:
*
*       SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/
status_t
SAL_IoConfigureInterrupt(uint32 u32IntNum, uint32 u32IntType)
{
    
    /* Force interrupt settings */

    DBUSREG(0xFE8)=0xffff;
    DBUSREG(0xFE9)=0xffff;
    DBUSREG(0xFE8)=0xff00;
    DBUSREG(0xFE9)=0xff00;

    /* clear the interrupt to start with */
    *((uint32 *)(PLATFORM_INTERRUPT_STATUS_REGISTER)) = ENCODER_INTERRUPT_STATUS_BIT_MASK;
    *((uint32 *)(PIO_1_INT_ENABLE_REG)) = ENCODER_INTERRUPT_STATUS_BIT_MASK & ~1;

    /* Enable PIO1 pin 14 IRQ, set level sensitive */
    *(PIO_1_DIR_REG) = 0x10000 << WIS_PIO_IRQ_PIN; /* Input function */
    *(PIO_1_POL_REG) = (0x10000 + WIS_PIO_POLARITY) << WIS_PIO_IRQ_PIN;

    switch (u32IntType)
    {
        case INT_TYPE_LEVEL_LOW:
            return (WIS_FAILURE);
            break;
            
        case INT_TYPE_LEVEL_HIGH:
            return (WIS_FAILURE);
            break;
            
        case INT_TYPE_EDGE_FALLING:
            return (WIS_FAILURE);
            break;
            
        case INT_TYPE_EDGE_RISING:
            *((uint32 *)(PLATFORM_INTERRUPT_STATUS_REGISTER)) = ENCODER_INTERRUPT_STATUS_BIT_MASK;
            break;
            
        default:
            return (SAL_FAILURE);
            
    }

    return(SAL_SUCCESS);
    
}



/*****************************************************************************
*
*   PROCEDURE:  
*   status_t SAL_DmaInit(void)
*
*   DESCRIPTION:
*   Set the bus timings as specified by the bus type and timing values
*  
*   ARGUMENTS:
*
*   u32IntMask - mask of interrupt bits to clear - see platform.h for masks
*
*   RETURNS:
*
*    SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/

status_t
SAL_DmaInit(uint32 u32IntMask)
{    
    return(SAL_SUCCESS);   
}
