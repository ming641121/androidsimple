/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       ringbuf.c
*
*   DESCRIPTION:
*       Ringbuffer routines.
*
*
*   $Id: ringbuf.c,v 1.1 2004/09/06 14:06:07 jfd Exp $
*
******************************************************************************/
    
#include "ringbuf.h"

void 
ringbuf_init(ringbuf_t * pRing, void **ppArray, int len, int full) 
{
    pRing->ppArray = ppArray;
    pRing->iRead = 0;
    pRing->iLen = len;
    if (full)
        pRing->iWrite = pRing->iLen - 1;
    
    else
        pRing->iWrite = 0;
}

void *
ringbuf_get(ringbuf_t * pRing) 
{
    int next;
    void *pData;
    if (pRing->iRead == pRing->iWrite)
        return ((void *) -1);  /* Ring empty */
    pData = pRing->ppArray[pRing->iRead];
    pRing->iRead = (pRing->iRead + 1) % pRing->iLen;
    return (pData);
}

void *
ringbuf_put(ringbuf_t * pRing, void *pData) 
{
    int next = (pRing->iWrite + 1) % pRing->iLen;
    if (next == pRing->iRead)
        return ((void *) -1);  /* Ring full */
    pRing->ppArray[pRing->iWrite] = pData;
    pRing->iWrite = next;
    return (pData);
}


