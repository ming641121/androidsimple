/********************************************************************************
*
*   FILE:     util.c
*
*      Utilities for WIS Media Library.
*
* $Id: util.c,v 1.1 2003/11/04 15:42:28 dmeyer Exp $
* 
*********************************************************************************/
#include <osl_vx.h>
#include <io_vx.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <netinet/in.h>		/* htonl() */

char *tok_white = " \t";
char *tok_eol = "\n";

/*
 * strcaseindex: case insensitive substring search
 *   Find substring 'sub' within string 's'.
 *   Return pointer to substring within 's', NULL if not found.
 */

const char *strcaseindex(const char *s, const char *sub)
{
    int len;
    for (len = strlen(sub); *s; s++)
	if (strncasecmp(s, sub, len) == 0)
	    return s;
    return 0;
}

/*
 * strrepl: string replace
 *   Delete 'len' characters from position 'start' in string 's',
 *   and insert 'repstr' at the deletion point.
 */

char *strrepl(char *s, int start, int len, const char *repstr)
{
    memmove(s + start + strlen(repstr),
	    s + start + len,
	    strlen(s + start + len) + 1);
    memmove(s + start, repstr, strlen(repstr));
    return s;
}

/*
 * Swap the bytes in a 32-bit word
 */

uint32 swap32(uint32 i)
{
    i = i << 16 | i >> 16;
    return (i & 0xff00ffff) >> 8 | (i & 0xffff00ff) << 8;
}

/*
 * Return (int) lg2(x).  Returns -1 if x == 0.
 */

int floorlg2(uint32 x)
{
    int b;

    if (x >> 16)  b  = 16, x >>= 16;
    else if (x)   b  =  0;
    else          b  = -1;
    if (x >>  8)  b +=  8, x >>=  8;
    if (x >>  4)  b +=  4, x >>=  4;
    if (x >>  2)  b +=  2, x >>=  2;

    return b + (int) (x >> 1);
}

/*
 * Return the number of bits set in a uint32
 */

int popcount(uint32 n)
{
    int count;

    for (count = 0; n; count++)
	n &= n - 1;	/* Take away LSB */

    return count;
}

/*
 * Convert hex digit to hex character
 */

int i2xdigit(int digit)
{
    digit &= 0xf;
    return (digit > 9) ? digit - 10 + 'a' : digit + '0';
}

/*
 * Convert hex character to digit
 */

int xdigit2i(int digit)
{
    if (digit >= '0' && digit <= '9') return (digit - '0'     );
    if (digit >= 'a' && digit <= 'f') return (digit - 'a' + 10);
    if (digit >= 'A' && digit <= 'F') return (digit - 'A' + 10);
    return 0;
}

/*
 * Return true of a constant is a well-formed integer of the type
 * supported by parse_integer.
 */

int isint(char *s)
{
    int base;

    if (*s == '-')
	s++;

    if (*s == '0') {
	if (s[1] == 'b' || s[1] == 'B') {
	    base = 2;
	    s += 2;
	} else if (s[1] == 'x' || s[1] == 'X') {
	    base = 16;
	    s += 2;
	} else
	    base = 8;
    } else
	base = 10;

    do
	if (! isxdigit((int) *s) || xdigit2i(*s) >= base)
	    return(0);
    while (*++s);

    return(1);
}

/*
 * Convert binary string to uint32
 */

uint32 parse_binary(char *str)
{
    int c;
    uint32 val = 0;
    while ((c = *str++) == '0' || c == '1')
	val = val * 2 + (c - '0');
    return val;
}

/*
 * Read an integer: return unsigned representation.
 * Number format explained below.
 *
 * Expects:
 * [-]0x[0-9|A-F|a-f]+   -hexadecimal if the string begins with "0x"
 * [-][0-9]+             -decimal integer
 * [-]0[0-7]+            -octal integer
 * [-]0b[0-1]+           -binary if the string begins with "0b"
 */

uint32 parse_integer(char *str)
{
    int neg;
    uint32 val;

    if (*str == '-') {
	neg = 1;
	str++;
    } else
	neg = 0;

    if (str[0] == '0' && (str[1] == 'b' || str[1] == 'B'))
	val = parse_binary(str + 2);		/* Binary number */
    else
	val = strtoul(str, (char **)NULL, 0);	/* Hex, decimal, or octal */

    if (! isint(str))
	printk("WARNING: truncated malformed integer \"%s\"\n", str);

    return neg ? -val : val;
}

/*
 * Read a long integer: can read a long hex integer, or a regular
 * integer in any base supported by parse_integer.
 *
 * buf[0] receives the least significant word (little-endian).
 * nbuf is the number size (count of uint32's).
 */

void parse_long_integer(uint32 *val, int nval, char *str)
{
    char eight[11], *s, *t;
    int i, neg;

    if (*str == '-') {
	neg = 1;
	str++;
    } else
	neg = 0;

    memset(val, 0, nval * sizeof (*val));

    if (str[0] != '0' || (str[1] != 'x' && str[1] != 'X')) {
	val[0] = parse_integer(str);
	goto done;
    }

    /* Skip to the last hex digit in the string */

    for (s = str + 1; isxdigit((int) s[1]); s++)
	;

    /* Parse backward in groups of 8 digits */

    i = 0;

    do {
	/* Copy 8 digits backward to form a string "0xdddddddd\0" */
	t = eight + 11;
	*--t = 0;
	while (t > eight + 2 && *s != 'x')
	    *--t = *s--;
	*--t = 'x';
	*--t = '0';

	val[i++] = parse_integer(t);
    } while (*s != 'x' && i < nval);

 done:
    if (neg) {
	uint32 cy = 1;
	for (i = 0; i < nval; i++)
	    if ((val[i] = (~val[i]) + cy) != 0)
		cy = 0;
    }
}

/*
 * Format a long integer.  If the value is less than 10, generates
 * decimal, otherwise generates hex.
 *
 * val[0] is the least significant word.
 * nval is the number of uint32's in the value.
 */

void format_long_integer(char *buf, uint32 *val, int nval)
{
    int i;

    for (i = nval - 1; i > 0; i--)	/* Skip leading zeroes */
	if (val[i])
	    break;
    if (i == 0 && val[i] < 10)		/* Only a single word < 10? */
	sprintf(buf, "%d", val[i]);
    else
	sprintf(buf, "0x%x", val[i]);	/* Print first word */
    while (--i >= 0)			/* Print rest of words, if any */
	sprintf(buf + strlen(buf), "%08x", val[i]);
}

/*
 * Add long integers.
 */

void add_long_integer(uint32 *dst, uint32 *src, int nval)
{
    int		i;
    uint32	tmp, new_cy, cy = 0;

    for (i = 0; i < nval; i++, cy = new_cy) {
	tmp = dst[i];		/* Add digits, detect overflow */
	dst[i] += src[i];
	new_cy = (dst[i] < tmp);
	tmp = dst[i];		/* Add carry, detect overflow */
	dst[i] += cy;
	new_cy += (dst[i] < tmp);
    }
}

/*
 * Subtract long integers.
 */

void sub_long_integer(uint32 *dst, uint32 *src, int nval)
{
    int		i;
    uint32	tmp, new_br, br = 0;

    for (i = 0; i < nval; i++, br = new_br) {
	tmp = dst[i];		/* Sub digits, detect underflow */
	dst[i] -= src[i];
	new_br = (dst[i] > tmp);
	tmp = dst[i];		/* Sub carry, detect underflow */
	dst[i] -= br;
	new_br += (dst[i] > tmp);
    }
}

/*
 * Negate long integer.
 */

void neg_long_integer(uint32 *dst, int nval)
{
    int		i;
    uint32	tmp, new_br, br = 0;

    for (i = 0; i < nval; i++, br = new_br) {
	dst[i] = -dst[i];
	new_br = (dst[i] > 0);
	tmp = dst[i];		/* Sub carry, detect overflow */
	dst[i] -= br;
	new_br += (dst[i] > tmp);
    }
}

/*
 * Ethernet CRC Algorithm
 *
 * To generate CRC:
 *    uint32 crc = ~crc32(~0, data, len), do not include CRC field in data
 *
 * To check CRC:
 *    uint32 check = crc32(~0, data, len), include CRC field in data
 *    If CRC is correct, result will be CRC32_CORRECT (defined in system.h).
 *
 * NOTE: This routine generates the same 32-bit value whether the
 * platform is big- or little-endian.  The value must be stored into a
 * network packet in big-endian order, i.e. using htonl() or equivalent.
 */

static int 		crc_table_inited;
static uint32 		crc_table[256];

uint32 crc32(uint32 crc, uint8 *data, int len)
{
    int			i;

    if (! crc_table_inited) {
	int		j;
	uint32		accum;

	for (i = 0; i < 256; i++) {
	    accum = i;

	    for (j = 0; j < 8; j++) {
		if (accum & 1)
		    accum = accum >> 1 ^ 0xedb88320UL;
		else
		    accum = accum >> 1;
	    }

	    crc_table[i] = swap32(accum);
	}

	crc_table_inited = 1;
    }

    for (i = 0; i < len; i++)
	crc = crc << 8 ^ crc_table[crc >> 24 ^ data[i]];

    return crc;
}

/*
 * parse_macaddr will take a string of the form H:H:H:H:H:H where each
 * H is one or two hex digits, or a string of the form 0xN where N may
 * consist of up to 12 hex digits.  The result is returned in a byte
 * array to avoid endian confusion.
 */
int parse_macaddr(char *str, mac_addr_t macaddr)
{
    char *s;
    int	colon = FALSE;
    int	i, c1, c2;

    if (strchr(str, ':')) {		/* Colon format */
	colon = TRUE;
    } else if (*str++ != '0' || tolower(*str++) != 'x') {
	return -1;
    } else {
	memset(macaddr, 0, 6);
    }
    /* Start at end and work back */
    s = str + strlen(str);
    for (i = 5; (i >= 0) && (s >= str); i--) {
	c2 = (s > str && isxdigit((int) s[-1])) ? xdigit2i((int) *--s) : 0;
	c1 = (s > str && isxdigit((int) s[-1])) ? xdigit2i((int) *--s) : 0;
	macaddr[i] = c1 * 16 + c2;
	if (colon && (s >= str) && (':' != *--s))
	    break;
    }
    return(((s <= str) && (!colon || (i == 0))) ? 0 : -1);
}

/*
 * format_macaddr requires a buffer of 18 bytes minimum.
 * It does not use sprintf so it can be called from an interrupt context.
 */
void format_macaddr(char buf[MACADDR_STR_LEN], mac_addr_t macaddr)
{
    int i;

    for (i = 0; i <= 5; i++) {
	*buf++ = i2xdigit(macaddr[i] >> 4);
	*buf++ = i2xdigit(macaddr[i]);
	*buf++ = ':';
    }

    *--buf = 0;
}

/*
 * increment_macaddr
 */
void increment_macaddr(mac_addr_t macaddr, int amount)
{
    int i, v;
    for (i = 5; i >= 0; i--) {
	v = (int) macaddr[i] + amount;
	macaddr[i] = v;
	if (v >= 0 && v <= 255)
	    break;
	amount = v >> 8;	/* carry or borrow (signed shift) */
    }
}

int parse_ipaddr(char *s, ip_addr_t *ipaddr)
{
    char *ts;
    int	i, x;
    ip_addr_t ip = 0;

    if (strchr(s, '.')) {		/* dotted notation */
	for (i = 0; i < 4; i++) {
	    x = strtol(s, &ts, 0);
	    if ((x > 0xff) || (x < 0)) {
		return(-1);
	    } 
	    ip = (ip << 8) | x;
	    if (*ts != '.') {	/* End of string */
		break;
	    }
	    s = ts + 1;
	}
	if (((i != 3) || (*ts != '\0'))) {
	    return(-1);
	} else {
	    *ipaddr = ip;
	    return(0);
	}
    } else if (isint(s)){
	*ipaddr = parse_integer(s);
	return(0);
    } else {
	return(-1);
    }
}

void format_ipaddr(char buf[IPADDR_STR_LEN], ip_addr_t ipaddr)
{
    sprintf(buf, "%d.%d.%d.%d", 
	    (ipaddr >> 24) & 0xff, (ipaddr >> 16) & 0xff, 
	    (ipaddr >> 8) & 0xff, ipaddr & 0xff);
}

/*
 * Routine to load a big-endian value from a packet with no alignment
 * restrictions.  Size is the length of the value in bytes (0-4).
 */
uint32 packet_load(uint8 *addr, int size)
{
    uint32		val = 0;

    switch (size) {
    default:
	val |= (uint32) *addr++ << 24;
    case 3:
	val |= (uint32) *addr++ << 16;
    case 2:
	val |= (uint32) *addr++ << 8;
    case 1:
	val |= (uint32) *addr++ << 0;
    case 0:
	;
    }

    return val;
}

/*
 * Optimized Packet Filler
 *
 * Fills a buffer of bytes with a 32-bit incrementing pattern in
 * big-endian order.  There are no alignment restrictions on the buffer
 * and length.
 *
 * The increment value is added to the pattern each time it is stored
 * (every 4 bytes).  The final value of the pattern is returned (after
 * all the incrementing).
 */
uint32 packet_store(uint8 *buf, int size, uint32 pat, uint32 inc)
{
    int			align_off = ((uint32) buf & 3);
    int			pat_off = 24;

    if (align_off) {
	int		align_shr = align_off * 8;
	int		align_shl = 32 - align_shr;

	/* Store bytes from pat (MSB ==> LSB) until buf is aligned. */

	for (; ((uint32) buf & 3) != 0 && size > 0; pat_off -= 8, size--)
	    *buf++ = pat >> pat_off;

	/* Store whole words, incrementing pat in the middle of words. */

	for (; size > 3; buf += 4, size -= 4) {
	    uint32 x = pat << align_shl;
	    pat += inc;
	    x |= pat >> align_shr;
	    *(uint32 *) buf = htonl(x);
	}
    } else
	for (; size > 3; buf += 4, size -= 4, pat += inc)
	    *(uint32 *) buf = htonl(pat);

    /* Store up to 3 residual bytes. */

    for (; size > 0; size--, pat_off -= 8) {
	*buf++ = pat >> pat_off;
	if (pat_off == 0) {
	    pat += inc;		/* Add increment and wrap around to MSB */
	    pat_off = 32;
	}
    }

    return pat;
}

/*
 * Optimized packet compare
 *
 * Returns byte offset of first mismatch, -1 for compare equal.
 */

int packet_compare(uint8 *p1, uint8 *p2, int size)
{
    int			i = 0;

    if ((((uint32) p1 ^ (uint32) p2) & 3) != 0)
	goto residual;

    for (; ((uint32) p1 & 3) != 0 && i < size; i++)
	if (p1[i] != p2[i])
	    return i;

    for (; i < size - 3; i += 4)
	if (*(uint32 *) &p1[i] != *(uint32 *) &p2[i])
	    break;

 residual:

    for (; i < size; i++)
	if (p1[i] != p2[i])
	    return i;

    return -1;
}
