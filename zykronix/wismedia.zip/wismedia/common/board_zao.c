/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       board_zao.c
*
*   DESCRIPTION:
*       Board specific routines for IXP425 Platforms (ZAO/Predator)
*
*  AUTHOR:
*       Jimmy Blair
*
******************************************************************************/

#include "sal_api.h"
#include "platform.h"

/******************************************************************************
*
*   PROCEDURE:  
*       int board_bus_timing_set (unsigned int bus_param)
*
*   DESCRIPTION:
*       Set the bus timings as specified by the bus_param argument
*  
*   ARGUMENTS:
*       unsigned int bus_param - actual timing values to set - see platform.h
*
*   RETURNS:
*       0
*
******************************************************************************/

int 
board_bus_timing_set (unsigned int bus_param)
{
#ifdef PREDATOR
    * (volatile unsigned int *) (IXP425_EXP_CS4) = bus_param;
#else
    * (volatile unsigned int *) (IXP425_EXP_CS5) = bus_param;
#endif
    return 0;
}

/******************************************************************************
*
*   PROCEDURE:  
*       board_int_clear (unsigned int num)
*
*   DESCRIPTION:
*       Clears a single GPIO interrupt
*  
*   ARGUMENTS:
*       num  (GPIO number, not a mask or IRQ number!)
*
*   RETURNS:
*       0
*
******************************************************************************/

int 
board_int_clear (unsigned int num)
{
    gpio_line_isr_clear ((unsigned char) num);
    return (0);
}

/******************************************************************************
*
*   PROCEDURE:  
*       int board_int_config (int num, int type)
*
*   DESCRIPTION:
*       Configure a GPIO pin as an interrupt source
*  
*   ARGUMENTS:
*       int num  -- GPIO pin number 
*       int type -- level or edge triggered, active high or low
*
*   RETURNS:
*       0 for success, -1 for failure
*
*   NOTES:
*       The interrupt lines on the WISchip are active high; however,
*       they are inverted to active low by an FPGA on the ZAO board.
*
******************************************************************************/

int 
board_int_config (int num, int type)
{
    unsigned int tmp;
    unsigned char intnum;

    intnum = num;

    switch (type)
    {
        case INT_TYPE_LEVEL_LOW:
            tmp = IXP425_GPIO_ACTIVE_LOW;
            break;

        case INT_TYPE_LEVEL_HIGH:
            tmp = IXP425_GPIO_ACTIVE_HIGH;
            break;

        case INT_TYPE_EDGE_FALLING:
            tmp = IXP425_GPIO_FALLING_EDGE;
            break;

        case INT_TYPE_EDGE_RISING:
            tmp = IXP425_GPIO_RISING_EDGE;
            break;

        default:
            return (-1);
    }

    gpio_line_config (num, tmp |IXP425_GPIO_IN);

    return (0);
}
