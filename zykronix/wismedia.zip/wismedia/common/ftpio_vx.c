/********************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
/********************************************************************************
*
*   FILE: 
*
*		ftpio_vx.c
*
*   DESCRIPTION:
* 		VxWorks FTP I/O abstraction layer.
*********************************************************************************/
/*
 *
 * FTP/RSH Module
 *
 * Abstracts VxWorks FTP and RSH modules to look like ordinary file I/O.
 *
 * Permissible filename syntaxes are:
 *
 *	user%pass@host:file
 *	user@host:file
 *	host:file
 *	file
 *
 * If user or host is missing, the defaults are used and are required.
 *
 * If no password is given and there is no default password, RSH is
 * used; otherwise, FTP is used.
 *
 * Bug: For RSH, errors cannot be detected easily.  If an error occurs
 * while opening a file for reading or writing, the open succeeds.
 * 
 * $Id: ftpio_vx.c,v 1.1 2003/11/04 15:42:28 dmeyer Exp $
 */

#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <selectLib.h>
#include <errnoLib.h>
#include <ftpLib.h>
#include <vxWorks.h>
#include <ftpLib.h>
#include <remLib.h>
#include <bootLib.h>
#include "config.h"

#include <assert.h>
#include <io_vx.h>
#include <osl_vx.h>
#include <ftpio_vx.h>
#include "config.h"
#include "sysLib.h"
#include "netinet/in.h"
#include "sockLib.h"

/*
 * Timeout for connections.
 */
#define FTP_DATA_CONN_TIMEOUT		20	/* sec */


/*
 * Structure to keep track of transfers in progress
 */

#define MAX_FTPIO_OPEN	5

typedef struct FTPIO_FILE
{
    int     rsh;        /* True if RSH, false if FTP */
    FILE    *data_fp;
    int     ctrl_fd;
    int     data_fd;
} FTPIO_FILE;

static FTPIO_FILE ftpio_iob[MAX_FTPIO_OPEN];

/*
 * ftpio_defaults
 *
 *   Routine to set default user, password, and host.  This routine is
 *   optional.  If used, allows any of these three fields to be omitted
 *   from file specifications.
 */

char *ftpio_dfl_user = 0;
char *ftpio_dfl_pass = "";
char *ftpio_dfl_host = 0;

void ftpio_defaults(char *user, char *pass, char *host)
{
    if (user)
        ftpio_dfl_user = strcpy(malloc(strlen(user) + 1), user);
    if (pass)
        ftpio_dfl_pass = strcpy(malloc(strlen(pass) + 1), pass);
    if (host)
        ftpio_dfl_host = strcpy(malloc(strlen(host) + 1), host);
}

/*
 * ftpio_split
 *
 *   Utility routine to break a file name into directory and file
 *   portions.  Works well on weird paths.  Modifies input string.
 */

void ftpio_split(char *path, char **dir, char **file)
{
    char        *last_slash;

    if ((last_slash = strrchr(path, '/')) == 0)
    {
        *dir = ".";
        *file = path;
    }
    else if (last_slash == path)
    {
        *dir = "/";
        *file = (path[1] ? &path[1] : ".");
    }
    else
    {
        *last_slash = 0;
        *dir = path;
        *file = (last_slash[1] ? &last_slash[1] : ".");
    }
}

/*
 * ftpio_breakline
 *
 *   Utility routine to parse filename syntax and supply defaults,
 *   if any.
 */

int ftpio_breakline(char *line,
                    char **host, char **user, char **file, char **pass)
{
    char        *percent, *atsign, *colon;

    if (line == NULL)
    {
        printk("netio: Null filename\n");
        return -1;
    }

    /*
     * Syntaxes supported (repeated from comment at top of file):
     *
     *	user%pass@host:file
     *	user@host:file
     *	host:file
     *	file
     */

    *user = ftpio_dfl_user;
    *pass = ftpio_dfl_pass;
    *host = ftpio_dfl_host;

    if ((colon = strchr(line, ':')) != 0)
        *colon++ = 0;

    if ((atsign = strchr(line, '@')) != 0)
        *atsign++ = 0;

    if ((percent = strchr(line, '%')) != 0)
        *percent++ = 0;

    if (percent && atsign && colon)
    {
        *user = line;
        *pass = percent;
        *host = atsign;
        *file = colon;
    }
    else if (! percent && atsign && colon)
    {
        *user = line;
        *host = atsign;
        *file = colon;
    }
    else if (! percent && ! atsign && colon)
    {
        *host = line;
        *file = colon;
    }
    else if (! percent && ! atsign && ! colon)
    {
        *file = line;
    }
    else
    {
        printk("netio: Filename syntax error (user[%%pass]@host:file)\n");
        return -1;
    }

    if (!*user || !*pass || !*host || !*file)
    {
        printk("netio: Insufficient filename spec (user[%%pass]@host:file)\n");
        return -1;
    }

    if (**file == 0)
        *file = ".";

    debugk(DK_VERBOSE, "ftpio_breakline:\n");
    debugk(DK_VERBOSE, "  File: %s\n", *file);
    debugk(DK_VERBOSE, "  User: %s\n", *user);
    debugk(DK_VERBOSE, "  Pass: %s\n", *pass);
    debugk(DK_VERBOSE, "  Host: %s\n", *host);

    return 0;
}

/*
 * ftpio_open
 *
 *   This routine is functionally similar to fopen.  The resulting file
 *   pointer can be used with stdio read and write routines.  It must be
 *   closed with ftpio_close, not fclose.  It is not legal to fseek.
 */

FILE *ftpio_open(char *filespec, char *fmode)
{
    char        *pass, *host, *file, *user;
    char        cmd[256];
    FTPIO_FILE      *ff;
    int         i;

    /*
    * Find a free slot in the table of outstanding transfers
    */

    for (i = 0; i < MAX_FTPIO_OPEN; i++)
        if (ftpio_iob[i].data_fp == 0)
            break;
    if (i == MAX_FTPIO_OPEN)        /* Too many outstanding */
        return 0;
    ff = &ftpio_iob[i];

    if (ftpio_breakline(filespec, &host, &user, &file, &pass) < 0)
        return 0;

    ff->rsh = (*pass == 0);

    /*
     * If password is non-empty, use ftpLib to open a connection for
     * reading, writing, or appending to the file.  Otherwise, use
     * remLib.
     */

    if (ff->rsh)
    {
        switch (fmode[0])
        {
            case 'a':   sprintf(cmd, "cat >> %s", file);    break;
            case 'w':   sprintf(cmd, "cat > %s" , file);    break;
            case 'r':   sprintf(cmd, "cat %s"   , file);    break;
            default :   cmd[0] = 0;             assert(0);
        }

        if ((ff->data_fd = rcmd(host, 514, user, user,
                                cmd, &ff->ctrl_fd)) == ERROR)
        {
            printk("ftpio_open: RSH connection failed to host %s\n", host);
            return 0;
        }
    }
    else
    {
        switch (fmode[0])
        {
            case 'a':   strcpy(cmd, "APPE %s");     break;
            case 'w':   strcpy(cmd, "STOR %s");     break;
            case 'r':   strcpy(cmd, "RETR %s");     break;
            default :   cmd[0] = 0;         assert(0);
        }

        if (FTPXfer(host, user, pass, "", cmd, "", file,
                    &ff->ctrl_fd, &ff->data_fd) == ERROR)
        {
            printk("ftpio_open: FTP connection failed to host %s\n", host);
            return 0;
        }
    }

    if ((ff->data_fp = fdopen(ff->data_fd, fmode)) == 0)
    {
        perror("fdopen");
        close(ff->ctrl_fd);
        close(ff->data_fd);
        return 0;
    }

    return ff->data_fp;
}

/*
 * ftpio_close
 *
 *   Closes a file pointer returned from ftpio_open.  Do not use fclose
 *   directly.
 */

int ftpio_close(FILE *fp)
{
    FTPIO_FILE      *ff;
    int         i, rc = 0;

    /* Search for entry in table of outstanding transfers */

    for (i = 0; i < MAX_FTPIO_OPEN; i++)
        if (ftpio_iob[i].data_fp == fp)
            break;
    if (i == MAX_FTPIO_OPEN)
        return -1;
    ff = &ftpio_iob[i];

    /* Close data pointer.  This also closes data_fd.  */

    fclose(ff->data_fp);

    if (! ff->rsh)
    {
        /*
         * Don't check ftpReplyGet for FTP_COMPLETE.  That would cause
         * an error if an FTP connection is closed prematurely, which is
         * not illegal and does happen.
         */

        (void) ftpReplyGet(ff->ctrl_fd, TRUE);

        if (ftpCommand(ff->ctrl_fd, "QUIT",
                       0, 0, 0, 0, 0, 0) != FTP_COMPLETE)
        {
            printk("ftpio_close: Error receiving FTP QUIT completion");
            rc = -1;
        }
    }

    close(ff->ctrl_fd);

    ff->data_fp = 0;

    return rc;
}

/*
 * ftpio_valid_fp
 *
 *  Convenient utility routine allowing an application to determine
 *  whether or not a file descriptor was opened using ftpio_fopen.
 */

int ftpio_valid_fp(FILE *fp)
{
    int         i;

    for (i = 0; i < MAX_FTPIO_OPEN; i++)
        if (ftpio_iob[i].data_fp == fp)
            return 1;

    return 0;
}

/*
 * ftpio_ls
 *
 *  Get a file listing and display output on stdout.
 */

int ftpio_ls(char *path, char *flags)
{
    char        *pass, *host, *file, *user, *dir, *c;
    int         rc = 0;
    int         c_fd, d_fd;     /* control/data FDs */
    char        buf[256];
    char        cmd[256];
    FILE        *f;
    int         f_on_line;
    int         rsh;
    int         one_per_line;

    if (flags == NULL)
        flags = "";

    if (ftpio_breakline(path, &host, &user, &file, &pass))
        return(-1);

    rsh = (pass[0] == 0);

    one_per_line = (rsh || strchr(flags, 'l') != NULL);

    if (rsh)
    {
        sprintf(cmd, "ls -C %s %s", flags, file);

        if ((d_fd = rcmd(host, 514, user, user, cmd, &c_fd)) == ERROR)
        {
            printk("ftpio_ls: RSH connection failed to host %s\n", host);
            return -1;
        }
    }
    else
    {
        ftpio_split(file, &dir, &file);

        sprintf(cmd, "NLST %s%s%s", flags, flags[0] ? " " : "", file);

        if (FTPXfer(host, user, pass, "", cmd,
                    dir, "" /* not used */,
                    &c_fd, &d_fd) == ERROR)
        {
            printk("ftpio_ls: FTP connection failed to host %s\n", host);
            return(-1);
        }
    }

    f = fdopen(d_fd, "r");
    f_on_line = 0;

    while (fgets(buf, sizeof(buf), f))
    {
        if ((c = strchr(buf, '\n')))
        {
            *c = '\0';
        }
        /* if this is a DOS FTP machine, get rid of the \r */
        if ((c = strchr(buf, '\r')))
        {
            *c = '\0';
        }
        f_on_line++;
        if (one_per_line)
        {
            printk("%s\n", buf); /* Normal for "ls -l " */
        }
        else 
            if (! (f_on_line % 4))
            printk("%s\n", buf);
        else
            printk("%-19s ", buf);
    }

    if (! one_per_line && (f_on_line % 4))
    {
        printk("\n");
    }

    fclose(f);

    if (! rsh)
    {
        if (ftpReplyGet(c_fd, TRUE) != FTP_COMPLETE)
        {
            perror("ERROR receiving FTP reply");
            rc = -1;
        }

        if (ftpCommand(c_fd, "QUIT", 0, 0, 0, 0, 0, 0) != FTP_COMPLETE)
        {
            perror("ERROR receiving FTP QUIT completion");
            rc = -1;
        }
    }

    close(c_fd);

    /*
     * Note: if 'ls' command fails on remote host, e.g. for file not
     * found, the ftpXfer above fails and returns -1, but the rcmd
     * doesn't.
     */

    return(rc);
}

/*
 * ftpio_remove
 *
 *   Delete a file.
 */

int
ftpio_remove(char *path)
{
    char        *pass, *host, *file, *user;
    char        cmd[256];
    int         rc = -1, c_fd = -1, d_fd = -1;

    if (ftpio_breakline(path, &host, &user, &file, &pass))
        goto done;

    if (pass[0] == 0)
    {     /* rsh */
        sprintf(cmd, "rm -f - %s", file);

        if ((d_fd = rcmd(host, 514, user, user, cmd, &c_fd)) == ERROR)
        {
            printk("ftpio_remove: RSH connection failed to host %s\n", host);
            goto done;
        }
    }
    else
    {
        if (FTPXfer(host, user, pass, "", "DELE %s", "", file,
                    &c_fd, NULL) == ERROR)
        {
            printk("ftpio_remove: FTP connection failed to host %s\n", host);
            goto done;
        }
    }

    rc = 0;

    done:

    if (c_fd >= 0)
    {
        if (pass[0] != 0)   /* ftp */
            (void) ftpCommand(c_fd, "QUIT", 0, 0, 0, 0, 0, 0);
        close(c_fd);
    }

    if (d_fd >= 0)
        close(d_fd);

    return(rc);
}

/*
 * ftpio_rename
 *
 *   Rename a file.  The old_path is a usual netio filename spec, but
 *   the destination name must be a plain path without %, @, or :.
 */

int ftpio_rename(char *old_path, char *new_path)
{
    char        *pass, *host, *file, *user;
    char        cmd[256];
    int         rc = -1, c_fd = -1, d_fd = -1;

    if (ftpio_breakline(old_path, &host, &user, &file, &pass))
        goto done;

    if (new_path == NULL)
    {
        printk("ftpio_rename: Null destination filename\n");
        return -1;
    }

    if (pass[0] == 0)
    {     /* rsh */
        sprintf(cmd, "mv -f %s %s", file, new_path);

        if ((d_fd = rcmd(host, 514, user, user, cmd, &c_fd)) == ERROR)
        {
            printk("ftpio_rename: RSH connection failed to host %s\n", host);
            return -1;
        }
    }
    else
    {
        if (FTPXfer(host, user, pass, "", "RNFR %s", "", file,
                    &c_fd, NULL) == ERROR)
        {
            printk("ftpio_rename: FTP connection failed to host %s\n", host);
            goto done;
        }

        if (ftpCommand(c_fd, "RNTO %s", (int) new_path,
                       0, 0, 0, 0, 0) != FTP_COMPLETE)
        {
            printk("ftpio_rename: FTP completion failed to host %s\n", host);
            goto done;
        }
    }

    rc = 0;

    done:

    if (c_fd >= 0)
    {
        if (pass[0] != 0)   /* ftp */
            (void) ftpCommand(c_fd, "QUIT", 0, 0, 0, 0, 0, 0);
        close(c_fd);
    }

    if (d_fd >= 0)
        close(d_fd);

    return(rc);
}

/*
 * FTPXfer
 *
 * This routine replaces VxWorks ftpXfer and doesn't have a bug that can
 * cause very small file transfers to fail.  In particular, it calls
 * select() on both the data and control sockets, and if they become
 * ready at the SAME TIME (as opposed to just the data socket), vxWorks
 * falsely assumes an error.
 */

BOOL ftpVerbose = 0; /* Todo: support via ftpLib.c */

STATUS FTPXfer(char *host, char *user, char *passwd, char *acct,
               char *cmd, char *dirname, char *filename,
               int *pCtrlSock, int *pDataSock)
{
    int         ctrlSock = ERROR, dataSock = ERROR;
    struct fd_set   rfd;
    int         result;
    struct timeval  tmo;
    char        *errmsg = NULL;

    if (ftpVerbose)
        printf("FTPXfer: hookup host=%s file=%s\n", host, filename);

    if ((ctrlSock = ftpHookup(host)) == ERROR)
    {
        errmsg = "server unreachable";
        goto error;
    }

    *pCtrlSock = ctrlSock;

    if (ftpVerbose)
        printf("FTPXfer: login user=%s\n", user);

    if (ftpLogin(ctrlSock, user, passwd, acct) != OK)
    {
        errmsg = "authentication failed";
        goto error;
    }

    if (ftpVerbose)
        printf("FTPXfer: set binary\n");

    if (ftpCommand(ctrlSock, "TYPE I", 0, 0, 0, 0, 0, 0) != FTP_COMPLETE)
    {
        errmsg = "set binary mode failed";
        goto error;
    }

    if (dirname[0])
    {
        if (ftpVerbose)
            printf("FTPXfer: cd %s\n", dirname);

        if (ftpCommand(ctrlSock, "CWD %s",
                       (int) dirname, 0, 0, 0, 0, 0) != FTP_COMPLETE)
        {
            errmsg = "change directory failed";
            goto error;
        }
    }

    /*
     * Retry loop for transient errors, such as the remote host being
     * unable to assign the requested port number.
     */

    retry_transient_error:

    /*
     * If this is a transfer command requiring a data connection,
     * first establish socket for server to connect back to.
     */

    if (pDataSock)
    {
        int         len;
        short           port;
        struct sockaddr_in  ownAddr;
        struct sockaddr_in  dataAddr;

        if (ftpVerbose)
            printf("FTPXfer: set binary\n");

        /* Find out our own address */

        len = sizeof (ownAddr);
        if (getsockname(ctrlSock, (struct sockaddr *) &ownAddr, &len) < 0)
        {
            errmsg = "FTP could not get own addr";
            goto error;
        }

        if ((dataSock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
        {
            errmsg = "FTP could not create data socket";
            goto error;
        }

        dataAddr = ownAddr;
        dataAddr.sin_port = htons(0);

        if (bind(dataSock,
                 (struct sockaddr *) &dataAddr,
                 sizeof (dataAddr)) != OK)
        {
            close(dataSock);
            errmsg = "FTP could not bind data socket";
            goto error;
        }

        /* Read back to find out what port was bound */

        len = sizeof (dataAddr);
        if (getsockname(dataSock, (struct sockaddr *) &dataAddr, &len) < 0)
        {
            errmsg = "FTP could not get data addr";
            goto error;
        }

        port = ntohs(dataAddr.sin_port);

        if (listen(dataSock, 1) < 0)
        {
            close(dataSock);
            errmsg = "FTP could not listen on data socket";
            goto error;
        }

        /* Use PORT command to inform server of data socket address */

        if (ftpCommand(ctrlSock,
                       "PORT %d,%d,%d,%d,%d,%d",
                       (int) ((UINT8 *) &dataAddr.sin_addr)[0],
                       (int) ((UINT8 *) &dataAddr.sin_addr)[1],
                       (int) ((UINT8 *) &dataAddr.sin_addr)[2],
                       (int) ((UINT8 *) &dataAddr.sin_addr)[3],
                       (int) (port >> 8),
                       (int) (port & 0xff)) != FTP_COMPLETE)
        {
            close(dataSock);
            errmsg = "FTP could not send PORT command";
            goto error;
        }
    }

    /*
     * Send the FTP command.
     */

    if (ftpVerbose)
        printf("FTPXfer: command %s\n", cmd);

    result = ftpCommand(ctrlSock, cmd, (int) filename, 0, 0, 0, 0, 0);

    if (ftpVerbose)
        printf("FTPXfer: result %d\n", result);

    switch (result)
    {
        case FTP_TRANSIENT:
            if (pDataSock)
                close(dataSock);
            goto retry_transient_error;
        case FTP_COMPLETE:
        case FTP_CONTINUE:
            if (pDataSock)
            {
                close(dataSock);
                errmsg = "server returned COMPLETE or CONTINUE instead of PRELIM";
                goto error;
            }
            return OK;  /* Non-transfer command succeeded */
        case FTP_PRELIM:
            if (! pDataSock)
            {
                errmsg = "server returned PRELIM for non-transfer command";
                goto error;
            }
            break;      /* Continue below to start transfer */
        default:
            if (pDataSock)
                close(dataSock);
            errmsg = "command failed";
            goto error;
    }

    /*
     * Wait for server to connect back on data socket.
     * Use select to provide a timeout.
     */

    FD_ZERO(&rfd);
    FD_SET(dataSock, &rfd);

    tmo.tv_sec = FTP_DATA_CONN_TIMEOUT;
    tmo.tv_usec = 0;

    if (ftpVerbose)
        printf("FTPXfer: wait for data\n");

    if (select(FD_SETSIZE, &rfd, NULL, NULL, &tmo) < 0)
    {
        if (pDataSock)
            close(dataSock);
        errmsg = "data conn failed or timed out";
        goto error;
    }

    if (ftpVerbose)
        printf("FTPXfer: get data conn\n");

    if ((dataSock = ftpDataConnGet(dataSock)) == ERROR)
    {
        errmsg = "failed to accept server connection";
        goto error;
    }

    *pDataSock = dataSock;

    if (ftpVerbose)
        printf("FTPXfer: return OK\n");

    return OK;

    error:

    if (errmsg && ftpVerbose)
        printErr("FTP ERROR: %s (errno=%d)\n", errmsg, errnoGet());

    if (ctrlSock != ERROR)
    {
        (void) ftpCommand(ctrlSock, "QUIT", 0, 0, 0, 0, 0, 0);
        close(ctrlSock);
    }

    if (ftpVerbose)
        printf("FTPXfer: return ERROR\n");

    return ERROR;
}
