/*
 * CLI Program for WIS Media Player
 */
#include <types.h>
#include <osl_vx.h>
#include <io_vx.h>
#include <ftpio_vx.h>
#include <version.h>
#include <assert.h>

/* Common Includes */
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <time.h>
#include <setjmp.h>
#include <stdio.h>
#include <signal.h>


/* CLI Command function */
typedef int (cmd_func)(int vdev, char* cmdline[], int argc);

#define MAX_CMDLINE_LEN  2048
#define RECURSION_DEPTH_MAX	               32
#define	PUSH_CTRL_C_CNT	(RECURSION_DEPTH_MAX + 4)

#define CLI_OK       0
#define CLI_FAIL     -1
#define CLI_EXIT     1


extern bool_t boStreamFileWrite;
extern FILE *encoderWritePtr;
#include "wis_error.h"
#include "wis_encoder.h"

extern void StreamWriteCallback(void* pFrame, sint32 len, void* user,
                                wis_frame_info_t frameInfo);


/*
 * cli_ctrl_c_cnt
 * Index indicating current top of stack for pushed
 * Control-C handlers. "-1" Indicates no handlers pushed.
 */
static volatile int     cli_ctrl_c_cnt = -1;

/*
 * cli_ctrl_c_stack
 * Tracks pushed control-C handlers. Both the jmpbuf and the
 * the setting thread is tracked.
 */
static volatile struct
{
	jmp_buf     *pc_jmpbuf;	/* Pointer to jmpbuf for longjmp */
	osl_thread_t    *pc_thread;	/* Thread that pushed the entry */
} cli_ctrl_c_stack[PUSH_CTRL_C_CNT];


/*
 * Function: 	cli_ctrl_c_handler
 * Purpose:	Actual handler called when Control-C occurs.
 * Parameters:	sig - not used.
 * Returns:	Nothing.
 */
void 
cli_ctrl_c_handler(int sig)
{
	assert(cli_ctrl_c_cnt >= 0);
	if (osl_thread_self() != cli_ctrl_c_stack[cli_ctrl_c_cnt].pc_thread)
	{
		printk("ERROR: thread 0x%x took my Control-C!!\n",
			   (uint32) osl_thread_self);
		return;
	}
	signal(SIGINT, cli_ctrl_c_handler);	/* Enable now */
	printk("\nInterrupt\n");
	longjmp(*cli_ctrl_c_stack[cli_ctrl_c_cnt].pc_jmpbuf, 1);
}

/*
 * Function: 	cli_ctrl_c_take
 * Purpose:	Fake a control-C exception (useful for assert).
 * Parameters:	none.
 * Returns:	Does not return.
 */
void
cli_ctrl_c_take(void)
{
	printk("\n");
	if (cli_ctrl_c_cnt >= 0)
	{
		longjmp(*cli_ctrl_c_stack[cli_ctrl_c_cnt].pc_jmpbuf, 1);
	}
	exit(1);
}

/*
 * Function: 	cli_push_ctrl_c
 * Purpose:	Push a control C long jump buffer onto the handler stack.
 * Parameters:	jb - pointer to long jump buffer (jmp_buf).
 * Returns:	Nothing
 */
void 
cli_push_ctrl_c(jmp_buf *jb)
{
	signal(SIGINT, SIG_IGN);
	assert(cli_ctrl_c_cnt < (PUSH_CTRL_C_CNT - 1));
	cli_ctrl_c_cnt++;
	cli_ctrl_c_stack[cli_ctrl_c_cnt].pc_jmpbuf = jb;
	cli_ctrl_c_stack[cli_ctrl_c_cnt].pc_thread = osl_thread_self();
	signal(SIGINT, cli_ctrl_c_handler);	/* Enable now */
}

/*
 * Function: 	cli_pop_ctrl_c
 * Purpose:	Pop an control-c entry off the handler stack.
 * Parameters:	None.
 * Returns:	Nothing.
 */
void 
cli_pop_ctrl_c(void)
{
	signal(SIGINT, SIG_IGN);
	cli_ctrl_c_cnt--;
	if (0 > cli_ctrl_c_cnt)
	{
		signal(SIGINT, SIG_DFL);
	}
	else
	{
		signal(SIGINT, cli_ctrl_c_handler);	/* Enable now */
	}
}





/* 
 * Command dispatch table.
 */
typedef struct cmd_s
{
	char* name;
	char* help;
	cmd_func* command;
} cmd_t;


int 
v4l_showdevs(int vdev, char* cmd[], int argc)
{
	int i;
	for (i = 0; i < argc; i++)
	{
		printf("arg[%d]: %s\n", i,cmd[i]);
	}
	return 0;
}

int 
run_shell(int vdev, char* cmd[], int argc)
{
	osl_native_shell();
	return 0;
}

int 
reboot_cmd(int vdev, char* cmd[], int argc)
{
	osl_reboot();
	return 0;
}



int 
cli_ls(int u, char* cmd[], int argc)
{
	char    *c, *flags = NULL;
	int i = 0;

	c = cmd[0];

	if (c != NULL && c[0] == '-')
	{
		flags = c;
		c = cmd[1];
	}

	if (c == NULL)
		c = ".";

	while ((i <= argc) && (c != NULL))
	{
		osl_ls(c, flags);
		c = cmd[i++];
	}

	return 0;
}

int 
cli_pwd(int u, char *cmd[], int argc)
{
	char    pwd[128];

	if (argc != 0)
	{
		return -1;
	}

	if (!osl_getcwd(pwd, sizeof(pwd)))
	{
		printk("%s: Error: Unable to determine current directory\n", 
			   cmd[0]);
		return -1;
	}
	else
	{
		printk("Working Directory: %s\n", pwd);
		return 0;
	}
}



int 
cli_do_copy(char* cmd[], char *s_src, char *s_dst)
{
	int volatile rv = -1;
	jmp_buf ctrl_c;
	FILE * volatile f_src = NULL,	/* Source/destination FILE */
	* volatile f_dst = NULL;

	if (!setjmp(ctrl_c))
	{
		char    buf[1024];
		int     r, w;

		cli_push_ctrl_c(&ctrl_c);

		if ((f_src = osl_fopen(s_src, "rb")) == NULL)
		{
			printk("%s: Error: unable to open input file: %s\n",
				   cmd[0], s_src);
			goto done;
		}

		if ((f_dst = osl_fopen(s_dst, "wb")) == NULL)
		{
			printk("%s: Error: unable to open output file: %s\n",
				   cmd[1], s_dst);
			goto done;
		}

		while ((r = fread(buf, 1, sizeof(buf), (FILE *) f_src)) > 0)
			if ((w = fwrite(buf, 1, r, (FILE *) f_dst)) != r)
			{
				printk("%s: Error writing %s\n", cmd[1], s_dst);
				goto done;
			}

		if (r < 0)
		{
			printk("%s: Error reading %s\n", cmd[0], s_src);
			goto done;
		}
		rv = 0;
	}
	else
	{
		rv = -1; /* Ctrl-C pressed, jmpbuf worked */
	}

	done:
	cli_pop_ctrl_c();
	if (f_src)
	{
		(void) osl_fclose((FILE *)f_src);
	}
	if (f_dst)
	{
		if (osl_fclose((FILE *)f_dst))
		{
			printk("%s: Error closing %s\n", cmd[1], s_dst);
			rv = -1;
		}
	}
	return(rv);
}    

int
cli_copy(int dev, char* cmd[], int argc)
{
	char *s_src, 
	*s_dst;	/* Source destination names */

	if (argc < 2)
	{
		printf ("Error: copy <source> <dest>\n");
		return -1;
	}
	/* 
	 * Figure out source/destination names, if no destination then use
	 * filename without path from source in current working directory.
	 */

	s_src = cmd[0];
	s_dst = cmd[1];			/* May be NULL */

	if (!s_dst)
	{			/* First, look back for '/' */
		if ((s_dst = strrchr(s_src, '/')))
		{
			s_dst;
		}
	}

	if (!s_dst)
	{			/* Look back for ':' */
		if ((s_dst = strrchr(s_src, ':')))
		{
			s_dst;
		}
	}

	if (!s_dst)
	{
		printk("%s: Error: No file to copy TO\n", cmd[1]);
		return -1;
	}
	return(cli_do_copy(cmd, s_src, s_dst));
}


int 
ftp_dumpframe(int vdev, char* cmd[], int argc)
{
	FILE* fp;
	char buffer[100];

	if (argc != 1)
	{
		printk("Error: dumpframe <file>\n");
		return -1;
	}
	ftpio_defaults("tornado", "tornado+", "192.168.0.38");

	fp = ftpio_open(cmd[0], "w");
	if (fp != NULL)
	{
		memset(buffer, 'j', 100);
		fwrite((void*)buffer, 100, 1, fp);
		ftpio_close(fp);
	}

	return 0;
}

int
cli_start_encoder(int vdev, char* cmd[], int argc)
{
	EncoderStart(150);
}

int
cli_stop_encoder(int vdev, char* cmd[], int argc)
{
	EncoderStop();
	if (encoderWritePtr != NULL)
	{
		fclose(encoderWritePtr);
	}
}

int
cli_call_ipaddr(int vdev, char* cmd[], int argc)
{

}

int
cli_talk_name(int vdev, char* cmd[], int argc)
{

}

int
cli_take_snapshot(int vdev, char* cmd[], int argc)
{

}


/*
	{"setbrc <targetrate> <peakrate> <maxfps> <gopsize> <buffersize>", "Set BRC parameters", cli_set_brc},
*/
int
cli_set_brc(int vdev, char* cmd[], int argc)
{

}

/*
	{"setdisplay <vga|qvga|cif|qcif> <32bit|16bit|8bit>", "Set the display size & color mode", cli_set_display},
*/
int
cli_set_display(int vdev, char* cmd[], int argc)
{

}

/*
	{"setencode <ionly|iponly|ibp> <mpeg2|mpeg4>", "Set the encoder GOP mode and encode format", cli_set_encode},
*/
int
cli_set_encode(int vdev, char* cmd[], int argc)
{

}

/*
	{"setlocal <enable|disable>", "Enable or disable local decode", cli_set_local},
*/
int
cli_set_local(int vdev, char* cmd[], int argc)
{

}

/*
	{"dumplocal <ipaddr> <username> <password> <filename>", "send locally encoded stream to an FTP server", cli_dump_local},
*/
int
cli_dump_local(int vdev, char* cmd[], int argc)
{
	status_t status;

	boStreamFileWrite = TRUE;
	ftpio_defaults("tornado", "vxworkstor", "192.168.1.101");

	encoderWritePtr = ftpio_open("stream.mpg", "w");

	if (encoderWritePtr != NULL)
	{
		/* Register Display callback */
		status =  EncoderRegisterFrameCallback((encoder_callback_t *)StreamWriteCallback, (void*)encoderWritePtr);
		if (status != ENCODER_SUCCESS)
		{
			logMsg("Error: could not register file write callback.\n");
			return WIS_FAILURE;
		}
	}

}

/*
	{"setdebuglevel <debuglevel>", "set the current system debug level", cli_set_debug_level},
*/
extern sint32 debugLevel;
int
cli_set_debug_level(int vdev, char* cmd[], int argc)
{
	debugLevel=*cmd[0] - '0';
}


#include "net.h"

/* XXX: test task, remove when done, see txvod.c for example sender  */
extern void txvod_test_sender(int streamId);


static osl_thread_t call_control_thread = OSL_THREAD_ERROR;

static vod_info_t servers[100];

int 
video_service_start(int dev, char* cmd[], int argc)
{
	int port = 2000;
	int index = 0;
	vod_info_t* vod = NULL;

	if (call_control_thread != OSL_THREAD_ERROR)
	{
		printk("VOD: call manager already running\n");
		return -1;
	}
	if (argc != 2)
	{
		printk("usage: start <port> <id>\n");
		return -1;
	}
	port = atoi(cmd[0]);
	index = atoi(cmd[1]);
	vod = &servers[index];
	vod->port = port;
	vod->streamIndex = index;

	printk("VOD: index=%d call port=%d\n", index, port);

	call_control_thread = osl_thread_create("tVODCC",
											OSL_THREAD_STKSZ,
											100,
											(void *)netvideo_call_control_service,
											(void *)vod);

	if (call_control_thread == OSL_THREAD_ERROR)
	{
		printk("VOD: error, could not start service on port %d\n",port);
	}
	return 0;
}

int 
video_service_stop(int dev, char* cmd[], int argc)
{
	if (call_control_thread != OSL_THREAD_ERROR)
	{
		osl_thread_destroy(call_control_thread);
		printk("VOD: call control service stopped\n");
	}
	netvideo_call_control_stop();
	call_control_thread = OSL_THREAD_ERROR;
	return 0;
}

extern void txvod_sender_callback(void *frame, sint32 len, void *userdata, bool_t boFrameIsDuplicate, bool_t boFrameIsStreamHeader);

int 
video_service_call(int dev, char* cmd[], int argc)
{
	status_t			status;

	if (argc < 3)
	{
		printk("usage: call <ipaddr> <port> <id>\n");
		return -1;
	}

	status = netvideo_connect(cmd[0],atoi(cmd[1]), 0, atoi(cmd[2]),1500);
	
	if (status != 0)
	{
		return(-1);
	}

#if 0

	osl_thread_create("Test Transmitter",
					  OSL_THREAD_STKSZ, 100,
					  (void*)txvod_test_sender,
					  (void*)0);
#else
	/* Register transmit callback */
	status =  EncoderRegisterFrameCallback((encoder_callback_t *)txvod_sender_callback, (void*)0);
	
	if (status != ENCODER_SUCCESS)
	{
		logMsg("Error: could not register local loopback display callback.\n");
		return WIS_FAILURE;
	}

#define ENCODER_JOB_TASK_PRIORITY   151
	/* Start Encoder! */
	status = EncoderStart(ENCODER_JOB_TASK_PRIORITY-1);
	if (status != ENCODER_SUCCESS)
	{
		logMsg("Error: could not start video encoder!\n");
		return WIS_FAILURE;
	}
#endif

}

int 
video_service_answer(int dev, char* cmd[], int argc)
{
	/* XXX: todo */
	return 0;
}

int 
video_service_hup(int dev, char* cmd[], int argc)
{
	/* XXX: todo */
	return 0;
}


/*
 * CLI Commands
 */

/* 
 * Command dispatch table.
 */
static cmd_t command_table[] = {
	{"cp", "Copy file: cp <src> <dst>", cli_copy},
	{"dumpframe", "Example of how to dump a frame via FTP", ftp_dumpframe},

	{"starte", "Start the encoder with the current configuration", cli_start_encoder},
	{"stope", "Stop the encoder", cli_stop_encoder},
	{"call <ipaddr> <name>", "Initiate a call to an  IP address with your name", cli_call_ipaddr},
	{"talk <name>", "Respond to a call from <name>", cli_talk_name},
	{"snapshot", "Save a snapshot of yourself", cli_take_snapshot},
	{"setbrc <targetrate> <peakrate> <maxfps> <gopsize> <buffersize>", "Set BRC parameters", cli_set_brc},
	{"setdisplay <vga|qvga|cif|qcif> <32bit|16bit|8bit>", "Set the display size & color mode", cli_set_display},
	{"setencode <ionly|iponly|ibp> <mpeg2|mpeg4>", "Set the encoder GOP mode and encode format", cli_set_encode},
	{"setlocal <enable|disable>", "Enable or disable local decode", cli_set_local},
	{"dumplocal", "send locally encoded stream to an FTP server", cli_dump_local},
	{"setdebugleveol <debuglevel>", "set the current system debug level", cli_set_debug_level},

	{"start", "Start VOD service", video_service_start},
	{"stop", "Start VOD service", video_service_stop},
	{"call", "Call/connect to remote service", video_service_call},
	{"answer", "Answer Call/connect from remote service", video_service_answer},
	{"hup", "Disconnect from remote service", video_service_hup},

	{"ls", "show files", cli_ls},
	{"pwd", "Print working directory", cli_pwd},
	{"sh", "Run VxWorks shell", run_shell},
	{"reboot", "Reboot system", reboot_cmd},
	{"reset", "Reboot system", reboot_cmd},  
};


#define _NUM_COMMANDS (sizeof(command_table)/sizeof(command_table[0]))
int NUM_COMMANDS = _NUM_COMMANDS;




#ifdef INCLUDE_EDITLINE

/*
 * Completion routines for command line editor
 */
int cli_list_possibilities(char *regpref, char ***avp)
{
	return 0;
}

char *cli_complete(char *regpref, int *unique)
{
	char *s;
	int i, j, len, upcase, pfxlen, pfxmin;
	char **av;
	int ac;

	if ((ac = cli_list_possibilities(regpref, &av)) == 0)
		return 0;

	len = strlen(regpref);
	pfxmin = 0;
	pfxlen = strlen(av[0]);

	for (i = 1; i < ac; i++)
	{
		/* Find length of common prefix of all matches */
		for (j = 0; av[pfxmin][j] && av[i][j]; j++)
			if (av[pfxmin][j] != av[i][j])
				break;
		if (j < pfxlen)
		{
			pfxmin = i;
			pfxlen = j;
		}
	}

	/* Generate completion.  Mimic case of input string. */
	s = malloc(pfxlen - len + 1);
	upcase = isupper((int) regpref[len - 1]);
	for (i = 0; i < pfxlen - len; i++)
		s[i] = upcase ? toupper(av[0][len + i]) : tolower(av[0][len + i]);
	s[i] = 0;

	*unique = (ac == 1);

	for (i = 0; i < ac; i++)
		free(av[i]);
	free(av);

	return s;
}
#endif /* INCLUDE_EDITLINE */

#if 0
char *
readline(char *prompt, char *buf, int bufsize, char *defl)
{
	char *s, *full_prompt;
	char *t;

	if (bufsize == 0)
		return buf;

	full_prompt = malloc(strlen(prompt) + (defl ? strlen(defl) : 0) + 8);
	strcpy(full_prompt, prompt);
	if (defl)
		sprintf(full_prompt + strlen(full_prompt), "[%s] ", defl);

	t = malloc(bufsize);
	printf("%s", full_prompt);
	if ((s = fgets(t, bufsize, stdin)) == 0)
	{
		free(t);
		clearerr(stdin);
	}
	else
	{
		s[bufsize - 1] = 0;
		if ((t = strchr(s, '\n')) != 0)
			*t = 0;
		/* Replace garbage characters with spaces */
		for (t = s; *t; t++)
			if (*t < 32 && *t != 7 && *t != 9)
				*t = ' ';
	}

	if (s == 0)
	{						/* Handle Control-D */
		buf[0] = 0;
		printf("EOF\n");
		buf = 0;
		goto done;
	}

	if (s[0] == 0)
	{
		if (! defl)
			buf[0] = 0;
		else if (buf != defl)
		{
			strncpy(buf, defl, bufsize);
			buf[bufsize - 1] = 0;
		}
	}
	else
	{
		if (strlen(s) >= bufsize - 1)
			printf("WARNING: input line truncated to %d chars\n",
				   bufsize - 1);
		strncpy(buf, s, bufsize);
		buf[bufsize - 1] = 0;
	}

	free(s);

	/*
	 * If line ends in a backslash, perform a continuation prompt.
	 */

	s = buf + strlen(buf) - 1;
	if (*s == '\\' && readline("? ", s, bufsize - (s - buf), 0) == 0)
		buf = 0;

	done:
	free(full_prompt);
	return buf;
}
#endif

/*
 * Process one command line input.
 * Invoke handler function if available, return CMD_OK, CMD_FAIL, or
 * CMD_EXIT to notify status of last command.
 *
 */
int
cli_process_command(int u, char* cmdline)
{
	int i, arg_cnt, cmd = -1, rv = 0;
	char *args[100];    
	i = 0;
	arg_cnt = 0;
	args[i] = strtok(cmdline, " ");

	/* Create list of arguments */
	while ((args[i++] = strtok(NULL, " ")) != NULL)
		arg_cnt++;

	for (cmd = 0; cmd < NUM_COMMANDS; cmd++)
	{
		if (!strcmp(cmdline, command_table[cmd].name))
			rv = command_table[cmd].command(u, args, arg_cnt);
	}
	if (!strcmp(cmdline,"help") || !strcmp(cmdline,"?"))
	{
		for (cmd = 0; cmd < NUM_COMMANDS; cmd++)
		{
			printf("\t%s - %s\n", 
				   command_table[cmd].name, command_table[cmd].help);
		}
	}
	return rv;
}


/*
 * Main CLI process engine.
 */
int 
cli_process(int u, const char *pfx, int eof_exit)
{
	char cmd[MAX_CMDLINE_LEN];
	char old_cmd[MAX_CMDLINE_LEN] = "";
	int modifier;
	char *tpfx;
	char *t;				/* Tmp buf pointer */
	char *s;				/* cmd buf pointer */
	int s_len;				/* cmd buf length */
	volatile int rv = CLI_OK;
	volatile int unit = u;
	jmp_buf ctrl_c;

#ifdef INCLUDE_EDITLINE
	extern void add_history(char *p);
#endif

	if (!setjmp(ctrl_c))
	{
		cli_push_ctrl_c(&ctrl_c);
	}
	do
	{
		if (printk_cons_is_enabled())
		{
			strcpy(cmd, pfx);
			if (unit >= 0)
			{
				/* sprintf(cmd + strlen(cmd), ".%d", unit); */
				sprintf(cmd + strlen(cmd), "", unit);
			}
			strcat(cmd, "> ");      
		}
		else
		{
			cmd[0] = 0;
		}
		tpfx = cmd;

		s = cmd;
		s_len = sizeof(cmd);

		while (TRUE)
		{

			s_len = sizeof(cmd) - (s - cmd);

			if (NULL == osl_readline(tpfx, s, s_len, NULL))
			{

				if (eof_exit)
				{
					printk("EOF\n");
					cli_pop_ctrl_c();
					return(CLI_OK);
				}
				else
				{
					printk("Type \"EXIT\" to exit shell\n");
					continue;
				}
			}
			t = s;
			s += strlen(s);
			if (s > t && s[-1] == '\\')
			{
				*s++ = ' ';		/* Replace with white space */
				tpfx = "? ";
				continue;
			}
			break;
		}

		/*
		 * Process each occurrence of !!, unless it would overflow the buffer.
		 */
		modifier = FALSE;
		while ((s = (char *) strcaseindex(cmd, "!!")) != 0 &&
			   strlen(cmd) - 2 + strlen(old_cmd) + 1 < MAX_CMDLINE_LEN)
		{
			strrepl(s, 0, 2, old_cmd);
			modifier = TRUE;
		}

		if (modifier)
		{		  /* Echo command if !! replaced */
			printk("%s\n", cmd);	/* Logs if enabled */
		}
		else
		{
			printk_file("%s\n", cmd);	/* Log command */
		}

		/*
		 * Save command in !! buffer, but only if it doesn't consist of
		 * all white space.  Also save in editline history, if active.
		 */
		if (strspn(cmd, " \t") < strlen(cmd))
		{
			strcpy(old_cmd, cmd);
#ifdef INCLUDE_EDITLINE
			add_history(cmd);
#endif /* INCLUDE_EDITLINE */
		}

		/*
		 * If command is preceded by #:, run it with non-default unit #.
		 * If #: occurs by itself, change unit number.
		 */
		u = strtol(cmd, &t, 0);

		if (t > cmd && *t == ':')
		{
			t++;
			if (! *t)
			{
				unit = u;
				printk("Default WIS device set to %d\n", unit);
			}
			else
			{
				rv = cli_process_command(u, t);
			}
		}
		else
		{
			rv = cli_process_command(unit, cmd);
		}

		tpfx = (char *)pfx;		/* backslash may have changed */

	} while (CLI_EXIT != rv);

	cli_pop_ctrl_c();

	return(rv);
}


void osl_shell(void)
{
	int unit = 0;
	uint32 flags;
#ifdef INCLUDE_EDITLINE
	osl_readline_config(cli_complete, cli_list_possibilities);
#endif /* INCLUDE_EDITLINE */

	osl_set_ctrl_c_thread(osl_thread_self());

	/*
	 * At boot time, probe for devices and attach the first one.
	 * In PLISIM, this is not done; the probe and attach commands
	 * must be given explicitly.
	 */

	flags = osl_boot_flags();
	while (1)
	{
		cli_process(unit, "VideoPhone", TRUE);
#ifdef VXWORKS
		printk("Top level (use reset to reboot)\n");
#else
		osl_reboot();
#endif
	}
}



void
cli_init(void)
{

#ifdef DEBUG_STARTUP
	debugk_select(DEBUG_STARTUP);
#endif

	osl_init();

	printk("WIS BIOS- Copyright (C) 2003 WIS Technologies,Inc\n"); 
	printk("Version %s built %s %s\n", VERSION_STRING, __DATE__, __TIME__);

	/* Launch shell thread */
	osl_thread_create("tCLI", 128*1024, 100, (void *) osl_shell, 0);
}


