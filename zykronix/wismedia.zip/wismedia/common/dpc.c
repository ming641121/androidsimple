/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*
*	dpc.c
*
*   DESCRIPTION:
*
*   Deferred procedure call mechanism.  This module implements a task
*   with a run-queue for tasks which need to be run in a separate
*   execution context.  In addition, it provides a run with-timeout or
*   time-stamping for tasks such that when multiple jobs are added at
*   the same time, they callback functions will run in the order in
*   which they were inserted.
*
*
* $Id: dpc.c,v 1.5 2005/01/12 23:09:34 jblair Exp $
*
******************************************************************************/

#include <os.h>
#ifdef VXWORKS
#include <assert.h>
#endif

#define	OSL_DPC_COUNT		256

typedef void	(*dpc_cb_fn_t)(void *, void *, void *, void *, void *);
/* Deferred Procedure call state type */
typedef struct osl_dpc_s {
    struct osl_dpc_s	*sd_next;	/* Forward pointer */
    uint32		sd_t;		/* Absolute time in usec */
    dpc_cb_fn_t sd_f;
    void		*sd_owner;	/* First parameter passed to sd_f */
    void		*sd_p2;		/* Four more parameters passed */
    void		*sd_p3;
    void		*sd_p4;
    void		*sd_p5;
} osl_dpc_t;

static osl_sem_t	osl_dpc_sem	= NULL;	/* Semaphore to sleep on */
static osl_dpc_t	*osl_dpc_free	= NULL;	/* Free callout structs */
static osl_dpc_t	*osl_dpc_alloc	= NULL;	/* Original allocation */
static osl_dpc_t	*osl_dpc_q	= NULL;	/* Pending callouts */
static volatile osl_thread_t	osl_dpc_threadid = OSL_THREAD_ERROR;

/*
 * Function:
 * 	_osl_dpc_time_q
 *
 * Purpose:
 *	Determine the semaphore timeout time based on the top of
 *	the work queue.
 *
 * Parameters:
 *	None
 *
 * Returns:
 *	Number of micro-seconds until next scheduled event,
 *	or osl_sem_FOREVER if there are no more events.
 */
static	int
_osl_dpc_time_q(void)
{
    int		usec_to_event;

    if (!osl_dpc_q) {
        return (osl_sem_FOREVER);
    }

    usec_to_event = (int) OSL_USECS_SUB(osl_dpc_q->sd_t, osl_time_usecs());

    return (usec_to_event < 0 ? 0 : usec_to_event);
}
/*
 * Function:
 * 	osl_dpc_thread
 *
 * Purpose:
 *	Background deferred procedure call thread used as context for DPCs.
 *
 * Parameters:
 *	a (Ignored)
 *
 * Returns:
 *	Does not return
 */
STATIC void
osl_dpc_thread(void *arg)
{
    osl_dpc_t	*d;

    COMPILER_REFERENCE(arg);

    while (1) {
	    int		il, t;
	    uint32	cur_time;

	    if ((t = _osl_dpc_time_q())) {
	        (void)osl_sem_take(osl_dpc_sem, t);
	    }

	cur_time = osl_time_usecs();

#ifdef VXWORKS
	il = osl_splhi();
#else
	osl_splhi(il);
#endif

	/* Process all DPCs not timed */

	while (((d = osl_dpc_q) != NULL) &&
	       OSL_USECS_SUB(d->sd_t, cur_time) <= 0) {
	    
        osl_dpc_q = d->sd_next;
	    
        osl_spl(il);
	    
        d->sd_f(d->sd_owner, d->sd_p2, d->sd_p3, d->sd_p4, d->sd_p5);
	    
#ifdef VXWORKS
	il = osl_splhi();
#else
	osl_splhi(il);
#endif
	    
        d->sd_next = osl_dpc_free;	/* Free queue entry */
	    osl_dpc_free = d;
	}

        osl_spl(il);

    }
}

/*
 * Function:
	osl_dpc_term
 *
 * Purpose:
 *	Terminate DPC support.
 *
 * Parameters:
 *	None
 *
 * Returns:
 *	Nothing
 */

STATIC void
_osl_dpc_stop(void *owner, void *p2, void *p3, void *p4, void *p5) {
    COMPILER_REFERENCE(p2);
    COMPILER_REFERENCE(p3);
    COMPILER_REFERENCE(p4);
    COMPILER_REFERENCE(p5);

    osl_dpc_threadid = OSL_THREAD_ERROR;
    osl_thread_exit(0);
}

void
osl_dpc_term(void)
{
    if (osl_dpc_threadid != OSL_THREAD_ERROR) {
	osl_dpc((osl_dpc_fn_t)_osl_dpc_stop, 0, 0, 0, 0, 0);

	while (osl_dpc_threadid != OSL_THREAD_ERROR) {
	    osl_msleep(10);
	    }
    }

    if (osl_dpc_sem != NULL) {
	    osl_sem_destroy(osl_dpc_sem);
	    osl_dpc_sem = NULL;
    }

    if (osl_dpc_alloc != NULL) {
	    osl_free(osl_dpc_alloc);
	    osl_dpc_alloc = NULL;
    }

    osl_dpc_q = NULL;
}

/*
 * Function:
 * 	osl_dpc_init
 *
 * Purpose:
 *	Initialize DPC support.
 *
 * Parameters:
 *	None
 *
 * Returns:
 *	0 on success, non-zero on failure
 *
 * Notes:
 *	This must be called before other DPC routines can be used.
 *	It must not be called from interrupt context.
 */
int
osl_dpc_init(int prio)
{
    int		i;

    if (osl_dpc_threadid != OSL_THREAD_ERROR) {
#ifdef VXWORKS
        logMsg("DPC Init: already running: error\n", 0,0,0,0,0,0);
#else
	printf("DPC Init: alread running: error\n");
#endif
        /* Already running */
	    return 0;
    }

    osl_dpc_sem = osl_sem_create("osl_dpc_sem", TRUE, 0);
    osl_dpc_threadid =
	osl_thread_create("tWISDPC",
			  OSL_THREAD_STKSZ,
			  prio,
			  osl_dpc_thread,
			  0);
    osl_dpc_alloc = osl_alloc(sizeof(osl_dpc_t) * OSL_DPC_COUNT, "osl_dpc");
    osl_dpc_free = osl_dpc_alloc;

    if (osl_dpc_sem == NULL ||
	    osl_dpc_threadid == OSL_THREAD_ERROR ||
	    osl_dpc_free == NULL) {
	    osl_dpc_term();
	    return -1;
    }

    for (i = 0; i < OSL_DPC_COUNT - 1; i++) {
	    osl_dpc_free[i].sd_next = &osl_dpc_free[i + 1];
    }

    osl_dpc_free[OSL_DPC_COUNT - 1].sd_next = NULL;
#ifdef VXWORKS
    logMsg("osl_dpc_init: DPC running\n", 0,0,0,0,0,0);
#else
    printf("DPC Init: DPC task running in kernel\n");
#endif    
    return 0;
}

/*
 * Function:
 * 	osl_dpc_time
 *
 * Purpose:
 *	Deferred procedure mechanism with timeout.
 *
 * Parameters:
 *	usec - number of microseconds < 2^31 to wait before the function
 *		is called.  May be 0 to cause immediate callout.
 *	f  - function to call when timeout expires.
 *	p1-p5 - parameters passed to callout function.
 *
 * Returns:
 *	0 - Queued.
 *	-1 - failed.
 *
 * Notes:
 *	May be called from interrupt context.
 */
int
osl_dpc_time(uint32 usec, osl_dpc_fn_t f,
	         void *owner, void *p2, void *p3, void *p4, void *p5)
{
    int		il;
    osl_dpc_t	*nt, *ct, *lt;		/* new/current/last timer */
    uint32	now;

#ifdef VXWORKS
    assert(osl_dpc_threadid != OSL_THREAD_ERROR);
#endif
    
    now = osl_time_usecs();

#ifdef VXWORKS
    il = osl_splhi();
#else
    osl_splhi(il);
#endif

    if ((nt = osl_dpc_free) != NULL) {
	    
        osl_dpc_free = nt->sd_next;

	    nt->sd_t = OSL_USECS_ADD(now, usec);
	    nt->sd_f  = f;
	    nt->sd_owner = owner;
	    nt->sd_p2 = p2;
	    nt->sd_p3 = p3;
	    nt->sd_p4 = p4;
	    nt->sd_p5 = p5;
	    nt->sd_next = NULL;

	    /*
	     * Find location in time Queue and insert, note that this
	     * search and insert results in multiple entries for the
	     * same time being called in the order in which they were
	     * inserted.
	     */
	    for (lt = NULL, ct = osl_dpc_q; ct; lt = ct, ct = ct->sd_next) {
	        if (OSL_USECS_SUB(nt->sd_t, ct->sd_t) < 0) {
		        break;
	        }
    	}

	/*
	 * lt is NULL if insert first entry, OR, points to entry after which
	 * we should insert.
	 */

	    if (lt) {
	        nt->sd_next = lt->sd_next;
	        lt->sd_next = nt;
	    } else {
	        nt->sd_next = osl_dpc_q;
	        osl_dpc_q	= nt;
	        osl_sem_give(osl_dpc_sem);/* Wake up, old sleep value stale */
        }
    }
    osl_spl(il);

    return (nt != NULL ? 0 : -1);
}

/*
 * Function:
 * 	osl_dpc
 *
 * Purpose:
 *	Deferred procedure mechanism with-out timeout.
 *
 * Parameters:
 *	f - function to call when timeout expires.
 *	p1-p5 - parameters passed to callout function.
 *
 * Returns:
 *	0 - Queued.
 *	-1 - failed.
 *
 * Notes:
 *	May be called from interrupt context.
 */
int
osl_dpc(osl_dpc_fn_t f, void *owner, void *p2, void *p3, void *p4, void *p5)
{   
    return osl_dpc_time((uint32)0, f, owner, p2, p3, p4, p5); 
}

/*
 * Function:
 *	osl_dpc_cancel
 *
 * Purpose:
 *	Cancel all DPCs belonging to a specified owner.
 *
 * Parameters:
 *	owner - first parameter to DPC calls
 *
 * Notes:
 *	Each DPC currently waiting on the queue whose first
 *	argument (owner) matches the specified value is removed
 *	from the queue and never executed.
 */

void
osl_dpc_cancel(void *owner)
{
    osl_dpc_t	**dp, *d;
    int		il;

#ifdef VXWORKS
    il = osl_splhi();
#else
    osl_splhi(il);
#endif

    dp = &osl_dpc_q;

    while ((d = *dp) != NULL) {
	if (d->sd_owner == owner) {
	    (*dp) = d->sd_next;
	    d->sd_next = osl_dpc_free;
	    osl_dpc_free = d;
	} else {
	    dp = &(*dp)->sd_next;
	}
    }

    osl_spl(il);
}

#ifdef VXWORKS
/*
 * Function: 	osl_dpc
 * Purpose:	Queue a deferred procedure call for a "net" task.
 * Parameters:	f - function to call
 *		p[1-5] - args passed to routine.
 * Returns:	0 - success, -1 failed.
 */
int
osl_dpc_net(void (f)(int, int, int, int, int), 
	int p1, int p2, int p3, int p4, int p5)
{
  if (netJobAdd((FUNCPTR)f, p1, p2, p3, p4, p5)) {
	return(-1);
    } else {
	return(0);
    }
}
#endif
