/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
******************************************************************************
*
*   FILE: 
*		queue.c
*
*   DESCRIPTION:
*	This is a variety of queue implementations used by the system.
*
*  AUTHOR:
*	Daniel Meyer
*
*   $Id: queue.c,v 1.7 2004/11/15 20:36:19 jblair Exp $ 
*
******************************************************************************/

#include "wis_types.h"
#include "wis_error.h"
#include "os.h"
#include "struct.h"

#include "queue_api.h"


osl_queue_t g_sOslQueues[OSL_Q_MAX_NUM_QUEUES];

/******************************************************************************
*
*   PROCEDURE:  
*       int OSL_QInit(sint32 s32QType, sint32 s32QElementSize,
*		  	     sint32 s32NumQElements)
*
*   DESCRIPTION:
*	Allocate and initialize the queue based on the parameters specified.
*  
*   ARGUMENTS:
*
*	s32QType - type of queue to create.  Types are defined in queue_api.h.
*	s32QElementSize - the size of each queue element.  The size must be
*			  divisible by sizeof(sint32).
*	s32NumQElements - The number of elements in the queue.
*
*   RETURNS:
* 	0 (no queue) or a queue number (int)
*
*   NOTES:
*
******************************************************************************/

int
OSL_QInit(sint32 s32QType, sint32 s32QElementSize, sint32 s32QNumElements)
{
	
	char     name[40];
	sint32 	i;
	
	/* find the first available queue number and create that queue */
	for (i=0; i < OSL_Q_MAX_NUM_QUEUES; i++)
	{
	  if (g_sOslQueues[i].queueSemaphore == NULL)
	    break;
	}
	
	/* if there are no queues available, return NULL */
	if (i == OSL_Q_MAX_NUM_QUEUES){
	  printf("ERROR: queue: no more queues\n");
	  return 0;
	}
	
	/* if the queue element size is not aligned, return NULL */
	if (s32QElementSize & (sizeof(sint32)-1)){
	  printf("ERROR: queue: unaligned element for queue.\n");
	  return 0;
	}
	
	/* create the semaphore that corresponds with this queue */
	sprintf(name, "Create Queue #%d", i+1);
	
	OSL_CreateCountingSemaphore((char *)name,
				    g_sOslQueues[i].queueSemaphore,
				    QUEUE_INITIAL_COUNT);
	
	/* allocate the queue which is element size * number of elements. */
	g_sOslQueues[i].ps32Buffer = OSL_Calloc(s32QElementSize,
						s32QNumElements);
	
	/* initialize the head and tail pointers */
	g_sOslQueues[i].s32HeadIndex = 0;
	g_sOslQueues[i].s32TailIndex = 0;
	g_sOslQueues[i].s32ElementSize = s32QElementSize;
	g_sOslQueues[i].s32NumQueueElements = s32QNumElements;
	g_sOslQueues[i].s32QueueSize = s32QElementSize * s32QNumElements;
	
	return i + 1;
	
}

/*************************** end of OSL_QInit *****************************/

/******************************************************************************
*
*   PROCEDURE:  
*       status_t *OSL_QDelete(int sQueueId)
*
*   DESCRIPTION:
*		Delete this queue if it exists.
*  
*   ARGUMENTS:
*
*		sQueueId - the queue ID to delete
*
*   RETURNS:
*
*	 	SUCCESS - deleted the queue successfully.
*		OSL_NO_Q_AVAILABLE - this queue does not exist
*
*   NOTES:
*
******************************************************************************/

status_t OSL_QDelete(int sQueueId)
{
	
    /* if this queue does not exist, return a failure */
  if ( (sQueueId > OSL_Q_MAX_NUM_QUEUES)
       || (g_sOslQueues[sQueueId-1].queueSemaphore == NULL) )
  {
      return(OSL_NO_Q_AVAILABLE);
  }
	
  /* delete the semaphore first to ensure that future get and put calls fail */
  OSL_SemCountDelete(g_sOslQueues[sQueueId-1].queueSemaphore);
  g_sOslQueues[sQueueId-1].queueSemaphore = NULL;
  
  /* free the queue memory */
  OSL_Free(g_sOslQueues[sQueueId-1].ps32Buffer);
  g_sOslQueues[sQueueId-1].ps32Buffer = NULL;
  
  return(SUCCESS);
	
}

/*************************** end of OSL_QDelete *****************************/

/******************************************************************************
*
*   PROCEDURE:  
*       status_t *OSL_QPut(int queueId, void *pvQueueElement,
* 			   sint32 s32QueueElementSize, sint32 s32Timeout)
*
*   DESCRIPTION:
*		Place an element in the queue.
*  
*   ARGUMENTS:
*
*      sQueueId - the queue id in which to place the element
*      ps32QueueElement - pointer to the queue element to place in the queue
*      s32QueueElementSize - size of the queue element (currently ignored)
*      s32Timeout - usecs to wait for the queue to have room for the element or
*		 OSL_WAIT_FOREVER.
*
*   RETURNS:
*
*		SUCCESS - the element was placed in the queue
* 		OSL_NO_Q_AVAILABLE - this queue id doesn't exist
*		OSL_QUEUE_IS_FULL - the queue is full
*
*   NOTES:
*
*         To avoid a global lock, and guarantee critical structures
*         are updated atomically, certain portions of this code will
*         execute with highest priority.
*
******************************************************************************/

status_t OSL_QPut(int queueId, void *pvQueueElement,
		  sint32 s32QueueElementSize, sint32 s32Timeout)
{
	int irqLevel;
	
	/* make sure that the requested queue number has been created */
	if (g_sOslQueues[queueId-1].queueSemaphore == NULL)
	{
		return(OSL_NO_Q_AVAILABLE);
	}
	
	/* FIXUP: XXX - this really needs to have a blocking mechanism
	 * for the queue becoming available */

	if (QUEUE_FULL(g_sOslQueues[queueId-1]) == TRUE)
	{
		return(OSL_QUEUE_IS_FULL);
	}

	/*
	 * Lock out interrupts - we don't want to get pre-empted by
	 *  the kernel
	 */
#ifdef VXWORKS
	irqLevel = osl_splhi();
#else
        osl_splhi (irqLevel);
#endif

	/* Place the element in the queue */
	memcpy(&g_sOslQueues[queueId-1].ps32Buffer[g_sOslQueues[queueId-1].s32HeadIndex/sizeof(sint32)],
		   pvQueueElement, g_sOslQueues[queueId-1].s32ElementSize);
	
	/* increment the head pointer to indicate the next free entry */
	if ( (g_sOslQueues[queueId-1].s32HeadIndex + g_sOslQueues[queueId-1].s32ElementSize)
		 == g_sOslQueues[queueId-1].s32QueueSize)
	{
		g_sOslQueues[queueId-1].s32HeadIndex = 0;
	}
	else
	{
		g_sOslQueues[queueId-1].s32HeadIndex += g_sOslQueues[queueId-1].s32ElementSize;
	}

	/* Resume kernel interrupt reception */
        osl_spl (irqLevel);
	
	/* increment this queue's semaphore by 1 count */
	OSL_SemCountGive(g_sOslQueues[queueId-1].queueSemaphore);
	
	return(SUCCESS);
	
}

/*************************** end of OSL_QPut *****************************/

/*****************************************************************************
*
*   PROCEDURE:  
*		status_t OSL_QGet(int queueId, void *pvQueueElement,
*	  		  sint32 s32QueueElementSize, sint32 s32Timeout)
*
*   DESCRIPTION:
*		Get an element from the queue.
*  
*   ARGUMENTS:
*
*      sQueueId - the queue id in which to place the element
*      pvQueueElement - pointer to the queue element to place in the queue
*      s32QueueElementSize - size of the queue element (currently ignored)
*      s32Timeout - usecs to wait for the queue to have room for the element or
*		 OSL_WAIT_FOREVER.
*
*   RETURNS:
*
*	SUCCESS - the element was placed in the queue
*	OSL_QUEUE_GET_TIMEOUT - if a timeout value is specified and we were
*				unable to get the value
* 	OSL_NO_Q_AVAILABLE - this queue id doesn't exist
*
*   NOTES:
*
*         To avoid a global lock, and guarantee critical structures
*         are updated atomically, certain portions of this code will
*         execute with highest priority.
*
*
******************************************************************************/

status_t OSL_QGet(int queueId, void *pvQueueElement,
		  sint32 s32QueueElementSize, sint32 s32Timeout)
{
	
	status_t retStatus;
	int irqLevel;
	
	/* make sure that the requested queue number has been created */
	if (g_sOslQueues[queueId-1].queueSemaphore == NULL)
	{
		return(OSL_NO_Q_AVAILABLE);
	}
	
	/* wait for the queue to have something in it */
	retStatus = OSL_SemCountTake(g_sOslQueues[queueId-1].queueSemaphore,
				     s32Timeout);
	
	if (retStatus != OSL_SUCCESS)
	{
		return(OSL_QUEUE_GET_TIMEOUT);
	}

	/* Lock out interrupts - we don't want to get pre-empted by
	   the kernel */
#ifdef VXWORKS
	irqLevel = osl_splhi();
#else
        osl_splhi (irqLevel);
#endif
	
	/* Get the element from the queue */
	memcpy(pvQueueElement, &g_sOslQueues[queueId-1].ps32Buffer[g_sOslQueues[queueId-1].s32TailIndex/sizeof(sint32)],
	       g_sOslQueues[queueId-1].s32ElementSize);
		
	/* increment the tail pointer to indicate the next entry to get */
	if ( (g_sOslQueues[queueId-1].s32TailIndex + g_sOslQueues[queueId-1].s32ElementSize)
		 == g_sOslQueues[queueId-1].s32QueueSize)
	{
		g_sOslQueues[queueId-1].s32TailIndex = 0;
	}
	else
	{
		g_sOslQueues[queueId-1].s32TailIndex += g_sOslQueues[queueId-1].s32ElementSize;
	}

	/* Kernel resume interrupt reception */
	osl_spl(irqLevel);
	
	return SUCCESS;
}



