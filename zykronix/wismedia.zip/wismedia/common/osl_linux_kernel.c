/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       osl_linux_kernel.c
*
*   DESCRIPTION:
*       Kernel OS-Layer Service Primitives (OSL)
*
*
*   $Id: osl_linux_kernel.c,v 1.10 2005/01/12 23:47:10 jfd Exp $
*
******************************************************************************/

#include <linux/kernel.h> 
#include <linux/fs.h>     
#include <linux/errno.h>  
#include <linux/types.h>  
#include <linux/proc_fs.h>
#include <linux/fcntl.h>  
#include <linux/pci.h>
#include <asm/system.h>   
#include <asm/io.h>			
#include <asm/irq.h>
#include <linux/list.h>
#include <linux/interrupt.h>
#include <linux/sched.h>
#include <linux/tqueue.h>
#include <linux/wait.h>
#include <linux/delay.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/slab.h>
#include <linux/mm.h>
#include <linux/time.h>
#include <linux/sched.h>
#include <linux/version.h>
#include <linux/videodev.h>
#include <asm/semaphore.h>
#include <asm/uaccess.h> /* put_user */
#include <asm/io.h>
#include <asm/unistd.h>
#include <asm/semaphore.h>
#include <linux/smp_lock.h>


#include "osl_linux.h"
#include "platform.h"

/***************************** Thread Support ************************/


/*
 * Private Internal Kernel Thread state
 */
typedef struct
kthread_struct
{
    /* private data */

        /* Linux task structure of thread */
        struct task_struct *thread;
        /* Task queue need to launch thread */
        struct tq_struct tq;
        /* function to be started as thread */
        void (*function) (struct kthread_struct *kthread);
        /* semaphore needed on start and creation of thread. */
        struct semaphore startstop_sem;

        /* public data */

        /* queue thread is waiting on. Gets initialized by
           init_kthread, can be used by thread itself.
        */
        wait_queue_head_t queue;
        /* flag to tell thread whether to die or not.
           When the thread receives a signal, it must check
           the value of terminate and call exit_kthread and terminate
           if set.
        */
        int terminate;
        /* additional data to pass to kernel thread */
        void *arg;
} kthread_t;


/*
 * Private Internal Thread functions
 */
static void
kthread_launcher(void *data)
{
        kthread_t *kthread = data;
        kernel_thread((int (*)(void *))kthread->function, (void *)kthread, 0);
        
}

/*
 * create a new kernel thread. Called by the creator.
 */
static void
start_kthread(void (*func)(kthread_t *), kthread_t *kthread)
{
        /* initialize the semaphore:
           we start with the semaphore locked. The new kernel
           thread will setup its stuff and unlock it. This
           control flow (the one that creates the thread) blocks
           in the down operation below until the thread has reached
           the up() operation.
         */
        init_MUTEX_LOCKED(&kthread->startstop_sem);

        /* store the function to be executed in the data passed to
           the launcher */
        kthread->function=func;
        
        /* create the new thread my running a task through keventd */

        /* initialize the task queue structure */
        kthread->tq.sync = 0;
        INIT_LIST_HEAD(&kthread->tq.list);
        kthread->tq.routine =  kthread_launcher;
        kthread->tq.data = kthread;

        /* and schedule it for execution */
        schedule_task(&kthread->tq);

        /* wait till it has reached the setup_thread routine */
        down(&kthread->startstop_sem);

}

/*
 * stop a kernel thread. Called by the removing instance
 */
static void
stop_kthread(kthread_t *kthread)
{
        if (kthread->thread == NULL)
        {
                printk(KERN_ERR "stop_kthread: "
		       "killing non existing thread!\n");
                return;
        }

        /* this function needs to be protected with the big
	   kernel lock (lock_kernel()). The lock must be
           grabbed before changing the terminate
	   flag and released after the down() call. */
        lock_kernel();
        
        /* initialize the semaphore. We lock it here, the
           leave_thread call of the thread to be terminated
           will unlock it. As soon as we see the semaphore
           unlocked, we know that the thread has exited.
	*/
        init_MUTEX_LOCKED(&kthread->startstop_sem);

        /* We need to do a memory barrier here to be sure that
           the flags are visible on all CPUs. 
        */
        mb();

        /* set flag to request thread termination */
        kthread->terminate = 1;

        /* We need to do a memory barrier here to be sure that
           the flags are visible on all CPUs. 
        */
        mb();
        kill_proc(kthread->thread->pid, SIGKILL, 1);
        /* block till thread terminated */
        down(&kthread->startstop_sem);

        /* release the big kernel lock */
        unlock_kernel();

        /* now we are sure the thread is in zombie state. We
           notify keventd to clean the process up.
        */
        kill_proc(2, SIGCHLD, 1);

}

/* initialize new created thread. Called by the new thread. */
static void
init_kthread(kthread_t *kthread, char *name)
{
        /* lock the kernel. A new kernel thread starts without
           the big kernel lock, regardless of the lock state
           of the creator (the lock level is *not* inheritated)
        */
        lock_kernel();

        /* fill in thread structure */
        kthread->thread = current;

        /* set signal mask to what we want to respond */
        siginitsetinv(&current->blocked,
		      sigmask(SIGKILL)|sigmask(SIGINT)|sigmask(SIGTERM));

        /* initialise wait queue */
        init_waitqueue_head(&kthread->queue);

        /* initialise termination flag */
        kthread->terminate = 0;

        /* set name of this process (max 15 chars + 0 !) */
        sprintf(current->comm, name);
        
        /* let others run */
        unlock_kernel();

        /* tell the creator that we are ready and let him continue */
        up(&kthread->startstop_sem);

}

/* cleanup of thread. Called by the exiting thread. */
static void
exit_kthread(kthread_t *kthread)
{
        /* we are terminating */

	/* lock the kernel, the exit will unlock it */
        lock_kernel();
        kthread->thread = NULL;
        mb();

        /* notify the stop_kthread() routine that we are terminating. */
	up(&kthread->startstop_sem);

	/* the kernel_thread that called clone() does a do_exit here. */

	/* there is no race here between execution of the "killer" and
	   real termination of the thread (race window between up and
	   do_exit), since both the thread and the "killer" function
	   are running with the kernel lock held.  The kernel lock
	   will be freed after the thread exited, so the code is
	   really not executed anymore as soon as the unload functions
	   gets the kernel lock back.  The init process may not have
	   made the cleanup of the process here, but the cleanup can
	   be done safely with the module unloaded.
	*/

}

/* *******************  Public Thread API Interface ******************/
typedef struct thread_ctrl_s {
    struct list_head list;
    kthread_t	kthread;
    char name[16];
    void (*f)(void*);
    void* arg;
} thread_ctrl_t;

LIST_HEAD(thread_list);

static void
__kthread_boot(kthread_t* kthread)
{
    thread_ctrl_t* ctrl = (thread_ctrl_t*)kthread->arg;
    if(!(kthread = &ctrl->kthread)){
	printk("Error: kthread_boot failed in %s:%d\n",
	       __FILE__,__LINE__);
    }
    init_kthread(kthread, ctrl->name);    
    ctrl->f(ctrl->arg);
    exit_kthread(kthread);
}

static thread_ctrl_t* 
_find_thread(struct task_struct* t)
{
    struct list_head* l;
    list_for_each(l, &thread_list) {
	thread_ctrl_t* ctrl = (thread_ctrl_t*)l;
	if(ctrl->kthread.thread == t) {
	    return ctrl;
	}
    }
    return NULL;
}

/*
 * Thread creation
 */
osl_thread_t
osl_thread_create(char *name, int ss, int prio, void (f)(void *), void *arg)
{
    thread_ctrl_t* ctrl; 

    ctrl = kmalloc(sizeof(thread_ctrl_t), GFP_ATOMIC);
    strncpy(ctrl->name, name, sizeof(ctrl->name)-1);
    ctrl->f = f;
    ctrl->arg = arg;
    ctrl->kthread.arg = ctrl;
    list_add(&ctrl->list, &thread_list);
    start_kthread(__kthread_boot, &ctrl->kthread);
    return (osl_thread_t)ctrl->kthread.thread;
}


int
osl_thread_destroy(osl_thread_t thread)
{
    /* could deschedule the thread here, but its unused anyways */
    thread_ctrl_t* ctrl;
    ctrl = _find_thread((struct task_struct*)thread);
    if(ctrl) {
	stop_kthread(&ctrl->kthread);
    } else {
      printk("osl_thread_destroy: thread terminated.\n");
    }
    return 0;
}

osl_thread_t
osl_thread_self(void)
{
    return (osl_thread_t)current;
}

char *
osl_thread_name(osl_thread_t thread, char *thread_name, int thread_name_size)
{	
    thread_ctrl_t* ctrl;
    ctrl = _find_thread((struct task_struct*)thread);
    if(ctrl) {
	strncpy(thread_name, ctrl->name, thread_name_size);
	thread_name[thread_name_size - 1] = 0;
	return thread_name;
    }
    else {
	thread_name[0] = 0;
	return NULL;
    }
}

void
osl_thread_exit(int rc)
{
    thread_ctrl_t* ctrl;
    ctrl = _find_thread(current);
    if(!(ctrl)){
	printk("Error: osl_thread_exit: no thread to terminate: %s:%d\n",
	       __FILE__,__LINE__);
    }
    exit_kthread(&ctrl->kthread);

    /* what to do here? */    
}


void
osl_thread_yield(void)
{
    schedule();
}

/*
 *  Suspend calling thread for a specified number of seconds.
 * Note: other tasks are free to run while the caller is suspended.
 */
void
osl_sleep(int sec)
{
    wait_queue_head_t queue;
    if (in_interrupt()) 
    {
        printk ("error: called osl_sleep from interrupt context\n");  
    }
    else 
    {
        init_waitqueue_head (&queue);
	interruptible_sleep_on_timeout (&queue, sec*HZ);
    }
}

/* Busy-wait for 'usec' microseconds */
void
osl_usleep (unsigned int usec)
{
    udelay ((unsigned long) usec);
    mb ();
}

/*
 *  Suspend calling thread for a specified number of microseconds.
 * 
 *	msec - number of milliseconds to suspend
 * Notes:
 *	The actual delay period depends on the resolution of the
 *	scheduler tick, generally 1/60 or 1/100 sec.
 *	Other tasks are free to run while the caller is suspended.
 *      Unless caller is an ISR ... then do busy-wait.
 */
void
osl_msleep (unsigned int msec)
{
    wait_queue_head_t queue;
    if (in_interrupt()) 
    {
        osl_usleep (1000 * msec);
    }
    else
    {
        /* convert msec to jiffies */
        msec += 1000L / HZ - 1;
        msec /= 1000L / HZ;
        init_waitqueue_head (&queue);
	interruptible_sleep_on_timeout(&queue, msec);
    }
}

/* Internal helper functions for Kernel version of Thread API */
static osl_thread_t _osl_main_thread = NULL;
void
osl_thread_main_set(osl_thread_t thread)
{
    _osl_main_thread = thread;
}
    
osl_thread_t	osl_thread_main_get(void)
{
    return _osl_main_thread;
}

/************************ Memory allocation support **********************/

void*
osl_alloc(unsigned int size, char* desc)
{

    return kmalloc(size, GFP_ATOMIC|GFP_KERNEL);
}

void*
osl_calloc(unsigned int num_elements, unsigned int sz)
{
    void* ptr = kmalloc(num_elements * sz, GFP_ATOMIC|GFP_KERNEL);
    memset(ptr, 0, num_elements * sz);
    return ptr;
}

void
osl_free(void *ptr)
{
    kfree(ptr);
}

/************************ Synchronization Primitive support **************/

/*
 * recursive_mutex_t
 *
 *   This is an abstract type built on the POSIX mutex that allows a
 *   mutex to be taken recursively by the same thread without deadlock.
 */

typedef struct recursive_mutex_s {
    osl_sem_t		sem;
    osl_thread_t	owner;
    int			recurse_count;
    char		*desc;
} recursive_mutex_t;


osl_mutex_t
osl_mutex_create(char *desc)
{
    recursive_mutex_t	*rm;

    if ((rm = osl_alloc(sizeof (recursive_mutex_t), desc)) == NULL) {
	return NULL;
    }

    rm->sem = osl_sem_create(desc, 1, 1);
    rm->owner = 0;
    rm->recurse_count = 0;
    rm->desc = desc;

    return (osl_mutex_t) rm;
}

void
osl_mutex_destroy(osl_mutex_t m)
{
    recursive_mutex_t	*rm = (recursive_mutex_t *) m;
    
    osl_sem_destroy(rm->sem);
    
    osl_free(rm);
}

int
osl_mutex_take(osl_mutex_t m, int usec)
{
    recursive_mutex_t	*rm = (recursive_mutex_t *) m;
    osl_thread_t	myself = osl_thread_self();
    int			err;

    if (rm->owner == myself) {
	rm->recurse_count++;
	return 0;
    }

    err = osl_sem_take(rm->sem, usec);
    
    if (err) {
	return -1;
    }	

    rm->owner = myself;

    return 0;
}

int
osl_mutex_give(osl_mutex_t m)
{
    recursive_mutex_t	*rm = (recursive_mutex_t *) m;
    int			err;

    if (rm->recurse_count > 0) {
	rm->recurse_count--;
	return 0;
    }

    rm->owner = 0;
    
    err = osl_sem_give(rm->sem);
    
    return err ? -1 : 0;
}

osl_sem_t
osl_sem_create(char *desc, int binary, int initial_count)
{
    struct semaphore* s;
    
    if ((s = osl_alloc(sizeof(*s), desc)) != 0) {
	sema_init(s, initial_count);
    }

    return (osl_sem_t) s;
}

void
osl_sem_destroy(osl_sem_t b)
{
    /* osl_free(s); */
}

int
osl_sem_take(osl_sem_t b, int usec)
{
    struct semaphore* s = (struct semaphore*)b;
    int			err;
    
    if (usec == osl_sem_FOREVER && !in_interrupt()) {
	down(s);
	err = 0;
    } else {
	int		time_wait = 1;

	/* Retry algorithm with exponential backoff */

	for (;;) {
	    if (down_trylock(s) == 0) {
		err = 0;
		break;
	    }

	    if (time_wait > usec) {
		time_wait = usec;
	    }

	    osl_usleep(time_wait);

	    usec -= time_wait;

	    if (usec == 0) {
		err = ETIMEDOUT;
		break;
	    }

	    if ((time_wait *= 2) > 100000) {
		time_wait = 100000;
	    }
	}
    }

    return err ? -1 : 0;
}

int
osl_sem_give(osl_sem_t b)
{
    struct semaphore* s = (struct semaphore*) b;
    up(s);
    return 0;
}


/*************************** Interrupt Support ***********************/
typedef void (*handler)(int, void *, struct pt_regs *); /* sched.h */

int
osl_int_connect(unsigned int irqnum,
		irq_handler_t isr_routine,
		const char *name, void *data)
{
  /*
   * NOTE: shared irq flags (SA_FLAGS) in platform.h 
   * Linux uses the flags to determine if the IRQ is shared or not.
   * Some platforms only allowed shared IRQ on the interrupt controller.
   */
  return request_irq(irqnum,
		     (handler)isr_routine,
		     SA_FLAGS,   
		     name,
		     data);

}

void
osl_int_disconnect(int irqNum, void* data)
{
    free_irq(irqNum, data);
    
}


void
osl_int_enable(int irq)
{
    enable_irq(irq);
}

void
osl_int_disable(int irq)
{
    disable_irq(irq);
}

/********************* Time Support ************************/

uint32
osl_time_usecs(void)
{
    struct timeval      ltv;
    do_gettimeofday(&ltv);
    return (ltv.tv_sec * SECOND_USEC + ltv.tv_usec);
}

/* Compute the difference between two successive calls to osl_time_usecs().
 * Accuracy is in microseconds.
 */
uint32
osl_usec_diff_time(uint32 timeStamp)
{
    uint32 timeDiff;
    uint32 timeNow = osl_time_usecs();
    timeDiff = (timeNow - timeStamp);
    return timeDiff;
}

void
osl_init(void)
{
    osl_thread_main_set(osl_thread_self());
    /* Note: done by EncoderSchedulerInit() */
    /* osl_dpc_init(100); */
}

void
osl_shutdown(void)
{
    osl_dpc_term();
}

/*
 * strncasecmp
 *	Compares two strings, ignoring case differences.
 * Results:
 *	Compares up to length chars of s1 and s2, returning -1, 0, or 1
 *	if s1 is lexicographically less than, equal to, or greater
 *	than s2 over those characters.
 *
 */
int
strncasecmp(char *s1, char *s2, int length)
{
    unsigned char u1, u2;

    /*
     * This array is designed for mapping upper and lower case letter
     * together for a case independent comparison.  The mappings are
     * based upon ASCII character sequences.
     */

    static unsigned char charmap[] = {
        0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
        0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
        0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
        0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f,
        0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,
        0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,
        0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
        0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,
        0x40, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
        0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f,
        0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77,
        0x78, 0x79, 0x7a, 0x5b, 0x5c, 0x5d, 0x5e, 0x5f,
        0x60, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
        0x68, 0x69, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f,
        0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77,
        0x78, 0x79, 0x7a, 0x7b, 0x7c, 0x7d, 0x7e, 0x7f,
        0x80, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
        0x88, 0x89, 0x8a, 0x8b, 0x8c, 0x8d, 0x8e, 0x8f,
        0x90, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97,
        0x98, 0x99, 0x9a, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f,
        0xa0, 0xa1, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7,
        0xa8, 0xa9, 0xaa, 0xab, 0xac, 0xad, 0xae, 0xaf,
        0xb0, 0xb1, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6, 0xb7,
        0xb8, 0xb9, 0xba, 0xbb, 0xbc, 0xbd, 0xbe, 0xbf,
        0xc0, 0xe1, 0xe2, 0xe3, 0xe4, 0xc5, 0xe6, 0xe7,
        0xe8, 0xe9, 0xea, 0xeb, 0xec, 0xed, 0xee, 0xef,
        0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7,
        0xf8, 0xf9, 0xfa, 0xdb, 0xdc, 0xdd, 0xde, 0xdf,
        0xe0, 0xe1, 0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7,
        0xe8, 0xe9, 0xea, 0xeb, 0xec, 0xed, 0xee, 0xef,
        0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7,
        0xf8, 0xf9, 0xfa, 0xfb, 0xfc, 0xfd, 0xfe, 0xff,
    };

    for (; length != 0; length--, s1++, s2++) {
        u1 = (unsigned char) *s1;
        u2 = (unsigned char) *s2;
        if (charmap[u1] != charmap[u2]) {
            return charmap[u1] - charmap[u2];
        }
        if (u1 == '\0') {
            return 0;
        }
    }
    return 0;
}

int
atoi(char s[])
{
    int i, n;
    n = 0;
    for (i = ((s[0] == '-') ? 1 : 0); s[i] >= '0' && s[i] <= '9'; ++i) {
        n = 10 * n + (s[i] - '0');
    }
    return n * ((s[0] == '-') ? -1 : 1);
}
