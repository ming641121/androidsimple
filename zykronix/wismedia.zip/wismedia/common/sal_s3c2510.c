/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       sal_s3c2510.c
*
*   DESCRIPTION:
*       This is the System Abstraction Layer for the Samsung s3c2510 (arm940t)
*    based systems.
*
*  AUTHOR:
*   Daniel Meyer
*
*   $Id: sal_s3c2510.c,v 1.4 2004/07/20 17:15:02 jfd Exp $ 
*
******************************************************************************/

#include "wis_types.h"
#include "wis_error.h"
#include "struct.h"
#include "platform.h"

#include "sal_api.h"
#include "os.h"

/******************************************************************************
*
*   PROCEDURE:  
*       void SAL_IoSetBusTimings(uint32 u32BusType, uint32 u32TimingValues)
*
*   DESCRIPTION:
*       Set the bus timings as specified by the bus type and timing values
*  
*   ARGUMENTS:
*
*       u32BusType - which bus to set - see platform.h
*       u32TimingValues - actual timing values to set - see platform.h
*
*   RETURNS:
*
*    SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/
status_t
SAL_IoSetBusTimings(uint32 u32BusType, uint32 u32TimingValues)
{
    
    if (u32TimingValues == ENCODER_BUS_INIT_MODE)
    {
        *((uint32*) MUXBCON) = 0x046DB088;
        *((uint32*) B2CON) = 0x8514E488;
    }
    
    if (u32TimingValues == ENCODER_BUS_RUNTIME_MODE)
    {
        *((uint32*) MUXBCON) = 0x046DB088;
        *((uint32*) B2CON) = 0x85070000;
    }

    return(SAL_SUCCESS);
    
}

/******************************************************************************
*
*   PROCEDURE:  
*       status_t SAL_IoClearInterrupt(uint32 u32IntMask)
*
*   DESCRIPTION:
*       Clear the interrupt to/at the interrupt controller.
*  
*   ARGUMENTS:
*
*       u32IntMask - mask of interrupt bits to clear - see platform.h for masks
*
*   RETURNS:
*
*    SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/

status_t
SAL_IoClearInterrupt(uint32 u32IntMask)
{
    
    volatile uint32 *interruptStatusRegister = (uint32 *)IOPEXTINTPND;
    *interruptStatusRegister = u32IntMask;    
    return(SAL_SUCCESS);
    
}

/*****************************************************************************
*
*   PROCEDURE:  
*       status_t SAL_IoConfigureInterrupt(uint32 u32IntNum, uint32 u32IntType)
*
*   DESCRIPTION:
*       Enable and configure the interrupt for a specific type of operation.
*  
*   ARGUMENTS:
*
*       u32IntNum - interrupt number to enable/configure
*       u32IntType - interrupt type to use (level sensitive, rising edge, etc.)
*
*   RETURNS:
*
*       SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/
status_t
SAL_IoConfigureInterrupt(uint32 u32IntNum, uint32 u32IntType)
{
    
    /* Force interrupt settings */
    /* EXTMASK page 619 sec 16.4.2 - enable external interrupt source */
    /* *((uint32*)0xf01400c) &= ~(1 << u32IntNum); //(0x7FFFFFFE & ~(1<<31)); */
    
    /* EXTMOD page 617 sec 16.4.1 - enable external interrupt #1 */
    /* *((uint32*)0xf014004) = (1 << u32IntNum); */

    /* IOPCON1: Enable external interrupts */
    *((uint32*) IOPCON1) &= ~(1<<(8 + u32IntNum));
    
    switch (u32IntType)
    {
        case INT_TYPE_LEVEL_LOW:
            return (WIS_FAILURE);
            break;
            
        case INT_TYPE_LEVEL_HIGH:
            *((uint32*) IOPEXTINT) |= (8 << (4*u32IntNum)); 
            break;
            
        case INT_TYPE_EDGE_FALLING:
            return (WIS_FAILURE);
            break;
            
        case INT_TYPE_EDGE_RISING:
            /* IOPEXTINT: rising edge */
            *((uint32*) IOPEXTINT) |= (1 << (4*u32IntNum)); 
            break;
            
        default:
            return (SAL_FAILURE);
            
    }

    /* IOPEXTINT: filtering  on*/
    *((uint32*) IOPEXTINT) |= (1<<(2+(4*u32IntNum)));   
    
    /* MUXBCON: Fixup timing */
#if 0
    *((uint32*) MUXBCON) |= (1<<26);
    *((uint32*) MUXBCON) |= (1<<8);
#else
    /* configure the bus and the associated timings - from Huy */
    *((uint32*) MUXBCON) = 0x046DB088; //|= (1<<26);
#endif
    
    return(SAL_SUCCESS);
    
}

/******************************************************************************
*
*   PROCEDURE:  
*       status_t SAL_DmaInit(void)
*
*   DESCRIPTION:
*       Set the bus timings as specified by the bus type and timing values
*  
*   ARGUMENTS:
*
*       u32IntMask - mask of interrupt bits to clear - see platform.h for masks
*
*   RETURNS:
*
*    SAL_SUCCESS or SAL_FAILURE
*
*   NOTES:
*
******************************************************************************/
status_t
SAL_DmaInit(uint32 u32IntMask)
{
    return(SAL_SUCCESS);    
}



