/******************************************************************************
*
*   FILE: 
*		osl_vx.c
*
*   DESCRIPTION:
*	VxWorks 5.5 OS Abstraction layer
*
* $Id: osl_vx.c,v 1.4 2004/03/01 15:42:25 jfd Exp $
* 
******************************************************************************/
#include <vxWorks.h> 
#include <cacheLib.h>
#include <taskLib.h>
#include <bootLib.h>
#include <intLib.h>
#include <netLib.h>
#include <logLib.h>
#include <sysLib.h>
#include <usrLib.h>
#include <vmLib.h>
#include <vxLib.h>
#include <end.h>
#include <endLib.h>
#include <netLib.h>
#include <hostLib.h>
#include <etherMultiLib.h>
#include <rebootLib.h>
#include <tyLib.h>
#include <shellLib.h>
#include <selectLib.h>

#include <types.h>
#include <signal.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <stdlib.h>
#include <ctype.h>
#include <assert.h>
#include <osl_vx.h>
#include <io_vx.h>
#include <ftpio_vx.h>
#include <config.h>			/* For BOOT_LINE_ADRS */

#define DMA_MEMORY_UNCACHEABLE

int	int_locked = 0;
#define	INT_LOCKED()		(int_locked)

CACHE_FUNCS	osl_cacheFuncs;

static osl_thread_t ctrl_c_thread;		/* main task process ID */
static osl_mutex_t console_mutex;

char	cwd_path[256];			/* Current Working Directory */

/*
 * Convert microseconds to VxWorks clock ticks.
 * Supports the FOREVER value.
 * Rounds UP to the nearest tick
 * (0 usec goes to 0 ticks, 1-999999 usec goes to 1 tick).
 * NOTE: at 100 Hz tick rate, works only for 0 <= usec <= 42,949,672.
 */

static int usec_to_tick(uint32 usec)
{
    int		tick;

    if (usec == (uint32)osl_mutex_FOREVER)
	return -1;

    tick = (sysClkRateGet() * usec / 1000000);

    return (tick ? tick : usec ? 1 : 0);
}

/*
 * String routines that vxWorks does not have
 */

char *strdup(const char *p)
{
    char *new;
    if ((new = malloc(strlen(p) + 1)) != NULL)
	(void) strcpy(new, p);
    return new;
}

int strcasecmp(const char* s1, const char* s2)
{
    unsigned char c1, c2;
    for (; *s1 || *s2; s1++, s2++) {
	c1 = islower(*s1) ? toupper(*s1) : *s1;
	c2 = islower(*s2) ? toupper(*s2) : *s2;
	if (c1 < c2)
	    return -1;
	if (c1 > c2)
	    return 1;
    }

    return 0;
}

int
strncasecmp(const char* s1, const char* s2, register size_t n)
{
    unsigned char c1, c2;
    for (; n && (*s1 || *s2); s1++, s2++, n--) {
	c1 = islower(*s1) ? toupper(*s1) : *s1;
	c2 = islower(*s2) ? toupper(*s2) : *s2;
	if (c1 < c2)
	    return -1;
	if (c1 > c2)
	    return 1;
    }

    return 0;
}

/*
 * osl_vprintf
 *
 *   This is the base routine upon which all standard printing is built.
 */
int
osl_vprintf(const char *fmt, va_list varg)
{
    int retv;

    if (INT_CONTEXT() || INT_LOCKED()) {
#ifdef HAVE_DIRECT_SERIAL
	retv = osl_vprintf_direct(fmt, varg);	/* ../prfd.c */
#else /* !HAVE_DIRECT_SERIAL */
	unsigned int a1, a2, a3, a4, a5, a6;

	a1 = va_arg(varg, unsigned int);
	a2 = va_arg(varg, unsigned int);
	a3 = va_arg(varg, unsigned int);
	a4 = va_arg(varg, unsigned int);
	a5 = va_arg(varg, unsigned int);
	a6 = va_arg(varg, unsigned int);

	/* Note: logMsg allows only 6 arguments */
	retv = logMsg((char *) fmt, a1, a2, a3, a4, a5, a6);
#endif /* !HAVE_DIRECT_SERIAL */
    } else {
	osl_mutex_take(console_mutex, osl_mutex_FOREVER);
	retv = vprintf(fmt, varg);
	fflush(stdout);
	osl_mutex_give(console_mutex);
    }

    return retv;
}

int
osl_printf(const char *fmt, ...)
{
    int retv;
    va_list varg;
    va_start(varg, fmt);
    retv = osl_vprintf(fmt, varg);
    va_end(varg);
    return retv;
}

static void
osl_sync_flash(void)
{
}

/* Remove "." and ".." from file names */

static	void
osl_normalize_file(char *f)
{
    char	*s, *p, *pe, *pp;

    s = strchr(f, ':');			/* Look for starting ':' */
    if (s) {
	s++;				/* Passed ':' */
    } else {
	s = f;
    }

    /* Remove "/./"'s */

    while ((p = strstr(s, "/./"))) {
	memmove(p, p+2, strlen(p + 2) + 1);
    }

    /* Remove trailing "/." */

    p = s + strlen(s) - 2;

    while ((p > s) && !strcmp(p, "/.")) {
	*p = '\0';
    }

    while (s[0] == '.' && s[1] == '/') { /* leading "./././" */
	memmove(s, s + 2, strlen(s + 2) + 1);
    }

    /* Remove ".."'s */

    while (1) {
	if (NULL == (p = strstr(s, "/../"))) {
	    p = s + strlen(s);
	    if ((p - s >= 3) && *--p == '.' && *--p == '.' && *--p == '/') {
		pe = p + 3;
	    } else {
		break;
	    }
	} else {
	    pe = p + 4;
	}

	for (pp = p - 1; pp > s && *pp != '/'; pp--)
	    ;
	memmove(pp + 1, pe, strlen(pe) + 1);
    }

    if (!strcmp(f, "../")) {
	strcpy(f, "/");
    }
}

#define	OSL_FTPIO_FILE(_s)	(0 != strchr((_s), '@'))

static	int
osl_expand_file(char *file, char *fname)
{
    char	*c;

    if (*file == '/') {		/* ABS in file system */
	strcpy(fname, file);	/* (allows /null, etc. to work) */
    } else if (NULL != (c = strchr(file, ':'))) {
	strcpy(fname, file);	/* FS and file name */
    } else {			/* Relative in file system */
	strcpy(fname, cwd_path);
	strcat(fname, file);
    }
    return(0);
}

/*
 * Get current working directory.
 */
char*
osl_getcwd(char *buf, size_t size)
{
    return(strncpy(buf, cwd_path, size));
}

/*
 * Set current working directory, it is stupid in that is just sets
 * a prefix for open/close/ and friends.
 */
int
osl_cd(char *dir)
{
    char	*c;
    if (strchr(dir, ':')) {		/* Total path given */
	strcpy(cwd_path, dir);
    } else {
	if (NULL == (c = strchr(cwd_path, ':'))) { /* Need abs path */
	    printk("Absolute path required with ':'\n");
	    return(-1);
	}
	if (*dir == '/') {	/* Absolute path in current file system */
	    c++;
	} else {		/* just add to end */
	    c += strlen(c);
	}
	strcpy(c, dir);
    }
    osl_normalize_file(cwd_path);

    /* Be sure string ends in "/" */

    strcat(cwd_path, "/");		/* Add 1 */
    c = cwd_path + strlen(cwd_path) - 1; /* Move to end */
    while ((c > cwd_path) && (*c == '/')) {
	c--;
    }
    *(c + 2) = '\0';

    return(0);
}

/*
 * Do an "ls" on VxWorks
 */
int
osl_ls(char *f, char *flags)
{
    char fname[256];
    int rv;

    if (osl_expand_file(f, fname)) {
	printk("Failed to expand file name: \"%s\"\n", f);
	rv = -1;
    } else if (OSL_FTPIO_FILE(fname)) {
	rv = ftpio_ls(fname, flags);
    } else if (!strncmp(fname, "flash:", 6)) {
	int long_fmt = (flags != NULL && strchr(flags, 'l') != NULL);
	rv = (ls(fname, long_fmt) != OK) ? -1 : 0;
    } else {
	printk("Invalid file name \"%s\"\n", fname);
	rv = -1;
    }

    if (rv < 0)
	printk("ls: Listing failed.\n");

    return rv;
}

int
osl_spl(int level)
{
    int	il;

    int_locked--;
    il = intUnlock(level);
    if (!INT_CONTEXT()) {
	taskUnlock();
    }
    return il;
}

int
osl_splhi(void)
{
    int il;

    if (!INT_CONTEXT()) {
	(void)taskLock();
    }
    il = intLock();
    int_locked++;
    return (il);
}


int
osl_int_connect(unsigned int irqNum,
		isr_handler_t isr_routine, char* name, void* data)
{
   /*
    * In vxWorks, the interrupt handler in intLib.h specifies that the
    * argument to the isr is a void pointer. This allows code to pass
    * a pointer to a structure to the ISR routine, like in Linux.
    */
    return intConnect((VOIDFUNCPTR *) irqNum, (VOIDFUNCPTR) isr_routine, data);
}

void
osl_int_disconnect(int irqNum, void* data)
{
    /* No matching call in intLib.h */
}


void
osl_int_enable(int irq)
{
    intEnable(irq);
}

void
osl_int_disable(int irq)
{
    intDisable(irq);
}



/*
 * osl_sleep(sec)
 */
void
osl_sleep(int sec)
{
    taskDelay((sec * sysClkRateGet())/1000000);
}

/*
 * osl_msleep(msec)
 */
void
osl_msleep(unsigned int msec)
{
    taskDelay((msec * sysClkRateGet())/1000);
}

/*
 * osl_usleep(usec)
 *
 *  NOTE: Minimum delay is one tick (1/60 or 1/100 second)
 *        unless usec=0, which causes a scheduler yield.
 */
void
osl_usleep(uint32 usec)
{
#if 0
/* IXDP425 */
    IMPORT void ixOsServSleep(int microseconds);
    ixOsServSleep((int)usec);
#else    
    taskDelay(usec_to_tick(usec));
#endif
}

/*
 * Date functions
 */
int
osl_date_set(time_t *val)
{
    return ERROR;
}

int
osl_date_get(time_t *val)
{
    time(val);
    return OK;
}

/*
 * NOTE: osl_double_time() is ideal for benchmarking in application code,
 *		and is efficient and convenient on CPUs with integral FP.
 *		Be sure to use the VX_FP_TASK flag when creating the task.
 *		DO NOT CALL from ISRs (floating point not allowed).
 */
double
osl_double_time(void)
{
    /* Otherwise, use the timebase to provide precision of clock tick. */

    struct timespec	tv;
    clock_gettime(CLOCK_REALTIME, &tv);
    return (tv.tv_sec + tv.tv_nsec * 0.000000001);

}

/*
 * NOTE: osl_time() must be safe to call from an interrupt routine
 * 		so it can be used for timestamping purposes.
 *		It appears that clock_gettime is interrupt-safe.
 */
time_t
osl_time(void)
{
    struct timespec	tv;
    clock_gettime(CLOCK_REALTIME, &tv);
    return tv.tv_sec;
}



/* Purpose:
 *      Returns the relative time in microseconds modulo 2^32.
 * Returns:
 *      Time in microseconds modulo 2^32
 * Notes:
 *      The precision is limited to the VxWorks clock period
 *      (typically 10000 usec.)
 *
 */
uint32
osl_time_usecs(void)
{
    struct timespec     ltv;

    clock_gettime(CLOCK_REALTIME, &ltv);

    return (ltv.tv_sec * 1000000 + ltv.tv_nsec / 1000);
}

/* Compute the difference between two successive calls to osl_time_usecs().
 * Accuracy is in microseconds.
 */
uint32
osl_usec_diff_time(uint32 timeStamp)
{
    uint32 timeDiff;
    uint32 timeNow = osl_time_usecs();
    timeDiff = (timeNow - timeStamp);
    return timeDiff;
}

/*
 * Control-C handling
 */
void
abortFuncJob(WIND_TCB *taskId)
{
    /* This runs in the context of some task manager thread and sends a
     * signal back to the shell. */
    taskId->excInfo.valid = 0;

    if (ctrl_c_thread != NULL)
	kill((int) ctrl_c_thread, SIGINT);
}

int
abortFuncHandler(void)
{
    /* This runs at INTERRUPT level where we can't do much at all except
     * call the undocumented excJobAdd to schedule a function to be called
     * by some task manager thread. */
    excJobAdd(abortFuncJob, (int) taskIdCurrent, 0, 0, 0, 0, 0);
    return 0;
}

int abortFuncDefault(void)
{
    /* There is no official way to get the default abort function from
     * vxWorks, so we'll try this: */

    ioctl(0, FIORFLUSH, 0);
    excJobAdd(shellRestart, TRUE, 0, 0, 0, 0, 0);
    return 0;
}

void
osl_readline_init(void)
{
#ifdef INCLUDE_EDITLINE
    extern void rl_real_ttyset(int);
    /* Put console in raw mode for editline package */
    rl_real_ttyset(0);
#endif /* INCLUDE_EDITLINE */
}

void
osl_readline_term(void)
{
#ifdef INCLUDE_EDITLINE
    extern void rl_real_ttyset(int);
    rl_real_ttyset(1);
#endif /* INCLUDE_EDITLINE */
}


int
osl_init(void)
/*
 * Function: 	osl_init
 * Purpose:	Initialize the SAL abstraction layer for Tornado.
 * Parameters:	None
 * Returns:	0 - success, -1 - failed.
 */
{
    BOOT_PARAMS p;
    char	*s;
    char	buf[256];

    static	int	inited = FALSE;

    if (inited) {
	return(0);
    }
    inited = TRUE;

#ifdef DMA_MEMORY_UNCACHEABLE
    osl_cacheFuncs = cacheNullFuncs;
#else
    osl_cacheFuncs = cacheDmaFuncs;
#endif


    /* ^X is too dangerous; change monitor trap character to ^\ */
    tyMonitorTrapSet('\\' & 037);

    console_mutex = osl_mutex_create("console mutex");
    tyAbortFuncSet(abortFuncHandler);

    /* Init readline lib */
    osl_readline_init();

    /*
     * Initialize flash device if present, ignore errors since it may
     * have been initialized if we booted from it, and/or may not be present.
     */
    (void)osl_flash_init(FALSE);

    /*
     * Try to figure out our current working directory based on the
     * VxWorks boot line.
     */

    bootStringToStruct(BOOT_LINE_ADRS, &p);

    /*
     * If boot string begins with "/flash/", then CWD is on the flash
     * disk, otherwise, we assume it is ftpio.
     */

    if (!strncmp(p.bootFile, "/flash/", 7)) {
	strcpy(buf, "flash:");
	strcat(buf, p.bootFile + 6);
    } else if (!strncmp(p.bootFile, "flash:", 6)) {
	strcpy(buf, p.bootFile);
    } else {
	sprintf(buf, "%s%s%s@%s:%s",
		p.usr,
		p.passwd[0] ? "%" : "",
		p.passwd,
		p.hostName,
		p.bootFile);
    }

    ftpio_defaults(p.usr, p.passwd, p.hostName);

    /* Nuke file name - leaving just directory */

    for (s = buf + strlen(buf);
	 s > buf && s[-1] != '/' && s[-1] != ':';
	 s--)
	;

    *s = 0;
    (void)osl_cd(buf);

    return(0);
}

void
osl_set_ctrl_c_thread(osl_thread_t thread)
{
    ctrl_c_thread = thread;
}


void *
osl_alloc(unsigned int sz, char *s)
{
    return(malloc(sz));
}

void *
osl_calloc(unsigned int num_elements, unsigned int sz)
{
    return(calloc(num_elements, sz));
}

void 
osl_free(void *p)
{
    free(p);
}

void *
osl_dma_alloc(size_t sz, char *s)
/*
 * Function: 	osl_dma_alloc
 * Purpose:	Allocate memory that can be dma'd into/out-of.
 * Parameters:	sx - number of bytes to allocate
 *		s - string associated with allocate
 * Returns:	Pointer to allocated memory or NULL.
 */
{
#if defined(DEBUG) 
    uint32	*p;
#endif
    
    /*
     * Length must be a multiple of 4 because DMA transfers to memory
     * write 32 bits at a time.  There is no read-modify-write for the
     * end of the data if the end is not aligned on a 32-bit boundary.
     */

    assert((sz & 3) == 0);

#ifdef DEBUG

    /*
     * Place sentinels at the beginning and end of the data area to
     * detect memory corruption.  These are verified on free.
     */

#ifdef DMA_MEMORY_UNCACHEABLE
    p = cacheDmaMalloc(sz + 12);
#else
    p = malloc(sz + 12);
#endif

    if (p == 0)
	return 0;

    p[0] = sz / 4;
    p[1] = 0xaaaaaaaa;
    p[2 + sz / 4] = 0xbbbbbbbb;

   return (void *) &p[2];

#else /* !DEBUG */

#ifdef DMA_MEMORY_UNCACHEABLE
    return cacheDmaMalloc(sz);
#else
    return malloc(sz);
#endif

#endif /* !DEBUG */
}

#ifdef DEBUG
#define NOT_CORRUPT(p) \
	(p && p[-1] == 0xaaaaaaaa && p[p[-2]] == 0xbbbbbbbb)
#endif

void
osl_dma_free(void *addr)
/*
 * Function: 	osl_dma_free
 * Purpose:	Free memory allocated by osl_dma_alloc
 * Parameters:	addr - pointer to memory to free.
 * Returns:	Nothing.
 */
{

#ifdef DEBUG

    uint32	*p	= (uint32 *) addr;

    /*
     * Verify sentinels on free.  If this assertion fails, it means that
     * memory corruption was detected.
     */

    assert(NOT_CORRUPT(p));	/* Use macro to beautify assert message */

    p[-1] = 0;			/* Detect redundant frees */

#ifdef DMA_MEMORY_UNCACHEABLE

    cacheDmaFree(&p[-2]);

#else
    free(&p[-2]);
#endif

#else /* !DEBUG */

#ifdef DMA_MEMORY_UNCACHEABLE

    cacheDmaFree(addr);
#else
    free(addr);
#endif

#endif /* !DEBUG */
}

/*ARGSUSED*/
osl_thread_t
osl_thread_create(char *name, int ss, int prio, void (f)(void *), void *arg)
/*
 * Function:   	osl_thread_create
 * Purpose:	Implement task create for unit environment.
 * Parameters:	name - name of task
 *		ss - stack size requested
 *		prio - scheduling prio (not used on UNIX).
 *		func - address of function to call
 *		arg - argument passed to "func".
 * Returns:	thread id
 */
{
    int		rv;
    sigset_t	new_mask, orig_mask;

    /* Make sure no child thread catches Control-C */

    sigemptyset(&new_mask);
    sigaddset(&new_mask, SIGINT);
    sigprocmask(SIG_BLOCK, &new_mask, &orig_mask);
    rv = taskSpawn(name, prio,
#if 0
		   VX_UNBREAKABLE | VX_FP_TASK,
#else
		   VX_SUPERVISOR_MODE |VX_FP_TASK,
#endif		   
		   ss, (FUNCPTR)f,
		   (int)arg, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    sigprocmask(SIG_SETMASK, &orig_mask, NULL);
    if (rv == ERROR)
	return(OSL_THREAD_ERROR);
    else
	return((osl_thread_t)rv);
}

int
osl_thread_destroy(osl_thread_t thread)
{
    if (taskDelete((int) thread) == ERROR)
	return -1;

    return 0;
}

osl_thread_t
osl_thread_self(void)
{
    return (osl_thread_t) taskIdSelf();
}

/*
 * Function:	osl_thread_exit
 * Purpose:	Exit the current thread
 * Parameters:	rc - return code from thread.
 * Returns:	Never returns.
 */
void
osl_thread_exit(int rc)
{
    exit(rc);
}


/*
 * Mutex and Binary Semaphore routines
 */

static int ctrl_c_depth = 0;

/*
 * Block Ctrl-C Handling on VxWorks.
 * Be careful by keeping track of depth and interrupt context.
 */
static void
ctrl_c_block(void)
{
    assert(!INT_CONTEXT());
    if (osl_thread_self() == ctrl_c_thread) {
	if (ctrl_c_depth++ == 0) {
	    sigset_t set;
	    sigemptyset(&set);
	    sigaddset(&set, SIGINT);
	    sigprocmask(SIG_BLOCK, &set, NULL);
	}
    }
}
/*
 * Unblock Ctrl-C
 */
static void
ctrl_c_unblock(void)
{
    assert(!INT_CONTEXT());
    if (osl_thread_self() == ctrl_c_thread) {
	assert(ctrl_c_depth > 0);
	if (--ctrl_c_depth == 0) {
	    sigset_t set;
	    sigemptyset(&set);
	    sigaddset(&set, SIGINT);
	    sigprocmask(SIG_UNBLOCK, &set, NULL);
	}
    }
}

/*
 * Mutex and Semaphores
 */
osl_mutex_t
osl_mutex_create(char *desc)
{
    SEM_ID sem;
    assert(!INT_CONTEXT());
    if ((sem = semMCreate(SEM_Q_PRIORITY |
			  SEM_DELETE_SAFE |
			  SEM_INVERSION_SAFE)) == 0)
	osl_printf("ERROR: could not allocate mutex %s\n", desc);
    return sem;
}

void
osl_mutex_destroy(osl_mutex_t m)
{
    assert(!INT_CONTEXT());
    assert(m);
    semDelete(m);
}

int
osl_mutex_take(osl_mutex_t m, int usec)
{
    assert(!INT_CONTEXT());
    ctrl_c_block();
    if (semTake(m, usec_to_tick(usec)) != OK) {
      ctrl_c_unblock();
      return -1;
    }
    return 0;
}

int
osl_mutex_give(osl_mutex_t m)
{
    assert(!INT_CONTEXT());
    if (semGive(m) != OK)
	return -1;
    ctrl_c_unblock();
    return 0;
}

osl_sem_t
osl_sem_create(char *desc, int binary, int initial_count)
{
    SEM_ID b;
    assert(!INT_CONTEXT());
    if (binary)
	b = semBCreate(SEM_Q_FIFO, initial_count);
    else
	b = semCCreate(SEM_Q_FIFO, initial_count);
    if (b == 0)
	osl_printf("ERROR: could not allocate sem %s\n", desc);
    return b;
}

void
osl_sem_destroy(osl_sem_t b)
{
    assert(b);
    semDelete(b);
}

int
osl_sem_take(osl_sem_t b, int usec)
{
    assert(!INT_CONTEXT());
    return semTake(b, usec_to_tick(usec)) != OK ? -1 : 0;
}

int
osl_sem_give(osl_sem_t b)
{
    return (semGive(b) != OK) ? -1 : 0;
}

int
osl_sem_reset(osl_sem_t b)
{
    /* Get rid of all pending Gives */
    while (semTake(b, NO_WAIT) == OK)
	;
    return 0;
}

/*
 * Function: 	osl_fopen
 * Purpose:	"fopen" a file.
 * Parameters:	name - name of file to open, look specifically for
 * 			"flash:" for ftpio format.
 *		mode - file mode.
 * Returns:	NULL or FILE * pointer.
 */
FILE *
osl_fopen(char *file, char *mode)
{
    char fname[256];

    if (osl_expand_file(file, fname)) {
	printk("Error: Cannot expand file name: %s\n", file);
	return(NULL);
    } else if (OSL_FTPIO_FILE(fname)) {
	return(ftpio_open(fname, mode));
    } else if (strcmp(file, "flash:") == 0) {
	return NULL;	/* Disaster if no filename --uses raw partition! */
    } else {
	return(fopen(fname, mode));
    }
}

/*
 * Function: 	osl_fclose
 * Purpose:	Close a file opened with osl_fopen
 * Parameters:	fp - FILE pointer.
 * Returns:	non-zero on error
 */
int
osl_fclose(FILE *fp)
{
    int		rv;

    if (ftpio_valid_fp(fp)) {
	rv = ftpio_close(fp);
    } else {
	rv = fclose(fp);
	osl_sync_flash();
    }

    return rv;
}

/*
 * Function: 	osl_remove
 * Purpose:	Remove a file from a file system.
 * Parameters:	file - name of file to remove.
 * Returns:	0 - OK
 *		-1 - failed.
 */
int
osl_remove(char *file)
{
    char	fname[256];
    int		rv;

    if (osl_expand_file(file, fname)) {
	printk("Error: Cannot expand file name\n");
	return(-1);
    } else if (OSL_FTPIO_FILE(fname)) {
	return(ftpio_remove(fname));
    } else {
	rv = remove(fname);
	osl_sync_flash();
	return rv;
    }
}

/*
 * Function: 	osl_rename
 * Purpose:	Rename a file on a file system.
 * Parameters:	file_old - name of existing file to rename.
 *		file_new - new name of file.
 * Returns:	0 - OK
 *		-1 - failed.
 */
int
osl_rename(char *file_old, char *file_new)
{
    char	fname_old[256];
    int		rv;

    if (osl_expand_file(file_old, fname_old)) {
	printk("Error: Cannot expand file name\n");
	return(-1);
    } else if (OSL_FTPIO_FILE(fname_old)) {
	if (OSL_FTPIO_FILE(file_new)) {
	    printk("Error: Destination must be plain pathname\n");
	    return -1;	/* File name only (no path) allowed for ftpio */
	}
	return(ftpio_rename(fname_old, file_new));
    } else {
	rv = rename(file_old, file_new);
	osl_sync_flash();
	return rv;
    }
}

/*
 * Function: osl_reboot.
 * Purpose: Reset system.
 */
void
osl_reboot(void)
{
    printk("Resetting...");
    osl_usleep(1000000);/* Time for message to flush on serial */
    reboot(BOOT_NORMAL);
}


/*
 * A VXWorks shell task is forked.  Wait until shell exits before returning.
 * Otherwise, socdiag and the shell fight over TTY input.
 */
void
osl_native_shell(void)
{
  tyAbortFuncSet(abortFuncDefault);

  osl_readline_term();				/* Leave raw mode */
  shellInit(10000 /* Stack size */, TRUE);	/* create the shell */

  do
    osl_usleep(100000);
  while (taskNameToId("tShell") != ERROR);

  osl_readline_init();				/* Back into raw mode */

  tyAbortFuncSet(abortFuncHandler);

}




/*
 * Initialize and format flash file system, mount it on "flash:", if format
 * is set,
 */
int
osl_flash_init(int format)
{
    int	rv = -1;
    return(rv);
}


int
osl_flash_boot(char *file)
{
    return(-1);
}


/*
 * Check RAM at specified address.
 */
int
osl_memory_check(uint32 addr)
{
    STATUS probeStatus = OK;


    /* Sanity check that we can do DMA ... */

    if (! CACHE_DMA_IS_WRITE_COHERENT()) {
	printk("osl_memory_check: device requires cache coherent memory\n");
	return -1;
    }

    /*
     * Test physical memory for sanity's sake. Just see if we can read
     * below the end of DRAM.
     */

    if (vxMemProbe((char *)sysMemTop()-24,
		  VX_READ, 4, (char*)&probeStatus) != OK) {
	printk("osl_memory_check: can't read last word in memory!\n");
	return -1;
    }

    debugk(DK_PCI, "System Memory Top: 0x%x\n", (uint32) sysMemTop());

    /*
     * Now, test that you can read/write the memory and that it does not
     * generate a bus error.
     */
    if ((vxMemProbe((char *)addr,
		    VX_READ,4,(char*)&probeStatus)!=OK) ||
	(vxMemProbe((char *)addr,
		    VX_WRITE,4,(char*)&probeStatus)!=OK)) {
	printk("osl_memory_check: vxMemProbe r/w error (addr=0x%x)\n",
	       addr);
	return -1;
    }

    return 0;
}

/* ARGSUSED */
uint32
osl_led(uint32 v)
{
    static uint32 led = 0;
    int		p_led = led;
    int		lv = intLock();

    led = v;

    intUnlock(lv);
    return(p_led);
}

/*
 * Watchdog function
 *
 *  If usec is 0, the watchdog timer is disarmed.
 *
 *  If usec is non-zero, the watchdog timer is armed (or re-armed) for
 *    approximately usec microseconds (if the exact requested usec is
 *    not supported, the next higher available value is used).
 *
 *  If the timer is armed and expires, the system is reset.
 */

/* ARGSUSED */
int
osl_watchdog_arm(uint32 usec)
{
    return -1;
}

/*
 * Function:
 *	osl_boot_flags
 * Purpose:
 *	Return boot flags from startup
 * Parameters:
 *	None
 * Returns:
 *	32-bit flags value, 0 if not supported or no flags set.
 */
uint32
osl_boot_flags(void)
{
    extern	BOOT_PARAMS	sysBootParams;

    return((uint32)sysBootParams.flags);
}


/*
 * Read input line, providing Emacs-based command history editing.
 */
char *
osl_readline(char *prompt, char *buf, int bufsize, char *defl)
{
    char *s, *full_prompt;
#ifdef INCLUDE_EDITLINE
    extern char *readline(const char *prompt);
#else
    char *t;
#endif

    if (bufsize == 0)
        return buf;

    full_prompt = malloc(strlen(prompt) + (defl ? strlen(defl) : 0) + 8);
    strcpy(full_prompt, prompt);
    if (defl)
	sprintf(full_prompt + strlen(full_prompt), "[%s] ", defl);

#ifdef INCLUDE_EDITLINE

    printk_file(full_prompt);
    s = readline(full_prompt);

#else /* !INCLUDE_EDITLINE */

    t = malloc(bufsize);
    printk("%s", full_prompt);
    if ((s = fgets(t, bufsize, stdin)) == 0) {
	free(t);
	clearerr(stdin);
    } else {
	s[bufsize - 1] = 0;
	if ((t = strchr(s, '\n')) != 0)
	    *t = 0;
	/* Replace garbage characters with spaces */
	for (t = s; *t; t++)
	    if (*t < 32 && *t != 7 && *t != 9)
		*t = ' ';
    }

#endif /* !INCLUDE_EDITLINE */

    if (s == 0) {                       /* Handle Control-D */
        buf[0] = 0;
        printk("EOF\n");
	buf = 0;
	goto done;
    }

    if (s[0] == 0) {
	if (! defl)
	    buf[0] = 0;
	else if (buf != defl) {
	    strncpy(buf, defl, bufsize);
	    buf[bufsize - 1] = 0;
	}
    } else {
	if (strlen(s) >= bufsize - 1)
	    printk("WARNING: input line truncated to %d chars\n",
		   bufsize - 1);
	strncpy(buf, s, bufsize);
	buf[bufsize - 1] = 0;
    }

    free(s);

    /*
     * If line ends in a backslash, perform a continuation prompt.
     */

    s = buf + strlen(buf) - 1;
    if (*s == '\\' && osl_readline("? ", s, bufsize - (s - buf), 0) == 0)
	buf = 0;

 done:
    free(full_prompt);
    return buf;
}

/*
 * Read a single char, include Emacs-style command line editing.
 */
int
osl_readchar(const char *prompt)
{
#ifdef INCLUDE_EDITLINE
    extern int readchar(const char *prompt);
#else
    char	buf[64];
#endif

#ifdef INCLUDE_EDITLINE
    return(readchar(prompt));
#else
    printk("%s", prompt);
    if (NULL == (fgets(buf, sizeof(buf), stdin))) {
	return(0);
    } else {
	return(buf[0]);
    }
#endif
}

#ifdef INCLUDE_EDITLINE
/*
 * Configure readline by passing it completion routine (for TAB
 * completion handling) and a list-possible routine (for ESC-? handling).
 */
void
osl_readline_config(char *(*complete)(char *pathname, int *unique),
		    int (*list_possib)(char *pathname, char ***avp))
{
    extern char		*(*rl_complete)(char *, int *);
    extern int		(*rl_list_possib)(char *, char ***);

    rl_complete = complete;
    rl_list_possib = list_possib;
}
#endif /* INCLUDE_EDITLINE */

/*
 * printk
 *
 *  Synchronized printing facility which allows multiplexing output
 *  to console and/or file.
 */

static FILE *file_fp = 0;		/* Non-NULL indicates file opened */
static char *file_nm = NULL;		/* Non-NULL indicates file selected */
static uint32 current_dk = DK_ERR;	/* Start with errors enabled */

static int console_enabled = 1;

int
printk_cons_enable(int enable)
{
    int old = console_enabled;
    console_enabled = enable;
    return old;
}

int
printk_cons_is_enabled(void)
{
    return console_enabled;
}

int
printk_cons(const char *fmt, ...)
{
    int retv;

    if (console_enabled) {
	va_list varg;
	va_start(varg, fmt);  
	retv = osl_vprintf(fmt, varg);
	va_end(varg);
    } else
	retv = 0;

    return retv;
}

char*
printk_file_name(void)
{
    return(file_nm);
}

int
printk_file_open(char *filename, int append)
{
    if (file_nm) {
	printk("Switching log file\n");
	printk_file_close();
    }
    if ((file_fp = osl_fopen(filename, append ? "a" : "w")) == 0) {
	perror("Error opening file");
	return -1;
    }
    file_nm = strcpy((char *)malloc(strlen(filename) + 1), filename);
    printk("File logging started to %s\n", filename);
    return 0;
}

int
printk_file_close(void)
{
    if (! file_nm) {
	printk("File logging is not on\n");
	return -1;
    }
    if (file_fp) {
	osl_fclose(file_fp);
	file_fp = 0;
    }
    free(file_nm);
    file_nm = NULL;
    printk("File logging off\n");
    return 0;
}

int
printk_file_enable(int enable)
{
    int old_enable = (file_fp != NULL);

    if (! old_enable && enable) {
	/* Enable */
	if (! file_nm) {
	    printk("Logging file not opened, can't enable\n");
	    return -1;
	}
	if ((file_fp = osl_fopen(file_nm, "a")) == 0) {
	    perror("Error opening file");
	    return -1;
	}
    }

    if (old_enable && ! enable) {
	if (file_fp) {
	    osl_fclose(file_fp);
	    file_fp = 0;
	}
	/* Note: file_nm remains valid; output can still be re-enabled */
    }

    return old_enable;
}

int
printk_file_is_enabled(void)
{
    return (file_fp != NULL);
}

void
printk_file_dpc(int a1, int a2, int a3, int a4, int a5)
{
    char	*fmt = (char *)a1;
    
    if (file_fp) {
	fprintf(file_fp, fmt, a2, a3, a4, a5);
	fflush(file_fp);
    }
}

int
vprintk_file(const char *fmt, va_list ap)
{
    int	retv;

    if (file_fp) {
	if (osl_int_context()) {
	    unsigned int a1, a2, a3, a4;
	    a1 = va_arg(ap, unsigned int);
	    a2 = va_arg(ap, unsigned int);
	    a3 = va_arg(ap, unsigned int);
	    a4 = va_arg(ap, unsigned int);
	    retv = osl_dpc_net(printk_file_dpc, (int)fmt, a1, a2, a3, a4);
	} else {
	    retv = vfprintf(file_fp, fmt, ap);
	    fflush(file_fp);
	}
    } else
	retv = 0;
    return(retv);
}    

int
printk_file(const char *fmt, ...)
{
    int retv;

    if (file_fp) {
	va_list varg;
	va_start(varg, fmt); 
	retv = vprintk_file(fmt, varg);
	va_end(varg);
    } else
	retv = 0;

    return retv;
}

int
vprintk(const char *fmt, va_list ap)
{
    int retv = 0;

    if (file_fp) {
	va_list ap_copy;
	va_copy(ap_copy, ap);	/* Avoid consuming same arg list twice. */
	retv = vprintk_file(fmt,ap_copy);
    }

    if (console_enabled)
	retv = osl_vprintf(fmt,ap);

    return retv;
}

int
printk(const char *fmt, ...)
{
    int retv;
    va_list varg;
    va_start(varg, fmt);  
    retv = vprintk(fmt, varg);
    va_end(varg);
    return retv;
}

/*
 * debugk
 *
 *  Debug printing facility (also synchronized with locks like printk).
 *  Specify one or more debug message classes in the call.  The message is
 *  displayed only if the message class is enabled via debugk_select().
 */
int
debugk_select(uint32 dk)
{
    current_dk = dk;
    return 0;
}

int
debugk_check(uint32 dk)
{
    return (current_dk & dk);
}

int
debugk(uint32 dk, const char *fmt, ...)
{
    int retv;

    if (dk == (dk & current_dk)) {
	va_list varg;
	va_start(varg, fmt);
	retv = vprintk(fmt, varg);
	va_end(varg);
    } else
	retv = 0;

    return retv;
}


/*
 * For supporting print from Interrupt context and various thread
 * priority levels.
 */

#ifdef HAVE_DIRECT_SERIAL

/*
 * Printf
 *
 * Reasonably complete subset of ANSI-style printf routines.
 * Needs only strlen and stdarg.
 * Behavior was regressed against Solaris printf(3s) routines (below).
 *
 * Supported format controls:
 *
 *	%%	percent sign
 *	%c	character
 *	%d	integer
 *	%hd	short integer
 *	%ld	long integer
 *	%u	unsigned integer
 *	%o	unsigned octal integer
 *	%x	unsigned hexadecimal integer (lowercase)
 *	%X	unsigned hexadecimal integer (uppercase)
 *	%s	string
 *	%p	pointer
 *	%n	store number of characters output so far
 *	%f	float
 *	%lf	double
 *
 * Flag modifiers supported:
 *	Field width, argument field width (*), left justify (-),
 *	zero-fill (0), alternate form (#), always include sign (+),
 *	space before positive numbers (space).
 *
 * Not supported: long long
 *
 * Functions implemented:
 *
 * int x_vsnprintf(char *buf, size_t bufsize, const char *fmt, va_list ap);
 * int x_vsprintf(char *buf, const char *fmt, va_list ap);
 * int x_snprintf(char *buf, size_t bufsize, const char *fmt, ...);
 * int x_sprintf(char *buf, const char *fmt, ...);
 */

static
void x_itoa(char *buf,	     	/* Large enough result buffer	*/
	    unsigned long num,	/* Number to convert		*/
	    int base,	     	/* Conversion base (2 to 16)	*/
	    int caps,	     	/* Capitalize letter digits	*/
	    int prec)		/* Precision (minimum digits)	*/
{
    char		tmp[36], *s, *digits;

    digits = (caps ? "0123456789ABCDEF" : "0123456789abcdef");

    s = &tmp[sizeof (tmp) - 1];

    for (*s = 0; num || s == &tmp[sizeof (tmp) - 1]; num /= base, prec--)
	*--s = digits[num % base];

    while (prec-- > 0)
	*--s = '0';

    strcpy(buf, s);
}

static
void x_ftoa(char *buf, double f, int decimals)
{
    int			exp = 0;
    unsigned int	int_part;
    double		round;
    int			i;

    if (f < 0.0) {
	*buf++ = '-';
	f = -f;
    }

    for (round = 0.5, i = 0; i < decimals; i++)
	round /= 10.0;

    f += round;

    if (f >= 4294967296.0)
	while (f >= 10.0) {
	    f /= 10.0;
	    exp++;
	}

    int_part = (unsigned int) f;
    f -= int_part;

    x_itoa(buf, int_part, 10, 0, 0);
    while (*buf)
	buf++;

    *buf++ = '.';

    for (i = 0; i < decimals; i++) {
	f *= 10.0;
	int_part = (unsigned int) f;
	f -= int_part;
	*buf++ = '0' + int_part;
    }

    if (exp) {
	*buf++ = 'e';
	x_itoa(buf, exp, 10, 0, 0);
    } else
	*buf = 0;
}

#define X_STORE(c) { 	\
    if (bp < be)	\
	*bp = (c); 	\
    bp++; 		\
}

#define X_INF		0x7ffffff0
int
x_vsnprintf(char *buf, size_t bufsize, const char *fmt, va_list ap)
{
    char		c, *bp, *be;
    double		f;

    bp = buf;
    be = (bufsize == X_INF) ? ((char *) 0) - 1 : &buf[bufsize - 1];

    while ((c = *fmt++) != 0) {
	int 		width = 0, ljust = 0, plus = 0, space = 0;
	int		altform = 0, prec = 0, half = 0, base = 0;
	int		tlong = 0, fillz = 0, plen, pad, prec_given = 0;
	long		num = 0;
	char		tmp[36], *p = tmp;

	if (c != '%') {
	    X_STORE(c);
	    continue;
	}

	for (c = *fmt++; ; c = *fmt++)
	    switch (c) {
	    case 'h': half = 1;	 	break;
	    case 'l': tlong = 1; 	break;
	    case '-': ljust = 1; 	break;
	    case '+': plus = 1; 	break;
	    case ' ': space = 1; 	break;
	    case '0': fillz = 1; 	break;
	    case '#': altform = 1; 	break;
	    case '*': width = -1;	break;	/* Mark as need-to-fetch */
	    case '.':
		if ((c = *fmt++) == '*')
		    prec = -1;			/* Mark as need-to-fetch */
		else {
		    for (prec = 0; c >= '0' && c <= '9'; c = *fmt++)
			prec = prec * 10 + (c - '0');
		    fmt--;
		}
		prec_given = 1;
		break;
	    default:
		if (c >= '1' && c <= '9') {
		    for (width = 0; c >= '0' && c <= '9'; c = *fmt++)
			width = width * 10 + (c - '0');
		    fmt--;
		} else
		    goto break_for;
		break;
	    }
    break_for:

	if (width == -1)
	    width = va_arg(ap,int);
	if (prec == -1)
	    prec = va_arg(ap,int);

	if (c == 0)
	    break;

	switch (c) {
	case 'd':
	case 'i':
	    num = tlong ? va_arg(ap, long) : va_arg(ap, int);
	    if (half)
		num = (int) (short) num;
	    /* For zero-fill, the sign must be to the left of the zeroes */
	    if (fillz && (num < 0 || plus || space)) {
		X_STORE(num < 0 ? '-' : space ? ' ' : '+');
		if (width > 0)
		    width--;
		if (num < 0)
		    num = -num;
	    }
	    if (! fillz) {
		if (num < 0) {
		    *p++ = '-';
		    num = -num;
		} else if (plus)
		    *p++ = '+';
		else if (space)
		    *p++ = ' ';
	    }
	    base = 10;
	    break;
	case 'u':
	    num = tlong ? va_arg(ap, long) : va_arg(ap, int);
	    if (half)
		num = (int) (short) num;
	    base = 10;
	    break;
	case 'p':
	    altform = 0;
	    /* Fall through */
	case 'x':
	case 'X':
	    num = tlong ? va_arg(ap, long) : va_arg(ap, int);
	    if (half)
		num = (int) (unsigned short) num;
	    if (altform) {
		prec += 2;
		*p++ = '0';
		*p++ = c;
	    }
	    base = 16;
	    break;
	case 'o':
	case 'O':
	    num = tlong ? va_arg(ap, long) : va_arg(ap, int);
	    if (half)
		num = (int) (unsigned short) num;
	    if (altform) {
		prec++;
		*p++ = '0';
	    }
	    base = 8;
	    break;
	case 'f':
	    f = va_arg(ap, double);
	    if (! prec_given)
		prec = 6;
	    x_ftoa(p, f, prec);
	    fillz = 0;
	    p = tmp;
	    prec = X_INF;
	    break;
	case 's':
	    p = va_arg(ap,char *);
	    if (prec == 0)
		prec = X_INF;
	    break;
	case 'c':
	    p[0] = va_arg(ap,int);
	    p[1] = 0;
	    prec = 1;
	    break;
	case 'n':
	    *va_arg(ap,int *) = bp - buf;
	    p[0] = 0;
	    break;
	case '%':
	    p[0] = '%';
	    p[1] = 0;
	    prec = 1;
	    break;
	default:
	    X_STORE(c);
	    continue;
	}

	if (base != 0) {
	    x_itoa(p, (unsigned int) num, base, (c == 'X'), prec);
	    if (prec)
		fillz = 0;
	    p = tmp;
	    prec = X_INF;
	}

	if ((plen = strlen(p)) > prec)
	    plen = prec;

	if (width < plen)
	    width = plen;

	pad = width - plen;

	while (! ljust && pad-- > 0)
	    X_STORE(fillz ? '0' : ' ');
	for (; plen-- > 0 && width-- > 0; p++)
	    X_STORE(*p);
	while (pad-- > 0)
	    X_STORE(' ');
    }

    if (bp < be)
	*bp = 0;
    else
	*be = 0;

    return (bp - buf);
}

int
x_vsprintf(char *buf, const char *fmt, va_list ap)
{
    return x_vsnprintf(buf, (size_t) X_INF, fmt, ap);
}

int
x_snprintf(char *buf, size_t bufsize, const char *fmt, ...)
{
    va_list		ap;
    int			r;

    va_start(ap,fmt);
    r = x_vsnprintf(buf, bufsize, fmt, ap);
    va_end(ap);

    return r;
}

int
x_sprintf(char *buf, const char *fmt, ...)
{
    va_list		ap;
    int			r;

    va_start(ap,fmt);
    r = x_vsnprintf(buf, (size_t) X_INF, fmt, ap);
    va_end(ap);

    return r;
}

int
osl_vprintf_direct(const char *fmt, va_list varg)
{
    char		buf[256];
    int			r;

    r = x_vsnprintf(buf, sizeof (buf), fmt, varg);

    sysSerialPrintString(buf);

    return r;
}

#endif /* HAVE_DIRECT_SERIAL */



/*
 * VxWorks TCP/IP Interface configuration support.
 * Support ifconfig like functionality.
 */
IMPORT int 	ipAttach ();		/* Import VxWorks routine */

/*
 * Macro:	OSL_MAP_NETUNIT
 * Purpose:	Takes "normalized" unit number and turns it into 
 *		something VxWorks can deal with
 * Parameters:	_x - unit number passed down.
 */
#define	OSL_MAP_NETUNIT(_x)	(_x) += 2

static int
osl_if_unconfig(char *pfx, END_OBJ *eo, char *if_name, int if_unit)
{
    debugk(DK_END, "%s: Stopping\n", pfx);
    if (OK != muxDevStop(eo)) {
	printk("%s: Error: muxDevStop failed: %s%d\n", 
	       pfx, if_name, if_unit);
	return(-1);
    }
    debugk(DK_END, "%s: Unloading\n", pfx);
    if (OK != muxDevUnload(if_name, if_unit)) {
	printk("%s: Error: muxDevUnload failed: %s%d\n",
	       pfx, if_name, if_unit);
	return(-1);
    }
    debugk(DK_END, "%s: Stopped and Unloaded: %s%d\n", 
	   pfx, if_name, if_unit);
    return(0);
}

/*
 * Function: 	osl_ifconfig
 * Purpose:	Configure a network device (load driver and start)
 * Parameters:	pfx - string printed for error messages.
 *		name - device name ("sn" for "sn0")
 *		unit - unint number (0 for "sn0")
 * Returns:	NULL - failed
 *		!NULL - opaque pointer.
 */
void *
osl_ifconfig(char *pfx,
	     int u,
	     char *if_name,
	     int if_unit, 
	     char *if_host,
	     mac_addr_t if_mac,
	     int if_vlan, 
	     ip_addr_t if_ip,
	     ip_addr_t if_netmask,
	     END_OBJ* (*end_load)(char *is, void *))
{
    char	if_name_str[END_NAME_MAX];
    char	if_init_str[64];
    char 	if_ip_str[IPADDR_STR_LEN];
    char	if_mac_str[MACADDR_STR_LEN];
    END_OBJ	*eo;			/* END object  */
    M2_INTERFACETBL	m2;

    OSL_MAP_NETUNIT(if_unit);
    debugk(DK_END, "%s: osl_if_config if_name=%s if_unit=%d\n", 
	   pfx, if_name, if_unit);
    /* Build vxWorks device name */
    sprintf(if_name_str, "%s%d", if_name, if_unit);

    /* Check to see if end device already loaded */

    if (NULL == (eo = endFindByName(if_name, if_unit))) {
	debugk(DK_END, "%s: End device not loaded: if %s if_unit %d\n", 
	       pfx, if_name, if_unit);
	format_macaddr(if_mac_str, if_mac);
#if VLAN_SUPPORT
	sprintf(if_init_str, "%d:%s:%d", u, if_mac_str, if_vlan);
#else
	sprintf(if_init_str, "%d:%s", u, if_mac_str);
#endif
	if (NULL == (eo = muxDevLoad(if_unit, end_load, 
				     if_init_str, 0 /*TRUE%%%*/, NULL))) {
	    printk("%s: muxDevLoad failed: Unit %d\n", pfx, u);
	    return(NULL);
	}

	debugk(DK_END, "%s: muxDevLoad successful: 0x%x\n", pfx, (int)eo);
	if (ERROR == muxDevStart(eo)) {
	    printk("%s: muxDevStart failed: Unit %d\n", pfx, u);
	    (void)muxDevUnload(if_name, if_unit);
	    return(NULL);
	}
    }
    /*
     * Configure device....
     */
    if (OK != muxIoctl(eo, EIOCGMIB2, (caddr_t)&m2)) {
	printk("%s: muxIoctl failed: Unit %d\n", pfx, u);
	(void)osl_if_unconfig(pfx, eo, if_name, if_unit);
	return(NULL);
    }
    debugk(DK_END, "%s: muxIOCTL successful: Unit %d\n", pfx, u);
    /*
     * Setup interface in following order:
     *		[1] Attach TCP/IP to END device
     *		[2] Set Netmask (if non-0)
     *		[3] Set IP address
     *		[4] Set host name associated with interface (if given).
     */
    if (OK != ipAttach(if_unit, if_name)) { /* [1] */
	printk("%s: ipAttach failed: Unit %d (interface %s)\n", 
	       pfx, u, if_name_str);
	(void)osl_if_unconfig(pfx, eo, if_name, if_unit);
	return(NULL);
    }
    debugk(DK_END, "%s: ipAttach successful: if_name %s if_unit %d\n", 
	   pfx, if_name, if_unit);

    if (0 != if_netmask) {		/* [2] */
	if (ERROR == ifMaskSet(if_name_str, if_netmask)) {
	    printk("%s: ifMaskSet failed: %s 0x%x\n", 
		   pfx, if_name_str, if_netmask);
	    (void)osl_if_unconfig(pfx, eo, if_name, if_unit);
	    return(NULL);
	}
    }

    format_ipaddr(if_ip_str, if_ip);	/* [3] */
    if (OK != ifAddrSet(if_name_str, (char *)if_ip_str)) {
	printk("%s: ifAddrSet failed: %s <-- %s\n", pfx, if_name, if_ip_str);
	(void)osl_if_unconfig(pfx, eo, if_name, if_unit);
	return(NULL);
    }
    debugk(DK_END, "%s: ifAddrSet successful: if %s\n", pfx, if_name_str);

    if (if_host && *if_host) {		/* [4] */
	debugk(DK_END, "%s: Setting hostname: %s\n", pfx, if_host);
	if (OK != hostAdd (if_host, if_ip_str)) {
	    printk("%s: Warning: Failed to set hostname %s for device %s\n", 
		   pfx, if_host, if_name_str);
	}
    }
    return((void *)eo);			/* This is our opaque value */
}


/*
 * Assertion routine with recovery for diag shell (see assert.h)
 */

void
_osl_assert(const char *expr, const char *file, int line)
{
#ifdef VXWORKS
    extern void sysReboot(void);
#endif
    char		buf[80];

#ifdef UNIX
    /*
     * You can have assertion failures call abort() when you're in GDB
     * by adding the following to your ~/.gdbinit: set environment GDB 1
     */

    if (getenv("GDB"))
	abort();
#endif

    printk("ERROR: Assertion failed: (%s) at %s:%d\n", expr, file, line);

#ifdef VXWORKS
    if (osl_int_context())
        reboot(BOOT_NORMAL);
#endif /* VXWORKS */

    /*
     * Allow user to continue or return to command prompt.
     */

    if (osl_readline("ERROR: Continue or quit (c/q)? ",
		     buf, sizeof (buf), "q") == NULL ||
	toupper(buf[0]) != 'C') {
	/* cli_ctrl_c_take(); */
    } else
	printk("WARNING: correct behavior no longer guaranteed\n");
}

