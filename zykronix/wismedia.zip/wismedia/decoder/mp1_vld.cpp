/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_FMT/MP1_vld.cpp"
 *	Description: MPEG1 VLD routines. Implementation of class CMp1Vld
 *	History:
 *		06-10-2002 - Weimin, file created
 * $Id: mp1_vld.cpp,v 1.2 2004/02/11 15:36:39 dmeyer Exp $
 */
#include <math.h>

#include "mp1_vld.h"

#define DEFAULT_MPEG1_SEQMODE		IPB
#define DEFAULT_MPEG1_FPMODE		FLHALF
#define DEFAULT_MPEG1_UVMODE		MPEG1
#define DEFAULT_MPEG1_DQMODE		MPEG1
#define DEFAULT_MPEG1_ACPRED		0
#define DEFAULT_MPEG1_USERQ			0
#define DEFAULT_MPEG1_INTERLACE		0


CMp1Vld::CMp1Vld(TMP_StrInfo *sInfo, TMP_FrmInfo *fInfo, TMP_BlkPair *mPair) : CBaseVld(sInfo, fInfo, mPair)
{
	SINT32 i;

	Mp1Tab1 = Mp1Tab;
	Mp1Tab2 = Mp1Tab1 + 256;
	Mp1Tab3 = Mp1Tab2 + 256;
	Mp1Tab4 = Mp1Tab3 + 32;
	Mp1Tab5 = Mp1Tab4 + 8;
	
	for(i = 0; i < 560; i ++)
	{
		Mp1Tab[i].run = CONSTivlc[i][0]; Mp1Tab[i].level = CONSTivlc[i][1];
		Mp1Tab[i].len = CONSTivlc[i][2]; Mp1Tab[i].sign  = CONSTivlc[i][3];
	}

	if (sInfo->interlace == FP_AUTO)sInfo->interlace= DEFAULT_MPEG1_INTERLACE;
	if (sInfo->acpred == FP_AUTO)	sInfo->acpred	= DEFAULT_MPEG1_ACPRED;
	if (sInfo->seq == FP_AUTO)		sInfo->seq		= DEFAULT_MPEG1_SEQMODE;
	if (sInfo->fpmode == FP_AUTO)	sInfo->fpmode	= DEFAULT_MPEG1_FPMODE;
	if (sInfo->uvmode == FP_AUTO)	sInfo->uvmode	= DEFAULT_MPEG1_UVMODE;
	if (sInfo->dqmode == FP_AUTO)	sInfo->dqmode	= DEFAULT_MPEG1_DQMODE;
	if (sInfo->userq  == FP_AUTO)	sInfo->userq	= DEFAULT_MPEG1_USERQ;

	pf_mv[0] = pf_mv[1] = pb_mv[0] = pb_mv[1] = 0;
	gop_fno = 0;
	bSkipped = 0;
	pict_struct = FRAME_STRUCT;
#ifdef _DEBUG
	fp = NULL;
	fp = fopen("c:/mp1debug.txt", "wt");
#endif
}

SINT32 CMp1Vld::StrHead(SINT32 &bits)
{
	static REAL64 ratetab[8] = { 23.976, 24.0, 25.0, 29.97, 30.0, 50.0, 59.94, 60.0 };
	
	store_coding_state();
	if (bits_quota < vlc.index + 1024) return reset_coding_state(bits, ERR_MEMORY);

	SINT32 j = 0, frame_rate_code;

	UINT32 sequence_start_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
	if (sequence_start_code != 0x000001B3) return reset_coding_state(bits, ERR_MISMCH);

	strInfo->cols = vlcLoad(&vlc, 12) >> 4;			// horizontal_size_value
	strInfo->rows = vlcLoad(&vlc, 12) >> 4;			// vertical_size_value
	vlcSkip(&vlc, 4);								// aspect_ratio_information
	frame_rate_code = vlcLoad(&vlc, 4);				// frame_rate_code
	strInfo->fps = ratetab[frame_rate_code - 1];
	vlcSkip(&vlc, 19);								// variable bit rate value + 1 bit marker
	vlcSkip(&vlc, 11);								// vbv_buffer_size_value
							  						// constrained_parameters_flag

	strInfo->userq = vlcLoad(&vlc, 1);				// load_intra_quantizer_matrix
	if (strInfo->userq)
	{
		for (j = 0; j < 64; j++)
		{
			strInfo->intraq[TabNZScan[j]] = vlcLoad(&vlc, 8);
		}
	}
	strInfo->userq = vlcLoad(&vlc, 1);				// load_inter_quantizer_matrix
	if (strInfo->userq)
	{
		for (j = 0; j < 64; j++)
		{
			strInfo->interq[TabNZScan[j]] = vlcLoad(&vlc, 8);
		}
	}

	nextstartcode();
	store_coding_state();
	UINT32 user_data_start_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
	if (user_data_start_code == 0x000001B2)
		nextstartcode();
	else
		reset_coding_state(bits, 0);

	bits = vlc.index;
	return SUCCESS;
}

SINT32 CMp1Vld::StrTail(SINT32 &bits)
{
	store_coding_state();
	if (bits_quota < vlc.index + 32) return reset_coding_state(bits, ERR_MEMORY);
	align();
	UINT32 session_end_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
	if (session_end_code != 0x000001B7) return reset_coding_state(bits, ERR_MISMCH);
	bits = vlc.index;
	return SUCCESS;
}

SINT32 CMp1Vld::GopHead(SINT32 &bits, SINT8* data)
{
	SINT32 nbits = vlc.index;

	store_coding_state();
	
	nbits += 32;
	if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);

	UINT32 group_start_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
	if (group_start_code == 0x000001B8)
	{
		nbits += 64;
		if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
		SINT32 tc = (vlcLoad(&vlc, 24) << 1) + vlcLoad(&vlc, 1);
		gop_fno = Tc2Frame(tc, strInfo->fps);
		vlcSkip(&vlc, 7);
#ifdef 	_BIG_ENDIAN_
		store_coding_state();
		UINT32 user_data_start_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
		if (user_data_start_code == 0x000001B2)
#else
		UINT32 user_data_start_code = *((UINT32 *)(vlc.codeStr - 3));
		if (user_data_start_code == 0xB2010000)
#endif
		{
			vlcSkip(&vlc, 24);
			vlcSkip(&vlc, 8);

			nbits += 8;
			if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);

			if (vlcRead(&vlc, 8) == 0xF0)
			{
				vlcSkip(&vlc, 8);

				nbits += 16;
				if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);

				SINT8 fps_col_row, seq_fpmode, uvmode, dqmode, acpred, userq;
				
				vlcSkip(&vlc, 1);
				fps_col_row = vlcLoad(&vlc, 1);
				seq_fpmode	= vlcLoad(&vlc, 1);
				uvmode		= vlcLoad(&vlc, 1);
				dqmode		= vlcLoad(&vlc, 1);
				acpred		= vlcLoad(&vlc, 1);
				userq		= vlcLoad(&vlc, 1);
				vlcSkip(&vlc, 1);

				vlcSkip(&vlc, 8);

				nbits += (fps_col_row ? 32 : 0) + (seq_fpmode ? 8 : 0) + 
					(uvmode ? 8 : 0) + (dqmode ? 8 : 0) + (userq ? 64 * 8 * 2 : 0);
				if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);

				if (fps_col_row)
				{
					vlcSkip(&vlc, 1);
					strInfo->fps = 30000.0 / vlcLoad(&vlc, 15);
					strInfo->cols = vlcLoad(&vlc, 8);
					strInfo->rows = vlcLoad(&vlc, 8);
				}

				if (seq_fpmode)
				{
					vlcSkip(&vlc, 1);
					strInfo->seq	= vlcLoad(&vlc, 3);
					strInfo->fpmode	= vlcLoad(&vlc, 4);
				}
				else
				{
					strInfo->seq	= DEFAULT_MPEG1_SEQMODE;
					strInfo->fpmode = DEFAULT_MPEG1_FPMODE;
				}

				if (uvmode)
					strInfo->uvmode = vlcLoad(&vlc, 8) & 0x7f;
				else
					strInfo->uvmode = DEFAULT_MPEG1_UVMODE;

				if (dqmode)
					strInfo->dqmode = vlcLoad(&vlc, 8) & 0x7f;
				else
					strInfo->dqmode = DEFAULT_MPEG1_DQMODE;

				if (acpred)
					strInfo->acpred = acpred;
				else
					strInfo->acpred = DEFAULT_MPEG1_ACPRED;

				if (userq)
				{
					SINT32 j;
					strInfo->userq = userq;
					for (j = 0; j < 64; j++)
						strInfo->intraq[TabNZScan[j]] = vlcLoad(&vlc, 8);
					for (j = 0; j < 64; j++)
						strInfo->interq[TabNZScan[j]] = vlcLoad(&vlc, 8);
				}
			}
			else
			{
				nextstartcode();
			}
		}
		else {
			reset_coding_state(bits, ERR_MISMCH);
			nextstartcode();
		}
		bits = vlc.index;
		return SUCCESS;
	}
	return reset_coding_state(bits, ERR_MISMCH);
}

SINT32 CMp1Vld::FrmHead(SINT32 &bits)
{
	SINT32 i = 0;

	store_coding_state();
	if (bits_quota < vlc.index + 32 + 40) return reset_coding_state(bits, ERR_MEMORY);

	UINT32 frame_start_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
	if (frame_start_code != 0x00000100) return reset_coding_state(bits, ERR_MISMCH);
	SINT32 cur_fno = vlcLoad(&vlc, 10) & 0x3ff;		// temporal reference
	if (gop_fno == 0)
	{
		SINT32 pno = ((SINT32)frmInfo->fno) & 0x3ff;
		if (cur_fno < pno - 0x200)
			cur_fno += 0x400;
		frmInfo->fno += cur_fno - pno;
	}
	else
		frmInfo->fno = gop_fno + cur_fno;

	frmInfo->ftype = vlcLoad(&vlc, 3) - 1;			// frame type
	vlcSkip(&vlc, 16);
	if (frmInfo->ftype == P_FRAME || frmInfo->ftype == B_FRAME)
	{
		forward_f_code = vlcLoad(&vlc, 4) & 0x7; // f_code
		if (frmInfo->ftype == B_FRAME)
		{
			backward_f_code = vlcLoad(&vlc, 4) & 0x7;
			vlcSkip(&vlc, 3);
		}
		else
		{
			vlcSkip(&vlc, 7);
		}
	}
	else
	{
		vlcSkip(&vlc, 3);
	}

	bits = vlc.index;
	return SUCCESS;
}


SINT32 CMp1Vld::FrmTail(SINT32 &bits)
{
	align();
	bits = vlc.index;
	return SUCCESS;
}

SINT32 CMp1Vld::StrMblk(TMP_BlkInfo *mb00, TMP_BlkInfo *mb01, TMP_BlkInfo *mb02, 
		TMP_BlkInfo *mb10, TMP_BlkInfo *mb11)
{
	SINT32	i = 0; 
	SINT32	col = mb11->col, row = mb11->row;
	SINT8	coded, frm = frmInfo->ftype;
	SINT8	intra, skip;
	SINT8 prev_quant = quant;
	static SINT32 gopno = 0;

	GetGOB(mb11);

	if (skip = SkipMblk(mb11)) {
#ifdef _DEBUG
		goto _PrintInfo;
#endif
		return vlc.index;
	}

	MBAinc = GetAddrInc();		// macro-block address incremental

	if (skip = SkipMblk(mb11)) {
#ifdef _DEBUG
		goto _PrintInfo;
#endif
		return vlc.index;
	}

	mb11->mbtype = GetMBType();	// macro-block type

	intra = mb11->mbtype & MB_INTRA;

	if (strInfo->interlace == 2 && (!intra)) // motion type == MC_FIELD
		vlcSkip(&vlc, 2);

	// get mquant if it has changed 
	prev_quant = quant;
	if (mb11->mbtype & MB_QUANT)
		mb11->Q = quant = vlcLoad(&vlc, 5);
	else
		mb11->Q = quant;

	if (mb11->mbtype & MB_FORWARD)
	{
		if (strInfo->interlace == 2) vlcSkip(&vlc, 1);
		// forward motion vectors, update predictors 
		GetMotionVector(mb11);
		pf_mv[0] = mb11->vx[0];
		pf_mv[1] = mb11->vy[0];
	}

	if (mb11->mbtype & MB_BACKWARD)
	{
		if (strInfo->interlace == 2) vlcSkip(&vlc, 1);
		// backward motion vectors, update predictors 
		GetMotionVector(mb11);
		pb_mv[0] = mb11->vx[0];
		pb_mv[1] = mb11->vy[0];
	}

	if (mb11->mbtype & MB_PATTERN) {
		mb11->cbp = GetCBP();
		if (!(mb11->mbtype & MB_FORWARD) && !(mb11->mbtype & MB_BACKWARD)) {
			for (i = 0; i < 6; i++) mb11->vx[i] = mb11->vy[i] = 0;
			pf_mv[0] = pf_mv[1] = 0;
		}
	}
	else
		mb11->cbp = 0;

	coded = mb11->cbp << 2;
	for (i = 0; i < 6; i++, coded <<= 1)
	{
		if (intra)
			GetDCValue(i, mb11);
		else
			mb11->dc[i] = 128;
		blkPair->pair[i] = (coded < 0 || intra)? vld8x8(!intra, &vlc, blkPair->run[i], blkPair->lvl[i]) : 0;
	}
	if (intra)
	{
		for (i = 0; i < 6; i++)
			mb11->cbp  |= (blkPair->pair[i] ? 1 : 0) << (5 - i);
	}
	// reset predictors 
	if (mb11->mbtype & MB_INTRA)
		pf_mv[0] = pf_mv[1] = pb_mv[0] = pb_mv[1] = 0;
	else
		dc_dct_pred[0] = dc_dct_pred[1] = dc_dct_pred[2] = 128;
	
	prev_mb_type = mb11->mbtype;

	// 5/21, to support interlace coding decoding, weimin
	if (pict_struct != FRAME_STRUCT && col == strInfo->cols - 1 && row == strInfo->rows / 2 - 1)
	{
		SINT32 bits;
		align();
		FrmHead(bits);
	}

#ifdef _DEBUG
_PrintInfo:
/*
	if (frmInfo->ftype == I_FRAME)
	{
		if (mb11->col == 0 && mb11->row == 0)
			fprintf(fp, "Frame: %d, type: %d\n", (int)(frmInfo->fno), frmInfo->ftype);
		fprintf(fp, "col %d, row %d, mbtype: %d, cbp: %x, Q: %d\n", mb11->col, mb11->row, mb11->mbtype, mb11->cbp, mb11->Q);
		for (i = 0; i < 6; i++)
			fprintf(fp, "%x\n", mb11->dc[i]);
		for (i = 0; i < 6; i++)
		{
			fprintf(fp, "Pair[%d]: %x\n", i, blkPair->pair[i]);
			for (int j = 0; j < blkPair->pair[i]; j++)
			{
				fprintf(fp, "%x, %x\n", blkPair->run[i][j], blkPair->lvl[i][j]);
			}
		}
		if (!(mb11->mbtype & MB_INTRA))
		{
			for (SINT32 i = 0; i < 6; i++)
				fprintf(fp, "%02x, %02x\n", mb11->vx[i], mb11->vy[i]);
		}
	}
*/
	if (mb11->col == 0 && mb11->row == 0) {
		if (frmInfo->ftype == I_FRAME) gopno++;
		fprintf(fp, "Frame: %d, gop: %d\n", (SINT32)(frmInfo->fno), gopno);
	}
	fprintf(fp, "MB(%d, %d), Q=%d, Qdiff=%d\n", mb11->row, mb11->col, mb11->Q, mb11->Q-prev_quant);
	if (!skip)
	{
		if (!(mb11->mbtype & MB_INTRA)) {
			if (!(mb11->vx[0] == 0 && mb11->vy[0] == 0))// || (mb11->col == 0 || mb11->col == strInfo->cols - 1))
				fprintf(fp, "MV: (%d, %d)\n", mb11->vx[0], mb11->vy[0]);
			fprintf(fp, "cbp: %d\n", mb11->cbp);
		}
		else {
			fprintf(fp, "DC: %d, %d, %d, %d, %d, %d\n", mb11->dc[0]-128, mb11->dc[1]-128, mb11->dc[2]-128, mb11->dc[3]-128, mb11->dc[4]-128, mb11->dc[5]-128);
			fprintf(fp, "cbp: 63\n");
		}
		for (i = 0; i < 6; i++)
		{
	//		fprintf(fp, "block %d: %d\n", i, blkPair->pair[i]);
			fprintf(fp, "Block %d\n", i);
			for (SINT32 j = 0; j < blkPair->pair[i]; j++)
				fprintf(fp, "run: %d, level: %d\n", blkPair->run[i][j], blkPair->lvl[i][j]);
		}
	}
#endif

	return vlc.index;
}

INLINE SINT32 CMp1Vld::GetGOB(TMP_BlkInfo *mb11)
{
	if (vlcRead(&vlc, 23) == 0x000000) // start slice
	{
		align();
		vlcSkip(&vlc, 24);			// slice_start_code
		vlcSkip(&vlc,  8);
		mb11->Q = quant = vlcLoad(&vlc, 6) >> 1;
		dc_dct_pred[0] = dc_dct_pred[1] = dc_dct_pred[2] = 128;
		pf_mv[0] = pf_mv[1] = pb_mv[0] = pb_mv[1] = 0;
		MBAinc = 1;
	}
	return SUCCESS;
}


INLINE SINT8 CMp1Vld::SkipMblk(TMP_BlkInfo *mb11)
{
	if (MBAinc > 1)	// Skip macro-block
	{
		bSkipped = 1;
		MBAinc--;
		mb11->Q = quant;
		mb11->vx[0] = mb11->vx[1] = mb11->vx[2] = mb11->vx[3] = mb11->vx[4] = mb11->vx[5] = 0;
		mb11->vy[0] = mb11->vy[1] = mb11->vy[2] = mb11->vy[3] = mb11->vy[4] = mb11->vy[5] = 0;
		mb11->cbp = 0;
		blkPair->pair[0] = blkPair->pair[1] = blkPair->pair[2] = blkPair->pair[3] = blkPair->pair[4] = blkPair->pair[5] = 0;
		mb11->dc[0] = mb11->dc[1] = mb11->dc[2] = mb11->dc[3] = mb11->dc[4] = mb11->dc[5] = 128;
		dc_dct_pred[0] = dc_dct_pred[1] = dc_dct_pred[2] = 128;
		if (frmInfo->ftype == B_FRAME)
		{
			mb11->mbtype = prev_mb_type;
			if (mb11->mbtype & MB_FORWARD) {
				mb11->vx[0] = mb11->vx[1] = mb11->vx[2] = mb11->vx[3] = pf_mv[0];
				mb11->vy[0] = mb11->vy[1] = mb11->vy[2] = mb11->vy[3] = pf_mv[1];
			}
			if (mb11->mbtype & MB_BACKWARD) {
				mb11->vx[0] = mb11->vx[1] = mb11->vx[2] = mb11->vx[3] = pb_mv[0];
				mb11->vy[0] = mb11->vy[1] = mb11->vy[2] = mb11->vy[3] = pb_mv[1];
			}
			mb11->vx[4] = mb11->vx[5] = (mb11->vx[0] + (mb11->vx[0] < 0)) >> 1;
			mb11->vy[4] = mb11->vy[5] = (mb11->vy[0] + (mb11->vy[0] < 0)) >> 1;
		}
		else
		{
			mb11->mbtype = MB_FORWARD;
			pf_mv[0] = pf_mv[1] = pb_mv[0] = pb_mv[1] = 0;
		}
		return 1;
	}
	return 0;
}

INLINE SINT32 CMp1Vld::GetAddrInc()
{
	SINT32 addrinc = 0;
	UINT32 code;

	if (bSkipped) 
	{
		bSkipped = 0;
		return 1;
	}
	while ((code = vlcRead(&vlc, 11)) == 0x08)
	{
		vlcSkip(&vlc, 11);
		addrinc += 33;
	}
	if (code > 0x7f)
	{
		code >>= 6;
		addrinc += MBAddrInc1[code].level;
		vlcSkip(&vlc, MBAddrInc1[code].len);
	}
	else if (code > 0x3f)
	{
		code = (code >> 3) & 0x07;
		addrinc += MBAddrInc2[code].level;
		vlcSkip(&vlc, MBAddrInc2[code].len);
	}
	else
	{
		addrinc += MBAddrInc3[code].level;
		vlcSkip(&vlc, MBAddrInc3[code].len);
	}
	bSkipped = 0;
	return addrinc;
}

INLINE SINT8 CMp1Vld::GetMBType()
{
	UINT32 code = vlcRead(&vlc, 6);

	vlcSkip(&vlc, MBTypeTab[frmInfo->ftype][code].len);
	return MBTypeTab[frmInfo->ftype][code].level;
}

INLINE SINT32 CMp1Vld::GetMVData()
{
	if (vlcLoad(&vlc, 1)) return 0; 

	UINT32 code = vlcRead(&vlc, 10);
	if (code >= 128)
	{
		code >>= 6;
		vlcSkip(&vlc, MVTable1[code].len - 1);
		return MVTable1[code].level;
	}
	vlcSkip(&vlc, MVTable2[code].len - 1);
	return MVTable2[code].level;
}

INLINE void CMp1Vld::SetMV(TMP_BlkInfo *mb11)
{
	SINT32 f_code, pmv[2];
	if ((mb11->mbtype & MB_FORWARD) || !(mb11->mbtype & MB_BACKWARD))
	{
		f_code = forward_f_code;
		pmv[0] = pf_mv[0]; pmv[1] = pf_mv[1];
	}
	else
	{
		f_code = backward_f_code;
		pmv[0] = pb_mv[0]; pmv[1] = pb_mv[1];
	}

	SINT32 r_size = 1 << (f_code - 1);
	SINT32 high = 16 * r_size - 1;
	SINT32 low = -16 * r_size;
	SINT32 range = 32 * r_size;

	SINT32 mvd_x, mvd_y, mv_x, mv_y, motion_code, residual;

	motion_code = GetMVData();
	if (f_code == 1 || motion_code == 0)
		mvd_x = motion_code;
	else
	{
		residual = vlcLoad(&vlc, f_code - 1);
		mvd_x = (((motion_code < 0) ? -motion_code : motion_code) - 1) * r_size + residual + 1;
		if (motion_code < 0) mvd_x = -mvd_x;
	}

	motion_code = GetMVData();
	if (f_code == 1 || motion_code == 0)
		mvd_y = motion_code;
	else
	{
		residual = vlcLoad(&vlc, f_code - 1);
		mvd_y = (((motion_code < 0) ? -motion_code : motion_code) - 1) * r_size + residual + 1;
		if (motion_code < 0) mvd_y = -mvd_y;
	}

	mv_x = pmv[0] + mvd_x;
	if (mv_x < low)	mv_x += range;
	if (mv_x > high)mv_x -= range;

	mv_y = pmv[1] + mvd_y;
	if (mv_y < low) mv_y += range;
	if (mv_y > high)mv_y -= range;

	SINT32 i;
	for (i = 0; i < 4; i++) 
	{
		mb11->vx[i] = mv_x;
		mb11->vy[i] = mv_y;
	}
}

INLINE void	CMp1Vld::GetMotionVector(TMP_BlkInfo *mb11)
{
	if (!(mb11->mbtype & MB_INTRA))
	{
		SetMV(mb11);
		mb11->vx[4] = mb11->vx[5] = (mb11->vx[0] + (mb11->vx[0] < 0)) >> 1;
		mb11->vy[4] = mb11->vy[5] = (mb11->vy[0] + (mb11->vy[0] < 0)) >> 1;
	}
	else
	{
		SINT32 i;
		for (i = 0; i < 6; i++)
			mb11->vx[i] = mb11->vy[i] = 0;
	}
}

INLINE SINT8 CMp1Vld::GetCBP()
{
	UINT32 code = vlcRead(&vlc, 9);
	if (code >= 128)
	{
		code >>= 4;
		vlcSkip(&vlc, MBCBPTable1[code].len);
		return MBCBPTable1[code].level;
	}
	vlcSkip(&vlc, MBCBPTable2[code].len);
	return MBCBPTable2[code].level;
}

// 100				0
// 00				1
// 01				2
// 101				3
// 110				4
// 1110				5
// 1111 0			6
// 1111 10			7
// 1111 110			8
// 1111 1110		9
// 1111 1111 0		10
// 1111 1111 1		11

INLINE SINT8 CMp1Vld::GetDCSizeLum()
{
	UINT32 code;

	code = vlcRead(&vlc, 3);
	if (code < 7)
	{
		code <<= 1;
		vlcSkip(&vlc, MP1DCSizeLum[code+1]);
		return MP1DCSizeLum[code];
	}

	SINT32 i;
	code = vlcRead(&vlc, 9);
	for (i = 4; i < 10; i++)
	{
		if (!(code & (1 << (9 - i)))) break;
	}
	
	vlcSkip(&vlc, MIN(9, i));

	return i+1;
}

// 00				0
// 01				1
// 10				2
// 110				3
// 1110				4
// 1111 0			5
// 1111 10			6
// 1111 110			7
// 1111 1110		8
// 1111 1111 0		9
// 1111 1111 10		10
// 1111 1111 11		11

INLINE SINT8 CMp1Vld::GetDCSizeChr()
{
	UINT32 code;

	code = vlcLoad(&vlc, 2);
	if (code < 3)
		return code;

	SINT32 i;
	code = vlcRead(&vlc, 8);
	for (i = 1; i < 9; i++)
	{
		if (!(code & (1 << (8 - i)))) break;
	}

	vlcSkip(&vlc, MIN(8, i));

	return i+2;
}

INLINE SINT32 CMp1Vld::GetDCDiff(SINT32 dc_size)
{
	SINT32 code = vlcLoad(&vlc, dc_size);
	SINT32 msb  = code >> (dc_size - 1);

	if (msb == 0) 
		return -(code ^ ((1 << dc_size) - 1));
	else 
		return code;
}

INLINE void	CMp1Vld::GetDCValue(SINT32 block, TMP_BlkInfo *mb11)
{
	SINT8	dc_size;
	SINT32	dc_diff;
	SINT32	cc = block < 4 ? 0 : (block & 1) + 1;

	if (block < 4) 
	{
		dc_size = GetDCSizeLum();
		if (dc_size != 0) 
			dc_diff = GetDCDiff(dc_size);
		else 
			dc_diff = 0;
	}
	else 
	{
		dc_size = GetDCSizeChr();
		if (dc_size != 0)
			dc_diff = GetDCDiff(dc_size);
		else 
			dc_diff = 0;
	}

	mb11->dc[block] = dc_diff;
	// dc reconstruction, prediction direction
	mb11->dc[block] += dc_dct_pred[cc];
	dc_dct_pred[cc] = mb11->dc[block];
}

SINT32 CMp1Vld::vld8x8(SINT8 first, MpgvlcManager *vlc, SINT8 *run, SINT32 *lvl)
{
#ifdef _BIG_ENDIAN_
	SINT32 i = 0;
	SINT32 reg; UINT8 *code = (UINT8 *)&reg; MpgvlcTab *tab;
	goto lbl_vlcShow;

lbl_lvlSave:
	lvl[i] = tab->level;

lbl_runSave:
	run[i ++] = tab->run;

//lbl_vlcSkip:
	vlcSkip(vlc, tab->len);

	first = 0;
lbl_vlcShow:
	reg = vlcShow(vlc);
	if(code[1] >= 0x04)
	{
		tab = &Mp1Tab1[code[1]];
		if (first)
		{
			if (tab->len == 32 || tab->len == 3)
			{
				lvl[i] = vlcLoad(vlc, 2) < 3 ? 1 : -1;
				run[i ++] = 0; first = 0; goto lbl_vlcShow;
			}
		}
		if(tab->len <  9)
			goto lbl_lvlSave; 
		else
		if(tab->run < 64)
			if((SINT8)code[2] >= 0)
				goto lbl_lvlSave;
			else {
				lvl[i] = - tab->level; goto lbl_runSave;
			}
		else
		if(tab->run > 64)
		{
			if (first) {
				lvl[i] = vlcLoad(vlc, 2) < 3 ? 1 : -1;
				run[i ++] = 0; first = 0; goto lbl_vlcShow;
			}
			else {
				vlcSkip(vlc, 2); return i;
			}
		}
		else
		{
			vlcSkip(vlc, 6);
			run[i] = vlcLoad(vlc, 6);
			SINT32 al = vlcLoad(vlc, 8);
			if (al == 0)
				lvl[i] = vlcLoad(vlc, 8);
			else if (al == 128)
				lvl[i] = vlcLoad(vlc, 8) - 256;
			else
				lvl[i] = al > 128 ? al - 256 : al;

			i++; first = 0; goto lbl_vlcShow;
		}
	}
	else
	if(code[1] == 0x00)
	{
		tab = &Mp1Tab2[code[2]];
		if(tab->len < 17)
			goto lbl_lvlSave;
		else
		if(tab->run < 65)
			if((SINT8)code[3] >= 0)
				goto lbl_lvlSave;
			else {
				lvl[i] = - tab->level; goto lbl_runSave;
			}
		else
		{
			vlcSkip(vlc, 2); return i;	// wrong entry!!!
		}
	}
	else
	if(code[1] == 0x02)
	{
		tab = &Mp1Tab4[code[2] >> 5];
		goto lbl_lvlSave;
	}
	else 
	if(code[1] == 0x03)
	{
		tab = &Mp1Tab5[code[2] >> 5];
		goto lbl_lvlSave;
	}
	else
	{
		tab = &Mp1Tab3[code[2] >> 3];
		goto lbl_lvlSave;
	}
#else
	SINT32 i = 0;
    SINT32 reg; UINT8 *code = (UINT8 *)&reg; MpgvlcTab *tab;
    goto lbl_vlcShow;

    lbl_lvlSave:
    lvl[i] = tab->level;

    lbl_runSave:
    run[i ++] = tab->run;

    //lbl_vlcSkip:
    vlcSkip(vlc, tab->len);

    first = 0;
    lbl_vlcShow:
    reg = vlcShow(vlc);
    if(code[2] >= 0x04)
    {
    	tab = &Mp1Tab1[code[2]];
    	if (first)
    	{
    		if (tab->len == 32 || tab->len == 3)
    		{
    			lvl[i] = vlcLoad(vlc, 2) < 3 ? 1 : -1;
    			run[i ++] = 0; first = 0; goto lbl_vlcShow;
    		}
    	}
    	if(tab->len <  9)
    		goto lbl_lvlSave; 
    	else
    	if(tab->run < 64)
    		if((SINT8)code[1] >= 0)
    			goto lbl_lvlSave;
    		else {
    			lvl[i] = - tab->level; goto lbl_runSave;
    		}
    	else
    	if(tab->run > 64)
    	{
    		if (first) {
    			lvl[i] = vlcLoad(vlc, 2) < 3 ? 1 : -1;
    			run[i ++] = 0; first = 0; goto lbl_vlcShow;
    		}
    		else {
    			vlcSkip(vlc, 2); return i;
    		}
    	}
    	else
    	{
    		vlcSkip(vlc, 6);
    		run[i] = vlcLoad(vlc, 6);
    		SINT32 al = vlcLoad(vlc, 8);
    		if (al == 0)
    			lvl[i] = vlcLoad(vlc, 8);
    		else if (al == 128)
    			lvl[i] = vlcLoad(vlc, 8) - 256;
    		else
    			lvl[i] = al > 128 ? al - 256 : al;

    		i++; first = 0; goto lbl_vlcShow;
    	}
    }
    else
    if(code[2] == 0x00)
    {
    	tab = &Mp1Tab2[code[1]];
    	if(tab->len < 17)
    		goto lbl_lvlSave;
    	else
    	if(tab->run < 65)
    		if((SINT8)code[0] >= 0)
    			goto lbl_lvlSave;
    		else {
    			lvl[i] = - tab->level; goto lbl_runSave;
    		}
    	else
    	{
    		vlcSkip(vlc, 2); return i;	// wrong entry!!!
    	}
    }
    else
    if(code[2] == 0x02)
    {
    	tab = &Mp1Tab4[code[1] >> 5];
    	goto lbl_lvlSave;
    }
    else 
    if(code[2] == 0x03)
    {
    	tab = &Mp1Tab5[code[1] >> 5];
    	goto lbl_lvlSave;
    }
    else
    {
    	tab = &Mp1Tab3[code[1] >> 3];
    	goto lbl_lvlSave;
    }
#endif
}
