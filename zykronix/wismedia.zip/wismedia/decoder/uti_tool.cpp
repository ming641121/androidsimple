/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/Uti_TOOL/Uti_TOOL.cpp"
 *	Description: Tool Utilities Interface implementation.
 *	History:
 *		05-02-2002 - Alpha, file created
 *		07-22-2003 - Weimin, Modified for C version Decoder
 * $Id: uti_tool.cpp,v 1.1 2003/11/04 15:42:31 dmeyer Exp $
 */
#include "uti_tool.h"
#include "string.h"


/**	SECTION - interface implementation
 */

INLINE	void	COPY64(UINT8 *mem, UINT8 *src, SINT32 length)
{
#if MMX_SUPPORT
	SINT32 num, tail;
	if((num = length >> 6) < 1) goto cpover;

	__asm
	{
		mov			eax,				src
		mov			ebx,				mem
		mov			CNT,				num

		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   8]
		movq		mm2,				Mptr [eax +  16]
		movq		mm3,				Mptr [eax +  24]
		movq		mm4,				Mptr [eax +  32]
		movq		mm5,				Mptr [eax +  40]
		movq		mm6,				Mptr [eax +  48]
		movq		mm7,				Mptr [eax +  56]

cp64:
		add			eax,				64
		sub			CNT,				1
		je			cleanup

		movq		Mptr [ebx +   0],	mm0
		movq		mm0,				Mptr [eax +   0]

		movq		Mptr [ebx +   8],	mm1
		movq		mm1,				Mptr [eax +   8]

		movq		Mptr [ebx +  16],	mm2
		movq		mm2,				Mptr [eax +  16]

		movq		Mptr [ebx +  24],	mm3
		movq		mm3,				Mptr [eax +  24]

		movq		Mptr [ebx +  32],	mm4
		movq		mm4,				Mptr [eax +  32]

		movq		Mptr [ebx +  40],	mm5
		movq		mm5,				Mptr [eax +  40]

		movq		Mptr [ebx +  48],	mm6
		movq		mm6,				Mptr [eax +  48]

		movq		Mptr [ebx +  56],	mm7
		movq		mm7,				Mptr [eax +  56]

		add			ebx,				64
		jmp			cp64

cleanup:
		movq		Mptr [ebx +   0],	mm0
		movq		Mptr [ebx +   8],	mm1
		movq		Mptr [ebx +  16],	mm2
		movq		Mptr [ebx +  24],	mm3
		movq		Mptr [ebx +  32],	mm4
		movq		Mptr [ebx +  40],	mm5
		movq		Mptr [ebx +  48],	mm6
		movq		Mptr [ebx +  56],	mm7

		emms
	}

cpover:
	if(tail = length & 63)
	{
		num <<= 6; mem += num; src += num;
		num = tail >> 2; tail &= 3;
		SINT32 i;
		if(num)
			for(i = 0; i < num; i ++)
				((SINT32*)mem)[i] = ((SINT32*)src)[i];
		if(tail)
			for(i = 0, mem += num << 2, src += num << 2; i < tail; i ++)
				mem[i] = src[i];
	}
#else
   /* See xscale.s for memcpy optimized for XScale CPU  */
    VCPY(mem, src, length);

//	SINT32 i;
//	for (i = 0; i < length; i++)
//		mem[i] = src[i];
#endif //MMX_SUPPORT
}

SINT32	copyMem(UINT8 *mem, UINT8 *src, SINT32 length)
{
	COPY64(mem, src, length); return length;
}

void	copyRec(UINT8 *tgt, SINT32 wtgt, UINT8 *src, SINT32 wsrc, SINT32 width, SINT32 height)
{
	for(SINT32 i = 0; i < height; i ++) {
		COPY64(tgt, src, width); tgt += wtgt; src += wsrc;
	}
}

/**	ENDOFSECTION
 */



/**	ENDOSOURCEFILE: "Uti_TOOL.cpp"
 */
