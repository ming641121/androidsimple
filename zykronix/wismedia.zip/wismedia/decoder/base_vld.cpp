/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_FMT/base_vld.cpp"
 *	Description: Basic VLD routines. Implementation of class CBaseVld
 *	History:
 *		05-07-2002 - Weimin, file created
 *  $Id: base_vld.cpp,v 1.1 2003/11/04 15:42:29 dmeyer Exp $
 */

#include "base_vld.h"
#include "mp4_vld.h"
#include "mp1_vld.h"
#include "mp2_vld.h"

CBaseVld::CBaseVld(TMP_StrInfo *sInfo, TMP_FrmInfo *fInfo, TMP_BlkPair *mPair)
{
	strInfo = sInfo;
	frmInfo = fInfo;
	blkPair = mPair;
}

CBaseVld::~CBaseVld()
{
}

SINT32 CBaseVld::Tc2Frame(SINT32 tc, REAL64 fps)
{
	SINT32 ifps, pict, sec, minute, hour, fno;

	ifps = (SINT32)(fps + 0.5);
	hour = tc >> 19;
	minute = (tc >> 13) & 0x3f;
	sec = (tc >> 6) & 0x3f;
	pict = tc & 0x3f;

	fno = hour % 24;
	fno = fno * 60 + minute;
	fno = fno * 60 + sec;
	fno = fno * ifps + pict;
	return fno;
}

void CBaseVld::StrInit(UINT8 *stream, SINT32 quota)
{
	vlcInit(&vlc, 0, stream);
	bits_quota = quota * 8;
}

SINT32 CBaseVld::CreateInstance(ITech_VLD	**pp, 
								 TMP_StrInfo *sInfo, 
								 TMP_FrmInfo *fInfo, 
								 TMP_BlkPair *mPair)
{
	if(pp==NULL || sInfo == NULL || fInfo == NULL || mPair == NULL)
		return ERR_MEMORY;
	
	switch(sInfo->mode)
	{
	case MPEG1:
		*pp = (ITech_VLD *)new CMp1Vld(sInfo, fInfo, mPair);
		break;
	case MPEG2:
		*pp = (ITech_VLD *)new CMp2Vld(sInfo, fInfo, mPair);
		break;
	case MPEG4:
		*pp = (ITech_VLD *)new CMp4Vld(sInfo, fInfo, mPair);
		break;
	default:
		*pp = (ITech_VLD *)new CMp4Vld(sInfo, fInfo, mPair);
		break;
	}
	
	if(pp==NULL)
		return ERR_MEMORY;

	return SUCCESS;
}

void CBaseVld::Release()
{
	switch(strInfo->mode)
	{
	case MPEG1:
		delete (CMp1Vld *)this;
		break;
	case MPEG2:
		delete (CMp2Vld *)this;
		break;
	case MPEG4:
		delete (CMp4Vld *)this;
		break;
	default:
		delete (CMp4Vld *)this;
		break;
	}
}

SINT32 ITech_VLD::CreateInstance(ITech_VLD	**pp, 
								 TMP_StrInfo *sInfo, 
								 TMP_FrmInfo *fInfo, 
								 TMP_BlkPair *mPair)
{
	return CBaseVld::CreateInstance(pp, sInfo, fInfo, mPair);
}

