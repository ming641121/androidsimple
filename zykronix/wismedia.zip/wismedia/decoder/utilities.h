/**	HEADERFILE: "WSDF/WISInclude/Utilities.H"
 *	Description: Utilities related definitions.
 *	History:
 *		04-29-2002 - Alpha, file created
 * $Id: utilities.h,v 1.1 2003/11/04 15:42:31 dmeyer Exp $
 */
#ifndef	_UTILITIES_H_
#define	_UTILITIES_H_



/**	SECTION - constants
 */
	typedef enum
	{
		IDX_HEAD	= 0,
		IDX_TAIL	= 0x40000000,
		IDX_ROOT	= - 1
	} EIndexLevel;

/**	ENDOFSECTION
 */



/**	SECTION - data structures
 */

/**	ENDOFSECTION
 */



#endif
/**	ENDOFHEADERFILE: "Utilities.H"
 */
