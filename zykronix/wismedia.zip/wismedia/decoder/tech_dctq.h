/**	HEADERFILE: "WSDF/WISDevelopSpace/WISLib/MultiMedia/Tech_DCTQ.h"
 *	Description: DCT and quantize (forward and inverse).
 *	Section: MultiMedia - Core Technologies
 *	History:
 *		05-01-2002 - Alpha, file created
 * $Id: tech_dctq.h,v 1.1 2003/11/04 15:42:31 dmeyer Exp $
 */
#ifndef	_TECH_DCTQ_H_
#define	_TECH_DCTQ_H_

#include	"wsdf.h"
#include	"multimedia.h"



/**	SECTION - constants and data exchange structures
 */

/**	ENDOFSECTION
 */



/**	SECTION - interface functions' declaration for C++
 */
#ifdef __cplusplus
	class CTechIQ
	{
		SINT32 member;				// handle pointing to a member structure

		public:
		// constructor
				CTechIQ(
					SINT8	mode,			// 'MultiMedia.H': EVideoFormat
					UINT8	*intraQ			// user defined quantize table for intra blocks
							= NULL,			//   NULL indicates default table
					UINT8	*interQ			// user defined quantize table for inter blocks
							= NULL			//   NULL indicates default table
					);

		// distructor
				~CTechIQ();

		// to dequantize macroblock DC values
		SINT32*	DCIQ(
					SINT32	*dcIQ,			// buffer to return dequantized dc values
					SINT32	*dc,			// quantized dc values
					SINT8	Q,				// quantize scale
					SINT8	mbtype,			// 'MultiMedia.H': EMBType
					SINT32	&round			// return rounding information
					);
		// return pointer to AC dequantize matrix
	};
#endif

/**	ENDOFSECTION
 */



/**	SECTION - inline functions declaration
 */

#include	"inverse_dctq.h"

/**	ENDOFSECTION
 */



#endif
/**	ENDOFHEADERFILE: "Tech_DCTQ.h"
 */
