/**	HEADERFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_FMT/BASE_VLD.H"
 *	Description: prototype of class CBaseVld and some structs definition for VLD 
 *	History:
 *		05-07-2002 - Weimin, file created
 * $Id: base_vld.h,v 1.1 2003/11/04 15:42:29 dmeyer Exp $
 */
#ifndef _MM_TECHBASE_VLD_H_
#define _MM_TECHBASE_VLD_H_

#include	"tech_fmt.h"
#include	"mm.h"
#include	"code.h"
#include 	"wsdf.h"

typedef struct
{
	SINT8 last, run, level, len;
}VLDtable;

class CBaseVld : public ITech_VLD
{
protected:
	MpgvlcManager	vlc;
	MpgvlcManager	iniVlc;

	TMP_StrInfo		*strInfo;
	TMP_FrmInfo		*frmInfo;
	TMP_BlkPair		*blkPair;

	SINT32			bits_quota;

public:
	INLINE void		nextstartcode()
	{
		vlcSkip(&vlc, vlc.count - 24);
		if (vlcRead(&vlc, 8) == 0x7F)
			vlcSkip(&vlc, 8);
		while (vlcRead(&vlc, 24) != 0x000001)
			vlcSkip(&vlc, 8);
	};

	INLINE void		align()
	{
		vlcSkip(&vlc, vlc.count - 24);
	}

	INLINE void		store_coding_state()
	{
		iniVlc = vlc;
	};
	INLINE SINT32	reset_coding_state(SINT32 &bits, SINT32 errCode)
	{
		vlc = iniVlc;
		bits = vlc.index;
		return errCode;
	};

public:
	CBaseVld(TMP_StrInfo *sInfo, TMP_FrmInfo *fInfo, TMP_BlkPair *mPair);

	virtual ~CBaseVld();

	virtual void StrInit(UINT8 *stream, SINT32 quota);
	virtual SINT32	StrHead(SINT32 &bits) { bits = vlc.index; return SUCCESS; };
	virtual SINT32	StrTail(SINT32 &bits) { bits = vlc.index; return SUCCESS; };
	virtual SINT32	GopHead(SINT32 &bits, SINT8* data) { bits = vlc.index; data[0] = 0; return SUCCESS; };
	virtual SINT32	FrmTail(SINT32 &bits) { bits = vlc.index; return SUCCESS; };

	STATIC	SINT32 CreateInstance(ITech_VLD	**pp, TMP_StrInfo *sInfo, TMP_FrmInfo *fInfo, TMP_BlkPair *mPair);
	void	Release();

protected:
	SINT32 Tc2Frame(SINT32 tc, REAL64 fps);
};


#endif
