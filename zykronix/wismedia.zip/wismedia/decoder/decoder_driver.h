/********************************************************************************
*
*   FILE: 
*		decoder_driver.c
*
*   DESCRIPTION:
*		This is the decoder driver.
*
*
* $Id: decoder_driver.h,v 1.1 2003/11/04 15:42:30 dmeyer Exp $
* 
*********************************************************************************/
 



typedef struct {

	uint8	*pFrame;
	uint32  frameLen;

} encoder_frame_t;

typedef
struct decoder_stream_config_s{
    int bpp;
    int screenWidth;
    int screenHeight;
    int inputMode;
    int outputMode;
} decoder_stream_config_t;

