/**	HEADERFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_FMT/MP2_VLD.H"
 *	Description: prototype of class CMp2Vld and definition of tables used by MPEG2 VLD 
 *	History:
 *		08-27-2002 - Weimin, file created
 */
#ifndef _MPEG2_VLD_H_
#define _MPEG2_VLD_H_

#include "base_vld.h"
#include "mp1_vld.h"

class CMp2Vld : public CMp1Vld
{
public:
	CMp2Vld(TMP_StrInfo *sInfo, TMP_FrmInfo *fInfo, TMP_BlkPair *mPair) : CMp1Vld(sInfo, fInfo, mPair) { };

	SINT32 StrHead(SINT32 &bits);
	SINT32 GopHead(SINT32 &bits, SINT8* data);
	SINT32 FrmHead(SINT32 &bits);
	SINT32 StrMblk(TMP_BlkInfo *mb00, TMP_BlkInfo *mb01, TMP_BlkInfo *mb02, 
		TMP_BlkInfo *mb10, TMP_BlkInfo *mb11)
	{
		return CMp1Vld::StrMblk(mb00, mb01, mb02, mb10, mb11);
	}

	SINT32 vld8x8(SINT8 first, MpgvlcManager *vlc, SINT8 *run, SINT32 *lvl);
};

#endif
