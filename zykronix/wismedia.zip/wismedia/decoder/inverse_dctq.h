/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_DCTQ/TechIQ.cpp"
 *	Description: Inverse DCT/Q inline functions implementation.
 *	History:
 *		05-02-2002 - Alpha, file created
 * $Id: inverse_dctq.h,v 1.1 2003/11/04 15:42:30 dmeyer Exp $
 */
#include	"wsdf.h"
#include	"multimedia.h"
#include	"mm.h"



/**	SECTION - inline functions implementation
 */
#if MMX_SUPPORT

INLINE	void	IQ8x8(
			SINT32 *acQ, SINT16 *c8x8, SINT32 pair, SINT8 *run, SINT32 *lvl,
			SINT8 mbtype, SINT8 round
			)
{
	SINT32 i, j, n = (mbtype & MB_INTRA) ? 1 : 0;
	for(j = 0; j < pair; j ++)
	{
		if((n += run[j]) > 63) return; i = TabTZScan[n ++];
		SINT32 q = acQ[i], l = lvl[j], r = (round ? (q >> 1) : 0) + 32767;
		c8x8[i] = (q * l + ((l > 0) ? r : - r)) >> 16;
	}
}


CONST SINT16 Sround = (1 << (DCTSCL - 1 ));
CONST SINT16 TabIDCT[16] = {
	 30274,  30274,  30274,  30274,	// cos(2/16) * 32768
	 23170,  23170,  23170,  23170,	// cos(4/16) * 32768
	 12540,  12540,  12540,  12540,	// cos(6/16) * 32768
	Sround, Sround, Sround, Sround,	// rounding
};

INLINE	void	IDCT8x8(SINT16 *c8x8, SINT16 *m8x8)
{
	__asm
	{
		mov			eax,				c8x8
		mov			ebx,				m8x8
		lea			ecx,				TabIDCT

		paddsw		mm0,				Mptr [eax]			; decode group blocking
		mov			CNT,				4
		jmp			idct_matrix4x8

m4x8_to_m8x4:
		// move bottom 4x4 to right 4x4

		movq		Mptr [eax +  64],	mm4
		movq		mm4,				mm0
		punpcklwd	mm0,				mm1					;  5  1    4  0

		movq		Mptr [eax +  96],	mm6
		movq		mm6,				mm2
		punpcklwd	mm2,				mm3					; 13  9   12  8

		punpckhwd	mm4,				mm1					;  7  3    6  2
		punpckhwd	mm6,				mm3					; 15 11   14 10

		movq		mm1,				mm0
		punpckldq	mm0,				mm2					; 12  8    4  0

		movq		mm3,				mm4
		punpckldq	mm4,				mm6					; 14 10    6  2

		movq		Mptr [ebx +   8],	mm0

		movq		Mptr [ebx +  40],	mm4
		punpckhdq	mm1,				mm2					; 13  9    5  1
		punpckhdq	mm3,				mm6					; 15 11    7  3

		movq		Mptr [ebx +  24],	mm1
		movq		mm1,				mm5
		movq		mm0,				Mptr [eax +  64]

		movq		Mptr [ebx +  56],	mm3
		movq		mm3,				mm7
		movq		mm6,				Mptr [eax +  96]

		// move top 4x4 to left 4x4

		punpcklwd	mm1,				mm0					;  5  1    4  0
		punpckhwd	mm5,				mm0					;  7  3    6  2

		punpcklwd	mm3,				mm6					; 13  9   12  8
		punpckhwd	mm7,				mm6					; 15 11   14 10

		movq		mm2,				mm1
		punpckldq	mm1,				mm3					; 12  8    4  0

		movq		mm4,				mm5
		punpckldq	mm5,				mm7					; 14 10    6  2

		movq		Mptr [ebx +   0],	mm1
		punpckhdq	mm2,				mm3					; 13  9    5  1
		punpckhdq	mm4,				mm7					; 15 11    7  3

		movq		Mptr [ebx +  32],	mm5

		movq		Mptr [ebx +  16],	mm2
		add			eax,				8
		add			ebx,				64

		movq		Mptr [ebx -  16],	mm4
		cmp			CNT,				3
		je			idct_matrix4x8

		mov			eax,				m8x8
		mov			ebx,				c8x8

		// end of matrix transpose

idct_matrix4x8:
		// line 3, 5, 1, 7 to 4, 5, 6, 7 to 6, 7, 4, 5

		movq		mm0,				Mptr [eax +  48]
		movq		mm4,				Mptr [eax +  48]	; f0(3x)
		movq		mm5,				Mptr [eax +  80]	; f0(5x)

		movq		mm1,				Mptr [eax +  16]
		movq		mm6,				Mptr [eax +  16]	; f0(1x)
		movq		mm7,				Mptr [eax + 112]	; f0(7x)

		movq		mm2,				Mptr [ecx +  16]	; c6
		psubsw		mm4,				mm5					; f1(4x) = f0(3x) - f0(5x)
		psubsw		mm6,				mm7					; f1(6x) = f0(1x) - f0(7x)

		movq		mm3,				Mptr [ecx +   0]	; c2
		paddsw		mm5,				mm0					; f1(5x) = f0(5x) + f0(3x)
		paddsw		mm7,				mm1					; f1(7x) = f0(7x) + f0(1x)

		movq		mm1,				Mptr [ecx +   8]	; c4
		pmulhw		mm4,				mm2					; f1(4x) = f1(4x) * c6
		pmulhw		mm6,				mm3					; f1(6x) = f1(6x) * c2

		psllw		mm4,				2					; f1(4x) = f1(4x) * 4
		psllw		mm6,				2					; f1(6x) = f1(6x) * 4

		psubsw		mm4,				mm5					; f1(4x) = f1(4x) - f1(5x)
		psubsw		mm6,				mm7					; f1(6x) = f1(6x) - f1(7x)

		movq		mm2,				mm4
		movq		mm3,				mm5

		paddsw		mm4,				mm6					; f2(4x) = f1(4x) + f1(6x)
		paddsw		mm5,				mm7					; f2(5x) = f1(5x) + f1(7x)

		psubsw		mm6,				mm2					; f2(6x) = f1(6x) - f1(4x)
		psubsw		mm7,				mm3					; f2(7x) = f1(7x) - f1(5x)

		pmulhw		mm6,				mm1					; f2(6x) = f2(6x) * c4
		pmulhw		mm7,				mm1					; f2(7x) = f2(7x) * c4

		movq		Mptr [eax +  16],	mm5					; f2(5x)
		psllw		mm6,				2					; f2(6x) = f2(6x) * 4
		psllw		mm7,				2					; f2(7x) = f2(7x) * 4

		movq		Mptr [eax +  48],	mm4					; f2(4x)
		psubsw		mm6,				mm5					; f2(6x) = f2(6x) - f2(5x)
		psubsw		mm7,				mm4					; f2(7x) = f2(7x) - f2(4x)

		// line 4, 0, 2, 6 to 0, 1, 2, 3 to 3, 2, 1, 0

		movq		mm2,				Mptr [eax +  32]	; f0(2x)
		movq		mm3,				Mptr [eax +  96]	; f0(6x)
		movq		mm0,				Mptr [eax +  32]

		movq		Mptr [eax +  80],	mm7					; f2(7x)
		psubsw		mm2,				mm3					; f1(2x) = f0(2x) - f0(6x)
		paddsw		mm3,				mm0					; f1(3x) = f0(6x) + f0(2x)

		pmulhw		mm2,				mm1					; f1(2x) = f1(2x) * c4
		movq		mm0,				Mptr [eax +  64]	; f0(4x)
		movq		mm1,				Mptr [eax +   0]	; f0(0x)

		movq		Mptr [eax + 112],	mm6					; f2(6x)
		psllw		mm2,				2					; f1(2x) = f1(2x) * 4
		psubsw		mm2,				mm3					; f1(2x) = f1(2x) - f1(3x)

		paddsw		mm0,				mm1					; f1(0x) = f0(4x) + f0(0x)
		movq		mm4,				mm2					; f1(2x)
		movq		mm5,				mm3					; f1(3x)

		psubsw		mm1,				Mptr [eax +  64]	; f1(1x) = f0(0x) - f0(4x)
		paddsw		mm3,				mm0					; f2(3x) = f1(3x) + f1(0x)
		psubsw		mm0,				mm5					; f2(0x) = f1(0x) - f1(3x)

		movq		mm5,				Mptr [eax +  16]
		paddsw		mm2,				mm1					; f2(2x) = f1(2x) + f1(1x)
		psubsw		mm1,				mm4					; f2(1x) = f1(1x) - f1(2x)

		// final stage, line 3, 2, 1, 0, 6, 7, 4, 5 to 5, 4, 7, 6, 0, 1, 2, 3

		movq		mm4,				Mptr [eax +  48]
		paddsw		mm5,				mm3					; f3(5x) = f2(5x) + f2(3x)

		psubsw		mm3,				Mptr [eax +  16]	; f3(3x) = f2(3x) - f2(5x)
		paddsw		mm4,				mm2					; f3(4x) = f2(4x) + f2(2x)

		psubsw		mm2,				Mptr [eax +  48]	; f3(2x) = f2(2x) - f2(4x)
		paddsw		mm7,				mm1					; f3(7x) = f2(7x) + f2(1x)
		paddsw		mm6,				mm0					; f3(6x) = f2(6x) + f2(0x)

		psubsw		mm1,				Mptr [eax +  80]	; f3(1x) = f2(1x) - f2(7x)
		sub			CNT,				1

		psubsw		mm0,				Mptr [eax + 112]	; f3(0x) = f2(0x) - f2(6x)
		cmp			CNT,				1
		jg			m4x8_to_m8x4

		// end of 1d transform

		// rounding - shifting - output

		movq		Mptr [ebx + 112],	mm3
		movq		mm3,				Mptr [ecx +  24]

		paddsw		mm5,				mm3
		paddsw		mm4,				mm3

		paddsw		mm7,				mm3
		paddsw		mm6,				mm3

		psraw		mm5,				6
		psraw		mm4,				6

		movq		Mptr [ebx +   0],	mm5
		psraw		mm7,				6
		psraw		mm6,				6

		movq		Mptr [ebx +  16],	mm4
		paddsw		mm0,				mm3
		paddsw		mm1,				mm3

		movq		Mptr [ebx +  32],	mm7
		psraw		mm0,				6
		psraw		mm1,				6

		movq		Mptr [ebx +  48],	mm6
		paddsw		mm2,				mm3
		movq		mm7,				Mptr [ebx + 112]

		movq		Mptr [ebx +  64],	mm0
		psraw		mm2,				6
		paddsw		mm3,				mm7

		movq		Mptr [ebx +  80],	mm1
		psraw		mm3,				6

		movq		Mptr [ebx +  96],	mm2
		add			eax,				8
		add			ebx,				8

		movq		Mptr [ebx + 104],	mm3
		cmp			CNT,				1
		je			idct_matrix4x8
	}
}

#else

#define		TC2		121095 
#define		TC4		92682 
#define		TC6		50159 

//#define		TC2		(30274 * 4)
//#define		TC4		(23170 * 4)
//#define		TC6		(12540 * 4)

/**********************************************************************
	NAME: ijdct_row
	DESCRIPTION: do row-based inverse DCT to a 1x8 row, the result is 
				 stored back
	PARAMETER:
			(in) : SINT16 *blk
			(out): SINT16 *blk
**********************************************************************/
INLINE void ijdct_row(SINT16 *blk)
{

	SINT32 x0, x1, x2, x3, x4, x5, x6, x7, xt;
  	
 
 /* Let's begin the butterfly procession! */

 /* First Pipe */
	x0 = blk[0] + blk[4];
	x1 = blk[0] - blk[4];
	x2 = blk[2] - blk[6];
	x3 = blk[2] + blk[6];
	x4 = blk[3] - blk[5];
	x5 = blk[3] + blk[5];
	x6 = blk[1] - blk[7];
	x7 = blk[1] + blk[7];

  /* Second Pipe */
	x2 = ((TC4 * x2)>>16) - x3;
	x4 = ((TC6 * x4)>>16) - x5;
	x6 = ((TC2 * x6)>>16) - x7;

  /* Third Pipe */
	xt = x0 + x3;
	x3 = x0 - x3;
	x0 = xt;
	xt = x1 + x2;
	x2 = x1 - x2;
	x1 = xt;
	xt = x6 - x4;
	x6 = x6 + x4;
	x4 = xt;
	xt = x7 - x5;
	x7 = x7 + x5;
	x5 = xt;

 /* Fourth Pipe */
	x4 = ((TC4 * x4)>>16) - x7;
	x5 = ((TC4 * x5)>>16) - x6;
 
 /* Fifth Pipe */
	blk[0] = (x0 + x7);
	blk[1] = (x1 + x6);
	blk[2] = (x2 + x5);
	blk[3] = (x3 + x4);
	blk[4] = (x3 - x4);
	blk[5] = (x2 - x5);
	blk[6] = (x1 - x6);
	blk[7] = (x0 - x7);
}

/**********************************************************************
	NAME: ijdct_col
	DESCRIPTION: do column-based inverse DCT to a 8x1 column, the result is 
				 stored to a 16x16 SINT16 matrix
	PARAMETER:
			(in) : SINT32 *blk
			(out): SINT16 *idctblk
**********************************************************************/
INLINE void ijdct_col(SINT16 *blk)
{
	SINT32 x0, x1, x2, x3, x4, x5, x6, x7, xt;
  	
 
 /* Let's begin the butterfly procession! */

 /* First Pipe */
	x0 = blk[0]  +  blk[32];
	x1 = blk[0]  -  blk[32];
	x2 = blk[16] -  blk[48];
	x3 = blk[16] +  blk[48];
	x4 = blk[24] -  blk[40];
	x5 = blk[24] +  blk[40];
	x6 = blk[8]  -  blk[56];
	x7 = blk[8]  +  blk[56];

  /* Second Pipe */
	x2 = ((TC4 * x2)>>16) - x3;
	x4 = ((TC6 * x4)>>16) - x5;
	x6 = ((TC2 * x6)>>16) - x7;

  /* Third Pipe */
	xt = x0 + x3;
	x3 = x0 - x3;
	x0 = xt;
	xt = x1 + x2;
	x2 = x1 - x2;
	x1 = xt;
	xt = x6 - x4;
	x6 = x6 + x4;
	x4 = xt;
	xt = x7 - x5;
	x7 = x7 + x5;
	x5 = xt;

 /* Fourth Pipe */
	x4 = ((TC4 * x4)>>16) - x7;
	x5 = ((TC4 * x5)>>16) - x6;
 
 /* Fifth Pipe */
	blk[0]  = CLP((x0 + x7 + 32)>>6, -256, 255);
	blk[8]  = CLP((x1 + x6 + 32)>>6, -256, 255);
	blk[16] = CLP((x2 + x5 + 32)>>6, -256, 255);
	blk[24] = CLP((x3 + x4 + 32)>>6, -256, 255);
	blk[32] = CLP((x3 - x4 + 32)>>6, -256, 255);
	blk[40] = CLP((x2 - x5 + 32)>>6, -256, 255);
	blk[48] = CLP((x1 - x6 + 32)>>6, -256, 255);
	blk[56] = CLP((x0 - x7 + 32)>>6, -256, 255);
}

// two dimensional inverse discrete cosine transform
INLINE	void	IDCT8x8(SINT16 *c8x8, SINT16 *m8x8)
{
    int i;
	for (i = 0; i < 8; i++)
		ijdct_row(c8x8 + 8 * i);

	for (i = 0; i < 8; i++)
		ijdct_col(c8x8 + i);

}

INLINE	void	IQ8x8(
			SINT32 *acQ, SINT16 *c8x8, SINT32 pair, SINT8 *run, SINT32 *lvl,
			SINT8 mbtype, SINT8 round
			)
{
	SINT32 i, j, n = (mbtype & MB_INTRA) ? 1 : 0;
	for(j = 0; j < pair; j ++)
	{
		if((n += run[j]) > 63) return; i = TabNZScan[n ++];
		SINT32 q = acQ[i], l = lvl[j], r = (round ? (q >> 1) : 0) + 32767;
		c8x8[i] = (q * l + ((l > 0) ? r : - r)) >> 16;
	}
}

#endif


/**	ENDOFSECTION
 */



/**	ENDOSOURCEFILE: "Inverse_DCTQ.cpp"
 */
