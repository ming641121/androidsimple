/**	HEADERFILE: "WSDF/WISDevelop/WISLib/MultiMedia/MP_UniDecTSC/BLKDecTSC.h"
 *	Description: Universal Decoder-Transcoder - decode and transcode a macroblock.
 *	History:
 *		05-05-2002 - Alpha, file created 
 * $Id: blkdec.h,v 1.1 2003/11/04 15:42:29 dmeyer Exp $
 */

/**	SECTION - class declaration and partial implementation
 */
 
#ifdef XSCALE
extern "C" {
void pmuXpotStart(void);
void pmuXpotFinish(void);
void pmuDcmpStart(void);
void pmuDcmpFinish(void);     
void pmuIdctStart(void);
void pmuIdctFinish(void);
};
#endif

	class CBLKDec
	{
		ITech_VLD	*vld;

		TMP_StrInfo	*sInfo;		// buffer for stream header
		TMP_FrmInfo	*fInfo;		// buffer for frame header
		TMP_BlkPair	*mPair;		// buffer for macroblock run-level pairs

		SINT32	h0;
		SINT32	h1;
		SINT32	v0;
		SINT32	v1;
		SINT8	Y4PP;
		SINT8	UVPP;
		SINT8	dDraw;

		CTechIQ		*cIQ;
		CUniDecMEM	*cMEM;
		TUniDecMEM	unidec;

		SINT8	doDec;
		SINT8	doDSP;

		// output memory YUV411, added by weimin, 09/25/2003
		UINT8	*opMemY;
		UINT8	*opMemU;
		UINT8	*opMemV;

		public:
		// constructor
				CBLKDec(
					ITech_VLD	*vld,
					TMP_StrInfo	*sInfo,		// buffer for stream header
					TMP_FrmInfo	*fInfo,		// buffer for frame header
					TMP_BlkPair	*mPair,		// buffer for macroblock run-level pairs
					SINT8	dDraw,
					SINT32	id,
					SINT8	*clipTbl,
					SINT32	mbln
					);

		// distructor
				~CBLKDec();

		void	PProcSetup(
					SINT8	Y4PP,
					SINT8	UVPP,
					SINT32	h0,
					SINT32	h1,
					SINT32	v0,
					SINT32	v1
					);

		void	UpdateFrame(
					SINT8	doDec,
					UINT8	*opMem,
					SINT32	ddWidth
					);

		SINT32	Decode(
					TMP_StrMBInfo	*BI
					)
		{
	 
            cMEM->UpdateMacroblock();
			TMP_BlkInfo &cur = unidec.ref11->bInfo;

			cur.col = unidec.col; cur.row = unidec.row;
			SINT32 decoded = -1, i;

			// VLD
			decoded = vld->StrMblk(
					&(unidec.ref00->bInfo),
					&(unidec.ref01->bInfo),
					&(unidec.ref02->bInfo),
					&(unidec.ref10->bInfo),
					&cur
					);

			fInfo->fq += cur.Q;

			if(!doDec) return decoded;

			// start optional decoding
			SINT32 dcIQ[6], *acQ, round;
			acQ = cIQ->DCIQ(dcIQ, cur.dc, cur.Q, cur.mbtype, round);

			if((cur.mbtype & MB_INTRA) == 0)
			{
				SINT32 Xmin = - (unidec.col << 5);
				SINT32 Xmax = (unidec.cols - unidec.col - 1) << 5;
				SINT32 Ymin = - (unidec.row << 5);
				SINT32 Ymax = (unidec.rows - unidec.row - 1) << 5;

				if(	(cur.vx[0] < Xmin) ||
					(cur.vx[0] > Xmax) ||
					(cur.vy[0] < Ymin) ||
					(cur.vy[0] > Ymax)
					)
				cur.vx[0] = cur.vx[1] = cur.vx[2] = cur.vx[3] = cur.vx[4] = cur.vx[5] =
				cur.vy[0] = cur.vy[1] = cur.vy[2] = cur.vy[3] = cur.vy[4] = cur.vy[5] = 0;

				TUniDecMB *ref = (cur.mbtype & MB_BACKWARD) ? unidec.posMb : unidec.preMb;
				for(i = 0; i < 6; i ++)
					unidec.refMb->c8x8[i].ptr = ref->c8x8[i].ptr +
						(cur.vx[i] >> 1) + (cur.vy[i] >> 1) * unidec.refMb->c8x8[i].offset;
			}

			CONST SINT32 ODD[2][2] = {
				{ PIXEL_XI_YI, PIXEL_XI_YH }, { PIXEL_XH_YI, PIXEL_XH_YH }
			};
			for(i = 0; i < 6; i ++)
			{
				if(mPair->pair[i] == 0)
					MSET8x8(unidec.c8x8, dcIQ[i] >> DCTSCL);
				// mmx
				else
				{
					// dequantize and inverse dct
					MSET8x8(unidec.c8x8, 0); unidec.c8x8[0] = dcIQ[i];
					IQ8x8(
						acQ, unidec.c8x8,
						mPair->pair[i], mPair->run[i], mPair->lvl[i], cur.mbtype, round
						);
					//pmuIdctStart();
                    IDCT8x8(unidec.c8x8, unidec.memTmp);	// mmx
                    //pmuIdctFinish();
				}

				// decompensation
				if((cur.mbtype & MB_INTRA) == 0){
                 //pmuDcmpStart();
					DCMP8x8(
						unidec.c8x8, ODD[cur.vx[i] & 1][cur.vy[i] & 1],
						unidec.refMb->c8x8[i].ptr, unidec.refMb->c8x8[i].offset
						);
                 //pmuDcmpFinish();
                }
                    // mmx

				// save back to frame buffer, downgrade from 16bit to 8bit
				//pmuXpotStart();
                XPOT8x8(unidec.c8x8, unidec.curMb->c8x8[i].ptr, unidec.curMb->c8x8[i].offset);
				//pmuXpotFinish();
                // mmx
			}

#if MMX_SUPPORT
			__asm emms
#endif
			if(!doDSP) return decoded;
			// start optional postprocess and output

			SINT8 ccMask[4];
			SINT8 cpMask[4] = {
				unidec.ref00->mask,
				unidec.ref01->mask,
				unidec.ref10->mask,
				unidec.ref11->mask,
			};
			TUniDecUnit *mbShow[4]; TUniDecMB *mbMem[4];

			if(!Y4PP && !UVPP)	// no postprocess
			{
				mbShow[3] = unidec.mbShow; mbMem[3] = unidec.outMb;
				ccMask[0] = ccMask[1] = ccMask[2] = 0; ccMask[3] = 1;
			}
			else if(cpMask[3])	// postprocess required
			{
#if MMX_SUPPORT
				SINT16 Q8[4], Q2[4];
				Q8[0] = Q8[1] = Q8[2] = Q8[3] = ((SINT16)cur.Q) << 3;
				Q2[0] = Q2[1] = Q2[2] = Q2[3] = ((SINT16)cur.Q) << 1;

				mbShow[0] = &(unidec.ref00->mbShow); mbMem[0] = &(unidec.ref00->mbMem);
				mbShow[1] = &(unidec.ref01->mbShow); mbMem[1] = &(unidec.ref01->mbMem);
				mbShow[2] = &(unidec.ref10->mbShow); mbMem[2] = &(unidec.ref10->mbMem);
				mbShow[3] = &(unidec.ref11->mbShow); mbMem[3] = &(unidec.ref11->mbMem);

				SINT8 hc = unidec.col > 0, hcc = unidec.col == unidec.cols - 1;
				SINT8 vc = unidec.row > 0, vcc = unidec.row == unidec.rows - 1;

				ccMask[0] = hc && vc ; ccMask[1] = hcc && vc ;
				ccMask[2] = hc && vcc; ccMask[3] = hcc && vcc;

				mbShow[3]->offset = unidec.mbShow->offset;
				mbShow[3]->ptr = unidec.mbShow->ptr;

				if(fInfo->ftype < B_FRAME)
					for(i = 0; i < 6; i ++)
						COPY8x8(mbMem[3]->c8x8[i].ptr, mbMem[3]->c8x8[i].offset,
							unidec.outMb->c8x8[i].ptr, unidec.outMb->c8x8[i].offset);
					// mmx

				SINT32 dh0 = unidec.col - h0, dh1 = h1 - unidec.col;
				SINT32 dv0 = unidec.row - v0, dv1 = v1 - unidec.row;

				if((dh0 >= 0) && (dh1 >= 0) && (dv0 >= 0) && (dv1 >= 0))
				{
					SINT8 hp = dh0 > 0, hpp = dh1 == 0, vp = dv0 > 0, vpp = dv1 == 0;
					SINT8 hpMask[6] = { hp, 1, hp, 1, hp, hp };
					SINT8 vpMask[6] = { vp, vp, 1, 1, vp, vp };
					SINT32 N, width;
					UINT8 *f64, *m64 = (UINT8*)(unidec.c8x8 + 16);

					// deblocking horizontally
					if((Y4PP > 0))
					{
						TUniDecUnit *unit[10] = {
							&(mbMem[2]->c8x8[1]), &(mbMem[3]->c8x8[0]), &(mbMem[3]->c8x8[1]),
							&(mbMem[2]->c8x8[3]), &(mbMem[3]->c8x8[2]), &(mbMem[3]->c8x8[3]),
							&(mbMem[2]->c8x8[4]), &(mbMem[3]->c8x8[4]),
							&(mbMem[2]->c8x8[5]), &(mbMem[3]->c8x8[5]),
						};
						CONST SINT32 ih[6] = { 1, 2, 4, 5, 7, 9 };

						N = (UVPP < 1) ? 6 : 10;
						for(i = 0; i < N; i ++)
							TRANSPOSE8x8(unidec.blkhp[i], 8, unit[i]->ptr, unit[i]->offset, m64);
						// mmx

						N = (UVPP < 1) ? 4 : 6;
						for(i = 0; i < N; i ++)
							if(hpMask[i])
							{
								UINT8 *ptr = unidec.blkhp[ih[i]] - 32;
								width = mbMem[3]->c8x8[i].offset;
								f64 = mbMem[3]->c8x8[i].ptr - 4;
								if(DBLK8x8(ptr, ptr, 8, Q8, Q2, m64))
									TRANSPOSE8x8(f64, width, ptr, 8, m64);
							}
						// mmx
					}

					// deblocking vertically
					if((Y4PP > 1))
					{
						TUniDecUnit *unit[10] = {
							&(mbMem[1]->c8x8[2]), &(mbMem[3]->c8x8[0]), &(mbMem[3]->c8x8[2]),
							&(mbMem[1]->c8x8[3]), &(mbMem[3]->c8x8[1]), &(mbMem[3]->c8x8[3]),
							&(mbMem[1]->c8x8[4]), &(mbMem[3]->c8x8[4]),
							&(mbMem[1]->c8x8[5]), &(mbMem[3]->c8x8[5]),
						};
						CONST SINT32 iv[6] = { 1, 4, 2, 5, 7, 9 };

						N = (UVPP < 2) ? 6 : 10;
						for(i = 0; i < N; i ++)
							COPY8x8(unidec.blkhp[i], 8, unit[i]->ptr, unit[i]->offset);
						// mmx

						N = (UVPP < 2) ? 4 : 6;
						for(i = 0; i < N; i ++)
							if(vpMask[i])
							{
								UINT8 *ptr = unidec.blkhp[iv[i]] - 32;
								width = mbMem[3]->c8x8[i].offset;
								f64 = mbMem[3]->c8x8[i].ptr - (width << 2);
								DBLK8x8(ptr, f64, width, Q8, Q2, m64);
							}
						// mmx
					}

					// deringing filter
					if((Y4PP > 2) && hp && vp)
					{
						N = (UVPP < 3) ? 4 : 6;

						SINT32 cwidth[6];
						cwidth[0] = cwidth[1] = cwidth[2] = cwidth[3] = mbMem[0]->c8x8[0].offset;
						cwidth[4] = cwidth[5] = mbMem[0]->c8x8[4].offset;

						UINT8 *c[6] = {
							mbMem[0]->c8x8[3].ptr,
							mbMem[1]->c8x8[2].ptr,
							mbMem[2]->c8x8[1].ptr,
							mbMem[3]->c8x8[0].ptr,
							mbMem[0]->c8x8[4].ptr + (cwidth[4] << 2) + 4,
							mbMem[0]->c8x8[5].ptr + (cwidth[5] << 2) + 4
						};
						DERINGING(c, cwidth, N, unidec.memTmp);
					}
				}
#else
				mbShow[3] = unidec.mbShow; mbMem[3] = unidec.outMb;
				ccMask[0] = ccMask[1] = ccMask[2] = 0; ccMask[3] = 1;
#endif  // MMX_SUPPORT
			}
			// optional output
			for(i = 0; i < 4; i ++)
				if(ccMask[i] && cpMask[i])
				{
					SINT32 width = mbShow[i]->offset;
					switch(dDraw)
					{
					case DDRAW_YV12:
						MB2YUV420(opMemY, opMemU, opMemV, unidec.cols * 16, 
								unidec.col, unidec.row, 
								mbMem[i]->c[0]->ptr, mbMem[i]->c[0]->offset,
								mbMem[i]->c[1]->ptr, mbMem[i]->c[1]->offset,
								mbMem[i]->c[2]->ptr, mbMem[i]->c[2]->offset
						);
						break;
					case DDRAW_YUY2 :
						MB2YUYV(mbShow[i]->ptr, width,
								mbMem[i]->c[0]->ptr, mbMem[i]->c[0]->offset,
								mbMem[i]->c[1]->ptr, mbMem[i]->c[1]->offset,
								mbMem[i]->c[2]->ptr, mbMem[i]->c[2]->offset
						);
						break;

					case DDRAW_UYVY :
						MB2UYVY(mbShow[i]->ptr, width,
								mbMem[i]->c[0]->ptr, mbMem[i]->c[0]->offset,
								mbMem[i]->c[1]->ptr, mbMem[i]->c[1]->offset,
								mbMem[i]->c[2]->ptr, mbMem[i]->c[2]->offset
						);
						break;

					case DDRAW_DIB24:
						width = - width;
					case DDRAW_RGB24:
						MB2BGR3(mbShow[i]->ptr, width,
								mbMem[i]->c[0]->ptr, mbMem[i]->c[0]->offset,
								mbMem[i]->c[1]->ptr, mbMem[i]->c[1]->offset,
								mbMem[i]->c[2]->ptr, mbMem[i]->c[2]->offset,
								(UINT32*)unidec.memTmp
						);
						break;

					case DDRAW_DIB32:
						width = - width;
					case DDRAW_RGB32:
						MB2BGR4(mbShow[i]->ptr, width,
								mbMem[i]->c[0]->ptr, mbMem[i]->c[0]->offset,
								mbMem[i]->c[1]->ptr, mbMem[i]->c[1]->offset,
								mbMem[i]->c[2]->ptr, mbMem[i]->c[2]->offset,
								(UINT32*)unidec.memTmp
						);
						break;
					case DDRAW_DIB565:
						width = - width;
					case DDRAW_RGB565:
						MB2RGB565(mbShow[i]->ptr, width,
								mbMem[i]->c[0]->ptr, mbMem[i]->c[0]->offset,
								mbMem[i]->c[1]->ptr, mbMem[i]->c[1]->offset,
								mbMem[i]->c[2]->ptr, mbMem[i]->c[2]->offset,
								(UINT32*)unidec.memTmp
						);
						break;
					case DDRAW_DIB555:
						width = - width;
					case DDRAW_RGB555:
						MB2RGB555(mbShow[i]->ptr, width,
								mbMem[i]->c[0]->ptr, mbMem[i]->c[0]->offset,
								mbMem[i]->c[1]->ptr, mbMem[i]->c[1]->offset,
								mbMem[i]->c[2]->ptr, mbMem[i]->c[2]->offset,
								(UINT32*)unidec.memTmp
						);
						break;
					}
				}
				// mmx

#if MMX_SUPPORT
			__asm emms
#endif
			return decoded;
		}


		SINT32	GetSnapShotBMP(UINT8 *bmp, SINT8 ddraw)
		{
			if (!bmp || !sInfo)
				return ERR_MEMORY;
			
			SINT32 i, j;
			UINT8 *pSrcY;
			UINT8 *pSrcU;
			UINT8 *pSrcV;
			SINT32 factor = ddraw == DDRAW_DIB24 ? 3 : 4;
			SINT32 width = sInfo->cols * 16 * factor;
			SINT32 yoff  = sInfo->cols * 16;
			SINT32 uvoff = sInfo->cols * 8;
			UINT8 *pDest = bmp;

			for (i = 0; i < sInfo->rows; i++)
			{
				pDest = bmp + width * (sInfo->rows - i) * 16;
				pSrcY = unidec.prevfrm->c[0] + i * 16 * sInfo->cols * 16;
				pSrcU = unidec.prevfrm->c[1] + i * 8 * sInfo->cols * 8;
				pSrcV = unidec.prevfrm->c[2] + i * 8 * sInfo->cols * 8;
				for (j = 0; j < sInfo->cols; j++)
				{
					MB2BGR3(pDest, -width,
							pSrcY, yoff,
							pSrcU, uvoff,
							pSrcV, uvoff,
							(UINT32*)unidec.memTmp);
					pSrcY += 16;
					pSrcU += 8;
					pSrcV += 8;
					pDest += 16 * factor;
				}
			}
#if MMX_SUPPORT
			__asm emms
#endif
			return SUCCESS;
		}

		SINT32	GetSnapShotYUV411(UINT8 *yuv411)
		{
			if (!yuv411 || !sInfo)
				return ERR_MEMORY;

			SINT32 size = sInfo->cols * 16 * sInfo->rows * 16;
			copyMem(yuv411, unidec.prevfrm->c[0], size);
			copyMem(yuv411 + size, unidec.prevfrm->c[1], size / 4);
			copyMem(yuv411 + size + size / 4, unidec.prevfrm->c[2], size / 4);
#if MMX_SUPPORT
			__asm emms
#endif

			return SUCCESS;
		}
	};	

/**	ENDOFSECTION
 */



/**	ENDOFHEADERFILE: "BLKDecTSC.h"
 */
