/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_CC/cc_export.cpp"
 *	Description: Export different format inline functions implementation.
 *	History:
 *		05-03-2002 - Alpha, file created
 * $Id: cc_export.h,v 1.2 2004/02/11 15:36:39 dmeyer Exp $
 */
#include	"wsdf.h"


/**	SECTION - inline functions implementation - MMX version
 */
#if MMX_SUPPORT

INLINE	void	MB2UYVY(
			UINT8 *uyvy, SINT32 width,
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff
			)
{
	__asm
	{
		mov			ebx,				y
		mov			eax,				uyvy
		mov			ecx,				width

		mov			esi,				u
		mov			edi,				v

		paddsw		mm0,				Mptr [ebx]			; decode group blocking
		sub			eax,				ecx
		mov			CNT,				8

uyvy_2:
		movq		mm6,				Mptr [edi +   0]	; v0, v1, v2, v3, v4, v5, v6, v7
		movq		mm0,				Mptr [esi +   0]	; u0, u1, u2, u3, u4, u5, u6, u7
		movq		mm1,				Mptr [esi +   0]	; u0, u1, u2, u3, u4, u5, u6, u7

		add			eax,				ecx
		mov			ecx,				yoff

		punpcklbw	mm0,				mm6					; u0, v0, u1, v1, u2, v2, u3, v3
		punpckhbw	mm1,				mm6					; u4, v4, u5, v5, u6, v6, u7, v7
		movq		mm7,				Mptr [ebx +   0]	; y0, y1, y2, y3, y4, y5, y6, y7

		movq		mm2,				mm0
		movq		mm4,				mm0
		punpcklbw	mm0,				mm7					; u0, y0, v0, y1, u1, y2, v1, y3

		movq		mm3,				mm1
		movq		mm5,				mm1
		punpckhbw	mm2,				mm7					; u2, y4, v2, y5, u3, y6, v3, y7

		movq		Mptr [eax +   0],	mm0
		movq		mm0,				mm4
		movq		mm7,				Mptr [ebx +   8]	; y8, y9, ya, yb, yc, yd, ye, yf

		movq		Mptr [eax +   8],	mm2
		add			ebx,				ecx
		mov			ecx,				width

		punpcklbw	mm1,				mm7					; u4, y8, v4, y9, u5, ya, v5, yb
		punpckhbw	mm3,				mm7					; u6, yc, v6, yd, u7, ye, v7, yf
		movq		mm7,				Mptr [ebx +   0]	; y0, y1, y2, y3, y4, y5, y6, y7

		movq		Mptr [eax +  16],	mm1
		punpcklbw	mm0,				mm7					; u0, y0, v0, y1, u1, y2, v1, y3
		punpckhbw	mm4,				mm7					; u2, y4, v2, y5, u3, y6, v3, y7

		movq		Mptr [eax +  24],	mm3
		add			eax,				ecx
		mov			ecx,				yoff

		movq		mm1,				mm5
		movq		mm7,				Mptr [ebx +   8]	; y8, y9, ya, yb, yc, yd, ye, yf

		movq		Mptr [eax +   0],	mm0
		punpcklbw	mm1,				mm7					; u4, y8, v4, y9, u5, ya, v5, yb
		punpckhbw	mm5,				mm7					; u6, yc, v6, yd, u7, ye, v7, yf

		movq		Mptr [eax +   8],	mm4
		add			ebx,				ecx
		mov			ecx,				uoff

		movq		Mptr [eax +  16],	mm1
		add			esi,				ecx
		mov			ecx,				voff

		movq		Mptr [eax +  24],	mm5
		add			edi,				ecx
		mov			ecx,				width

		sub			CNT,				1
		jg			uyvy_2
	}
}

INLINE	void	MB2YUYV(
			UINT8 *yuyv, SINT32 width,
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff
			)
{
	__asm
	{
		mov			ebx,				y
		mov			eax,				yuyv
		mov			ecx,				width

		mov			esi,				u
		mov			edi,				v

		paddsw		mm0,				Mptr [ebx]			; decode group blocking
		sub			eax,				ecx
		mov			CNT,				8

yuyv_2:
		movq		mm6,				Mptr [edi +   0]	; v0, v1, v2, v3, v4, v5, v6, v7
		movq		mm0,				Mptr [esi +   0]	; u0, u1, u2, u3, u4, u5, u6, u7
		movq		mm1,				Mptr [esi +   0]	; u0, u1, u2, u3, u4, u5, u6, u7

		add			eax,				ecx
		mov			ecx,				yoff

		punpcklbw	mm0,				mm6					; u0, v0, u1, v1, u2, v2, u3, v3
		punpckhbw	mm1,				mm6					; u4, v4, u5, v5, u6, v6, u7, v7

		movq		mm2,				Mptr [ebx +   0]	; y0, y1, y2, y3, y4, y5, y6, y7
		movq		mm3,				Mptr [ebx +   0]	; y0, y1, y2, y3, y4, y5, y6, y7

		movq		mm4,				Mptr [ebx +   8]	; y8, y9, ya, yb, yc, yd, ye, yf
		movq		mm5,				Mptr [ebx +   8]	; y8, y9, ya, yb, yc, yd, ye, yf

		punpcklbw	mm2,				mm0					; y0, u0, y1, v0, y2, u1, y3, v1
		punpckhbw	mm3,				mm0					; y4, u2, y5, v2, y6, u3, y7, v3 

		add			ebx,				ecx
		mov			ecx,				width

		movq		Mptr [eax +   0],	mm2
		punpcklbw	mm4,				mm1					; y8, u4, y9, v4, ya, u5, yb, v5 
		punpckhbw	mm5,				mm1					; yc, u6, yd, v6, ye, u7, yf, v7, 

		movq		Mptr [eax +   8],	mm3
		movq		mm6,				Mptr [ebx +   0]	; y0, y1, y2, y3, y4, y5, y6, y7
		movq		mm7,				Mptr [ebx +   0]	; y0, y1, y2, y3, y4, y5, y6, y7

		movq		Mptr [eax +  16],	mm4
		movq		mm2,				Mptr [ebx +   8]	; y8, y9, ya, yb, yc, yd, ye, yf
		movq		mm3,				Mptr [ebx +   8]	; y8, y9, ya, yb, yc, yd, ye, yf

		movq		Mptr [eax +  24],	mm5
		punpcklbw	mm6,				mm0					; y0, u0, y1, v0, y2, u1, y3, v1
		punpckhbw	mm7,				mm0					; y4, u2, y5, v2, y6, u3, y7, v3 

		add			eax,				ecx
		mov			ecx,				yoff

		movq		Mptr [eax +   0],	mm6
		punpcklbw	mm2,				mm1					; y8, u4, y9, v4, ya, u5, yb, v5, 
		punpckhbw	mm3,				mm1					; yc, u6, vyd, 6, ye, u7, yf, v7, 

		movq		Mptr [eax +   8],	mm7
		add			ebx,				ecx
		mov			ecx,				uoff

		movq		Mptr [eax +  16],	mm2
		add			esi,				ecx
		mov			ecx,				voff

		movq		Mptr [eax +  24],	mm3
		add			edi,				ecx
		mov			ecx,				width

		sub			CNT,				1
		jg			yuyv_2
	}
}



CONST UINT8 TabBGR4[64] = {
	255,   0, 255,   0, 255,   0, 255,   0,
	128,   0, 128,   0, 128,   0, 128,   0,
	 16,  16,  16,  16,  16,  16,  16,  16,
	 75,   0,  75,   0,  75,   0,  75,   0,
	 25,   0,  25,   0,  25,   0,  25,   0,
	 52,   0,  52,   0,  52,   0,  52,   0,
	129,   0, 129,   0, 129,   0, 129,   0,
	102,   0, 102,   0, 102,   0, 102,   0,
};

INLINE	void	MB2BGR4(
			UINT8 *bgr4, SINT32 width,
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff,
			UINT32 *mem
			)
{
	UINT8 *y1 = y + 8, *u1 = u + 4, *v1 = v + 4;

	__asm
	{
		mov			eax,				mem
		lea			ecx,				TabBGR4

		mov			ebx,				y
		mov			esi,				u
		mov			edi,				v

		mov			CNT,				16
		jmp			bgr3x8x2

next_side:
		mov			ebx,				y1
		mov			esi,				u1
		mov			edi,				v1

bgr3x8x2:
		pxor		mm7,				mm7					; 0
		movq		mm0,				Mptr [esi]
		movq		mm1,				Mptr [edi]

		movq		mm6,				Mptr [ecx +   8]	; 128
		punpcklbw	mm0,				mm7
		punpcklbw	mm1,				mm7

		movq		mm2,				Mptr [ecx +  32]	; 25
		movq		mm3,				Mptr [ecx +  40]	; 52

		psubsw		mm0,				mm6					; u0, u1, u2, u3
		psubsw		mm1,				mm6					; v0, v1, v2, v3

		movq		mm6,				Mptr [ecx +  48]	; 129
		movq		mm7,				Mptr [ecx +  56]	; 102

		mov			ecx,				uoff
		pmullw		mm2,				mm0
		pmullw		mm3,				mm1

		add			esi,				ecx
		mov			ecx,				voff

		add			eax,				48
		pmullw		mm0,				mm6					; cb = (516 * u) / 4
		pmullw		mm1,				mm7					; cr = (408 * v) / 4

		add			edi,				ecx
		lea			ecx,				TabBGR4
		sub			CNT,				1
		paddsw		mm2,				mm3					; cg = (100 * u + 208 * v) / 4

		// line 0

		movq		mm6,				Mptr [ecx +  16]	; 16
		movq		mm7,				Mptr [ebx]
		psubusb		mm7,				mm6					; y0, y1, y2, y3, y4, y5, y6, y7

		movq		mm3,				Mptr [ecx +   0]	; 255, 0
		movq		mm5,				Mptr [ecx +  24]	; 75

		pand		mm3,				mm7					; y0, y2, y4, y6
		psrlw		mm7,				8					; y1, y3, y5, y7

		pmullw		mm3,				mm5					; cy = (300 * y) / 4
		pmullw		mm7,				mm5					; cy = (300 * y) / 4

		movq		mm4,				mm0
		movq		mm5,				mm0

		paddsw		mm4,				mm3					; cb + cy -> b(2n)
		paddsw		mm5,				mm7					; cb + cy -> b(2n + 1)

		psraw		mm4,				6
		psraw		mm5,				6

		packuswb	mm4,				mm3
		packuswb	mm5,				mm7
		punpcklbw	mm4,				mm5					; cb[0..7]

		movq		Mptr [eax -  48],	mm4
		movq		mm4,				mm1
		movq		mm5,				mm1

		paddsw		mm4,				mm3					; cr + cy -> r(2n)
		paddsw		mm5,				mm7					; cr + cy -> r(2n + 1)

		mov			ecx,				yoff
		psraw		mm4,				6
		psraw		mm5,				6

		packuswb	mm4,				mm3
		packuswb	mm5,				mm7

		add			ebx,				ecx
		punpcklbw	mm4,				mm5					; cr[0..7]

		movq		Mptr [eax -  40],	mm4
		psubsw		mm3,				mm2					; cy - cg -> g(2n)
		psubsw		mm7,				mm2					; cy - cg -> g(2n + 1)

		psraw		mm3,				6
		psraw		mm7,				6

		packuswb	mm3,				mm2
		packuswb	mm7,				mm2

		lea			ecx,				TabBGR4
		punpcklbw	mm3,				mm7					; cr[0..7]

		movq		Mptr [eax -  32],	mm3
		movq		mm7,				Mptr [ebx]
		psubusb		mm7,				mm6					; y0, y1, y2, y3, y4, y5, y6, y7

		// line 1

		movq		mm3,				Mptr [ecx +   0]	; 255, 0
		movq		mm5,				Mptr [ecx +  24]	; 75

		pand		mm3,				mm7					; y0, y2, y4, y6
		psrlw		mm7,				8					; y1, y3, y5, y7

		pmullw		mm3,				mm5					; cy = (300 * y) / 4
		pmullw		mm7,				mm5					; cy = (300 * y) / 4

		movq		mm4,				mm0
		movq		mm5,				mm0

		paddsw		mm4,				mm3					; cb + cy -> b(2n)
		paddsw		mm5,				mm7					; cb + cy -> b(2n + 1)

		psraw		mm4,				6
		psraw		mm5,				6

		packuswb	mm4,				mm3
		packuswb	mm5,				mm7
		punpcklbw	mm4,				mm5					; cb[0..7]

		movq		Mptr [eax -  24],	mm4
		movq		mm4,				mm1
		movq		mm5,				mm1

		paddsw		mm4,				mm3					; cr + cy -> r(2n)
		paddsw		mm5,				mm7					; cr + cy -> r(2n + 1)

		mov			ecx,				yoff
		psraw		mm4,				6
		psraw		mm5,				6

		packuswb	mm4,				mm3
		packuswb	mm5,				mm7

		add			ebx,				ecx
		punpcklbw	mm4,				mm5					; cr[0..7]

		movq		Mptr [eax -  16],	mm4
		psubsw		mm3,				mm2					; cy - cg -> g(2n)
		psubsw		mm7,				mm2					; cy - cg -> g(2n + 1)

		psraw		mm3,				6
		psraw		mm7,				6

		packuswb	mm3,				mm2
		packuswb	mm7,				mm2

		lea			ecx,				TabBGR4
		punpcklbw	mm3,				mm7					; cr[0..7]

		movq		Mptr [eax -   8],	mm3
		cmp			CNT,				8
		je			next_side

		cmp			CNT,				0
		jg			bgr3x8x2

		// end of color conversion

		// begin of interleaving

		mov			eax,				mem
		mov			ebx,				bgr4
		pxor		mm6,				mm6					; 00000000

		paddsw		mm0,				Mptr [eax]			; decode group blocking
		mov			ecx,				width
		mov			CNT,				16

bgr0x:
		movq		mm2,				Mptr [eax +   8]	; rrrrrrrr
		movq		mm0,				Mptr [eax +   0]	; bbbbbbbb
		movq		mm1,				Mptr [eax +   0]	; bbbbbbbb

		movq		mm4,				Mptr [eax +  16]	; gggggggg
		movq		mm5,				Mptr [eax +  16]	; gggggggg

		punpcklbw	mm0,				mm2					; brbrbrbr (0..3)
		punpckhbw	mm1,				mm2					; brbrbrbr (4..7)
		punpcklbw	mm4,				mm6					; g0g0g0g0 (0..3)

		movq		mm2,				mm0
		movq		mm3,				mm1
		punpcklbw	mm0,				mm4					; bgr0bgr0 (0..1)

		movq		Mptr [ebx +   0],	mm0
		punpckhbw	mm5,				mm6					; g0g0g0g0 (4..7)
		punpckhbw	mm2,				mm4					; bgr0bgr0 (2..3)

		movq		Mptr [ebx +   8],	mm2
		punpcklbw	mm1,				mm5					; bgr0bgr0 (4..5)
		add			eax,				384

		movq		Mptr [ebx +  16],	mm1
		punpckhbw	mm3,				mm5					; bgr0bgr0 (6..7)
		movq		mm2,				Mptr [eax +   8]	; rrrrrrrr

		movq		Mptr [ebx +  24],	mm3
		movq		mm0,				Mptr [eax +   0]	; bbbbbbbb
		movq		mm1,				Mptr [eax +   0]	; bbbbbbbb

		movq		mm4,				Mptr [eax +  16]	; gggggggg
		movq		mm5,				Mptr [eax +  16]	; gggggggg

		punpcklbw	mm0,				mm2					; brbrbrbr (0..3)
		punpckhbw	mm1,				mm2					; brbrbrbr (4..7)
		punpcklbw	mm4,				mm6					; g0g0g0g0 (0..3)

		movq		mm2,				mm0
		movq		mm3,				mm1
		punpcklbw	mm0,				mm4					; bgr0bgr0 (0..1)

		movq		Mptr [ebx +  32],	mm0
		punpckhbw	mm5,				mm6					; g0g0g0g0 (4..7)
		punpckhbw	mm2,				mm4					; bgr0bgr0 (2..3)

		movq		Mptr [ebx +  40],	mm2
		punpcklbw	mm1,				mm5					; bgr0bgr0 (4..5)
		sub			eax,				360

		movq		Mptr [ebx +  48],	mm1
		punpckhbw	mm3,				mm5					; bgr0bgr0 (6..7)

		movq		Mptr [ebx +  56],	mm3
		add			ebx,				ecx

		sub			CNT,				1
		jg			bgr0x
	}
}

INLINE void   MB2BGR3(
			UINT8 *bgr3, SINT32 width,
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff,
			UINT32 *mem
			)
{
	MB2BGR4((UINT8*)mem, 64, y, yoff, u, uoff, v, voff, mem + 256);
	for(SINT32 i = 0; i < 16; i ++, bgr3 += width, mem += 16)
	{
		*((UINT32*)(bgr3 +  0)) = mem[ 0];
		*((UINT32*)(bgr3 +  3)) = mem[ 1];
		*((UINT32*)(bgr3 +  6)) = mem[ 2];
		*((UINT32*)(bgr3 +  9)) = mem[ 3];
		*((UINT32*)(bgr3 + 12)) = mem[ 4];
		*((UINT32*)(bgr3 + 15)) = mem[ 5];
		*((UINT32*)(bgr3 + 18)) = mem[ 6];
		*((UINT32*)(bgr3 + 21)) = mem[ 7];
		*((UINT32*)(bgr3 + 24)) = mem[ 8];
		*((UINT32*)(bgr3 + 27)) = mem[ 9];
		*((UINT32*)(bgr3 + 30)) = mem[10];
		*((UINT32*)(bgr3 + 33)) = mem[11];
		*((UINT32*)(bgr3 + 36)) = mem[12];
		*((UINT32*)(bgr3 + 39)) = mem[13];
		*((UINT32*)(bgr3 + 42)) = mem[14];
		UINT8* tail = (UINT8*)(mem + 15);
		bgr3[45] = tail[0]; bgr3[46] = tail[1]; bgr3[47] = tail[2];
	}
}
/**	ENDOFSECTION
 */

#else /* MMX_SUPPORT */
/**	SECTION - inline functions implementation - C/C++ version
 */
INLINE	void	MB2UYVY(
			UINT8 *uyvy, SINT32 width,
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff
			)
{
	SINT32 i, j;

	for (i = 0; i < 16; i++)
	{
		for (j = 0; j < 8; j++)
		{
#ifdef _BIG_ENDIAN_
			uyvy[j * 4 + 0] = y[j * 2];
			uyvy[j * 4 + 1] = u[j];
			uyvy[j * 4 + 2] = y[j * 2 + 1];
			uyvy[j * 4 + 3] = v[j];
#else
			uyvy[j * 4 + 0] = u[j];
			uyvy[j * 4 + 1] = y[j * 2];
			uyvy[j * 4 + 2] = v[j];
			uyvy[j * 4 + 3] = y[j * 2 + 1];
#endif
		}
		uyvy += width;
		y += yoff;
		if (i & 1) {
			u += uoff;
			v += voff;
		}
	}
}

INLINE	void	MB2YUYV(
			UINT8 *yuyv, SINT32 width,
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff
			)
{
	SINT32 i, j;

	for (i = 0; i < 16; i++)
	{
		for (j = 0; j < 8; j++)
		{
			yuyv[j * 4 + 0] = y[j * 2];
			yuyv[j * 4 + 1] = u[j];
			yuyv[j * 4 + 2] = y[j * 2 + 1];
			yuyv[j * 4 + 3] = v[j];
		}
		yuyv += width;
		y += yoff;
		if (i & 1) {
			u += uoff;
			v += voff;
		}
	}
}

INLINE	void	MB2BGR4(
			UINT8 *bgr4, SINT32 width,
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff,
			UINT32 *mem
			)
{
	SINT32 i, j, r, g, b, y1, u1, v1;
	UINT32 *bgr4_32;

	bgr4_32 = (UINT32 *)bgr4;

	for (i = 0; i < 16; i++)
	{
		for (j = 0; j < 16; j++)
		{
			u1 = u[j>>1] - 128;
			v1 = v[j>>1] - 128;
			y1 = ((y[j] - 16) * 298) >> 8;
			r = y1 + ((409 * v1) >> 8);
			g = y1 - ((208 * v1 + 100 * u1) >> 8);
			b = y1 + ((516 * u1) >> 8);
			r = CLP(r, 0, 255);
			g = CLP(g, 0, 255);
			b = CLP(b, 0, 255);

#if 1
			bgr4_32[j] = (b << 24) | (g << 16) | (r << 8);
#else
			bgr4[4 * j + 0] = b;
			bgr4[4 * j + 1] = g;
			bgr4[4 * j + 2] = r;
			bgr4[4 * j + 3] = 0;
#endif

		}
#if 1
		bgr4_32 += (width/4);
#else
		bgr4 += width;
#endif
		y += yoff;
		if (i & 1) {
			u += uoff;
			v += voff;
		}
	}
}

INLINE void   MB2BGR3(
			UINT8 *bgr3, SINT32 width,
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff,
			UINT32 *mem
			)
{
	SINT32 i, j, r, g, b, y1, u1, v1;

	for (i = 0; i < 16; i++)
	{
		for (j = 0; j < 16; j++)
		{
			u1 = u[j>>1] - 128;
			v1 = v[j>>1] - 128;
			y1 = ((y[j] - 16) * 298) >> 8;
			r = y1 + ((409 * v1) >> 8);
			g = y1 - ((208 * v1 + 100 * u1) >> 8);
			b = y1 + ((516 * u1) >> 8);
			r = CLP(r, 0, 255);
			g = CLP(g, 0, 255);
			b = CLP(b, 0, 255);

			bgr3[3 * j + 0] = b;
			bgr3[3 * j + 1] = g;
			bgr3[3 * j + 2] = r;
		}
		bgr3 += width;
		y += yoff;
		if (i & 1) {
			u += uoff;
			v += voff;
		}
	}
}


INLINE	void	MB2RGB565(
			UINT8 *rgb565, SINT32 width,
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff,
			UINT32 *mem
			)
{
	SINT32 i, j, r, g, b, y1, u1, v1;
	UINT16 *rgb565_16;
	register UINT16 reg;

	rgb565_16 = (UINT16 *)rgb565;


	for (i = 0; i < 16; i++)
	{
		for (j = 0; j < 16; j++)
		{
			u1 = u[j>>1] - 128;
			v1 = v[j>>1] - 128;
			y1 = ((y[j] - 16) * 298) >> 8;
			r = y1 + ((409 * v1) >> 8);
			g = y1 - ((208 * v1 + 100 * u1) >> 8);
			b = y1 + ((516 * u1) >> 8);
			r = CLP(r, 0, 255);
			g = CLP(g, 0, 255);
			b = CLP(b, 0, 255);


			reg = ((r << 8) & 0xf800) | ((g << 3) & 0x07e0) | ((b >> 3) & 0x001f);
#ifdef _BIG_ENDIAN_
			rgb565_16[j] = (reg << 8) | (reg >> 8);
#else
			rgb565_16[j] = reg;
#endif
		}

		rgb565_16 += (width/2);

		y += yoff;
		if (i & 1) {
			u += uoff;
			v += voff;
		}
	}
}


INLINE	void	MB2RGB555(
			UINT8 *rgb555, SINT32 width,
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff,
			UINT32 *mem
			)
{
	SINT32 i, j, r, g, b, y1, u1, v1;
	UINT16 *rgb555_16;
	register UINT16 reg;

	rgb555_16 = (UINT16 *)rgb555;


	for (i = 0; i < 16; i++)
	{
		for (j = 0; j < 16; j++)
		{
			u1 = u[j>>1] - 128;
			v1 = v[j>>1] - 128;
			y1 = ((y[j] - 16) * 298) >> 8;
			r = y1 + ((409 * v1) >> 8);
			g = y1 - ((208 * v1 + 100 * u1) >> 8);
			b = y1 + ((516 * u1) >> 8);
			r = CLP(r, 0, 255);
			g = CLP(g, 0, 255);
			b = CLP(b, 0, 255);


			reg = ((r << 7) & 0x7c00) | ((g << 2) & 0x03e0) | ((b >> 3) & 0x001f);
#ifdef _BIG_ENDIAN_
			rgb555_16[j] = (reg << 8) | (reg >> 8);
#else
			rgb555_16[j] = reg;
#endif
		}

		rgb555_16 += (width/2);

		y += yoff;
		if (i & 1) {
			u += uoff;
			v += voff;
		}
	}
}

INLINE	void	MB2YUV420(
			UINT8 *yuv420Y, UINT8 *yuv420U, UINT8 *yuv420V, SINT32 width, SINT32 col, SINT32 row, 
			UINT8 *y, SINT32 yoff, UINT8 *u, SINT32 uoff, UINT8 *v, SINT32 voff
			)
{
	SINT32 i;
	SINT32 widthcr = width >> 1;
	UINT8 *pY = yuv420Y + row * 16 * width + col * 16;
	UINT8 *pU = yuv420U + row * 8 * widthcr + col * 8;
	UINT8 *pV = yuv420V + row * 8 * widthcr + col * 8;

	for (i = 0; i < 8; i++)
	{
		VCPY(pY, y, 16);
		pY += width;
		y += yoff;
		VCPY(pY, y, 16);
		pY += width;
		y += yoff;
		VCPY(pU, u, 8);
		pU += widthcr;
		u += uoff;
		VCPY(pV, v, 8);
		pV += widthcr;
		v += voff;
	}
}

#endif /* MMX_SUPPORT */

/**	ENDOFSECTION
 */



/**	ENDOSOURCEFILE: "cc_export.cpp"
 */
