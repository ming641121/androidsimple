/******************************************************************************
*
*   FILE: 
*		decoder_driver.c
*
*   DESCRIPTION:
*		This is the decoder driver.
*
*
*     $Id: decoder_driver.cpp,v 1.3 2004/03/01 15:42:25 jfd Exp $
*
******************************************************************************/

#include "wis_types.h"
#include "wis_error.h"
#include "os.h"
#include "tasks.h"
#include "decoder_driver.h"
#include "wis_decoder.h"
#include "wis_encoder.h"
#include "struct.h"
#include "logLib.h"

#include "string.h"
#include "mp_unidectsc.h"

sint32 boDecoderReset = FALSE;
sint32 boDecodeFrame=FALSE;
sint32 boFrameStep=FALSE;


/* task variables local to this file */
static uint32	thisTaskId=0;
static sint8	thisTaskName[MAX_TASK_NAME_LENGTH];

#define MAX_NUM_DECODERS 10


/* Local decoder instances, indexed in API by 
 * stream handle which is an index into this array */
IMP_UniDecTSC  *decoders[MAX_NUM_DECODERS];
int            __n_decoders = 2; /* Default to local and remote */

volatile int __n_decoder_frames_total;
/* Decoder configuration structures */
decoder_stream_config_t decoderConfigs[MAX_NUM_DECODERS];


OS_QUEUE decoderDriverQueue;

//extern "C" OS_QUEUE decoderDriverQueue;

extern void *video_fb_address;


extern "C" status_t 
decoderSetModeCPP(int stream, int input, sint32 output, sint32 width, sint32 height)
{
    if (stream > MAX_NUM_DECODERS){
	return DECODER_FAILURE;
    }
    switch(output){
    /* Output types for decoderSetMode */
    case DECODER_OUTPUT_MODE_RGB24:
        decoderConfigs[stream].outputMode = DDRAW_RGB24;
	decoderConfigs[stream].bpp = 3;
	break;
    case DECODER_OUTPUT_MODE_RGB32:
        decoderConfigs[stream].outputMode = DDRAW_RGB32;
	decoderConfigs[stream].bpp = 4;
	break;
    case DECODER_OUTPUT_MODE_YUV: 
	decoderConfigs[stream].outputMode = DDRAW_YV12;
	decoderConfigs[stream].bpp = 1;
	break;
    case DECODER_OUTPUT_MODE_YCBCR:
        decoderConfigs[stream].outputMode = DDRAW_YUY2;
	decoderConfigs[stream].bpp = 2;
	break; 
    case DECODER_OUTPUT_MODE_UYVY:
        decoderConfigs[stream].outputMode = DDRAW_UYVY;
	decoderConfigs[stream].bpp = 2;
	break; 
    case DECODER_OUTPUT_MODE_DIB24:
        decoderConfigs[stream].outputMode = DDRAW_DIB24;
	decoderConfigs[stream].bpp = 3;
	break; 
    case DECODER_OUTPUT_MODE_DIB32:
        decoderConfigs[stream].outputMode = DDRAW_DIB32;
        decoderConfigs[stream].bpp = 4;
	break; 
	case DECODER_OUTPUT_MODE_RGB565:
		decoderConfigs[stream].outputMode = DDRAW_RGB565;
		decoderConfigs[stream].bpp = 2;
	break; 
    default:
	decoderConfigs[stream].outputMode = DDRAW_RGB32;
	decoderConfigs[stream].bpp = 4;
	break;
    }
    switch(input){
    /* Input types for decoderSetMode */
    case DECODER_INPUT_MODE_MPEG4:
	decoderConfigs[stream].inputMode = MPEG4;
	break;
    case DECODER_INPUT_MODE_MPEG2:
        decoderConfigs[stream].inputMode = MPEG2;
	break;
    case DECODER_INPUT_MODE_MPEG1:
        decoderConfigs[stream].inputMode = MPEG1;
	break;
    case DECODER_INPUT_MODE_H261:
        decoderConfigs[stream].inputMode = H261;
	break;
    case DECODER_INPUT_MODE_H263:
        decoderConfigs[stream].inputMode = H263;
	break;
    case DECODER_INPUT_MODE_H26L:
	decoderConfigs[stream].inputMode = H26L;
	break;
    case DECODER_INPUT_MODE_MPEG4XGO:
	decoderConfigs[stream].inputMode = MPEG4XGO;
	break;
    case DECODER_INPUT_MODE_MPEG2X4:
	decoderConfigs[stream].inputMode = MPEG2X4;
	break;
    case DECODER_INPUT_MODE_MJPEG:
	decoderConfigs[stream].inputMode = MOTIONJPEG;
	break;
    case DECODER_INPUT_MODE_DV:
	decoderConfigs[stream].inputMode = DV;
	break;
    case DECODER_INPUT_MODE_GO:
	decoderConfigs[stream].inputMode = GO;
	break;
    default:
	decoderConfigs[stream].inputMode = MPEG4;
	break;
    }
    
    decoderConfigs[stream].screenHeight = height;
    decoderConfigs[stream].screenWidth = width;
        
    logMsg("\n\n\nDecoderSetMode: %dx%d, bpp=%d, input=%d, output=%d\n",
	   decoderConfigs[stream].screenWidth,
	   decoderConfigs[stream].screenHeight,
           decoderConfigs[stream].bpp,
	   decoderConfigs[stream].inputMode,
	   decoderConfigs[stream].outputMode,0);
    return DECODER_SUCCESS;

}


extern "C" status_t decoderGetSnapshotCPP(sint32 stream, uint8 *bufferPtr)
{
	
	switch (decoderConfigs[stream].outputMode)
	{
		case DDRAW_YV12:
			decoders[stream]->GetSnapShotYUV411(bufferPtr);
			break;
			
		case DDRAW_RGB32:
			decoders[stream]->GetSnapShotBMP(bufferPtr, DDRAW_DIB32);
			break;
			
		case DDRAW_RGB24:
			decoders[stream]->GetSnapShotBMP(bufferPtr, DDRAW_DIB24);
			break;
	}
	
	return(DECODER_SUCCESS);
	
}

extern "C" status_t decodeOneFrameCPP(sint32 stream, void *frame, sint32 len, void *destFrame, sint32 *dlen, d_frameInfo_t *type)

{

	//sint32 ddWidth = 800*4;
	status_t status;
	TMP_FrmInfo frmInfo;

	/* FIXUP:  Remember to initialize this and set the type */
	type->timestamp++;
	sint32 ddWidth = decoderConfigs[stream].bpp * decoderConfigs[stream].screenWidth;
	status = decoders[stream]->FRMDecTSC(NULL, (uint8 *) destFrame, ddWidth /* pitch */, &frmInfo,
					     NULL, NULL, dlen, (uint8 *)frame);
	__n_decoder_frames_total++;

	if (status == 0)
		return(DECODER_SUCCESS);
	else
		return(-status);

}

extern "C" int DecoderSetNumStreamsCPP(int ndecoders)
{
	if(ndecoders > MAX_NUM_DECODERS){
		return DECODER_FAILURE;
	} 
	__n_decoders = ndecoders;

    	return DECODER_SUCCESS;
}

/******************************************************************************
*
*   PROCEDURE:  
*       int DecoderInit(uint8 *pFrame, uint32 frameLen)
*
*   DESCRIPTION:
*       Create and initialize the decoders for use within the system.
*  
*   ARGUMENTS:
*       uint8 * - a pointer to the first frame, which must include the sequence
*                 header.
*       uint32 - length of the first frame including the headers.
*
*   RETURNS:
*       sint32 - number of bytes that were in the stream header.
*
*******************************************************************************/

extern "C" sint32 DecoderInit(uint8 *pFrame, uint32 frameLen)
{

	sint32 numStreamHeaderBytes=0;
	sint32 status=0;
	__n_decoder_frames_total=0;
    int i;
    
	for(i = 0; i < __n_decoders;i++)
    {
	    status = IMP_UniDecTSC::CreateInstance(&decoders[i], 
						   decoderConfigs[i].inputMode, 0, 0, NULL);

	    status = decoders[i]->Sync(NULL, NULL, NULL, &numStreamHeaderBytes, pFrame);

	    status = decoders[i]->UniDecTSCSetup(decoderConfigs[i].outputMode);

	    decoders[i]->Configurate(FP_AUTO, 0, NULL);
	}

	/* move the pointer to the actual frame header instead of the stream header */
    return(numStreamHeaderBytes);
}

/**************************** end of DecoderInit *****************************/

/******************************************************************************
*
*   PROCEDURE:  
*       void DecoderStop(void)
*
*   DESCRIPTION:
*       This function is responsible for deleting all of the decoders to
*   recover the memory used by this function.
*  
*   ARGUMENTS:
*
*	  NONE
*
*   RETURNS:
*
*    NONE
*
*******************************************************************************/

extern "C" void DecoderStop(void)
{
    int i;

	for(i = 0; i < __n_decoders;i++)
    {
        decoders[i]->Release();
	}

    return;
}

/***************************** end of DecoderStop ****************************/

/********************************************************************************
*
*   PROCEDURE:  
*       DecoderDriverTask(void)
*
*   DESCRIPTION:
*       This task is responsible for initializing and servicing the decoder.
*  
*   ARGUMENTS:
*
*	  NONE
*
*   RETURNS:
*
*    NONE
*
********************************************************************************/

extern "C"
void DecoderDriverTask(void)
{

	sint32 status;
	encoder_frame_t decoderDriverQueueElement;
	sint32 frameLength=0;
	sint32 frameLengthMismatch=0;
	TMP_FrmInfo frmInfo;
	sint32 ddWidth = 800*2; //352*4;

	/* setup local task information */
	strncpy(thisTaskName, DECODER_DRIVER_TASK_NAME, MAX_TASK_NAME_LENGTH);

	FOREVER
	{

		/* Wait for decoder events */
		OS_QUEUE_RECEIVE(decoderDriverQueue, decoderDriverQueueElement,
						 sizeof(encoder_frame_t), OS_WAIT_FOREVER);

		if (boDecoderReset == FALSE)
		{							 
			DecoderInit(decoderDriverQueueElement.pFrame, decoderDriverQueueElement.frameLen);

			boDecoderReset = TRUE;
		}


		while ( (boFrameStep == TRUE) && (boDecodeFrame == FALSE) ) { taskDelay(10); }

		// pitch is the number of bytes for each line of display
		status = decoders[0]->FRMDecTSC(NULL, (uint8 *) video_fb_address, ddWidth/* pitch */, &frmInfo, NULL,
					    NULL, &frameLength, decoderDriverQueueElement.pFrame);

		if (frameLength != decoderDriverQueueElement.frameLen)
		{
			frameLengthMismatch++;
		}

		boDecodeFrame = FALSE;

	}

}

/***************************** end of DecoderDriverTask ***************************/

/***************************** end of decoder_driver.c ***************************/

