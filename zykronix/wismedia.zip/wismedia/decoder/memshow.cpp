/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/MP_UniDecTSC/MemShow.cpp"
 *	Description: Universal Decoder output memory management.
 *	History:
 *		05-05-2002 - Alpha, file created
 * $Id: memshow.cpp,v 1.1 2003/11/04 15:42:30 dmeyer Exp $
 */
#include	"unidec.h"



CUniDecShow::CUniDecShow(SINT32 cols, SINT32 rows, SINT8 dDraw)
{
	interpolation = 0;
	switch(dDraw)
	{
	case DDRAW_DIB24:
	case DDRAW_RGB24: nWidth = 48 * cols; nHeight = 16 * rows; break;
	case DDRAW_DIB32:
	case DDRAW_RGB32: nWidth = 64 * cols; nHeight = 16 * rows; break;
	default:          nWidth = 32 * cols; nHeight = 16 * rows;
	}

	PrevFrm.fno = 0;
	PrevFrm.ddMem = NULL;

	PostFrm.fno = 0;
	PostFrm.ddMem = new UINT8[nWidth * nHeight];
	PostFrm.ddWidth = nWidth;

	SetBlack(PostFrm.ddMem, dDraw, nWidth, nHeight);
}

CUniDecShow::~CUniDecShow() { delete PostFrm.ddMem; }

void	CUniDecShow::SetInterpolation(SINT8 interpolation)
{
	if(this->interpolation != interpolation)
		if((this->interpolation = interpolation) && PrevFrm.ddMem)
			copyRec(
				PostFrm.ddMem, PostFrm.ddWidth, PrevFrm.ddMem, PrevFrm.ddWidth,
				nWidth, nHeight
				);
}

UINT8*	CUniDecShow::UpdateFrame(REAL64 fno, UINT8 *ddMem, SINT32 &ddWidth)
{
	PrevFrm.ddMem = ddMem; PrevFrm.ddWidth = ddWidth;
	if(interpolation) {
		if(ddMem)
			copyRec(
				PrevFrm.ddMem, PrevFrm.ddWidth, PostFrm.ddMem, PostFrm.ddWidth,
				nWidth, nHeight
				);
		PrevFrm.fno = PostFrm.fno;
		PostFrm.fno = fno; ddWidth = PostFrm.ddWidth; return PostFrm.ddMem;
	}
	else {
		PrevFrm.fno = fno; return ddMem;
	}
}

UINT8*	CUniDecShow::MemQuery(REAL64 fno, UINT8 *ddMem, SINT32 ddWidth)
{
	if(!PrevFrm.ddMem || !ddMem) return NULL;

	if(!interpolation || (fno < PrevFrm.fno + 0.5) || (fno > PostFrm.fno - 0.5)) {
		if(ddMem != PrevFrm.ddMem)
			copyRec(
				ddMem, ddWidth, PrevFrm.ddMem, PrevFrm.ddWidth,
				nWidth, nHeight
				);
	}
	else {
		SINT8 tbl[512], *delta_tbl = tbl + 256;
		UINT8 *curr = ddMem, *prev = PrevFrm.ddMem, *post = PostFrm.ddMem;

		SINT32 inc = (SINT32)(4096 * (fno - PrevFrm.fno) / (PostFrm.fno - PrevFrm.fno));
		SINT32 sum = - 255 * inc;
		SINT32 i, j;

		for(i = - 255; i < 256; i ++, sum += inc)
			delta_tbl[i] = (SINT8)(sum >> 12);

		for(i = 0; i < nHeight; i ++)
		{
			for(j = 0; j < nWidth; j ++)
				curr[j] = prev[j] + delta_tbl[(SINT32)post[j] - prev[j]];
			curr += ddWidth; prev += PrevFrm.ddWidth; post += PostFrm.ddWidth;
		}

		PrevFrm.fno = fno; PrevFrm.ddMem = ddMem; PrevFrm.ddWidth = ddWidth;
	}

	return ddMem;
}

UINT8*	CUniDecShow::MemToShow(REAL64 &opfno) { opfno = PrevFrm.fno; return PrevFrm.ddMem; }



/**	ENDOFSOURCEFILE: "MemShow.cpp"
 */
