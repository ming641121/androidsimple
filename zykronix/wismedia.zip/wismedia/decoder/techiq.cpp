/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_DCTQ/TechIQ.cpp"
 *	Description: CTechIQ class implementation.
 *	History:
 *		05-02-2002 - Alpha, file created
 * $Id: techiq.cpp,v 1.1 2003/11/04 15:42:31 dmeyer Exp $
 */
#include	"tech_dctq.h"

#define	techiq	((MEMBER_TechIQ *)member)



/**	SECTION - data structures
 */
	typedef struct
	{
		SINT32	*tab;			// pointing to user defined quantize tables
		SINT32	*dc4Y;			// dc table for Y
		SINT32	*dc4C;			// dc table for color
		SINT32	*ac4intra;		// ac table for intra blocks
		SINT32	*ac4inter;		// ac table for inter blocks
		SINT32	rnd4intra;		// rounding for intra blocks
		SINT32	rnd4inter;		// rounding for inter blocks
	} MEMBER_TechIQ;

/**	ENDOFSECTION
 */



/**	SECTION - related functions
 */
#define	IQTABSIZE		128 * 32
#define	SclQ			(1 << (DCTSCL + 11))
#define	calQ(j, Scl, Q)	(SINT32)(cos[j & 7] * cos[j >> 3] * Scl * Q * SclQ)

SINT32	iQTab[IQTABSIZE];



SINT32	IQTabInit(SINT32 *table = NULL, UINT8 *intraQ = NULL, UINT8 *interQ = NULL)
{
	CONST REAL64 cos[8] = {
		0.70710679065997, 0.98078528105666, 0.92387953507478, 0.83146961788496,
		0.70710679065997, 0.55557024694407, 0.38268345093153, 0.19509034501116,
	};

	STATIC SINT32 ref = 0;
	SINT32 i, j;

	if(ref == 0)
	{
		// init dc coefficients
		CONST SINT32 mp4dcQ[64] = {
			 8,  8,  8,  8,  8, 10, 12, 14, 16, 17, 18, 19, 20, 21, 22, 23,
			24, 25, 26, 27, 28, 29, 30, 31, 32, 34, 36, 38, 40, 42, 44, 46,

			 8,  8,  8,  8,  8,  9,  9, 10, 10, 11, 11, 12, 12, 13, 13, 14,
			14, 15, 15, 16, 16, 17, 17, 18, 18, 19, 20, 21, 22, 23, 24, 25,
		};

		for(i = 0; i < 64; i ++)
		{
			iQTab[i] = calQ(0, mp4dcQ[i], 8);
			iQTab[i + 64] = calQ(0, 8, 8);
		}

		// init ac coefficients
		CONST SINT32 mp2acQ[64] = {
			 8, 16, 19, 22, 22, 26, 26, 27, 16, 16, 22, 22, 26, 27, 27, 29,
			19, 22, 26, 26, 27, 29, 29, 35, 22, 24, 27, 27, 29, 32, 34, 38,
			26, 27, 29, 29, 32, 35, 38, 46, 27, 29, 34, 34, 35, 40, 46, 56,
			29, 34, 34, 37, 40, 48, 56, 69, 34, 37, 38, 40, 48, 58, 69, 83,
		};

		for(i = 1; i < 32; i ++)
			for(j = 0; j < 64; j ++)
			{
				iQTab[128 * i      + j] = calQ(j, i, mp2acQ[j]);
				iQTab[128 * i + 64 + j] = calQ(j, i, 16);
			}
	}

	if(table)
	{
		SINT32 *intraq = table, *interq = table + 64;
		for(i = 0; i <  8; i ++)
			for(j = 0; j <  8; j ++)
			{
				intraq[i * 8 + j] = intraQ ? intraQ[i + 8 * j] : 16;
				interq[i * 8 + j] = interQ ? interQ[i + 8 * j] : 16;
			}

		for(i = 1; i < 32; i ++)
			for(j = 0; j < 64; j ++)
			{
				table[128 * i      + j] = calQ(j, i, intraq[j]);
				table[128 * i + 64 + j] = calQ(j, i, interq[j]);
			}
	}

	return ref ++;
}

/**	ENDOFSECTION
 */



/**	SECTION - interface implementation for C++ style
 */
CTechIQ::CTechIQ(SINT8 mode, UINT8 *intraQ, UINT8 *interQ)
{
	mode &= GO - 1;
	member = (SINT32)(new MEMBER_TechIQ);

	techiq->rnd4intra = ((mode == MPEG1) || (mode == MPEG2)) ? 0 : 1;
	techiq->rnd4inter = 1;

	techiq->dc4Y = (mode == MPEG4) ? iQTab      : iQTab + 64;
	techiq->dc4C = (mode == MPEG4) ? iQTab + 32 : iQTab + 96;

	if(intraQ || interQ)
	{
		techiq->tab = new SINT32[IQTABSIZE];
		IQTabInit(techiq->tab, intraQ, interQ);
		techiq->ac4intra = techiq->tab;
		techiq->ac4inter = techiq->tab + 64;
	}
	else
	{
		techiq->tab = NULL;
		IQTabInit();
		techiq->ac4intra = ((mode == MPEG1) || (mode == MPEG2)) ? iQTab : iQTab + 64;
		techiq->ac4inter = iQTab + 64;
	}
}

CTechIQ::~CTechIQ()
{
	if(techiq->tab) delete techiq->tab;
	delete techiq;
}

SINT32*	CTechIQ::DCIQ(SINT32 *dcIQ, SINT32 *dc, SINT8 Q, SINT8 mbtype, SINT32 &round)
{
	CLP(Q, 1, 31); SINT32 *acQ;
	if((mbtype & MB_INTRA) == 0)
	{
		round = techiq->rnd4inter;
		acQ = techiq->ac4inter + 128 * Q;
		dcIQ[0] = dcIQ[1] = dcIQ[2] = dcIQ[3] = dcIQ[4] = dcIQ[5] = 0;
	}
	else
	{
		round = techiq->rnd4intra;
		acQ = techiq->ac4intra + 128 * Q;

		SINT32 dcQ[6];
		dcQ[0] = dcQ[1] = dcQ[2] = dcQ[3] = techiq->dc4Y[Q];
		dcQ[4] = dcQ[5] = techiq->dc4C[Q];

		dcIQ[0] = (dcQ[0] * dc[0]) >> 16; dcIQ[1] = (dcQ[1] * dc[1]) >> 16;
		dcIQ[2] = (dcQ[2] * dc[2]) >> 16; dcIQ[3] = (dcQ[3] * dc[3]) >> 16;
		dcIQ[4] = (dcQ[4] * dc[4]) >> 16; dcIQ[5] = (dcQ[5] * dc[5]) >> 16;
	}
	return acQ;
}

/**	ENDOFSECTION
 */



#undef	techiq
/**	ENDOSOURCEFILE: "TechIQ.cpp"
 */
