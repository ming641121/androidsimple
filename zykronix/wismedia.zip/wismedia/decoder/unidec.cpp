/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Decode_C/UniDec.cpp"
 *	Description: Universal Decoder
 *	History:
 *		05-07-2002 - Alpha, file created as MP_UniDecTSC.cpp
 *		07-17-2003 - Weimin, modified for C version decoder only
 * $Id: unidec.cpp,v 1.1 2003/11/04 15:42:31 dmeyer Exp $
 */
#include	"unidec.h"


/**	SECTION - constants, structures and macro functions
 */

/**	ENDOFSECTION
 */

#ifdef XSCALE
extern "C" void clippingTableInit(void);
#endif


SINT8	IMP_UniDecTSC::AdjDecLvl(
			SINT8 DecLvl, SINT8 adjDecLvl, SINT32 bufferredFrm, SINT32 *adjTab, SINT8 ftype
			)
{
	if(bufferredFrm > adjTab[0]) DecLvl --;
	if(bufferredFrm > adjTab[1]) DecLvl --;
	if(bufferredFrm > adjTab[2]) DecLvl --;
	if(bufferredFrm > adjTab[3]) DecLvl --;
	if(ftype != I_FRAME)
		DecLvl = MIN(DecLvl, adjDecLvl);
	return MAX(DecLvl, 0);

}

SINT32	IMP_UniDecTSC::CreateInstance(
			IMP_UniDecTSC **pp, SINT8 modeSrc, SINT8 modeTSC, SINT8 modeWIS, TMP_StrInfo *sInfo
			)
{
	if(!sInfo)
	{
		TMP_StrInfo si; sInfo = &si;
		si.interlace = 0;
		si.mode      = modeSrc;
		si.seq       = FP_AUTO;
		si.cols      = FP_AUTO;
		si.rows      = FP_AUTO;
		si.fps       = FP_AUTO;
		si.uvmode    = FP_AUTO;
		si.dqmode    = FP_AUTO;
		si.fpmode    = FP_AUTO;
		si.acpred    = FP_AUTO;
		si.wismode	 = modeWIS;
		si.userq     = 0;
		for(SINT32 i = 0; i < 64; i ++)
			si.intraq[i] = si.interq[i] = 16;
	}
    *pp = new CUniDec(sInfo, modeTSC); return SUCCESS;
}

void	IMP_UniDecTSC::Release() { delete (CUniDec*)this; }



SINT32	CUniDec::Sync(
			TMP_StrInfo *sInfo, SINT32 *numTSC, UINT8 *ptr4HdrTSC,
			SINT32 *numSrc, UINT8 *ptr4HdrSrc
			)
{
	// osd text;
	decoded_osdtext[0] = 0;

	UINT8 *endptr = ptr4HdrSrc ? ReSync(rptr = ptr4HdrSrc, DEC_FIFOSIZE) : srcFrm[0].ptr;
	if(!bSync) return ERR_MISMCH;

	if(numTSC) *numTSC = 0;

	if(sInfo) *sInfo = this->sInfo;
	if(numSrc) *numSrc = endptr - rptr;

	LastFno = LastPno = 0;
	if (this->sInfo.seq == IPB) LastPno = 1;

	return SUCCESS;
}



SINT32	CUniDec::FRMDecTSC(
			REAL64 *timeStamp, UINT8 *ddMem, SINT32 ddWidth,
			TMP_FrmInfo *fInfo, SINT32 *numTSC, UINT8 *ptr4FrmTSC,
			SINT32 *numSrc, UINT8 *ptr4FrmSrc
			)
{
	if(!bSync) return ERR_ACCESS;
	SINT8 usefifo = ptr4FrmSrc == NULL;
	SINT32 bufferredFrm = BufferredFrm();
	if(usefifo)
	{
		if(bufferredFrm < FrmLvl[0]) return ERR_MEMORY;
		ptr4FrmSrc = srcFrm[rFrmIdx].ptr;
		FrmLvl[0] = 2;
	}

	SINT32 bits;
	vld->StrInit(ptr4FrmSrc, DEC_FIFOSIZE);
	vld->GopHead(bits, decoded_osdtext);

	if(vld->FrmHead(bits) != SUCCESS) return ERR_MISMCH;

	TMP_FrmInfo *fi = &(this->fInfo);

	SINT8 DecLvl = MIN(IPB, this->DecLvl);
	if(usefifo)
		DecLvl = adjDecLvl =
			AdjDecLvl(DecLvl, adjDecLvl, bufferredFrm, FrmLvl + 1, fi->ftype);

	cBLK->PProcSetup(Y4PP, UVPP, h0, h1, v0, v1);
	cShow->SetInterpolation(DecLvl == IPBDROP);

	SINT8 doDec = (fi->ftype != D_FRAME) && (DecLvl > fi->ftype);

	if((fi->ftype < B_FRAME) && (sInfo.seq < IPB))
		LastPno = fi->fno;

	REAL64 no = (fi->ftype < B_FRAME) ? LastPno : fi->fno;
	SINT32 width = ddWidth;
//	UINT8 *opMem = (doDec && ddMem) ? cShow->UpdateFrame(no, ddMem, width) : NULL;
	UINT8 *opMem = cShow->UpdateFrame(no, ddMem, width);
	if (!(doDec && ddMem)) opMem = NULL;
	cBLK->UpdateFrame(doDec, opMem, width);
	UINT8 *mem = NULL;

	if(fi->ftype == D_FRAME)
	{
		if(ddMem && (DecLvl > D_FRAME))
			mem = cShow->MemQuery(opfno = fi->fno, ddMem, ddWidth);
	}
	else
	{
		if(doDec || numSrc)
		{
			TMP_StrMBInfo *BI = SMBI;
			for(SINT32 i = 0; i < sInfo.rows; i ++)
				for(SINT32 j = 0; j < sInfo.cols; j ++)
					if(!usefifo || *((SINT32*)(ptr4FrmSrc + (bits >> 3))) != 0)
						bits = cBLK->Decode(BI ++);
		}

//		if(doDec && ddMem) mem = cShow->MemToShow(opfno);
		mem = cShow->MemToShow(opfno);
		if (!(doDec && ddMem)) mem = NULL;
		fi->fq /= sInfo.cols * sInfo.rows;
	}

	vld->FrmTail(bits);
	if(numSrc) *numSrc = bits >> 3;
	if(usefifo && bSync)
	{
		MODPLUS(rFrmIdx, 1, DEC_FIFOFRMS)
		rptr = srcFrm[rFrmIdx].ptr;
	}

	if(numTSC) numTSC[0] = 0;

	if((fi->ftype < B_FRAME) && (sInfo.seq == IPB))
		LastPno = fi->fno;

	if(timeStamp) *timeStamp = opfno / sInfo.fps;
	fi->timeStamp = fi->fno / sInfo.fps;
	if(fInfo) *fInfo = *fi;

	SINT32 r = (mem && doDec && (opfno > 0)) ? SUCCESS : ERR_UNKNOWN;
	return r;
}



SINT32	CUniDec::Duplicate(UINT8 *ddMem, SINT32 ddWidth)
{
	if(!bSync) return ERR_ACCESS;
	return cShow->MemQuery(- 1, ddMem, ddWidth) ? SUCCESS : ERR_UNKNOWN;
}



UINT8*	CUniDec::ReSync(UINT8 *ptr, SINT32 quota)
{
	while(true)
	{
		SINT32 bits;
		dHD->StrInit(ptr, quota);

		SINT32 rStr = dHD->StrHead(bits);

		SINT32 rGop = dHD->GopHead(bits, decoded_osdtext);

		if(((rStr == SUCCESS) || (rGop == SUCCESS)) && (CheckSync() == SUCCESS)) {
			wFrmIdx = - 1;
			rptr = ptr; srcFrm[0].ptr = ptr + (bits >> 3);
			bSync = 1; return srcFrm[0].ptr;
		}
		if(((rStr == ERR_MEMORY) || (rGop == ERR_MEMORY))) {
			bSync = 0; return ptr;
		}

		ptr ++, quota --;
	}
}

SINT32	CUniDec::FRMSplit()
{
	SINT32 fs = 0, bufferredFrm = BufferredFrm();
	while(bufferredFrm < DEC_FIFOFRMS)
	{
		SINT32 bits;
		dHD->StrInit(sptr, wptr - sptr);
		SINT32 rFrm = dHD->FrmHead(bits);

		if(rFrm == ERR_MEMORY) break;
		if(rFrm != SUCCESS)
			sptr ++;
		else
		{
			MODPLUS(wFrmIdx, 1, DEC_FIFOFRMS)
			srcFrm[wFrmIdx].ptr = sptr;
			srcFrm[wFrmIdx].ftype = fI.ftype;
			sptr += bits >> 3;
			bufferredFrm ++;
			fs ++;
		}
	}
	return fs;
}



/**	ENDOFSOURCEFILE: "UniDec.cpp"
 */
