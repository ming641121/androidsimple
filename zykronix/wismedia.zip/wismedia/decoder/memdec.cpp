/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/MP_UniDecTSC/MemDec.cpp"
 *	Description: Universal Decoder decoding memory management.
 *	History:
 *		05-04-2002 - Alpha, file created
 * $Id: memdec.cpp,v 1.1 2003/11/04 15:42:30 dmeyer Exp $
 */
#include	"unidec.h"



CUniDecMEM::CUniDecMEM(
			SINT8 seq, SINT32 mbWidth, SINT32 mbHeight, TUniDecMEM *unidec,
			SINT32 id, SINT8 *clipTbl, SINT32 mbln
			)
{
	SINT32 i, j;
	this->unidec = unidec;
	this->id = id; this->clipTbl = clipTbl; this->mbln = mbln;

	i =	4096 + unidec->cols * unidec->rows * 384 * 3;
	j =	sizeof(TUniDecMB) * 4 +
		sizeof(TUniDecMBx) * (unidec->cols + 2) +
		sizeof(TUniDecFrm) * 3 +
		sizeof(TUniDecUnit);

	mem = new UINT8[i + j + 32];

	unidec->c8x8	= (SINT16*)MEM32(mem);
	unidec->memTmp	= unidec->c8x8 + 64;
	for(unidec->blkhp[0] = (UINT8*)unidec->memTmp, j = 1; j < 10; j ++)
		unidec->blkhp[j] = unidec->blkhp[j - 1] + 64;

	mbMem			= (TUniDecMB*)(MEM32(mem) + i);
	unidec->refMb	= mbMem + 1;
	unidec->preMb	= unidec->refMb + 1;
	unidec->posMb	= unidec->preMb + 1;
	ref				= (TUniDecMBx*)(unidec->posMb + 1);
	unidec->prevfrm	= (TUniDecFrm*)(ref + unidec->cols + 2);
	unidec->postfrm	= unidec->prevfrm + 1;
	unidec->bppxfrm = unidec->postfrm + 1;
	unidec->mbShow	= (TUniDecUnit*)(unidec->bppxfrm + 1);

	for(i = 0; i < 4; i ++)
	{
		mbMem[i].c[0] = mbMem[i].c8x8;
		mbMem[i].c[1] = mbMem[i].c8x8 + 4;
		mbMem[i].c[2] = mbMem[i].c8x8 + 5;
		for(j = 0; j < 6; j ++)
			mbMem[i].c8x8[j].offset = ((j < 4) ? 16 : 8) * unidec->cols;
	}

	unidec->prevfrm->c[0] = MEM32(mem) + 4096;
	unidec->prevfrm->c[1] = unidec->prevfrm->c[0] + unidec->cols * unidec->rows * 256;
	unidec->prevfrm->c[2] = unidec->prevfrm->c[1] + unidec->cols * unidec->rows * 64;
	unidec->postfrm->c[0] = unidec->prevfrm->c[2] + unidec->cols * unidec->rows * 64;
	unidec->postfrm->c[1] = unidec->postfrm->c[0] + unidec->cols * unidec->rows * 256;
	unidec->postfrm->c[2] = unidec->postfrm->c[1] + unidec->cols * unidec->rows * 64;
	unidec->bppxfrm->c[0] = unidec->postfrm->c[2] + unidec->cols * unidec->rows * 64;
	unidec->bppxfrm->c[1] = unidec->bppxfrm->c[0] + unidec->cols * unidec->rows * 256;
	unidec->bppxfrm->c[2] = unidec->bppxfrm->c[1] + unidec->cols * unidec->rows * 64;

	for(i = 0; i < unidec->cols + 2; i ++)
	{
		ref[i].mbMem.c[0] = ref[i].mbMem.c8x8;
		ref[i].mbMem.c[1] = ref[i].mbMem.c8x8 + 4;
		ref[i].mbMem.c[2] = ref[i].mbMem.c8x8 + 5;
		for(j = 0; j < 6; j ++)
			ref[i].mbMem.c8x8[j].offset = ((j < 4) ? 16 : 8) * unidec->cols;
	}

	this->seq = seq;
	width = mbWidth; height = mbHeight;
	offset = (mbHeight < 0) ? - (unidec->rows * mbHeight + 1) : 0;
}

CUniDecMEM::~CUniDecMEM() { delete mem; }

void	CUniDecMEM::UpdateFrame(UINT8 *opMem, SINT32 ddWidth, SINT8 do_pp, SINT8 ip)
{
	offShow = ddWidth * height;
	unidec->mbShow->offset = ddWidth;
	this->opMem = opMem + offset * ddWidth;
	this->do_pp = do_pp;

	SINT32 i, j;

	for(i = 0; i < 3; i ++)
		mbMem->c[i]->ptr = unidec->bppxfrm->c[i];

	mbMem->c8x8[1].ptr = mbMem->c8x8[0].ptr + 8;
	mbMem->c8x8[2].ptr = mbMem->c8x8[0].ptr + (unidec->cols << 7);
	mbMem->c8x8[3].ptr = mbMem->c8x8[1].ptr + (unidec->cols << 7);

	for(i = 0; i < unidec->cols + 2; i ++)
		for(j = 0; j < 6; j ++)
			ref[i].mbMem.c8x8[j].ptr = mbMem->c8x8[j].ptr;

	if(ip)
	{
		TUniDecFrm *frm	= unidec->prevfrm;
		unidec->prevfrm	= unidec->postfrm;
		unidec->postfrm	= frm;
		unidec->curMb	= unidec->posMb;
		unidec->outMb	= (seq == IPB) ? unidec->preMb : unidec->posMb;
		unidec->oputfrm	= (seq == IPB) ? unidec->prevfrm : unidec->postfrm;
	}
	else
		unidec->curMb	=
		unidec->outMb	= mbMem;

	pre_pos = unidec->prevfrm->c[0] - unidec->postfrm->c[0];
	bpp_pos = unidec->bppxfrm->c[0] - unidec->postfrm->c[0];

	idx[0] = - 1; idx[1] = 0; idx[2] = 1; idx[3] = unidec->cols - 1; idx[4] = unidec->cols;
	unidec->col = - 1, unidec->row = 0;
}



/**	ENDOFSOURCEFILE: "MemDec.cpp"
 */
