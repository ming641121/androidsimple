/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_FMT/mp4_vld.cpp"
 *	Description: MPEG4 VLD routines. Implementation of class CMp4Vld
 *	History:
 *		05-07-2002 - Weimin, file created
 */
extern "C" { 
#include <math.h>
};

#include "mp4_vld.h"

#define DEFAULT_MP4_SEQMODE		IPB
#define DEFAULT_MP4_FPMODE		FLHALF
#define DEFAULT_MP4_UVMODE		MPEG4
#define DEFAULT_MP4_DQMODE		MPEG4
#define DEFAULT_MP4_ACPRED		0
#define DEFAULT_MP4_USERQ		0
#define DEFAULT_MP4_INTERLACE	0
//inline functions

/* Note: On VxWorks 5.5 (Intel XScale), inline functions are not
 * supported
 */
#ifdef VXWORKS
#define  abs(x)  ((x) >= 0 ? (x) : -(x))
#endif /* !VXWORKS */
/* Constants */
static const SINT32 areamap[6] = { 0, 1, 3, 5, 2, 4};
static const SINT32 Xpos[6] = {-1, 0, -1, 0, -1, -1};
static const SINT32 Ypos[6] = {-2, -2, 0, 0, -2, -2};
static const SINT32 Xtab[6] = {1, 0, 3, 2, 4, 5};
static const SINT32 Ytab[6] = {2, 3, 0, 1, 4, 5};
static const SINT32 Ztab[6] = {3, 2, 1, 0, 4, 5};

_INLINE SINT8 CMp4Vld::SkipMblk(TMP_BlkInfo *mb11)
{
	if (strInfo->wismode && frmInfo->ftype != I_FRAME)
	{
		SINT8 skip = vlcLoad(&vlc, 1);
		if (skip)
		{
			mb11->vx[0] = mb11->vy[0] = 
			mb11->vx[1] = mb11->vy[1] = 
			mb11->vx[2] = mb11->vy[2] = 
			mb11->vx[3] = mb11->vy[3] = 
			mb11->vx[4] = mb11->vy[4] = 
			mb11->vx[5] = mb11->vy[5] = 0;
			mb11->cbp = 0;
			mb11->mbtype = MB_FORWARD;
			if (frmInfo->ftype == B_FRAME)
			{
				if (vlcLoad(&vlc, 1))
					mb11->mbtype = MB_BACKWARD;
			}

			blkPair->pair[0] = blkPair->pair[1] = blkPair->pair[2] = blkPair->pair[3] = blkPair->pair[4] = blkPair->pair[5] = 0;
			mb11->Q = quant;
			mb11->dc[0] = mb11->dc[1] = mb11->dc[2] = mb11->dc[3] = DC_Y[mb11->Q];
			mb11->dc[4] = mb11->dc[5] = DC_UV[mb11->Q];
			return 1;
		}
		else if (frmInfo->ftype == B_FRAME)
		{
			SINT8 mbtype = vlcRead(&vlc, 2);
			if (mbtype > 1)
			{
				vlcSkip(&vlc, 1);
				mb11->mbtype = MB_FORWARD;
			}
			else
			{
				vlcSkip(&vlc, 2);
				mb11->mbtype = mbtype ? MB_BACKWARD : MB_INTRA;
			}
		}
		else
			mb11->mbtype = MB_FORWARD;
	}
	else if (frmInfo->ftype != I_FRAME)
	{
		SINT8 skip = vlcRead(&vlc, 1);
		if (skip)
		{
			vlcSkip(&vlc, 1);
			mb11->vx[0] = mb11->vy[0] = 
			mb11->vx[1] = mb11->vy[1] = 
			mb11->vx[2] = mb11->vy[2] = 
			mb11->vx[3] = mb11->vy[3] = 
			mb11->vx[4] = mb11->vy[4] = 
			mb11->vx[5] = mb11->vy[5] = 0;
			mb11->cbp = 0;
			mb11->mbtype = MB_FORWARD;

			blkPair->pair[0] = blkPair->pair[1] = blkPair->pair[2] = blkPair->pair[3] = blkPair->pair[4] = blkPair->pair[5] = 0;
			mb11->Q = quant;
			mb11->dc[0] = mb11->dc[1] = mb11->dc[2] = mb11->dc[3] = DC_Y[mb11->Q];
			mb11->dc[4] = mb11->dc[5] = DC_UV[mb11->Q];
			return 1;
		}
		else {
			mb11->mbtype = MB_FORWARD;
			if (frmInfo->ftype == P_FRAME)
				vlcSkip(&vlc, 1);
		}
	}

	return 0;
}

_INLINE SINT8 CMp4Vld::GetCBP_B(SINT8 &cbp)
{
	UINT32 modb = vlcLoad(&vlc, 2);
	UINT32 mbtype = 0;
	mbtype = vlcRead(&vlc, 4);
	if (mbtype >= 8) {
		mbtype = MB_DIRECT;
		vlcSkip(&vlc, 1);
	}
	else if (mbtype >= 4) {
		mbtype = MB_FORWARD | MB_BACKWARD;
		vlcSkip(&vlc, 2);
	}
	else if (mbtype >= 2) {
		mbtype = MB_BACKWARD;
		vlcSkip(&vlc, 3);
	}
	else {
		mbtype = MB_FORWARD;
		vlcSkip(&vlc, 4);
	}
	if (modb == 1)
		cbp = 0;
	else
		cbp = vlcLoad(&vlc, 6);

//	if (cbp != 0 && !(mbtype & MB_DIRECT)) // DQUANT
//		vlcSkip(&vlc, 1);

	return mbtype;
}

_INLINE SINT8 CMp4Vld::GetCBPC(SINT8 &cbpc)
{
	if (frmInfo->ftype == I_FRAME)
	{
		UINT32 code = vlcRead(&vlc, 9);
		if (code == 1)
		{
			vlcSkip(&vlc, 9);
			cbpc = -1;
			return 0;
		}
		else if (code < 8)
			return -1;

		code >>= 3;
		if (code >= 32)
		{
			vlcSkip(&vlc, 1);
			cbpc = 0;
			return 3;
		}
		vlcSkip(&vlc, MP4MCBPCTabIntra[code].len);
		cbpc = MP4MCBPCTabIntra[code].cbp;
		return MP4MCBPCTabIntra[code].mbtype;
	}
	else
	{
		UINT32 code = vlcRead(&vlc, 9);
		if (code == 1)
		{
			vlcSkip(&vlc, 9);
			cbpc = -1;
			return 0;
		}
		else if (code == 0)
			return -1;

		if (code >= 256)
		{
			vlcSkip(&vlc, 1);
			cbpc = 0;
			return 0;
		}
		vlcSkip(&vlc, MP4MCBPCTabInter[code].len);
		cbpc = MP4MCBPCTabInter[code].cbp;
		return MP4MCBPCTabInter[code].mbtype;
	}
}

_INLINE SINT8 CMp4Vld::GetCBPY(SINT8 mbtype)
{
	SINT8  cbpy;
	UINT32 code = vlcRead(&vlc, 6);

	if (code < 2) return -1;
			  
	if (code >= 48) 
	{
		vlcSkip(&vlc, 2);
		cbpy = 15;
	} 
	else 
	{
		vlcSkip(&vlc, MP4CBPYTabIntra[code].len);
		cbpy = MP4CBPYTabIntra[code].cbp;
	}

	if (!(mbtype & MB_INTRA)) cbpy = 15 - cbpy;

	return cbpy;
}

_INLINE SINT8 CMp4Vld::GetACPred(SINT8 mbtype)
{
	if (mbtype & MB_INTRA)
		return vlcLoad(&vlc, 1);
	else
		return 0;
}

_INLINE SINT8 CMp4Vld::GetDQuant(SINT8 mbtype)
{
	SINT8 dquant;
	if (mbtype & MB_QUANT)
	{
		dquant = vlcLoad(&vlc, 2);
		quant += MP4DQtab[dquant];
		quant = CLP(quant, RC_MIN_Q, RC_MAX_Q);
	}
	return quant;
}

_INLINE SINT32 CMp4Vld::GetMVData()
{
	if (vlcLoad(&vlc, 1)) return 0;
	
	UINT32 code = vlcRead(&vlc, 12);
	if (code >= 512)
	{
		code = (code >> 8) - 2;
		vlcSkip(&vlc, MP4MVTab0[code].len);
		return MP4MVTab0[code].level;
	}
	else if (code >= 128)
	{
		code = (code >> 2) - 32;
		vlcSkip(&vlc, MP4MVTab1[code].len);
		return MP4MVTab1[code].level;
	}
	
	code -= 4; 

	vlcSkip(&vlc, MP4MVTab2[code].len);
	return MP4MVTab2[code].level;
}

_INLINE SINT8 CMp4Vld::SetMV(SINT32 block, TMP_BlkInfo *mb01, TMP_BlkInfo *mb02, TMP_BlkInfo *mb10, TMP_BlkInfo *mb11)
{
	SINT32 hor_mv_data, ver_mv_data, hor_mv_res, ver_mv_res;
	SINT32 f_code = ((mb11->mbtype & MB_FORWARD) ? forward_f_code : backward_f_code);
	SINT32 scale_fac = 1 << (f_code - 1);
	SINT32 high = (32 * scale_fac) - 1;
	SINT32 low = ((-32) * scale_fac);
	SINT32 range = (64 * scale_fac);

	SINT32 mvd_x, mvd_y, pmv[2], mv_x, mv_y;

	hor_mv_data = GetMVData();

	if ((scale_fac == 1) || (hor_mv_data == 0))
		mvd_x = hor_mv_data;
	else 
	{
		hor_mv_res = vlcLoad(&vlc, f_code - 1); // mv residual
		mvd_x = ((abs(hor_mv_data) - 1) * scale_fac) + hor_mv_res + 1;
		if (hor_mv_data < 0)
			mvd_x = - mvd_x;
	}

	ver_mv_data = GetMVData(); 

	if ((scale_fac == 1) || (ver_mv_data == 0))
		mvd_y = ver_mv_data;
	else 
	{
		ver_mv_res = vlcLoad(&vlc, f_code - 1);
		mvd_y = ((abs(ver_mv_data) - 1) * scale_fac) + ver_mv_res + 1;
		if (ver_mv_data < 0)
			mvd_y = - mvd_y;
	}

	FindPMV((block==-1 ? 0 : block), pmv, mb01, mb02, mb10, mb11);

	mv_x = pmv[0] + mvd_x;
	if (mv_x < low)
		mv_x += range;
	if (mv_x > high)
		mv_x -= range;

	mv_y = pmv[1] + mvd_y;
	if (mv_y < low)
		mv_y += range;
	if (mv_y > high)
		mv_y -= range;

#ifdef _DEBUG
//	if (frmInfo->ftype == B_FRAME)
//		fprintf(fp, "%d, %d: MV(%d, %d), PMV(%d, %d), MVD(%d, %d)\n", mb11->col, mb11->row, mv_x, mv_y, pmv[0], pmv[1], mvd_x, mvd_y);
#endif

	if (block == -1) 
	{
		SINT32 i;
		for (i = 0; i < 4; i++) 
		{
			mb11->vx[i] = mv_x;
			mb11->vy[i] = mv_y;
		}
		if (frmInfo->ftype == B_FRAME)
		{
			if (mb11->mbtype & MB_FORWARD) { pf_mv[0] = mv_x; pf_mv[1] = mv_y; }
			else { pb_mv[0] = mv_x; pb_mv[1] = mv_y; }
		}
	}
	else 
	{
		mb11->vx[block] = mv_x;
		mb11->vy[block] = mv_y;
	}


	return 1;	
}


_INLINE void CMp4Vld::FindPMV(SINT32 block, SINT32 *pmv, TMP_BlkInfo *mb01, TMP_BlkInfo *mb02, TMP_BlkInfo *mb10, TMP_BlkInfo *mb11)
{

	if (frmInfo->ftype == B_FRAME)
	{
		if (mb11->mbtype & MB_FORWARD)
		{
			pmv[0] = pf_mv[0];
			pmv[1] = pf_mv[1];
		}
		else
		{
			pmv[0] = pb_mv[0];
			pmv[1] = pb_mv[1];
		}
		return;
	}

	SINT32 p1x, p2x, p3x, p1y, p2y, p3y;
	SINT32 col = mb11->col;
	SINT32 row = mb11->row;
	pmv[0] = pmv[1] = 0;
	SINT32 l = (col == 0), r = (col == strInfo->cols - 1), t = (row == 0);
	SINT32 area = (l << 2) + (r << 1) + t;

	switch(areamap[area])
	{
	case 0:
		switch (block)
		{
			case 0: 
				p1x = mb10->vx[1]; p1y = mb10->vy[1];
				p2x = mb01->vx[2]; p2y = mb01->vy[2];
				p3x = mb02->vx[2]; p3y = mb02->vy[2];
				break;
			case 1:
				p1x = mb11->vx[0]; p1y = mb11->vy[0];
				p2x = mb01->vx[3]; p2y = mb01->vy[3];
				p3x = mb02->vx[2]; p3y = mb02->vy[2];
				break;
			case 2:
				p1x = mb10->vx[3]; p1y = mb10->vy[3];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
			default: // case 3
				p1x = mb11->vx[2]; p1y = mb11->vy[2];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
		}
		break;
	case 1:
		switch (block)
		{
			case 0: 
				pmv[0] = mb10->vx[1]; pmv[1] = mb10->vy[1];
				return;
			case 1:
				pmv[0] = mb11->vx[0]; pmv[1] = mb11->vy[0];
				return;
			case 2:
				p1x = mb10->vx[3]; p1y = mb10->vy[3];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
			default: // case 3
				p1x = mb11->vx[2]; p1y = mb11->vy[2];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
		}
		break;
	case 2:
		switch (block)
		{
			case 0: 
				p1x = p1y = 0;
				p2x = mb01->vx[2]; p2y = mb01->vy[2];
				p3x = mb02->vx[2]; p3y = mb02->vy[2];
				break;
			case 2:
				p1x = p1y = 0;
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
			case 1:
				p1x = mb11->vx[0]; p1y = mb11->vy[0];
				p2x = mb01->vx[3]; p2y = mb01->vy[3];
				p3x = mb02->vx[2]; p3y = mb02->vy[2];
				break;
			default: // case 3
				p1x = mb11->vx[2]; p1y = mb11->vy[2];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
		}
		break;
	case 3:
		switch (block)
		{
			case 0: 
				p1x = mb10->vx[1]; p1y = mb10->vy[1];
				p2x = mb01->vx[2]; p2y = mb01->vy[2];
				p3x = p3y = 0;
				break;
			case 1:
				p1x = mb11->vx[0]; p1y = mb11->vy[0];
				p2x = mb01->vx[3]; p2y = mb01->vy[3];
				p3x = p3y = 0;
				break;
			case 2:
				p1x = mb10->vx[3]; p1y = mb10->vy[3];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
			default: // case 3
				p1x = mb11->vx[2]; p1y = mb11->vy[2];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
		}
		break;
	case 4:
		switch (block)
		{
			case 0: 
				return;
			case 1:
				pmv[0] = mb11->vx[0]; pmv[1] = mb11->vy[0];
				return;
			case 2:
				p1x = p1y = 0;
//				p2x = mb01->vx[2]; p2y = mb01->vy[2];
//				p3x = mb02->vx[2]; p3y = mb02->vy[2];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
			default: // case 3
				p1x = mb11->vx[2]; p1y = mb11->vy[2];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
		}
		break;
	default:
		switch (block)
		{
			case 0: 
				pmv[0] = mb10->vx[1]; pmv[1] = mb10->vy[1];
				return;
			case 1:
				pmv[0] = mb11->vx[0]; pmv[1] = mb11->vy[0];
				return;
			case 2:
				p1x = mb10->vx[3]; p1y = mb10->vy[3];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
			default: // case 3
				p1x = mb11->vx[2]; p1y = mb11->vy[2];
				p2x = mb11->vx[0]; p2y = mb11->vy[0];
				p3x = mb11->vx[1]; p3y = mb11->vy[1];
				break;
		}
		break;
	}

	pmv[0] = p1x + p2x + p3x - MIN(p1x, MIN(p2x, p3x)) - MAX(p1x, MAX(p2x, p3x));
	pmv[1] = p1y + p2y + p3y - MIN(p1y, MIN(p2y, p3y)) - MAX(p1y, MAX(p2y, p3y));
	return;
}


_INLINE void CMp4Vld::GetMotionVector(TMP_BlkInfo *mb01, TMP_BlkInfo *mb02, TMP_BlkInfo *mb10, TMP_BlkInfo *mb11)
{
	SINT32 i;

	if (mb11->mbtype & MB_4V)
	{
		if (mb11->col == 6 && mb11->row == 8)
			i = 0;
		for (i = 0; i < 4; i++)
			SetMV(i, mb01, mb02, mb10, mb11);
		SINT32 sum = mb11->vx[0] + mb11->vx[1] + mb11->vx[2] + mb11->vx[3];
		mb11->vx[4] = mb11->vx[5] = (ChromaMVRoundTab[ABS(sum) & 15] + ((ABS(sum) >> 4) << 1));
		if (sum < 0) mb11->vx[4] = mb11->vx[5] = -mb11->vx[4];
		sum = mb11->vy[0] + mb11->vy[1] + mb11->vy[2] + mb11->vy[3];
		mb11->vy[4] = mb11->vy[5] = (ChromaMVRoundTab[ABS(sum) & 15] + ((ABS(sum) >> 4) << 1));
		if (sum < 0) mb11->vy[4] = mb11->vy[5] = -mb11->vy[4];

		if (frmInfo->ftype == B_FRAME)
		{
			if (mb11->mbtype & MB_FORWARD) { pf_mv[0] = mb11->vx[0]; pf_mv[1] = mb11->vy[0]; }
			else { pb_mv[0] = mb11->vx[0]; pb_mv[1] = mb11->vy[0]; }
		}
	}
	else if (!(mb11->mbtype & MB_INTRA))
	{
		SetMV(-1, mb01, mb02, mb10, mb11);
		mb11->vx[4] = mb11->vx[5] = (mb11->vx[0] >> 1) | ((mb11->vx[0] & 3) != 0);
		mb11->vy[4] = mb11->vy[5] = (mb11->vy[0] >> 1) | ((mb11->vy[0] & 3) != 0);
	}
	else
	{
		for (i = 0; i < 6; i++)
			mb11->vx[i] = mb11->vy[i] = 0;
//		pf_mv[0] = pf_mv[1] = pb_mv[0] = pb_mv[1] = 0; 
	}
}

_INLINE SINT8 CMp4Vld::GetDCSizeLum()
{
	UINT32 code;

	code = vlcRead(&vlc, 3);
	if (code)
	{
		code <<= 1;
		vlcSkip(&vlc, MP4DCSizeLum[code+1]);
		return MP4DCSizeLum[code];
	}

	SINT32 i;
	code = vlcRead(&vlc, 11);
	for (i = 4; i < 12; i++)
	{
		if (code & Mask[12 - i]) break;
	}
	
	vlcSkip(&vlc, i);

	return i+1;
}

_INLINE SINT8 CMp4Vld::GetDCSizeChr()
{
	UINT32 code;

	code = vlcLoad(&vlc, 2);
	if (code) return MP4DCSizeChr[code];

	SINT32 i;
	code = vlcRead(&vlc, 10);
	for (i = 1; i < 11; i++)
		if (code & Mask[11 - i]) break;

	vlcSkip(&vlc, i);
	
	return i + 2;
}

_INLINE SINT32 CMp4Vld::GetDCDiff(SINT32 dc_size)
{
	SINT32 code = vlcLoad(&vlc, dc_size);
	SINT32 msb  = code >> (dc_size - 1);

	if (msb == 0) 
		return -(code ^ ((1 << dc_size) - 1));
	else 
		return code;
}

_INLINE void	CMp4Vld::DCRecon(SINT32 block, TMP_BlkInfo *mb00, TMP_BlkInfo *mb01, TMP_BlkInfo *mb10, TMP_BlkInfo *mb11)
{
	SINT32 i, grad_hor, grad_ver, dc_pred;
	SINT32 block_A, block_B, block_C;

	SINT32 col = mb11->col;
	SINT32 row = mb11->row;
	SINT32 Q = mb11->Q;
	TMP_BlkInfo *mbx[4];
	mbx[0] = mb00; mbx[1] = mb01;
	mbx[2] = mb10; mbx[3] = mb11;
	i = block;

	if (col == 0 && row == 0)
	{
		block_A = ((i == 1 || i == 3) && (mbx[3 + Xpos[i]]->mbtype & MB_INTRA)) ? 
			((mbx[3 + Xpos[i]]->dc[Xtab[i]])<<6) : ((i < 4) ? DC_Y[Q] : DC_UV[Q]); //128;
		block_B = (i == 3 && (mbx[3 + Xpos[i] + Ypos[i]]->mbtype & MB_INTRA)) ? 
			((mbx[3 + Xpos[i] + Ypos[i]]->dc[Ztab[i]])<<6) : ((i < 4) ? DC_Y[Q] : DC_UV[Q]); //128;
		block_C = ((i == 2 || i == 3) && (mbx[3 + Ypos[i]]->mbtype & MB_INTRA)) ? 
			((mbx[3 + Ypos[i]]->dc[Ytab[i]])<<6) : ((i < 4) ? DC_Y[Q] : DC_UV[Q]); //128;
	}
	else if (col == 0)
	{
		block_A = ((i == 1 || i == 3) && (mbx[3 + Xpos[i]]->mbtype & MB_INTRA)) ? 
			((mbx[3 + Xpos[i]]->dc[Xtab[i]])<<6) : ((i < 4) ? DC_Y[Q] : DC_UV[Q]); //128;
		block_B = ((i == 1 || i == 3) && (mbx[3 + Xpos[i] + Ypos[i]]->mbtype & MB_INTRA)) ? 
			((mbx[3 + Xpos[i] + Ypos[i]]->dc[Ztab[i]])<<6) : ((i < 4) ? DC_Y[Q] : DC_UV[Q]); //128;
		block_C = (mbx[3 + Ypos[i]]->mbtype & MB_INTRA) ? ((mbx[3 + Ypos[i]]->dc[Ytab[i]])<<6) :
			((i < 4) ? DC_Y[Q] : DC_UV[Q]);
	}
	else if (row == 0)
	{
		block_A = (mbx[3 + Xpos[i]]->mbtype & MB_INTRA) ? ((mbx[3 + Xpos[i]]->dc[Xtab[i]])<<6) :
			((i < 4) ? DC_Y[Q] : DC_UV[Q]);
		block_B = ((i == 2 || i == 3) && (mbx[3 + Xpos[i] + Ypos[i]]->mbtype & MB_INTRA)) ? 
			((mbx[3 + Xpos[i] + Ypos[i]]->dc[Ztab[i]])<<6) : ((i < 4) ? DC_Y[Q] : DC_UV[Q]); //128;
		block_C = ((i == 2 || i == 3) && (mbx[3 + Ypos[i]]->mbtype & MB_INTRA)) ? 
			((mbx[3 + Ypos[i]]->dc[Ytab[i]])<<6) : ((i < 4) ? DC_Y[Q] : DC_UV[Q]); //128;
	}
	else
	{
		block_A = (mbx[3 + Xpos[i]]->mbtype & MB_INTRA) ? ((mbx[3 + Xpos[i]]->dc[Xtab[i]])<<6) :
			((i < 4) ? DC_Y[Q] : DC_UV[Q]);
		block_B = (mbx[3 + Xpos[i] + Ypos[i]]->mbtype & MB_INTRA) ? 
			((mbx[3 + Xpos[i] + Ypos[i]]->dc[Ztab[i]])<<6) : ((i < 4) ? DC_Y[Q] : DC_UV[Q]);
		block_C = (mbx[3 + Ypos[i]]->mbtype & MB_INTRA) ? 
			((mbx[3 + Ypos[i]]->dc[Ytab[i]])<<6) : ((i < 4) ? DC_Y[Q] : DC_UV[Q]);
	}

	grad_hor = block_B - block_C;
	grad_ver = block_A - block_B;
	grad_hor = grad_hor > 0 ? grad_hor : -grad_hor;
	grad_ver = grad_ver > 0 ? grad_ver : -grad_ver;
	if (grad_ver < grad_hor)
		dc_pred = block_C;
	else
		dc_pred = block_A;

	mb11->dc[i] += (dc_pred + 32) >> 6;
}

_INLINE void	CMp4Vld::GetDCValue(SINT32 block, TMP_BlkInfo *mb00, TMP_BlkInfo *mb01, TMP_BlkInfo *mb10, TMP_BlkInfo *mb11)
{
	SINT8	dc_size;
	SINT32	dc_diff;

	if (block < 4) 
	{
		dc_size = GetDCSizeLum();
		if (dc_size != 0) 
			dc_diff = GetDCDiff(dc_size);
		else 
			dc_diff = 0;
		if (dc_size > 8)
			vlcSkip(&vlc, 1); // marker bit
	}
	else 
	{
		dc_size = GetDCSizeChr();
		if (dc_size != 0)
			dc_diff = GetDCDiff(dc_size);
		else 
			dc_diff = 0;
		if (dc_size > 8)
			vlcSkip(&vlc, 1); // marker bit
	}

	mb11->dc[block] = dc_diff;
	// dc reconstruction, prediction direction
	DCRecon(block, mb00, mb01, mb10, mb11);
}

_INLINE VLDtable *CMp4Vld::vldTableB16(UINT32 reg)
{
	VLDtable *tab = NULL;
	UINT8 *code = (UINT8 *)&reg;

#ifdef _BIG_ENDIAN_

	if (code[1] >= 32)
		tab = &tableB16_1[code[1]];
	else if (code[1] >= 8)
	{
		reg >>= 5;
		tab = &tableB16_2[code[2]];
	}
	else 
	{
		reg >>= 3;
		tab = &tableB16_3[code[2]];
	}
#else

	if (code[2] >= 32)
		tab = &tableB16_1[code[2]];
	else if (code[2] >= 8)
	{
		reg >>= 5;
		tab = &tableB16_2[code[1]];
	}
	else 
	{
		reg >>= 3;
		tab = &tableB16_3[code[1]];
	}


#endif
//	else
//		return NULL;
	vlcSkip(&vlc, tab->len);
	return tab;
}

_INLINE VLDtable *CMp4Vld::vldTableB17(UINT32 reg)
{
	VLDtable *tab = NULL;
	UINT8 *code = (UINT8 *)&reg;

#ifdef _BIG_ENDIAN_
	if (code[1] >= 32)
		tab = &tableB17_1[code[1]];
	else if (code[1] >= 8)
	{
		reg >>= 5;
		tab = &tableB17_2[code[2]];
	}
	else // if (code >= 16)
	{
		reg >>= 3;
		tab = &tableB17_3[code[2]];
	}
#else
	if (code[2] >= 32)
		tab = &tableB17_1[code[2]];
	else if (code[2] >= 8)
	{
		reg >>= 5;
		tab = &tableB17_2[code[1]];
	}
	else // if (code >= 16)
	{
		reg >>= 3;
		tab = &tableB17_3[code[1]];
	}
#endif
//	else
//		return NULL;
	vlcSkip(&vlc, tab->len);
	return tab;
}

_INLINE SINT32 CMp4Vld::vld8x8Intra(MpgvlcManager *vlc, SINT8 *run, SINT32 *lvl)
{
	SINT32 i = 0, level;
	UINT32 code;
	VLDtable *tab;

	do
	{
		code = vlcShow(vlc);
		tab = vldTableB16(code);
		if (tab->run != 64)
		{
			run[i] = tab->run;
			lvl[i++] = tab->level;
		}
		else	// escape mode
		{
			switch(vlcRead(vlc, 2))
			{
			case 0x0:
			case 0x1:	// escape mode 1
				vlcSkip(vlc, 1);
				code = vlcShow(vlc);
				tab = vldTableB16(code);
				level = ABS(tab->level) + MP4IntraMaxLevel[tab->last][tab->run];
				run[i] = tab->run;
				lvl[i++] = tab->level < 0 ? -level : level;
				break;
			case 0x2:	// escape mode 2
				vlcSkip(vlc, 2);
				code = vlcShow(vlc);
				tab = vldTableB16(code);
				run[i] = tab->run + MP4IntraMaxRun[tab->last][ABS(tab->level)] + 1;
				lvl[i++] = tab->level;
				break;
			case 0x3:	// escape mode 3, FLC
				vlcSkip(vlc, 2);
				tab = &tableB16_1[0];
				tab->last = vlcLoad(vlc, 1);
				run[i] = vlcLoad(vlc, 7) >> 1;
				level = vlcLoad(vlc, 13) >> 1;
				lvl[i++] = (level & 0x800) ? (level | (-1 ^ 0xfff)) : level;
				break;
			}
		}
	}while(!tab->last);

	return i;
}

_INLINE SINT32 CMp4Vld::vld8x8Inter(MpgvlcManager *vlc, SINT8 *run, SINT32 *lvl)
{
	SINT32 i = 0, level;
	UINT32 code;
	VLDtable *tab;

	do
	{
		code = vlcShow(vlc);
		tab = vldTableB17(code);
		if (tab->run != 64)
		{
			run[i] = tab->run;
			lvl[i++] = tab->level;
		}
		else	// escape mode
		{
			switch(vlcRead(vlc, 2))
			{
			case 0x0:
			case 0x1:	// escape mode 1
				vlcSkip(vlc, 1);
				code = vlcShow(vlc);
				tab = vldTableB17(code);
				level = ABS(tab->level) + MP4InterMaxLevel[tab->last][tab->run];
				run[i] = tab->run;
				lvl[i++] = tab->level < 0 ? -level : level;
				break;
			case 0x2:	// escape mode 2
				vlcSkip(vlc, 2);
				code = vlcShow(vlc);
				tab = vldTableB17(code);
				run[i] = tab->run + MP4InterMaxRun[tab->last][ABS(tab->level)] + 1;
				lvl[i++] = tab->level;
				break;
			case 0x3:	// escape mode 3, FLC
				vlcSkip(vlc, 2);
				tab = &tableB17_1[0];
				tab->last = vlcLoad(vlc, 1);
				run[i] = vlcLoad(vlc, 7) >> 1;
				level = vlcLoad(vlc, 13) >> 1;
				lvl[i++] = (level & 0x800) ? (level | (-1 ^ 0xfff)) : level;
				break;
			}
		}
	}while(!tab->last);

	return i;
}



// Interface functions

CMp4Vld::CMp4Vld(TMP_StrInfo *sInfo, TMP_FrmInfo *fInfo, TMP_BlkPair *mPair) :
	  CBaseVld(sInfo, fInfo, mPair) 
{
	SINT32 i;
	
	tableB16_1 = MP4ACtable;
	tableB16_2 = tableB16_1 + 256;
	tableB16_3 = tableB16_2 + 256;
	tableB17_1 = tableB16_3 + 256;
	tableB17_2 = tableB17_1 + 256;
	tableB17_3 = tableB17_2 + 256;

	for (i = 0; i < 768; i++)
	{
		MP4ACtable[i]		= MP4TableACIntra[i];
		MP4ACtable[768 + i] = MP4TableACInter[i];
	}

	pf_mv[0] = pf_mv[1] = pb_mv[0] = pb_mv[1] = 0;

	if (sInfo->interlace == FP_AUTO)sInfo->interlace= DEFAULT_MP4_INTERLACE;
	if (sInfo->acpred == FP_AUTO)	sInfo->acpred	= DEFAULT_MP4_ACPRED;
	if (sInfo->seq	== FP_AUTO)		sInfo->seq		= DEFAULT_MP4_SEQMODE;
	if (sInfo->fpmode == FP_AUTO)	sInfo->fpmode	= DEFAULT_MP4_FPMODE;
	if (sInfo->uvmode == FP_AUTO)	sInfo->uvmode	= DEFAULT_MP4_UVMODE;
	if (sInfo->dqmode == FP_AUTO)	sInfo->dqmode	= DEFAULT_MP4_DQMODE;
	if (sInfo->userq  == FP_AUTO)	sInfo->userq	= DEFAULT_MP4_USERQ;
	if (sInfo->wismode== FP_AUTO)	sInfo->wismode	= 1;

	fInfo->fno = 0;

#ifdef _DEBUG
	fp = fopen("c:\\mp4decode.txt", "wt");
#endif

}

SINT32 CMp4Vld::StrHead(SINT32 &bits)
{
	SINT32 nbits = vlc.index + 32;

	store_coding_state();
	
	if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);

	UINT32 vo_start_code = (vlcLoad(&vlc, 24) << 3) + vlcLoad(&vlc, 3);
	if (vo_start_code == VO_START_CODE)
	{
		vlcSkip(&vlc, 5);
		
		nbits += 32 + 9 + 1;
		if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
		UINT32 vol_start_code = (vlcLoad(&vlc, 24) << 4) + vlcLoad(&vlc, 4);
		if (vol_start_code != VOL_START_CODE) return reset_coding_state(bits, ERR_MISMCH);
		
		vlcSkip(&vlc, 4);
		vlcSkip(&vlc, 9);		// Random accessible VOL(1) + Visual object type indication(8)
		
		UINT32 layer_id = 1;
		if (vlcLoad(&vlc, 1))	// Is object layer identifier
		{
			nbits += 7;
			if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
			layer_id = vlcLoad(&vlc, 4);  // Visual object layer version(4) 
			vlcSkip(&vlc, 3);	// Visual object layer priority(3)
		}
		
		nbits += 4 + 1;
		if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
		vlcSkip(&vlc, 4);		// Aspect ratio information
		if (vlcLoad(&vlc, 1))	// VOL control parameter
		{
			nbits += 3 + 1;
			if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
			vlcSkip(&vlc, 3);	// chroma_format(2) + low_delay(1)
			if (vlcLoad(&vlc, 1))	// vbv_parameters
			{
				nbits += 16 + 16 + 16 + 15 + 16;
				if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
				vlcSkip(&vlc, 16);	// first_half_bit_rate(15) + marker
				vlcSkip(&vlc, 16);	// latter_half_bit_rate(15) + marker
				vlcSkip(&vlc, 16);	// first_half_vbv_buffer_size(15) + marker
				vlcSkip(&vlc, 15);	// latter_half_vbv_buffer_size(3) + first_half_vbv_occupancy(11) + marker
				vlcSkip(&vlc, 16);	// latter_half_vbv_occupancy
			}
		}
		
		nbits += 3 + 16 + 1 + 1;
		if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
		UINT32 shape = vlcLoad(&vlc, 2);		// VOL shape(2)
		vlcSkip(&vlc, 1);				// marker
		UINT32 time_increment_resolution = vlcLoad(&vlc, 16);
		vlcSkip(&vlc, 1);		// marker
		if (vlcLoad(&vlc, 1))	// fixed_vop_rate
		{
			SINT32 bit = (SINT32)ceil(log((REAL64)time_increment_resolution) / log(2.0));
			if (bit < 1) bit = 1;
			nbits += bit;
			if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
			UINT32 fixed_vop_time_increment = vlcLoad(&vlc, bit);
			strInfo->fps = time_increment_resolution / (REAL64)fixed_vop_time_increment;
		}
		else
			strInfo->fps = 29.97;
		
		vlcSkip(&vlc, 1);
		strInfo->cols = (vlcLoad(&vlc, 14) >> 1) >> 4;
		strInfo->rows = (vlcLoad(&vlc, 14) >> 1) >> 4;
		strInfo->interlace = vlcLoad(&vlc, 1);

		nbits += 4 + 1;
		if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
		vlcSkip(&vlc, 1);	// Disable OBMC (1)
		vlcSkip(&vlc, (layer_id == 1 ? 1 : 2)); //Enable sprite object(1 or 2)
		if (layer_id != 1 && shape != 0)
			vlcSkip(&vlc, 1); //Enable low-latency sprite
		vlcSkip(&vlc, 1);	// Video data is not 8-bit
		if (vlcLoad(&vlc, 1))	// VOL quantization type
		{
			nbits += 1;
			if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
			if (strInfo->userq = vlcLoad(&vlc, 1))	// load intra quant matrix
			{
				SINT32 k = 0;
				nbits += 64 * 8;
				if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
				while(k < 64) 
				{
					strInfo->intraq[TabNZScan[k]] = vlcLoad(&vlc, 8);
					k++;
				} 
			}
			nbits += 1;
			if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
			if (vlcLoad(&vlc, 1))		// load inter quant matrix
			{
				SINT32 k = 0;
				nbits += 64 * 8;
				if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
				while(k < 64) 
				{
					strInfo->interq[TabNZScan[k]] = vlcLoad(&vlc, 8);
					k++;
				} 
			}
		}

		nbits += 1;
		if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
		if (layer_id != 1)
			vlcSkip(&vlc, 1); // VOL quarter pixel(1)
		vlcSkip(&vlc, 1);  // Disable complexity estimation(1)
		vlcSkip(&vlc, 1);  // Disable re-sync marker(1)
		vlcSkip(&vlc, 1);  // Enable data partitioning(1)
		if (layer_id != 1) {
			if (vlcLoad(&vlc, 1)) {  // Enable newpred(1)
				vlcSkip(&vlc, 2);	// requested_upstream_message_type
				vlcSkip(&vlc, 1);	// newpred_segment_type
			}
			vlcSkip(&vlc, 1); // Enable reduced resolution(1)
		}
		vlcSkip(&vlc, 1); // Scalability coding(1)

		nextstartcode();

#ifdef 	_BIG_ENDIAN_
		store_coding_state();
		UINT32 user_data_start_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
		if (user_data_start_code == 0x000001B2)
#else
		UINT32 user_data_start_code = *((UINT32 *)(vlc.codeStr - 3));
		if (user_data_start_code == 0xB2010000)
#endif
		{
			align();
			vlcSkip(&vlc, 24);
			vlcSkip(&vlc,  8);

			while(vlcRead(&vlc, 24) != 0x000001)
				vlcSkip(&vlc, 8);
		}
		else
			reset_coding_state(bits, ERR_MISMCH);

		bits =  vlc.index;
		return SUCCESS;
	}
	return reset_coding_state(bits, ERR_MISMCH);
}

SINT32 CMp4Vld::GopHead(SINT32 &bits, SINT8* data)
{
	SINT32 nbits = vlc.index;
	nbits += 32;

	store_coding_state();

	if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
	UINT32 gop_start_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
	if (gop_start_code == GOP_START_CODE)
	{

		nbits += 24 + 32;
		if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);
		vlcSkip(&vlc, 24);	// time code(18) + closed_gop(1) + broken link(1) + stuffing(4)
		
		store_coding_state();
		UINT32 user_data_start_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
		if (user_data_start_code == 0x000001B2)
		{
			vlcSkip(&vlc, 24);
			vlcSkip(&vlc,  8);

			nbits += 8;
			if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);

			if ( data ) data[0] = 0;
			if (vlcRead(&vlc, 8) == 0xF1) // on screen display text
			{
				vlcSkip(&vlc, 8);

				SINT32 index = 0;
				UINT32 ch;
				if ( ( ch = vlcRead(&vlc, 8) ) == 0xFF ) // osd display options
				{
					for ( SINT32 j = 0 ; j < 10 ; j ++ ) // sizeof(OSD_DISPLAY_OPTIONS)
					{
						ch = vlcLoad(&vlc, 8);
						data[index++] = ch;
					}
				}

				while ( ch = vlcLoad(&vlc, 8) )
				{
					if ( index < 127 )
					{
						if ( data ) data[index] = ch;
						index++;
					}
				}
				if (data) data[index] = 0; // trailing 0
			}

			if (vlcRead(&vlc, 8) == 0xF0)
			{
				vlcSkip(&vlc, 8);

				nbits += 16;
				if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);

				SINT8 fps_col_row, seq_fpmode, uvmode, dqmode, acpred, userq;
				
				vlcSkip(&vlc, 1);
				fps_col_row = vlcLoad(&vlc, 1);
				seq_fpmode	= vlcLoad(&vlc, 1);
				uvmode		= vlcLoad(&vlc, 1);
				dqmode		= vlcLoad(&vlc, 1);
				acpred		= vlcLoad(&vlc, 1);
				userq		= vlcLoad(&vlc, 1);
				vlcSkip(&vlc, 1);

				vlcSkip(&vlc, 8);

				nbits += (fps_col_row ? 32 : 0) + (seq_fpmode ? 8 : 0) + 
					(uvmode ? 8 : 0) + (dqmode ? 8 : 0) + (userq ? 64 * 8 * 2 : 0);
				if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);

				if (fps_col_row)
				{
					strInfo->wismode = vlcLoad(&vlc, 1);
					strInfo->fps = 30000.0 / vlcLoad(&vlc, 15);
					strInfo->cols = vlcLoad(&vlc, 8);
					strInfo->rows = vlcLoad(&vlc, 8);
				}

				if (seq_fpmode)
				{
					vlcSkip(&vlc, 1);
					strInfo->seq	= vlcLoad(&vlc, 3);
					strInfo->fpmode	= vlcLoad(&vlc, 4);
				}
				else
				{
					strInfo->seq	= DEFAULT_MP4_SEQMODE;
					strInfo->fpmode = DEFAULT_MP4_FPMODE;
				}

				if (uvmode)
					strInfo->uvmode = vlcLoad(&vlc, 8) & 0x7f;
				else
					strInfo->uvmode = DEFAULT_MP4_UVMODE;

				if (dqmode)
					strInfo->dqmode = vlcLoad(&vlc, 8) & 0x7f;
				else
					strInfo->dqmode = DEFAULT_MP4_DQMODE;

				if (acpred)
					strInfo->acpred = acpred;
				else
					strInfo->acpred = DEFAULT_MP4_ACPRED;

				if (userq)
				{
					SINT32 j;
					strInfo->userq = userq;
					for (j = 0; j < 64; j++)
						strInfo->intraq[TabNZScan[j]] = vlcLoad(&vlc, 8);
					for (j = 0; j < 64; j++)
						strInfo->interq[TabNZScan[j]] = vlcLoad(&vlc, 8);
				}
			}
			else
			{
				nextstartcode();
			}
		}
		else
			reset_coding_state(bits, ERR_MISMCH);

		bits = vlc.index;
		return SUCCESS;
	}
	return reset_coding_state(bits, ERR_MISMCH);
}

SINT32 CMp4Vld::FrmHead(SINT32 &bits)
{
	SINT32 nbits = vlc.index;
	nbits += 128; // 32 + 3 + 17 + 1 + 3 + 1 + 3 + 5 + 3 + 3;

	store_coding_state();
	if (bits_quota < nbits) return reset_coding_state(bits, ERR_MEMORY);

	UINT32 vop_start_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
	if (vop_start_code != VOP_START_CODE) return reset_coding_state(bits, ERR_MISMCH);

	frmInfo->ftype = vlcLoad(&vlc, 2);
	while(vlcLoad(&vlc, 1) == 1);
	
	SINT32 fno = (vlcLoad(&vlc, 17) >> 1) & 0x7fff; //marker + VOP time increment + marker
	SINT32 pno = ((UINT32)frmInfo->fno) & 0x7fff;
	if (fno < pno - 0x4000)
		fno += 0x8000;
	frmInfo->fno += fno - pno;

	if (vlcLoad(&vlc, 1) != 1)	// skip frame
	{
		frmInfo->ftype = D_FRAME;
//		nextstartcode();
		bits = vlc.index;
		return SUCCESS;
	}

	if (frmInfo->ftype == P_FRAME)
	{
		vlcSkip(&vlc, 1);	// rounding type = 0
	}

	vlcSkip(&vlc, 3);		// Intra DC VLC switch
	frmInfo->fq = quant = vlcLoad(&vlc, 5);

	if (frmInfo->ftype != I_FRAME)
	{
		forward_f_code = vlcLoad(&vlc, 3);
	}
	else
	{
		SINT32 j, k;
		for (j = 0; j < 45; j++)
			for (k = 0; k < 36; k++)
				m_mbmodeP[j][k] = MB_INTRA;
	}
	if (frmInfo->ftype == B_FRAME)
	{
		backward_f_code = vlcLoad(&vlc, 3);
	}

	bits = vlc.index;
	pf_mv[0] = pf_mv[1] = pb_mv[0] = pb_mv[1] = 0;
	return SUCCESS;
}

SINT32 CMp4Vld::FrmTail(SINT32 &bits)
{
//	nextstartcode();
	align();
//	while (vlcRead(&vlc, 24) != 0x000001)
//		vlcSkip(&vlc, 8);
	bits = vlc.index;
	return SUCCESS;
}

SINT32 CMp4Vld::StrMblk(TMP_BlkInfo *mb00, TMP_BlkInfo *mb01, TMP_BlkInfo *mb02, 
		TMP_BlkInfo *mb10, TMP_BlkInfo *mb11)
{
	SINT32 i;
	SINT8 cbpc, cbpy, coded;
	SINT32 ini_len = vlc.index;

	if (mb11->col == 0)
		pf_mv[0] = pf_mv[1] = pb_mv[0] = pb_mv[1] = 0;
	if (strInfo->wismode == 0 && frmInfo->ftype == B_FRAME && m_mbmodeP[mb11->col][mb11->row] == 0)
	{
		acpred = 0;
		mb11->Q = quant;
		mb11->cbp = 0; mb11->mbtype = MB_FORWARD; 
		for (i = 0; i < 6; i++) {
			mb11->vx[i] = mb11->vy[i] = 0;
			blkPair->pair[i] = 0;
		}
#ifdef _DEBUG
		if (mb11->col == 0 && mb11->row == 0)
			fprintf(fp, "Frame type: %d\n", frmInfo->ftype);
		fprintf(fp, "MB(%d, %d), skip mode\n", mb11->col, mb11->row);
#endif
		return vlc.index;
	}

	if (SkipMblk(mb11)) 
	{
#ifdef _DEBUG
//		if (mb11->col == 0 && mb11->row == 0)
//			fprintf(fp, "Frame %d:\n\n", (SINT32)frmInfo->fno);
//		fprintf(fp, "(%d, %d)\n", mb11->col, mb11->row);
//		fprintf(fp, "(0, 0), (0, 0), (0, 0), (0, 0)\n\n");
		if (mb11->col == 0 && mb11->row == 0)
//			fprintf(fp, "Frame %d:\n", (SINT32)frmInfo->fno);
			fprintf(fp, "Frame type: %d\n", frmInfo->ftype);
//		fprintf(fp, "MB(%d, %d), Q: %d\n", mb11->col, mb11->row, mb11->Q);
		fprintf(fp, "MB(%d, %d), skip mode\n", mb11->col, mb11->row);
//		fprintf(fp, "MV: (0, 0)\n");
//		for (i = 0; i < 6; i++)
//			fprintf(fp, "block %d: 0\n", i);
#endif
		pf_mv[0] = pf_mv[1] = pb_mv[0] = pb_mv[1] = 0;
		if (frmInfo->ftype == P_FRAME)
			m_mbmodeP[mb11->col][mb11->row] = 0;
		return vlc.index;
	}

	if ((strInfo->wismode == 0) && (frmInfo->ftype == B_FRAME))
	{
		mb11->mbtype = GetCBP_B(cbpc);
		mb11->cbp = cbpc;
		acpred = 0;
		if (mb11->cbp) {
			SINT32 dquant = vlcLoad(&vlc, 1);
			if (dquant == 0)
				mb11->Q = quant;
			else {
				dquant = vlcLoad(&vlc, 1);
				if (dquant == 0)
					quant -= 2;
				else
					quant += 2;
				quant = CLP(quant, RC_MIN_Q, RC_MAX_Q);
				mb11->Q = quant;
			}
		}
		else
			mb11->Q = quant;
	}
	else
	{
		if ((i = GetCBPC(cbpc)) < 0) return vlc.index;
		
		if (i >= 3)
			mb11->mbtype = MP4MBTypeMap[i];
		else
			mb11->mbtype |= MP4MBTypeMap[i];

		acpred	= GetACPred(mb11->mbtype);

		cbpy = GetCBPY(mb11->mbtype);

		mb11->cbp = (cbpy << 2) + cbpc;

		mb11->Q = GetDQuant(mb11->mbtype);
	}

	if (frmInfo->ftype == P_FRAME)
		m_mbmodeP[mb11->col][mb11->row] = mb11->mbtype;

	GetMotionVector(mb01, mb02, mb10, mb11);	

	coded = mb11->cbp << 2;
	if (mb11->mbtype & MB_INTRA)
	{
		for (i = 0; i < 6; i++, coded <<= 1)
		{
			GetDCValue(i, mb00, mb01, mb10, mb11);
			blkPair->pair[i] = (coded < 0)? vld8x8Intra(&vlc, blkPair->run[i], blkPair->lvl[i]) : 0;
		}
	}
	else
	{
		for (i = 0; i < 6; i++, coded <<= 1)
		{
			mb11->dc[i] = ((i < 4) ? DC_Y[mb11->Q] : DC_UV[mb11->Q]);
			blkPair->pair[i] = (coded < 0) ? vld8x8Inter(&vlc, blkPair->run[i], blkPair->lvl[i]) : 0;
		}
	}

#ifdef _DEBUG
	SINT32 j;
	/*
//	fprintf(fp, "DC(%3d, %3d): %4x, %4x, %4x, %4x, %4x, %4x\n", mb11->col, mb11->row, mb11->dc[0], mb11->dc[1], mb11->dc[2], mb11->dc[3], mb11->dc[4], mb11->dc[5]);
//	for (i = 0; i < 6; i++)
	if (frmInfo->ftype != I_FRAME)
	{
//		fprintf(fp, "Block %d:\n", i);
//		for (SINT32 j = 0; j < blkPair->pair[i]; j++)
//			fprintf(fp, "%4x, %4x\n", blkPair->run[i][j], blkPair->lvl[i][j]);
		if (mb11->col == 0 && mb11->row == 0)
			fprintf(fp, "Frame %d:\n\n", (SINT32)frmInfo->fno);
		fprintf(fp, "(%d, %d)\n", mb11->col, mb11->row);
		fprintf(fp, "(%d, %d), ", mb11->vx[0], mb11->vy[0]);
		fprintf(fp, "(%d, %d), ", mb11->vx[1], mb11->vy[1]);
		fprintf(fp, "(%d, %d), ", mb11->vx[2], mb11->vy[2]);
		fprintf(fp, "(%d, %d)\n\n", mb11->vx[3], mb11->vy[3]);
	}
	*/
	if (mb11->col == 0 && mb11->row == 0)
//		fprintf(fp, "Frame: %d\n", (SINT32)frmInfo->fno);
//		fprintf(fp, "Frame type: %d\n", frmInfo->ftype);
		fprintf(fp, "Frame type: %d, number: %d\n", frmInfo->ftype, (SINT32)frmInfo->fno);
//	fprintf(fp, "byte length: %d\n", (vlc.index - ini_len)/8);
//	fprintf(fp, "MB(%d, %d), Q: %d.\n", mb11->col, mb11->row, mb11->Q);
	if (!(mb11->mbtype & MB_INTRA)) {
		if (frmInfo->ftype == B_FRAME) {
			if (mb11->mbtype & MB_FORWARD)
				fprintf(fp, "MB(%d, %d), forward (%d, %d), CBP: %d.\n", mb11->col, mb11->row, mb11->vx[0], mb11->vy[0], mb11->cbp);
			else if (mb11->mbtype & MB_BACKWARD)
				fprintf(fp, "MB(%d, %d), backward(%d, %d), CBP: %d.\n", mb11->col, mb11->row, mb11->vx[0], mb11->vy[0], mb11->cbp);
		}
		else 
		{
			fprintf(fp, "MB(%d, %d), CBP: %d.\n", mb11->col, mb11->row, mb11->cbp);
//			fprintf(fp, "MV: (%d, %d)\n", mb11->vx[0], mb11->vy[0]);
//			fprintf(fp, "MV: (%d, %d), (%d, %d), (%d, %d), (%d, %d), (%d, %d)\n", mb11->vx[0], mb11->vy[0], mb11->vx[1], mb11->vy[1], mb11->vx[2], mb11->vy[2], mb11->vx[3], mb11->vy[3], mb11->vx[4], mb11->vy[4]);	
			fprintf(fp, "MV: (%d, %d), (%d, %d), (%d, %d), (%d, %d)\n", mb11->vx[0], mb11->vy[0], mb11->vx[1], mb11->vy[1], mb11->vx[2], mb11->vy[2], mb11->vx[3], mb11->vy[3]);	
		}
	} 
	else
		fprintf(fp, "MB(%d, %d), CBP: 63.\n", mb11->col, mb11->row);
//		fprintf(fp, "DC: %d, %d, %d, %d, %d, %d\n", mb11->dc[0], mb11->dc[1], mb11->dc[2], mb11->dc[3], mb11->dc[4], mb11->dc[5]);
	
	for (i = 0; i < 6; i++)
	{
//		fprintf(fp, "block %d: %d\n", i, blkPair->pair[i]);
		for (j = 0; j < blkPair->pair[i]; j++)
			fprintf(fp, "run: %d, level: %d\n", blkPair->run[i][j], blkPair->lvl[i][j]);
		if (!(mb11->mbtype & MB_INTRA)) {
			if (blkPair->pair[i])
				fprintf(fp, "block %d\n", i);
		}
		else
			fprintf(fp, "block %d, DC: %d\n", i, mb11->dc[i]);
	}

#endif

	return vlc.index;
}
