/**	HEADERFILE: "WSDF/WISDevelop/WISLib/MultiMedia/MP_UniDecTSC/MemDec.h"
 *	Description: Universal Decoder decoding memory management.
 *	History:
 *		05-04-2002 - Alpha, file created
 * $Id: memdec.h,v 1.1 2003/11/04 15:42:30 dmeyer Exp $
 */



/**	SECTION - constants, structures and macro functions
 */
	typedef struct {
		UINT8	*c[3];
	} TUniDecFrm;

	typedef struct {
		UINT8	*ptr;
		SINT32	offset;
	} TUniDecUnit;

	typedef struct {
		TUniDecUnit	c8x8[6];
		TUniDecUnit	*c[3];
	} TUniDecMB;

	typedef struct {
		TMP_BlkInfo	bInfo;
		TUniDecMB	mbMem;
		TUniDecUnit	mbShow;
		SINT8	mask;
	} TUniDecMBx;

	typedef struct {
		SINT32	col;
		SINT32	row;
		SINT32	cols;
		SINT32	rows;

		SINT16	*c8x8;
		SINT16	*memTmp;
		UINT8	*blkhp[10];

		TUniDecMBx	*ref00;
		TUniDecMBx	*ref01;
		TUniDecMBx	*ref02;
		TUniDecMBx	*ref10;
		TUniDecMBx	*ref11;

		TUniDecMB	*refMb;
		TUniDecMB	*preMb;
		TUniDecMB	*posMb;
		TUniDecMB	*curMb;
		TUniDecMB	*outMb;

		TUniDecFrm	*prevfrm;
		TUniDecFrm	*postfrm;
		TUniDecFrm	*bppxfrm;
		TUniDecFrm	*oputfrm;

		TUniDecUnit	*mbShow;
	} TUniDecMEM;

/**	ENDOFSECTION
 */



/**	SECTION - class declaration and partial implementation
 */
	class CUniDecMEM
	{
		SINT8	seq;
		UINT8	*mem;
		UINT8	*opMem;
		SINT8	do_pp;

		SINT32	idx[5];
		SINT32	pre_pos;
		SINT32	bpp_pos;
		SINT32	width;
		SINT32	height;
		SINT32	offset;
		SINT32	offShow;

		TUniDecMBx	*ref;
		TUniDecMB	*mbMem;
		TUniDecMEM	*unidec;

		SINT32	id;
		SINT32	mbln;
		SINT8	*clipTbl;

		public:
		// constructor
				CUniDecMEM(
					SINT8	seq,
					SINT32	mbWidth,
					SINT32	mbHeight,
					TUniDecMEM	*unidec,
					SINT32	id,
					SINT8	*clipTbl,
					SINT32	mbln
					);

		// distructor
				~CUniDecMEM();

		void	UpdateFrame(
					UINT8	*opMem,
					SINT32	ddWidth,
					SINT8	do_pp,
					SINT8	ip
					);

		void	UpdateMacroblock()
		{
			SINT32 i;
			if(++ unidec->col == unidec->cols) { unidec->col = 0; unidec->row ++; }
			for(i = 0; i < 5; i ++) MODPLUS(idx[i], 1, unidec->cols + 2);

			unidec->ref00 = ref + idx[0];
			unidec->ref01 = ref + idx[1];
			unidec->ref02 = ref + idx[2];
			unidec->ref10 = ref + idx[3];
			unidec->ref11 = ref + idx[4];

			SINT32 inc[3] = { 16, 8, 8 };
			SINT32 off[3] = { unidec->cols << 8, unidec->cols << 6, unidec->cols << 6 };

			unidec->mbShow->ptr = unidec->col ?
				(unidec->mbShow->ptr + width) : (opMem + offShow * unidec->row);
			for(i = 0; i < 3; i ++)
				unidec->posMb->c[i]->ptr = unidec->col ?
					(unidec->posMb->c[i]->ptr + inc[i]) :
					(unidec->postfrm->c[i] + off[i] * unidec->row);

			unidec->posMb->c8x8[1].ptr = unidec->posMb->c8x8[0].ptr + 8;
			unidec->posMb->c8x8[2].ptr = unidec->posMb->c8x8[0].ptr + (unidec->cols << 7);
			unidec->posMb->c8x8[3].ptr = unidec->posMb->c8x8[1].ptr + (unidec->cols << 7);

			for(i = 0; i < 6; i ++)
				unidec->preMb->c8x8[i].ptr = unidec->posMb->c8x8[i].ptr + pre_pos;

			if(do_pp)
				for(i = 0; i < 6; i ++)
					mbMem->c8x8[i].ptr =
					unidec->ref11->mbMem.c8x8[i].ptr = unidec->posMb->c8x8[i].ptr + bpp_pos;

			if(clipTbl)
				unidec->ref11->mask = clipTbl[unidec->col + unidec->row * mbln] == id;
			else
				unidec->ref11->mask = 1;
		}
	};

/**	ENDOFSECTION
 */



/**	ENDOFHEADERFILE: "MemDec.h"
 */
