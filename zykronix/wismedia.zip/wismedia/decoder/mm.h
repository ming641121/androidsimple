/**	HEADERFILE: "WSDF/WISDevelopSpace/WISLib/MultiMedia/MM.H"
 *	Description: MultiMedia shared constants, tables and quick functions.
 *	History:
 *		05-01-2002 - Alpha, file created
 * $Id: mm.h,v 1.1 2003/11/04 15:42:30 dmeyer Exp $
 */
#ifndef	_MM_H_
#define	_MM_H_



/**	SECTION - constants
 */

/**	ENDOFSECTION
 */



/**	SECTION - constant tables
 */
	CONST SINT32 TabNZScan[64] = {
		 0,  1,  8, 16,  9,  2,  3, 10, 17, 24, 32, 25, 18, 11,  4,  5,
		12, 19, 26, 33, 40, 48, 41, 34, 27, 20, 13,  6,  7, 14, 21, 28,
		35, 42, 49, 56, 57, 50, 43, 36, 29, 22, 15, 23, 30, 37, 44, 51,
		58, 59, 52, 45, 38, 31, 39, 46, 53, 60, 61, 54, 47, 55, 62, 63,
	};

	CONST SINT32 TabTZScan[64] = {
		 0,  8,  1,  2,  9, 16, 24, 17, 10,  3,  4, 11, 18, 25, 32, 40,
		33, 26, 19, 12,  5,  6, 13, 20, 27, 34, 41, 48, 56, 49, 42, 35,
		28, 21, 14,  7, 15, 22, 29, 36, 43, 50, 57, 58, 51, 44, 37, 30,
		23, 31, 38, 45, 52, 59, 60, 53, 46, 39, 47, 54, 61, 62, 55, 63,
	};

	#define	DCTSCL		6

/**	ENDOFSECTION
 */



/**	SECTION - quick functions
 */

/**	ENDOFSECTION
 */



#endif
/**	ENDOFHEADERFILE: "MM.H"
 */
