/**	HEADERFILE: "WSDF/WISDevelop/WISLib/MultiMedia/MP_UniDecTSC/MemShow.h"
 *	Description: Universal Decoder output memory management.
 *	History:
 *		05-05-2002 - Alpha, file created
 * $Id: memshow.h,v 1.1 2003/11/04 15:42:30 dmeyer Exp $
 */



/**	SECTION - constants, structures and macro functions
 */
	typedef struct {
		REAL64	fno;
		UINT8	*ddMem;
		SINT32	ddWidth;
	} TUniDecShow;

/**	ENDOFSECTION
 */



/**	SECTION - class declaration and partial implementation
 */
	class CUniDecShow
	{
		TUniDecShow	PrevFrm;
		TUniDecShow	PostFrm;

		SINT32	nWidth;
		SINT32	nHeight;

		SINT8	interpolation;

		public:
		// constructor
				CUniDecShow(SINT32 cols, SINT32 rows, SINT8 dDraw);

		// distructor
				~CUniDecShow();

		void	SetInterpolation(SINT8 interpolation);

		UINT8*	UpdateFrame(REAL64 fno, UINT8 *ddMem, SINT32 &ddWidth);

		UINT8*	MemQuery(REAL64 fno, UINT8 *ddMem, SINT32 ddWidth);

		UINT8*	MemToShow(REAL64 &opfno);

		STATIC	void	SetBlack(UINT8 *ddMem, SINT8 dDraw, SINT32 ddWidth, SINT32 ddHeight)
		{
			UINT8 BLACK[4] = { 0, 0, 0, 0 }; SINT32 color = 1;
			switch(dDraw)
			{
			case DDRAW_YUY2	: color = 2; BLACK[1] = 128; break;
			case DDRAW_UYVY	: color = 2; BLACK[0] = 128; break;
			case DDRAW_DIB24:
			case DDRAW_RGB24: color = 3; break;
			case DDRAW_DIB32:
			case DDRAW_RGB32: color = 4; break;
			case DDRAW_DIB565:
			case DDRAW_RGB565:
			case DDRAW_DIB555:
			case DDRAW_RGB555: color = 2; break;
			}
			UINT8 *ln = ddMem;
			for(SINT32 i = 0; i < ddHeight; i ++, ln += ddWidth)
				for(SINT32 j = 0; j < ddWidth; j += color)
					for(SINT32 c = 0; c < color; c ++)
						ln[j + c] = BLACK[c];
		}
	};

/**	ENDOFSECTION
 */



/**	ENDOFHEADERFILE: "MemShow.h"
 */
