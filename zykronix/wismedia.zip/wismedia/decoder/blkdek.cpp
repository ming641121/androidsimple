/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/MP_UniDecTSC/BLKDecTSC.cpp"
 *	Description: Universal Decoder-Transcoder - decode and transcode a macroblock.
 *	History:
 *		05-05-2002 - Alpha, file created
 * $Id: blkdek.cpp,v 1.1 2003/11/04 15:42:29 dmeyer Exp $
 */
#include	"unidec.h"



CBLKDec::CBLKDec(
			ITech_VLD *vld, TMP_StrInfo *sInfo, TMP_FrmInfo *fInfo, TMP_BlkPair *mPair, SINT8 dDraw,
			SINT32 id, SINT8 *clipTbl, SINT32 mbln
			)
{
	this->vld = vld; 
	this->sInfo = sInfo; this->fInfo = fInfo; this->mPair = mPair;
	this->dDraw = dDraw;
	cIQ = new CTechIQ(
		sInfo->mode,
		sInfo->userq ? sInfo->intraq : NULL,
		sInfo->userq ? sInfo->interq : NULL
		);
	unidec.cols = sInfo->cols; unidec.rows = sInfo->rows;

	SINT32 mbWidth = 32, mbHeight = 16;
	switch(dDraw)
	{
	case DDRAW_DIB24: mbHeight	= - 16;
	case DDRAW_RGB24: mbWidth	= 48; break;
	case DDRAW_DIB32: mbHeight	= - 16;
	case DDRAW_RGB32: mbWidth	= 64; break;
	case DDRAW_DIB565: mbHeight	= - 16;
	case DDRAW_RGB565: mbWidth	= 32; break;
	case DDRAW_DIB555: mbHeight	= - 16;
	case DDRAW_RGB555: mbWidth	= 32; break;
	}
	cMEM = new CUniDecMEM(sInfo->seq, mbWidth, mbHeight, &unidec, id, clipTbl, mbln);
	PProcSetup(0, 0, 0, unidec.cols - 1, 0, unidec.rows - 1);
}

CBLKDec::~CBLKDec()
{
	delete cIQ; delete cMEM;
}

void	CBLKDec::PProcSetup(SINT8 Y4PP, SINT8 UVPP, SINT32 h0, SINT32 h1, SINT32 v0, SINT32 v1)
{
	this->Y4PP = Y4PP; this->UVPP = UVPP;
	this->h0 = h0; this->h1 = h1; this->v0 = v0; this->v1 = v1;
}

void	CBLKDec::UpdateFrame(SINT8 doDec, UINT8 *opMem, SINT32 ddWidth)
{
	fInfo->fq = 0;
	this->doDec = doDec;
	this->opMemY = opMem;
	this->opMemU = opMem + unidec.cols * unidec.rows * 256;
	this->opMemV = this->opMemU + unidec.cols * unidec.rows * 64;
	doDSP = opMem != NULL;
	cMEM->UpdateFrame(opMem, ddWidth, Y4PP || UVPP, fInfo->ftype < B_FRAME);
}



/**	ENDOFSOURCEFILE: "BLKDecTSC.cpp"
 */
