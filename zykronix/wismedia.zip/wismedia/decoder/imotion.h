/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_MOTION/imotion.cpp"
 *	Description: Motion decompensation inline functions implementation.
 *	History:
 *		05-03-2002 - Alpha, file created
 * $Id: imotion.h,v 1.1 2003/11/04 15:42:30 dmeyer Exp $
 */
#include	"wsdf.h"
#include	"multimedia.h"



/**	SECTION - inline functions implementation
 */
#if MMX_SUPPORT

CONST SINT16 TabDCMP[8] = { 1, 1, 1, 1, 2, 2, 2, 2 };

INLINE	void	DCMP8x8(SINT16 *c8x8, SINT32 odd, UINT8 *ref, SINT32 roff)
{
	__asm
	{
		mov			eax,				ref
		mov			ebx,				c8x8
		lea			ecx,				TabDCMP

		mov			CNT,				4
		mov			esi,				roff
		pxor		mm6,				mm6					; 0, 0, 0, 0

		// switch(odd)

		mov			edi,				odd

		cmp			edi,				PIXEL_XH_YI
		je			mv_odd_xn

		cmp			edi,				PIXEL_XI_YH
		je			mv_odd_ny

		cmp			edi,				PIXEL_XH_YH
		je			mv_odd_xy

		// no half-pixel

		// preloading line 0

		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   0]

		punpcklbw	mm0,				mm6					; r00[0a]
		punpckhbw	mm1,				mm6					; r00[0b]

mv_odd_nn_2:
		// get line 0

		paddsw		mm0,				Mptr [ebx +   0]	; pix[0a] = r00[0a] + res[0a]
		add			eax,				esi

		paddsw		mm1,				Mptr [ebx +   8]	; pix[0b] = r00[0b] + res[0b]
		movq		mm2,				Mptr [eax +   0]
		movq		mm3,				Mptr [eax +   0]

		movq		Mptr [ebx +   0],	mm0
		punpcklbw	mm2,				mm6					; r00[1a]
		punpckhbw	mm3,				mm6					; r00[1b]

		movq		Mptr [ebx +   8],	mm1
		add			ebx,				32

		// get line 1

		paddsw		mm2,				Mptr [ebx -  16]	; pix[1a] = r0x[1a] + res[1a]
		add			eax,				esi

		paddsw		mm3,				Mptr [ebx -   8]	; pix[1b] = r0x[1b] + res[1b]
		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   0]

		movq		Mptr [ebx -  16],	mm2
		punpcklbw	mm0,				mm6					; r00[2a]
		punpckhbw	mm1,				mm6					; r00[2b]

		movq		Mptr [ebx -   8],	mm3
		sub			CNT,				1
		jg			mv_odd_nn_2

		jmp			mmx_return

mv_odd_xn:
		// xo half-pixel

		// preloading line 0

		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   0]

		punpcklbw	mm0,				mm6					; r00[0a]
		punpckhbw	mm1,				mm6					; r00[0b]

		movq		mm7,				Mptr [ecx +   0]	; 1, 1, 1, 1

mv_odd_xn_2:
		movq		mm2,				Mptr [eax +   1]
		movq		mm3,				Mptr [eax +   1]

		punpcklbw	mm2,				mm6					; r01[0a]
		punpckhbw	mm3,				mm6					; r01[0b]

		// get line 0

		paddsw		mm0,				mm2					; r0x[0a] = r01[0a] + r00[0a]
		paddsw		mm1,				mm3					; r0x[0b] = r01[0b] + r00[0b]

		add			eax,				esi
		paddsw		mm0,				mm7					; r0x[0a] = r0x[0a] + 1
		psraw		mm0,				1					; r0x[0a] = r0x[0a] / 2

		paddsw		mm0,				Mptr [ebx +   0]	; pix[0a] = r0x[0a] + res[0a]
		paddsw		mm1,				mm7					; r0x[0b] = r0x[0b] + 1
		psraw		mm1,				1					; r0x[0b] = r0x[0b] / 2

		paddsw		mm1,				Mptr [ebx +   8]	; pix[0b] = r0x[0b] + res[0b]
		add			ebx,				32

		movq		Mptr [ebx -  32],	mm0
		movq		mm2,				Mptr [eax +   0]
		movq		mm3,				Mptr [eax +   0]

		movq		Mptr [ebx -  24],	mm1
		punpcklbw	mm2,				mm6					; r00[1a]
		punpckhbw	mm3,				mm6					; r00[1b]

		movq		mm0,				Mptr [eax +   1]
		movq		mm1,				Mptr [eax +   1]

		punpcklbw	mm0,				mm6					; r01[1a]
		punpckhbw	mm1,				mm6					; r01[1b]

		// get line 1

		paddsw		mm2,				mm0					; r0x[1a] = r01[1a] + r00[1a]
		paddsw		mm3,				mm1					; r0x[1b] = r01[1b] + r00[1b]

		add			eax,				esi
		paddsw		mm2,				mm7					; r0x[1a] = r0x[1a] + 1
		psraw		mm2,				1					; r0x[1a] = r0x[1a] / 2

		paddsw		mm2,				Mptr [ebx -  16]	; pix[1a] = r0x[1a] + res[1a]
		paddsw		mm3,				mm7					; r0x[1b] = r0x[1b] + 1
		psraw		mm3,				1					; r0x[1b] = r0x[1b] / 2

		paddsw		mm3,				Mptr [ebx -   8]	; pix[1b] = r0x[1b] + res[1b]
		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   0]

		movq		Mptr [ebx -  16],	mm2
		punpcklbw	mm0,				mm6					; r00[2a]
		punpckhbw	mm1,				mm6					; r00[2b]

		movq		Mptr [ebx -   8],	mm3
		sub			CNT,				1
		jg			mv_odd_xn_2

		jmp			mmx_return

		paddsw		mm0,				Mptr [eax]			; decode group blocking
		cmp			CNT,				0					; decode group blocking
		je			mmx_return								; decode group blocking

mv_odd_ny:
		// ny half-pixel

		// preloading line 0

		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   0]

		punpcklbw	mm0,				mm6					; r00[0a]
		punpckhbw	mm1,				mm6					; r00[0b]

		add			eax,				esi
		movq		mm7,				Mptr [ecx +   0]	; 1, 1, 1, 1

		// preloading line 1

		movq		mm2,				Mptr [eax +   0]
		movq		mm3,				Mptr [eax +   0]

		punpcklbw	mm2,				mm6					; r00[1a]
		punpckhbw	mm3,				mm6					; r00[1b]

		paddsw		mm0,				mm2					; rx0[0a] = r00[0a] + r00[1a]
		paddsw		mm1,				mm3					; rx0[0b] = r00[0b] + r00[1b]

mv_odd_ny_2:
		// get line 0

		add			eax,				esi
		paddsw		mm0,				mm7					; rx0[0a] = rx0[0a] + 1
		psraw		mm0,				1					; rx0[0a] = rx0[0a] / 2

		paddsw		mm0,				Mptr [ebx +   0]	; pix[0a] = rx0[0a] + res[0a]
		paddsw		mm1,				mm7					; rx0[0b] = rx0[0b] + 1
		psraw		mm1,				1					; rx0[0b] = rx0[0b] / 2

		paddsw		mm1,				Mptr [ebx +   8]	; pix[0b] = rx0[0b] + res[0b]
		movq		mm4,				mm2					; r00[1a]
		movq		mm5,				mm3					; r00[1b]

		movq		Mptr [ebx +   0],	mm0
		movq		mm0,				Mptr [eax +   0]
		punpcklbw	mm0,				mm6					; r00[2a]

		movq		Mptr [ebx +   8],	mm1
		movq		mm1,				Mptr [eax +   0]
		punpckhbw	mm1,				mm6					; r00[2b]

		add			ebx,				32
		paddsw		mm4,				mm0					; rx0[1a] = r00[1a] + r00[2a]
		paddsw		mm5,				mm1					; rx0[1b] = r00[1b] + r00[2b]

		// get line 1

		add			eax,				esi
		paddsw		mm4,				mm7					; rx0[1a] = rx0[1a] + 1
		psraw		mm4,				1					; rx0[1a] = rx0[1a] / 2

		paddsw		mm4,				Mptr [ebx -  16]	; pix[1a] = rx0[1a] + res[1a]
		paddsw		mm5,				mm7					; rx0[1b] = rx0[1b] + 1
		psraw		mm5,				1					; rx0[1b] = rx0[1b] / 2

		paddsw		mm5,				Mptr [ebx -   8]	; pix[1b] = rx0[1b] + res[1b]
		movq		mm2,				Mptr [eax +   0]
		movq		mm3,				Mptr [eax +   0]

		movq		Mptr [ebx -  16],	mm4
		punpcklbw	mm2,				mm6					; r00[3a]
		punpckhbw	mm3,				mm6					; r00[3b]

		movq		Mptr [ebx -   8],	mm5
		paddsw		mm0,				mm2					; rx0[2a] = r00[2a] + r00[3a]
		paddsw		mm1,				mm3					; rx0[2b] = r00[2b] + r00[3b]

		sub			CNT,				1
		jg			mv_odd_ny_2

		jmp			mmx_return

		paddsw		mm0,				Mptr [eax]			; decode group blocking
		cmp			CNT,				0					; decode group blocking
		je			mmx_return								; decode group blocking

mv_odd_xy:
		// bi half-pixel

		// preloading line 0

		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   0]

		punpcklbw	mm0,				mm6					; r00[0a]
		punpckhbw	mm1,				mm6					; r00[0b]

		movq		mm4,				Mptr [eax +   1]
		movq		mm5,				Mptr [eax +   1]

		punpcklbw	mm4,				mm6					; r01[0a]
		punpckhbw	mm5,				mm6					; r01[0b]

		paddsw		mm4,				mm0					; r0x[0a] = r01[0a] + r00[0a]
		paddsw		mm5,				mm1					; r0x[0b] = r01[0b] + r00[0b]

		add			eax,				esi
		movq		mm7,				Mptr [ecx +   8]	; 2, 2, 2, 2

		// preloading line 1

		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   0]

		punpcklbw	mm0,				mm6					; r00[1a]
		punpckhbw	mm1,				mm6					; r00[1b]

		movq		mm2,				Mptr [eax +   1]
		movq		mm3,				Mptr [eax +   1]

mv_odd_xy_2:
		punpcklbw	mm2,				mm6					; r01[1a]
		punpckhbw	mm3,				mm6					; r01[1b]

		// get line 0

		paddsw		mm2,				mm0					; r0x[1a] = r01[1a] + r00[1a]
		paddsw		mm3,				mm1					; r0x[1b] = r01[1b] + r00[1b]

		paddsw		mm4,				mm2					; rxx[0a] = r0x[0a] + r0x[1a]
		paddsw		mm5,				mm3					; rxx[0b] = r0x[0b] + r0x[1b]

		add			eax,				esi
		paddsw		mm4,				mm7					; rxx[0a] = rxx[0a] + 2
		psraw		mm4,				2					; rxx[0a] = rxx[0a] / 4

		paddsw		mm4,				Mptr [ebx +   0]	; pix[0a] = rxx[0a] + res[0a]
		paddsw		mm5,				mm7					; rxx[0b] = rxx[0b] + 2
		psraw		mm5,				2					; rxx[0b] = rxx[0b] / 4

		paddsw		mm5,				Mptr [ebx +   8]	; pix[0b] = rxx[0b] + res[0b]
		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   0]

		movq		Mptr [ebx +   0],	mm4
		punpcklbw	mm0,				mm6					; r00[2a]
		punpckhbw	mm1,				mm6					; r00[2b]

		movq		Mptr [ebx +   8],	mm5
		movq		mm4,				Mptr [eax +   1]
		movq		mm5,				Mptr [eax +   1]

		punpcklbw	mm4,				mm6					; r01[2a]
		punpckhbw	mm5,				mm6					; r01[2b]

		// get line 1

		paddsw		mm4,				mm0					; r0x[2a] = r01[2a] + r00[2a]
		paddsw		mm5,				mm1					; r0x[2b] = r01[2b] + r00[2b]

		paddsw		mm2,				mm4					; rxx[1a] = r0x[1a] + r0x[2a]
		paddsw		mm3,				mm5					; rxx[1b] = r0x[1b] + r0x[2b]

		add			eax,				esi
		paddsw		mm2,				mm7					; rxx[1a] = rxx[1a] + 2
		psraw		mm2,				2					; rxx[1a] = rxx[1a] / 4

		paddsw		mm2,				Mptr [ebx +  16]	; pix[1a] = rxx[1a] + res[1a]
		paddsw		mm3,				mm7					; rxx[1b] = rxx[1b] + 2
		psraw		mm3,				2					; rxx[1b] = rxx[1b] / 4

		paddsw		mm3,				Mptr [ebx +  24]	; pix[1b] = rxx[1b] + res[1b]
		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   0]

		movq		Mptr [ebx +  16],	mm2
		punpcklbw	mm0,				mm6					; r00[3a]
		punpckhbw	mm1,				mm6					; r00[3b]

		movq		Mptr [ebx +  24],	mm3
		movq		mm2,				Mptr [eax +   1]
		movq		mm3,				Mptr [eax +   1]

		add			ebx,				32
		sub			CNT,				1
		jg			mv_odd_xy_2

mmx_return:
	}
}

#else

INLINE	void	DCMP8x8(SINT16 *c8x8, SINT32 odd, UINT8 *ref, SINT32 roff)
{
	SINT32 i, j;

#ifdef XSCALE
	/* Intel recommended single prefetch case */
   __asm__ (" pld [%0] \n" : : "r" (ref+32)); 
#endif

	if (odd == PIXEL_XI_YI)
	{
		for (i = 0; i < 8; i++)
		{
			for (j = 0; j < 8; j++)
				c8x8[j] += ref[j];
			c8x8 += 8;
			ref += roff;
		}
	}
	else if (odd == PIXEL_XH_YI)
	{
		for (i = 0; i < 8; i++)
		{
			for (j = 0; j < 8; j++)
				c8x8[j] += (SINT16)(ref[j] + ref[j + 1] + 1) >> 1;
			c8x8 += 8;
			ref += roff;
		}
	}
	else if (odd == PIXEL_XI_YH)
	{
		for (i = 0; i < 8; i++)
		{
			for (j = 0; j < 8; j++)
				c8x8[j] += (SINT16)(ref[j] + ref[j + roff] + 1) >> 1;
			c8x8 += 8;
			ref += roff;
		}
	}
	else  // PIXEL_XH_YH
	{
		for (i = 0; i < 8; i++)
		{
			for (j = 0; j < 8; j++)
				c8x8[j] += (SINT16)(ref[j] + ref[j + 1] + ref[j + roff] + ref[j + roff + 1] + 2) >> 2;
			c8x8 += 8;
			ref += roff;
		}
	}
}

#endif


/**	ENDOFSECTION
 */



/**	ENDOSOURCEFILE: "imotion.cpp"
 */
