/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_MEMxfer/memxfer.cpp"
 *	Description: Memory related inline functions implementation.
 *	History:
 *		05-03-2002 - Alpha, file created    \
 * $Id: memxfer.h,v 1.1 2003/11/04 15:42:30 dmeyer Exp $
 */
#include	"wsdf.h"



/**	SECTION - inline functions implementation
 */
#if MMX_SUPPORT

INLINE	void	MSET8x8(SINT16 *c8x8, SINT16 val)
{
	SINT16 tab[4] = { val, val, val, val };
	__asm
	{
		mov			eax,				c8x8
		lea			ecx,				tab
		movq		mm0,				Mptr [ecx]

		movq		Mptr [eax +   0],	mm0
		movq		Mptr [eax +   8],	mm0
		movq		Mptr [eax +  16],	mm0
		movq		Mptr [eax +  24],	mm0
		movq		Mptr [eax +  32],	mm0
		movq		Mptr [eax +  40],	mm0
		movq		Mptr [eax +  48],	mm0
		movq		Mptr [eax +  56],	mm0
		movq		Mptr [eax +  64],	mm0
		movq		Mptr [eax +  72],	mm0
		movq		Mptr [eax +  80],	mm0
		movq		Mptr [eax +  88],	mm0
		movq		Mptr [eax +  96],	mm0
		movq		Mptr [eax + 104],	mm0
		movq		Mptr [eax + 112],	mm0
		movq		Mptr [eax + 120],	mm0
	}
}



INLINE	void	XPOT8x8(SINT16 *c8x8, UINT8 *f8x8, SINT32 width)
{
	__asm
	{
		mov			eax,				c8x8
		mov			ebx,				f8x8
		mov			esi,				width

		movq		mm0,				Mptr [eax +   0]
		movq		mm1,				Mptr [eax +   8]
		movq		mm2,				Mptr [eax +  16]
		movq		mm3,				Mptr [eax +  24]
		movq		mm4,				Mptr [eax +  32]
		movq		mm5,				Mptr [eax +  40]
		movq		mm6,				Mptr [eax +  48]
		movq		mm7,				Mptr [eax +  56]

		packuswb	mm0,				mm1
		packuswb	mm2,				mm3
		packuswb	mm4,				mm5

		movq		Mptr [ebx],			mm0					; row 0
		add			ebx,				esi
		packuswb	mm6,				mm7

		movq		Mptr [ebx],			mm2					; row 1
		add			ebx,				esi
		movq		mm0,				Mptr [eax +  64]

		movq		Mptr [ebx],			mm4					; row 2
		add			ebx,				esi
		movq		mm1,				Mptr [eax +  72]

		movq		Mptr [ebx],			mm6					; row 3
		add			ebx,				esi
		packuswb	mm0,				mm1

		movq		mm2,				Mptr [eax +  80]
		movq		mm3,				Mptr [eax +  88]
		movq		mm4,				Mptr [eax +  96]
		movq		mm5,				Mptr [eax + 104]
		movq		mm6,				Mptr [eax + 112]
		movq		mm7,				Mptr [eax + 120]

		movq		Mptr [ebx],			mm0					; row 4
		add			ebx,				esi
		packuswb	mm2,				mm3

		movq		Mptr [ebx],			mm2					; row 5
		add			ebx,				esi
		packuswb	mm4,				mm5

		movq		Mptr [ebx],			mm4					; row 6
		add			ebx,				esi
		packuswb	mm6,				mm7

		movq		Mptr [ebx],			mm6					; row 7
	}
}



INLINE	void	COPY8x8(UINT8 *tgt, SINT32 w_tgt, UINT8 *src, SINT32 w_src)
{
	__asm
	{
		mov			eax,				src
		mov			ebx,				tgt
		mov			esi,				w_src
		mov			edi,				w_tgt

		// ln0

		movq		mm0,				Mptr [eax]
		add			eax,				esi
		movq		Mptr [ebx],			mm0
		add			ebx,				edi

		// ln1

		movq		mm0,				Mptr [eax]
		add			eax,				esi
		movq		Mptr [ebx],			mm0
		add			ebx,				edi

		// ln2

		movq		mm0,				Mptr [eax]
		add			eax,				esi
		movq		Mptr [ebx],			mm0
		add			ebx,				edi

		// ln3

		movq		mm0,				Mptr [eax]
		add			eax,				esi
		movq		Mptr [ebx],			mm0
		add			ebx,				edi

		// ln4

		movq		mm0,				Mptr [eax]
		add			eax,				esi
		movq		Mptr [ebx],			mm0
		add			ebx,				edi

		// ln5

		movq		mm0,				Mptr [eax]
		add			eax,				esi
		movq		Mptr [ebx],			mm0
		add			ebx,				edi

		// ln6

		movq		mm0,				Mptr [eax]
		add			eax,				esi
		movq		Mptr [ebx],			mm0
		add			ebx,				edi

		// ln7

		movq		mm0,				Mptr [eax]
		movq		Mptr [ebx],			mm0
	}
}



INLINE	void	TRANSPOSE8x8(UINT8 *tgt, SINT32 w_tgt, UINT8 *src, SINT32 w_src, UINT8 *mem)
{
	__asm
	{
		mov			eax,				src
		mov			esi,				w_src
		mov			ecx,				mem

		// line 0..3

		movq		mm0,				Mptr [eax]			; a0 a1 a2 a3 a4 a5 a6 a7
		movq		mm2,				Mptr [eax]
		add			eax,				esi

		movq		mm1,				Mptr [eax]			; b0 b1 b2 b3 b4 b5 b6 b7
		punpcklbw	mm0,				mm1
		add			eax,				esi

		movq		mm4,				Mptr [eax]			; c0 c1 c2 c3 c4 c5 c6 c7
		movq		mm5,				Mptr [eax]
		add			eax,				esi

		movq		mm3,				Mptr [eax]			; d0 d1 d2 d3 d4 d5 d6 d7
		punpckhbw	mm2,				mm1
		add			eax,				esi

		punpcklbw	mm4,				mm3					; c0 d0 c1 d1 c2 d2 c3 d3
		punpckhbw	mm5,				mm3					; c4 d4 c5 d5 c6 d6 c7 d7

		movq		mm1,				mm0					; a0 b0 a1 b1 a2 b2 a3 b3
		movq		mm3,				mm2					; a4 b4 a5 b5 a6 b6 a7 b7

		punpcklwd	mm0,				mm4					; a0 b0 c0 d0 a1 b1 c1 d1
		punpckhwd	mm1,				mm4					; a2 b2 c2 d2 a3 b3 c3 d3
		punpcklwd	mm2,				mm5					; a4 b4 c4 d4 a5 b5 c5 d5
		punpckhwd	mm3,				mm5					; a6 b6 c6 d6 a7 b7 c7 d7

		movq		Mptr [ecx +   0],	mm0
		movq		Mptr [ecx +   8],	mm1

		// line 4..7


		movq		mm4,				Mptr [eax]			; e0 e1 e2 e3 e4 e5 e6 e7
		movq		mm6,				Mptr [eax]
		add			eax,				esi

		movq		mm5,				Mptr [eax]			; f0 f1 f2 f3 f4 f5 f6 f7
		punpcklbw	mm4,				mm5
		add			eax,				esi

		movq		mm0,				Mptr [eax]			; g0 g1 g2 g3 g4 g5 g6 g7
		movq		mm1,				Mptr [eax]
		add			eax,				esi

		movq		mm7,				Mptr [eax]			; h0 h1 h2 h3 h4 h5 h6 h7
		punpckhbw	mm6,				mm5

		punpcklbw	mm0,				mm7					; g0 h0 g1 h1 g2 h2 g3 h3
		punpckhbw	mm1,				mm7					; g4 h4 g5 h5 g6 h6 g7 h7

		movq		mm5,				mm4					; e0 f0 e1 f1 e2 f2 e3 f3
		movq		mm7,				mm6					; e4 f4 e5 f5 e6 f6 e7 f7

		punpcklwd	mm4,				mm0					; e0 f0 g0 h0 e1 f1 g1 h1
		punpckhwd	mm5,				mm0					; e2 f2 g2 h2 e3 f3 g3 h3
		punpcklwd	mm6,				mm1					; e4 f4 g4 h4 e5 f5 g5 h5
		punpckhwd	mm7,				mm1					; e6 f6 g6 h6 e7 f7 g7 h7

		// output

		mov			ebx,				tgt
		mov			edi,				w_tgt

		movq		mm0,				Mptr [ecx +   0]
		movq		mm1,				Mptr [ecx +   0]

		punpckldq	mm0,				mm4					; a0 b0 c0 d0 e0 f0 g0 h0
		punpckhdq	mm1,				mm4					; a1 b1 c1 d1 e1 f1 g1 h1

		movq		Mptr [ebx],			mm0
		add			ebx,				edi

		movq		Mptr [ebx],			mm1
		add			ebx,				edi

		movq		mm0,				Mptr [ecx +   8]
		movq		mm1,				Mptr [ecx +   8]

		punpckldq	mm0,				mm5					; a2 b2 c2 d2 e2 f2 g2 h2
		punpckhdq	mm1,				mm5					; a3 b3 c3 d3 e3 f3 g3 h3

		movq		Mptr [ebx],			mm0
		movq		mm0,				mm2
		add			ebx,				edi

		movq		Mptr [ebx],			mm1
		punpckldq	mm0,				mm6					; a4 b4 c4 d4 e4 f4 g4 h4
		add			ebx,				edi

		punpckhdq	mm2,				mm6					; a5 b5 c5 d5 e5 f5 g5 h5
		movq		mm1,				mm3

		movq		Mptr [ebx],			mm0
		punpckldq	mm1,				mm7					; a6 b6 c6 d6 e6 f6 g6 h6
		add			ebx,				edi

		movq		Mptr [ebx],			mm2
		punpckhdq	mm3,				mm7					; a7 b7 c7 d7 e7 f7 g7 h7
		add			ebx,				edi

		movq		Mptr [ebx],			mm1
		add			ebx,				edi

		movq		Mptr [ebx],			mm3
	}
}

#elif XSCALE

/* Begin: other XScale optimized routines, see xscale.s */
extern "C" INLINE	void	MSET8x8(SINT16 *c8x8, SINT16 val);
extern "C" INLINE   void    XPOT8x8(SINT16 *c8x8, UINT8 *f8x8, SINT32 width);

#if 0
/* Note: see xscale.s for assembly optimized version of this routine,
 *       this is left here for reference only on optimizing C code with PLD on Xscale.
 */
INLINE  void    XPOT8x8(SINT16 *c8x8, UINT8 *f8x8, SINT32 width)
{
        SINT32 i, j;
  		/* Intel recommended 3-cache-line prefetch of c8x8 array */   
	    __asm__ (" pld [%0] \n" : : "r" (c8x8+16)); 
        __asm__ (" pld [%0] \n" : : "r" (c8x8+32)); 
        __asm__ (" pld [%0] \n" : : "r" (c8x8+48)); 
        for (i = 0; i < 8; i++)
        {       
                for (j = 0; j < 8; j++)
                        f8x8[j] = CLP(c8x8[j], 0, 255);
                c8x8 += 8;
                f8x8 += width;
        }
}
#endif

INLINE	void	COPY8x8(UINT8 *tgt, SINT32 w_tgt, UINT8 *src, SINT32 w_src)
{
	SINT32 i, j;

	for (i = 0; i < 8; i++)
	{
		VCPY(tgt, src, 8); /* See xscale.s */
		tgt += w_tgt;
		src += w_src;
	}
}

INLINE	void	TRANSPOSE8x8(UINT8 *tgt, SINT32 w_tgt, UINT8 *src, SINT32 w_src, UINT8 *mem)
{
	SINT32 i, j;

	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
			tgt[j] = src[j * w_src];
		tgt += w_tgt;
		src += 1;
	}
}


/* End XScale Optimized Routines */
#else

INLINE	void	MSET8x8(SINT16 *c8x8, SINT16 val)
{
	SINT32 i;

	for (i = 0; i < 64; i++)
		c8x8[i] = val;
}

INLINE	void	XPOT8x8(SINT16 *c8x8, UINT8 *f8x8, SINT32 width)
{
	SINT32 i, j;

	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
			f8x8[j] = CLP(c8x8[j], 0, 255); //(UINT8)c8x8[j];
		c8x8 += 8;
		f8x8 += width;
	}
}

INLINE	void	COPY8x8(UINT8 *tgt, SINT32 w_tgt, UINT8 *src, SINT32 w_src)
{
	SINT32 i, j;

	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
			tgt[j] = src[j];
		tgt += w_tgt;
		src += w_src;
	}
}

INLINE	void	TRANSPOSE8x8(UINT8 *tgt, SINT32 w_tgt, UINT8 *src, SINT32 w_src, UINT8 *mem)
{
	SINT32 i, j;

	for (i = 0; i < 8; i++)
	{
		for (j = 0; j < 8; j++)
			tgt[j] = src[j * w_src];
		tgt += w_tgt;
		src += 1;
	}
}

#endif


/**	ENDOFSECTION
 */



/**	ENDOSOURCEFILE: "memxfer.cpp"
 */
