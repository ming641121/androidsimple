/**	SOURCEFILE: "WSDF/WISDevelop/WISLib/MultiMedia/Tech_FMT/MP2_vld.cpp"
 *	Description: MPEG2 VLD routines. Implementation of class CMp2Vld
 *	History:
 *		08-27-2002 - Weimin, file created
 * $Id: mp2_vld.cpp,v 1.2 2004/02/11 15:36:39 dmeyer Exp $
 */

#include "mp2_vld.h"

SINT32 CMp2Vld::StrHead(SINT32 &bits)
{
	SINT32 r = SUCCESS;
	r = CMp1Vld::StrHead(bits);
	if (r != SUCCESS)
		return r;

	for (SINT32 i = 0; i < 22; i++)
		vlcSkip(&vlc, 8);

	bits = vlc.index;
	pict_struct = BOTTOM_FIELD;
	return r;
}

SINT32 CMp2Vld::GopHead(SINT32 &bits, SINT8* data)
{
	SINT32 r = CMp1Vld::StrHead(bits);
	if (r == SUCCESS) // skip extension header
	{
		for (SINT32 i = 0; i < 10; i++)
			vlcSkip(&vlc, 8);
	}

	return CMp1Vld::GopHead(bits, data);
}

SINT32 CMp2Vld::FrmHead(SINT32 &bits)
{
	SINT32 r = SUCCESS;
	SINT32 i = 0;

	store_coding_state();
	if (bits_quota < vlc.index + 32 + 40) return reset_coding_state(bits, ERR_MEMORY);

	UINT32 frame_start_code = (vlcLoad(&vlc, 24) << 8) + vlcLoad(&vlc, 8);
	if (frame_start_code != 0x00000100) return reset_coding_state(bits, ERR_MISMCH);
	SINT32 cur_fno = vlcLoad(&vlc, 10) & 0x3ff;		// temporal reference
	if (gop_fno == 0)
	{
		SINT32 pno = ((SINT32)frmInfo->fno) & 0x3ff;
		if (cur_fno < pno - 0x200)
			cur_fno += 0x400;
		frmInfo->fno += cur_fno - pno;
	}
	else
		frmInfo->fno = gop_fno + cur_fno;

	frmInfo->ftype = vlcLoad(&vlc, 3) - 1;			// frame type
	vlcSkip(&vlc, 16);
	if (frmInfo->ftype == P_FRAME || frmInfo->ftype == B_FRAME)
	{
		forward_f_code = vlcLoad(&vlc, 4) & 0x7; // f_code
		if (frmInfo->ftype == B_FRAME)
		{
			backward_f_code = vlcLoad(&vlc, 4) & 0x7;
			vlcSkip(&vlc, 3);
		}
		else
		{
			vlcSkip(&vlc, 7);
		}
	}
	else
	{
		vlcSkip(&vlc, 3);
	}

	vlcSkip(&vlc, 24);
	vlcSkip(&vlc, 12);
	forward_f_code = vlcLoad(&vlc, 4);
	vlcSkip(&vlc, 4);
	backward_f_code = vlcLoad(&vlc, 4);
	vlcSkip(&vlc, 4);
	vlcSkip(&vlc, 2);
	pict_struct = vlcLoad(&vlc, 2);
	if (pict_struct != FRAME_STRUCT)
		strInfo->interlace = 2;
	vlcSkip(&vlc, 12);
	bits = vlc.index;
	return r;
}

SINT32 CMp2Vld::vld8x8(SINT8 first, MpgvlcManager *vlc, SINT8 *run, SINT32 *lvl)
{
	SINT32 i = 0;
	SINT32 reg; UINT8 *code = (UINT8 *)&reg; MpgvlcTab *tab;
	goto lbl_vlcShow;

#ifdef _BIG_ENDIAN_

lbl_lvlSave:
	lvl[i] = tab->level;

lbl_runSave:
	run[i ++] = tab->run;

//lbl_vlcSkip:
	vlcSkip(vlc, tab->len);

	first = 0;
lbl_vlcShow:
	reg = vlcShow(vlc);
	if(code[1] >= 0x04)
	{
		tab = &Mp1Tab1[code[1]];
		if (first)
		{
			if (tab->len == 32 || tab->len == 3)
			{
				lvl[i] = vlcLoad(vlc, 2) < 3 ? 1 : -1;
				run[i ++] = 0; first = 0; goto lbl_vlcShow;
			}
		}
		if(tab->len <  9)
			goto lbl_lvlSave; 
		else
		if(tab->run < 64)
			if((SINT8)code[2] >= 0)
				goto lbl_lvlSave;
			else {
				lvl[i] = - tab->level; goto lbl_runSave;
			}
		else
		if(tab->run > 64)
		{
			if (first) {
				lvl[i] = vlcLoad(vlc, 2) < 3 ? 1 : -1;
				run[i ++] = 0; first = 0; goto lbl_vlcShow;
			}
			else {
				vlcSkip(vlc, 2); return i;
			}
		}
		else
		{
			vlcSkip(vlc, 6);
			run[i] = vlcLoad(vlc, 6);
			SINT32 al = vlcLoad(vlc, 12);
			if (al & 0x800) al = 0xfffff000 + al;
			lvl[i] = al;
			i++; first = 0; goto lbl_vlcShow;
		}
	}
	else
	if(code[1] == 0x00)
	{
		tab = &Mp1Tab2[code[2]];
		if(tab->len < 17)
			goto lbl_lvlSave;
		else
		if(tab->run < 65)
			if((SINT8)code[3] >= 0)
				goto lbl_lvlSave;
			else {
				lvl[i] = - tab->level; goto lbl_runSave;
			}
		else
		{
			vlcSkip(vlc, 2); return i;	// wrong entry!!!
		}
	}
	else
	if(code[1] == 0x02)
	{
		tab = &Mp1Tab4[code[2] >> 5];
		goto lbl_lvlSave;
	}
	else 
	if(code[1] == 0x03)
	{
		tab = &Mp1Tab5[code[2] >> 5];
		goto lbl_lvlSave;
	}
	else
	{
		tab = &Mp1Tab3[code[2] >> 3];
		goto lbl_lvlSave;
	}
#else


lbl_lvlSave:
	lvl[i] = tab->level;

lbl_runSave:
	run[i ++] = tab->run;

//lbl_vlcSkip:
	vlcSkip(vlc, tab->len);

	first = 0;
lbl_vlcShow:
	reg = vlcShow(vlc);
	if(code[2] >= 0x04)
	{
		tab = &Mp1Tab1[code[2]];
		if (first)
		{
			if (tab->len == 32 || tab->len == 3)
			{
				lvl[i] = vlcLoad(vlc, 2) < 3 ? 1 : -1;
				run[i ++] = 0; first = 0; goto lbl_vlcShow;
			}
		}
		if(tab->len <  9)
			goto lbl_lvlSave; 
		else
		if(tab->run < 64)
			if((SINT8)code[1] >= 0)
				goto lbl_lvlSave;
			else {
				lvl[i] = - tab->level; goto lbl_runSave;
			}
		else
		if(tab->run > 64)
		{
			if (first) {
				lvl[i] = vlcLoad(vlc, 2) < 3 ? 1 : -1;
				run[i ++] = 0; first = 0; goto lbl_vlcShow;
			}
			else {
				vlcSkip(vlc, 2); return i;
			}
		}
		else
		{
			vlcSkip(vlc, 6);
			run[i] = vlcLoad(vlc, 6);
			SINT32 al = vlcLoad(vlc, 12);
			if (al & 0x800) al = 0xfffff000 + al;
			lvl[i] = al;
			i++; first = 0; goto lbl_vlcShow;
		}
	}
	else
	if(code[2] == 0x00)
	{
		tab = &Mp1Tab2[code[1]];
		if(tab->len < 17)
			goto lbl_lvlSave;
		else
		if(tab->run < 65)
			if((SINT8)code[0] >= 0)
				goto lbl_lvlSave;
			else {
				lvl[i] = - tab->level; goto lbl_runSave;
			}
		else
		{
			vlcSkip(vlc, 2); return i;	// wrong entry!!!
		}
	}
	else
	if(code[2] == 0x02)
	{
		tab = &Mp1Tab4[code[1] >> 5];
		goto lbl_lvlSave;
	}
	else 
	if(code[2] == 0x03)
	{
		tab = &Mp1Tab5[code[1] >> 5];
		goto lbl_lvlSave;
	}
	else
	{
		tab = &Mp1Tab3[code[1] >> 3];
		goto lbl_lvlSave;
	}


#endif
}

