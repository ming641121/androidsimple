/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
/******************************************************************************
*
*   FILE: 
*	wis_decoder.h
*
*   DESCRIPTION:
*
*   This is the API (Application Programming Interface) for the WIS Decoder.
* $Id: wis_decoder.c,v 1.3 2004/03/01 15:42:25 jfd Exp $
*
******************************************************************************/

#include "wis_types.h"
#include "wis_decoder.h"
#include "wis_error.h"


/*
 * Function: DecoderSetNumStreamse - set the number of decoder streams
 * Arguments:
 *	ndecoders - number of streams
 * Returns: SUCCESS or FAILURE, if FAILURE, more detailed info may be provided.         
 *           
 */
sint32 DecoderSetNumStreams(int ndecoders)
{
	return DecoderSetNumStreamsCPP(ndecoders);
}

/*
 * Function: DecoderSetMode - set decoder operating mode
 * Arguments:
 *           inputtype - one of  DECODER_INPUT_XXX constants (above)
 *           output - one of DECODER_OUTPUT_XXX constants (above)
 *           width  -  output width of display (pitch) - has nothing todo with frame
 *                     For example, on 800x600 display, width is 800
 *           height - output height of display (number of scan lines)
 *                    For example, on 800x600 display, height is 600
 * Returns: SUCCESS or FAILURE, if FAILURE, more detailed info may be provided.         
 *           
 */
status_t DecoderSetMode(sint32 stream, sint32 inputtype, sint32 output, sint32 width, sint32 height)
{

	return decoderSetModeCPP(stream,inputtype,output, width, height);
}

/******************************* end of DecoderSetMode *****************************/

/* 
 * Function: DecoderGetMode - get current decoder operating mode
 * Arguments:
 *           inputtype - one of  DECODER_INPUT_XXX constants (above)
 *           output - one of DECODER_OUTPUT_XXX constants (above)
 *           width  -  output width of display (pitch) - has nothing todo with frame
 *                     For example, on 800x600 display, width is 800
 *           height - output height of display (number of scan lines)
 *                    For example, on 800x600 display, height is 600
 * Returns: SUCCESS or FAILURE, if FAILURE, more detailed info may be provided.    
 */
status_t DecoderGetMode(int stream, sint32* input, sint32* output, sint32 *width, sint32 *height)
{
	return DECODER_FAILURE;
}

/******************************* end of DecodeGetMode *****************************/

/* 
 * Function: DecoderGetVersionInfo
 * Purpose:  return information about current decoder engine.
 * Return:   decoderVersion info structure.
 */
decoderVersion_t DecoderGetVersionInfo(void)
{
	decoderVersion_t version;
	version.decoderVersion = 0x1;

	return version;
}

/*************************** end of DecodeGetVersionInfo *****************************/

/* 
 * Function:  DecodeOneFrame
 * Purpose:   Decode a single frame, as in when we receive one off the network 
 * Arguments: frame -  Elementary Stream frame received from Encoder
 *            len - length of frame received from encoder
 *            destFrame - pointer to output buffer (must be allocated >= width*height*bpp) 
 *            dlen - pointer to length of new RGB decoded frame, we fill this in for you.
 *            type - The encoder updates this structure to provide additional info about the frame, 
 *                   updated after call
 */
status_t DecodeOneFrame(int stream, void *frame, sint32 len, void *destFrame, sint32 *dlen, d_frameInfo_t *type)
{
	return(decodeOneFrameCPP(stream, frame, len, destFrame, dlen, type));
}

/******************************* end of DecodeOneFrame *****************************/

/* 
 * Function: DecoderGetSnapshot - Take a snapshot of the current screen.
 * Arguments: decoderInstance - decoder Instance number
 *			  bufferPtr - pointer to the buffer to place the image
 * Return: address of frame buffer for output image. NULL indicates failure.
 */
status_t DecoderGetSnapshot(sint32 stream, uint8* bufferPtr)
{
	return(decoderGetSnapshotCPP(stream, bufferPtr));
}

/**************************** end of EncoderGetSnapshot *************************/



/******************************* end of wis_decoder.c *****************************/

