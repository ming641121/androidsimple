/**	HEADERFILE: "WSDF/WISDevelopSpace/WISLib/MultiMedia/Tech_FMT.h"
 *	Description: VLC and VLD.
 *	Section: MultiMedia - Core Technologies
 *	History:
 *		05-03-2002 - Weimin, file created
 * $Id: tech_fmt.h,v 1.1 2003/11/04 15:42:31 dmeyer Exp $
 */
#ifndef _TECH_FMT_H_
#define _TECH_FMT_H_

#include	"wsdf.h"
#include	"multimedia.h"



/**	SECTION - constants and data exchange structures
 */

/**	ENDOFSECTION
 */


const SINT32 DC_Y[32] = 
{
	8192, 8192, 8192, 8192, 8192, 6554, 5461, 4681, 
	4096, 3855, 3641, 3449, 3277, 3121, 2979, 2849, 
	2731, 2621, 2521, 2427, 2341, 2260, 2185, 2114, 
	2048, 1928, 1820, 1725, 1638, 1560, 1489, 1425
};

const SINT32 DC_UV[32] = 
{
	8192, 8192, 8192, 8192, 8192, 7282, 7282, 6554, 
	6554, 5958, 5958, 5461, 5461, 5041, 5041, 4681, 
	4681, 4369, 4369, 4096, 4096, 3855, 3855, 3641, 
	3641, 3449, 3277, 3121, 2979, 2849, 2731, 2621
};

const SINT32 DC_SCALER_Y[32]=
{	8,	8,	8,	8,	8,	10,	12,	14,
	16,	17,	18,	19,	20,	21,	22,	23,
	24,	25,	26,	27,	28,	29,	30,	31,
	32,	34,	36,	38,	40,	42,	44,	46
};

const SINT32 DC_SCALER_UV[32]=
{	8,	8,	8,	8,	8,	9,	9,	10,
	10,	11,	11,	12,	12,	13,	13,	14,
	14,	15,	15,	16,	16,	17,	17,	18,
	18,	19,	20,	21,	22,	23,	24,	25
};

/**	SECTION - interface functions' declaration for C++
 */
#ifdef __cplusplus
	class ITech_VLD
	{
		public:
		// constructor
		STATIC	SINT32	CreateInstance(
					ITech_VLD	**pp,		// return a pointer to real class object
					TMP_StrInfo	*sInfo,		// pass buffer for stream header
					TMP_FrmInfo	*fInfo,		// pass buffer for frame header
					TMP_BlkPair	*mPair		// pass buffer for macroblock run-level pairs
					);
		// return EFuncReturn ('WSDF.H')

		// distructor
		virtual	void	Release() PURE;

		// to init VLD
		virtual	void	StrInit(
					UINT8	*srcStr,		// buffer to get source stream
					SINT32	quota			// available bytes in srcStr
					) PURE;

		// to get stream header
		virtual	SINT32	StrHead(
					SINT32	&bits			// return bits used since StrInit
					) PURE;
		// return SUCCESS or ERR_MISMCH or ERR_MEMORY

		// to get GOP header
		virtual	SINT32	GopHead(
					SINT32	&bits,			// return bits used since StrInit
					SINT8* data			// return user data pointer. maximum 127 bytes
					) PURE;
		// return SUCCESS or ERR_MISMCH or ERR_MEMORY

		// to get frame header
		virtual	SINT32	FrmHead(
					SINT32	&bits			// return bits used since StrInit
					) PURE;
		// return SUCCESS or ERR_MISMCH or ERR_MEMORY

		// to get frame Tail
		virtual	SINT32	FrmTail(
					SINT32	&bits			// return bits used since StrInit
					) PURE;
		// return SUCCESS or ERR_MISMCH or ERR_MEMORY

		// to get a macroblock
		virtual	SINT32	StrMblk(
					TMP_BlkInfo	*mb00,		// macroblock upper-left
					TMP_BlkInfo	*mb01,		// macroblock upper
					TMP_BlkInfo	*mb02,		// macroblock upper-right
					TMP_BlkInfo	*mb10,		// macroblock left
					TMP_BlkInfo	*mb11		// macroblock current
					) PURE;
		// return bits used since StrInit
	};
#endif

/**	ENDOFSECTION
 */



#endif
/**	ENDOFHEADERFILE: "Tech_FMT.h"
 */
