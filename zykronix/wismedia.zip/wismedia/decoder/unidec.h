/**	HEADERFILE: "WSDF/WISDevelop/WISLib/MultiMedia/MP_UniDecTSC/UniDecTSC.h"
 *	Description: Motion Picture Universal Decoder & Transcoder global header file.
 *	History:
 *		05-05-2002 - Alpha, file created
 * $Id: unidec.h,v 1.1 2003/11/04 15:42:31 dmeyer Exp $
 */
#ifndef	_UNIDECTSC_H_
#define	_UNIDECTSC_H_

#ifndef VXWORKS
#include	<memory.h>
#endif
#include	<string.h>

#include	"mp_unidectsc.h"

#if MMX_SUPPORT
#include	<tech_pproc.h>
#endif

#include	"uti_tool.h"
#include	"tech_fmt.h"
#include	"tech_dctq.h"
#include	"imotion.h"
#include	"cc_export.h"
#include	"memxfer.h"

#include	"memdec.h"
#include	"memshow.h"
#include	"blkdec.h"


/**	SECTION - constants and data exchange structures
 */
	#define DEC_FIFOMAXW	(1024 * 128)
	#define DEC_FIFOSIZE	(1024 * 1024)
	#define DEC_FIFOFRMS	64

	typedef struct {
		UINT8	*ptr;
		SINT8	ftype;
	} TUniDecSrc;

/**	ENDOFSECTION
 */



/**	SECTION - class declaration and partial implementation
 */
	class CUniDec : public IMP_UniDecTSC
	{
		SINT32	FrmLvl[5];

		UINT8	*FiFo;
		UINT8	*FiFoAlertPtr;
		UINT8	*rptr;
		UINT8	*wptr;
		UINT8	*sptr;

		SINT8	userspec_osdtext[128];		// current user specified osd text
		SINT8	decoded_osdtext[128];		// osd text that were decoded from the source stream.

		SINT32	rFrmIdx;
		SINT32	wFrmIdx;
		TUniDecSrc	srcFrm[DEC_FIFOFRMS];

		ITech_VLD	*dHD;
		ITech_VLD	*vld;

		SINT8	DecLvl;
		SINT8	adjDecLvl;
		SINT8	TSCLvl;

		TMP_StrInfo	sInfo;		// buffer for stream header
		TMP_FrmInfo	fInfo;		// buffer for frame header
		TMP_BlkPair	mPair;		// buffer for macroblock run-level pairs
		TMP_FrmInfo	fI;
		TMP_BlkPair	mP;
		TMP_StrMBInfo	*SMBI;

		CBLKDec		*cBLK;
		CUniDecShow	*cShow;

		REAL64	LastFno;
		REAL64	LastPno;
		REAL64	opfno;

		SINT32	h0;
		SINT32	h1;
		SINT32	v0;
		SINT32	v1;
		SINT8	Y4PP;
		SINT8	UVPP;

		SINT32	CheckSync()
		{
			if(			(sInfo.interlace == FP_AUTO      ) ||
						(sInfo.mode      == FP_AUTO      ) ||
						(sInfo.seq       == FP_AUTO      ) ||
						(sInfo.cols      == FP_AUTO      ) ||
						(sInfo.rows      == FP_AUTO      ) ||
						(sInfo.fps       == FP_AUTO      ) ||
						(sInfo.uvmode    == FP_AUTO      ) ||
						(sInfo.dqmode    == FP_AUTO      ) ||
						(sInfo.fpmode    == FP_AUTO      ) ||
						(sInfo.acpred    == FP_AUTO      ) ||
						(sInfo.userq     == FP_AUTO      )
						)
				return ERR_MISMCH;
			else
				return SUCCESS;
		}

		SINT32	BufferredFrm()
		{
			if(wFrmIdx < 0) return 0;
			SINT32 ri = rFrmIdx, wi = wFrmIdx;
			MODPLUS(ri, 0, DEC_FIFOFRMS); MODPLUS(wi, 0, DEC_FIFOFRMS);
			SINT32 c = wi - ri + 1; if(c <= 0) c += DEC_FIFOFRMS;
			return c;
		}

		UINT8*	ReSync(UINT8 *ptr, SINT32 quota);
		SINT32	FRMSplit();

		public:

		SINT8	bSync;

		CUniDec(TMP_StrInfo *si, SINT8 modeTSC)
		{
			bSync = 0; rFrmIdx = 0; wFrmIdx = - 1;
			FiFo = NULL; cBLK = NULL; cShow = NULL;
			SMBI = NULL; 
			
			// osd text;
			userspec_osdtext[0] = 0;
			decoded_osdtext[0] = 0;
			
			FrmLvl[0] = 2;
			FrmLvl[1] = 10002;
			FrmLvl[2] = 20002;
			FrmLvl[3] = 30002;
			FrmLvl[4] = 40002;
			DecLvl = IPB;
			adjDecLvl = 0;

			sInfo = *si;
			ITech_VLD::CreateInstance(&dHD, &sInfo, &fI, &mP);
			ITech_VLD::CreateInstance(&vld, &sInfo, &fInfo, &mPair);
			memset(&fI, 0, sizeof(TMP_FrmInfo)); memset(&mP, 0, sizeof(TMP_BlkPair));

			Configurate();
			SetTSCOption(0);
		}

		~CUniDec()
		{
			dHD->Release(); vld->Release(); 
			if(FiFo) delete FiFo; if(cBLK) delete cBLK; if(cShow) delete cShow;
			if(SMBI) delete SMBI;
		}

		SINT32	Sync(
					TMP_StrInfo *sInfo, SINT32 *numTSC = NULL, UINT8 *ptr4HdrTSC = NULL,
					SINT32 *numSrc = NULL, UINT8 *ptr4HdrSrc = NULL
					);

		virtual SINT32	UniDecTSCSetup(
					SINT8 dDraw,
					SINT8 DecLvl = FP_AUTO, SINT8 TSCLvl = FP_AUTO, TMP_PPrcSet *ppSet = NULL,
					SINT32 *fifoLvl = NULL,
					SINT32 id = 0, SINT8 *clipTbl = NULL, SINT32 mbln = - 1
					)
		{
			if(bSync)
			{
				memset(&fInfo, 0, sizeof(TMP_FrmInfo));
				memset(&mPair, 0, sizeof(TMP_BlkPair));
				if(fifoLvl)
					for(SINT32 i = 0; i < 5; i ++) FrmLvl[i] = fifoLvl[i] + 2;
				opfno = 0;

				if(cBLK) delete cBLK; if(cShow) delete cShow; if(SMBI) delete SMBI;
				if(mbln < sInfo.cols) mbln = sInfo.cols;
				SMBI = new TMP_StrMBInfo[sInfo.cols * sInfo.rows];
				cBLK = new CBLKDec(vld, &sInfo, &fInfo, &mPair, dDraw, id, clipTbl, mbln);
				cShow = new CUniDecShow(sInfo.cols, sInfo.rows, dDraw);
				Configurate(DecLvl, TSCLvl, ppSet);

				rFrmIdx = 0; rptr = srcFrm[0].ptr;
				return SUCCESS;
			}
			return ERR_ACCESS;
		}

		SINT32	FRMDecTSC(
					REAL64 *timeStamp, UINT8 *ddMem, SINT32 ddWidth,
					TMP_FrmInfo *fInfo, SINT32 *numTSC = NULL, UINT8 *ptr4FrmTSC = NULL,
					SINT32 *numSrc = NULL, UINT8 *ptr4FrmSrc = NULL
					);

		SINT32	Duplicate(UINT8 *ddMem, SINT32 ddWidth);

		void	SetTSCOption(SINT32 TSCOption = 0)
		{
		}

		void	Configurate(
					SINT8 DecLvl = FP_KEEP, SINT8 TSCLvl = FP_KEEP, TMP_PPrcSet *ppSet = NULL
					)
		{
			LET(this->DecLvl, DecLvl, IPB);
			LET(this->TSCLvl, TSCLvl, IPB);

			TMP_PPrcSet pp = { DPP_NULL, 0, 0, sInfo.cols * 16, sInfo.rows * 16 };
			if(!ppSet) ppSet = &pp;

			switch(ppSet->pproc)
			{
			case DPP_NULL:
					Y4PP = 0; UVPP = 0; break;
			case 1:
					Y4PP = 1; UVPP = 0; break;
			case 2:
					Y4PP = 1; UVPP = 1; break;
			case DPP_DBLKLUM:
					Y4PP = 2; UVPP = 0; break;
			case 4:
					Y4PP = 2; UVPP = 1; break;
			case DPP_DBLK:
					Y4PP = 2; UVPP = 2; break;
			case DPP_DBLKDRNGLUM:
					Y4PP = 3; UVPP = 0; break;
			case 7:
					Y4PP = 3; UVPP = 1; break;
			case 8:
					Y4PP = 3; UVPP = 2; break;
			case DPP_DBLKDRNG:
					Y4PP = 3; UVPP = 3; break;
			}

			h0 = CLP((ppSet->rcLeft) >> 4, 0, sInfo.cols - 2);
			v0 = CLP((ppSet->rcTop ) >> 4, 0, sInfo.rows - 2);
			h1 = CLP((ppSet->rcLeft + ppSet->rcWidth  - 1) >> 4, h0 + 1, sInfo.cols - 1);
			v1 = CLP((ppSet->rcTop  + ppSet->rcHeight - 1) >> 4, v0 + 1, sInfo.rows - 1);
		}

		SINT32	SourceInput(UINT8 *srcStr, SINT32 quota)
		{
			if(!FiFo) {
				FiFo = new UINT8[DEC_FIFOSIZE + 32]; memset(FiFo, 0, DEC_FIFOSIZE + 32);
				FiFoAlertPtr = FiFo + DEC_FIFOSIZE - DEC_FIFOMAXW;
			}
			if(!srcStr) {
				bSync = 0; sptr = wptr = FiFo; return SUCCESS;
			}
			if((quota < 1) || (quota > DEC_FIFOMAXW)) return ERR_MEMORY;

			if(!bSync)
			{
				copyMem(wptr, srcStr, quota); wptr += quota;
				sptr = ReSync(FiFo, wptr - FiFo);
				if(!bSync)
				{
					copyMem(FiFo, sptr, wptr - sptr); wptr -= sptr - FiFo;
					return SUCCESS;
				}
			}
			else
			{
				UINT8 *rp = rptr, *wp = wptr + quota;
				if(rp > wptr) {
					if((wp > FiFoAlertPtr) || (wp > rp))
						return ERR_MEMORY;
				}
				else {
					if((wp > FiFoAlertPtr) && (wp - srcFrm[wFrmIdx].ptr > rp - FiFo))
						return ERR_MEMORY;
				}
				copyMem(wptr, srcStr, quota); wptr += quota;
			}

			FRMSplit();

			if(wptr > FiFoAlertPtr)
			{
				SINT32 dptr = srcFrm[wFrmIdx].ptr - FiFo; wptr -= dptr; sptr -= dptr;
				copyMem(FiFo, srcFrm[wFrmIdx].ptr, wptr - FiFo);
				srcFrm[wFrmIdx].ptr = FiFo;
			}
			return SUCCESS;
		}

		REAL64	GetFiFoRatio(SINT32 *bufferredFrm = NULL)
		{
			UINT8 *rp = rptr, *wp = wptr; SINT32 r;
			if(rp > wp)
				r = DEC_FIFOSIZE - (MIN(rp, FiFoAlertPtr) - wp);
			else
				r = wp - rp;

			if(bufferredFrm) *bufferredFrm = BufferredFrm();
			return 1.0 * r / DEC_FIFOSIZE;
		}

		TMP_StrMBInfo*	GetStrMBInfo() { return SMBI; }

		// get snapshot bitmap buffer stored in bmp, rgb24or32 specify 24bits(1) or 32bits(0) bitmap
		SINT32	GetSnapShotBMP(UINT8 *bmp, SINT8 rgb24or32)
		{
			if (!bmp || !cBLK)
				return ERR_MEMORY;

			return cBLK->GetSnapShotBMP(bmp, (rgb24or32 ? DDRAW_DIB24 : DDRAW_DIB32));
		}

		SINT32	GetSnapShotYUV411(UINT8 *yuv411)
		{
			if (!yuv411 || !cBLK)
				return ERR_MEMORY;

			return cBLK->GetSnapShotYUV411(yuv411);
		}

		// get the on-screen-display text from last gop header from decoded stream. 
		// this is optional operation and currently only implemented with MPEG4
		// on-screen-display text is at maximum 128 byte, including the trailing 0;
		SINT32 GetCurrentOnScreenDisplayText(UINT8* data)
		{
			VCPY(data, decoded_osdtext, 128);
			return SUCCESS;
		}

		// set the on-screen-display text into the next gop header of the transcoded stream.
		// if there is on-screen-display text in the source stream, that text will override this one.
		// this is optional operation and currently only implemented with MPEG4
		// on-screen-display text is at maximum 128 byte, including the trailing 0;
		SINT32 SetCurrentOnScreenDisplayText(UINT8* data)
		{
			if ( data == NULL )
			{
				userspec_osdtext[0] = 0;
			}
			else
			{
				VCPY(userspec_osdtext, data, 128);
				userspec_osdtext[127] = 0;	// for the peace of my mind
			}
			return SUCCESS;
		}
	};

/**	ENDOFSECTION
 */



#endif
/**	ENDOFHEADERFILE: "UniDecTSC.h"
 */
