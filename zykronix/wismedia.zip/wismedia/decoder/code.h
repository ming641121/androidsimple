/*
 * $Id: code.h,v 1.2 2004/02/11 15:36:39 dmeyer Exp $
 *
 */
#ifndef _VLC_VLD_CODE_H_
#define _VLC_VLD_CODE_H_

typedef struct {
	SINT32 count;
	UINT32 reg;
	UINT8  *io;

	SINT32 index;
	UINT8  *codeStr;
} MpgvlcManager;

#define codeSet(code, N) ((code) << (N))



INLINE void   vlcInit(MpgvlcManager *vlc, SINT32 out, UINT8 *codeStr)
{
	if(out)
	{
		vlc->count = 0; vlc->reg = 0;
#ifdef _BIG_ENDIAN_
		vlc->io = ((UINT8*)&(vlc->reg));
#else
		vlc->io = ((UINT8*)&(vlc->reg)) + 3;
#endif
	}
	else
	{
		vlc->count = 24;
		vlc->io = ((UINT8*)&(vlc->reg));
#ifdef _BIG_ENDIAN_
		vlc->io[3] = codeStr[2]; vlc->io[2] = codeStr[1]; vlc->io[1] = codeStr[0]; codeStr += 3;
#else
		vlc->io[0] = codeStr[2]; vlc->io[1] = codeStr[1]; vlc->io[2] = codeStr[0]; codeStr += 3;
#endif
	}

	if(codeStr) { vlc->index = 0; vlc->codeStr = codeStr; }
}

INLINE void   vlcSave(MpgvlcManager *vlc, SINT32 num, UINT32 code)
{
	vlc->count += num; vlc->reg |= code << (32 - vlc->count);
	while(vlc->count >= 8) { *vlc->codeStr ++ = *vlc->io; vlc->reg <<= 8; vlc->count -= 8; vlc->index += 8; }
}

INLINE void   vlcSkip(MpgvlcManager *vlc, SINT32 num)
{
	vlc->count -= num; vlc->index += num;
	while(vlc->count < 24) { 
		vlc->reg <<= 8; 
#ifdef _BIG_ENDIAN_
		vlc->io[3] = *vlc->codeStr ++; 
#else
		vlc->io[0] = *vlc->codeStr ++; 
#endif		
		vlc->count += 8; 
	}
}

INLINE UINT32 vlcShow(MpgvlcManager *vlc) { return vlc->reg >> (vlc->count - 24); }

INLINE UINT32 vlcRead(MpgvlcManager *vlc, SINT32 num) { return (vlc->reg << (32 - vlc->count)) >> (32 - num); }

INLINE UINT32 vlcLoad(MpgvlcManager *vlc, SINT32 num)
{
	UINT32 val = vlcRead(vlc, num);
	vlcSkip(vlc, num);
	return val;
}

#endif
