/******************************************************************************
*
*   FILE: 
*       audio_driver.h
*
*   DESCRIPTION:
*
*   $Id: audio_driver.h,v 1.7 2005/01/11 11:53:59 jblair Exp $
*
******************************************************************************/

#include "wis_types.h"
#include "platform.h"
#include "wsdf.h"
#include "multimedia.h"
#include "struct.h"
#include "pacgen.h"

#ifndef AUDIO_DRIVER_H
#define AUDIO_DRIVER_H

status_t AD_Shutdown(void);

/* Audio Queue definitions */
typedef struct
{
    uint32 messageData;
    uint32 messageType;
} sAudioDriverQueueElement_t;

#define AUDIO_HW_BUFFER_SIZE_WORDS             (AUDIO_HW_BUFFER_SIZE/2)

typedef struct sAudioFrame
{

    uint8       *pAudioFrame;
    sint32      s32FrameLen;

} sAudioFrame_t;

#define AUDIO_DRIVER_QUEUE_SIZE             60

/* in the status register */
#define AUDIO_STREAM_BUFFER_FULL_MASK       0x40

#define AUDIO_SHUTDOWN                    0x40000002

#define AUDIO_PORT_STREAM                   0xFFF2

#define AUDIO_BASE_ADDR ENCODER_BASE_ADDR

#define AUDIO_READ_REG16(offset)        \
                *(volatile uint16 *) (AUDIO_BASE_ADDR + offset)

#define AUDIO_WRITE_REG16(offset, dataToWrite)          \
                *(volatile uint16 *) (AUDIO_BASE_ADDR + offset) = dataToWrite

extern TVIDEOCFGFIX     encoderFixedSettings;
extern TCFGVIDEOEX      encoderVariableSettings;
#endif /* AUDIO_DRIVER_H */

