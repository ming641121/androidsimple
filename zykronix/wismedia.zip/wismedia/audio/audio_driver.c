/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*    audio_driver.c
*
*   DESCRIPTION:
*     This is the driver for the audio device. (AD means 'Audio Driver module')
*
*  AUTHOR:
*   Daniel Meyer, Jimmy Blair 
*
*   $Id: audio_driver.c,v 1.20 2005/01/12 16:18:53 jblair Exp $ 
*
******************************************************************************/

#include <asm/system.h>
#include "wis_types.h"
#include "wis_error.h"
#include "os.h"
#include "tasks.h"
#include "platform.h"
#include "encoder_driver.h"
#include "audio_driver.h"
#include "wis_audio.h"
#include "struct.h"
#include "queue_api.h"
#include "sal_api.h"
#include "ringbuf.h"

extern void wis_acb (void *mpframe, int len, void *user, int flags);
extern bool_t g_bAudioHardwareInitialized;
extern ringbuf_t amemRing;     /* defined in wisdev_linux.c */
extern int debugLevel;

int avsync_audio_frame; 
int __n_audio_frames_total;
int AudioFrameSize;

int audioDone=0;
int sAudioDriverQueue;

/* global signal meaning that this is the very first audio frame */
bool_t g_bAudioFirstFrame = TRUE;

osl_thread_t audioDriverTaskId=0;

void *audio_buffer_base;
int audio_buffer_len;
int audio_correction_rate = 0;
int audio_correction_count = 0;
int audio_big_endian = 0;
int audio_channels = 0;
int audio_rate = 0;

/* task variables local to this file */
static void *sample_ptr;
static void *frame_start;
static int samples_per_buffer; 
static int frame_len; 
static int correction_ticker; 

/* Callback support */
extern sAudioCallbackHandler_t  __cblist[]; 
extern int __n_audio_handlers;

status_t
AD_DiagTest(void)
{
    return SUCCESS;
}

status_t
AD_Shutdown(void)
{
    sAudioDriverQueueElement_t element;
    status_t returnStatus = WIS_SUCCESS;

    element.messageType = AUDIO_SHUTDOWN;

    OSL_QPut(sAudioDriverQueue, (int *)&element,
        sizeof(sAudioDriverQueueElement_t), OS_NO_WAIT);

    while (audioDone == 0)
        osl_msleep (1);  /* This gives AD_Task a chance to run */

    return returnStatus;
}

status_t
AD_ResetHW(void)
{
    return SUCCESS;
}


/******************************************************************************
*
*   PROCEDURE:  
*       AD_Init(void)
*
*   DESCRIPTION:
*       Initialize the audio device and driver
*  
*   ARGUMENTS:
*
*     NONE
*
*   RETURNS:
*
*    NONE
*
******************************************************************************/
void
AD_Init (void)
{
}


/******************************************************************************
*
*  Procedure Name:
*       AD_SignalFrame(aframe_t *aframe)
*
*  Description:
*       When a frame arrives, signal it here.  A frame is defined as number of
*   1024 byte increments defined by the user.
*  
*  Arguments:
*       aframe - pointer to audio frame descriptor. 
*
*  Returns:
*
*    NONE
*
*   Notes:
*
******************************************************************************/


void
AD_SignalFrame(aframe_t *aframe)
{
    int i;
    int flags=0;

    if (debugLevel >= DEBUG_LEVEL_PRINTFS)
    {
        printf("Signal Audio Frame\n");
    }
    
    if (g_bAudioFirstFrame == TRUE)
    {
        flags |= AUDIO_FLAG_FRAME_IS_STREAM_HEADER;
        g_bAudioFirstFrame = FALSE;
    }

    /* Invoke callbacks .. */
    for ( i = 0; i < __n_audio_handlers; i++ )
    {
	wis_acb(aframe, aframe->len,
                (void*)__cblist[i].pAudioFrameCallbackUser, flags );
    }
}


void
AD_audio_isr(int irq, void* isrData, struct pt_regs* regs)
{
    int i, j;
    uint16 val[2];
    short intstatus;
    aframe_t *aframe;  /* audio frame descriptor */

    intstatus = AUDIO_READ_REG16(ENCODER_STATUS);

    /* Only handle the full-audio-buffer interrupt */
    if ((intstatus & AUDIO_STREAM_BUFFER_FULL_MASK) == 0) {
        goto done;
    }

    /* Read audio segment from chip */
    for (i=0; i < samples_per_buffer; i++ )
    {
	for (j=0; j < audio_channels; j++ )
	{
	    val[j] = AUDIO_READ_REG16(AUDIO_PORT_STREAM);
#ifdef _BIG_ENDIAN_ 
	    if( ! audio_big_endian )
#else
	    if( audio_big_endian )
#endif
		    val[j] = ( val[j] << 8 ) | ( val[j] >> 8 );
	}
	if( audio_correction_rate < 0 && correction_ticker-- == 0 )
	{
	    --audio_correction_count;
	    correction_ticker = -audio_correction_rate;
	    continue;
	}
	for (j=0; j < audio_channels; j++ )
	{
	    *((uint16 *)sample_ptr) = val[j];
	    sample_ptr += 2;
	    if( sample_ptr == audio_buffer_base + audio_buffer_len )
		sample_ptr = audio_buffer_base;
	    frame_len += 2;
	}
	if( audio_correction_rate > 0 && correction_ticker-- == 0 )
	{
	    for (j=0; j < audio_channels; j++ )
	    {
		*((uint16 *)sample_ptr) = val[j];
		sample_ptr += 2;
		if( sample_ptr == audio_buffer_base + audio_buffer_len )
			sample_ptr = audio_buffer_base;
		frame_len += 2;
	    }
	    ++audio_correction_count;
	    correction_ticker = audio_correction_rate;
	}
    }

    /* If we have a full frame worth of audio, send it up */
    if( frame_len >= AudioFrameSize )
    {
	aframe = (aframe_t *) ringbuf_get (&amemRing);

	if( (int)aframe != -1 )
	{
	    aframe->addr = frame_start;
	    aframe->len = AudioFrameSize;
	    AD_SignalFrame (aframe);
	} /* otherwise drop the entire frame */
	frame_start += AudioFrameSize;
	if( frame_start == audio_buffer_base + audio_buffer_len )
		frame_start = audio_buffer_base;
	frame_len -= AudioFrameSize;
	avsync_audio_frame++;
	__n_audio_frames_total++;
    }

    done:
    /* clear the interrupt to the interrupt controller */
    board_int_clear (AUDIO_INTERRUPT_STATUS_BIT_MASK);

    return;
}



/******************************************************************************
*
*  Procedure Name:
*       AD_Task(void)
*
*  Description:
*       This task is responsible for initializing and
*       servicing the audio capture device
*  
*  Arguments:
*
*     NONE
*
*  Returns:
*
*    NONE
*
*   Notes:
*
******************************************************************************/

void
AD_Task()
{
    sAudioDriverQueueElement_t sAudioDriverQueueElement;

    audioDone = 0;
    avsync_audio_frame = 0;
    frame_len = 0;
    correction_ticker = 0; 
    samples_per_buffer = AUDIO_HW_BUFFER_SIZE_WORDS / audio_channels;
    sample_ptr = audio_buffer_base;
    frame_start = audio_buffer_base;

    /* global flag to tell whether this is the first audio frame */
    g_bAudioFirstFrame = TRUE;

    /* clear the interrupt at the interrupt controller */
    board_int_clear (AUDIO_INTERRUPT_STATUS_BIT_MASK);

    if (debugLevel >= DEBUG_LEVEL_PRINTFS)
    {
        printf("Begin Audio Driver Task\n");
    }

    /*
     * Setup message queue, the ISR uses it to communicate with the
     * audio stream task.
     */
    sAudioDriverQueue = OSL_QInit(OSL_Q_TYPE_ISR_TO_TASK,
                  sizeof(sAudioDriverQueueElement_t),
                  AUDIO_DRIVER_QUEUE_SIZE);

#ifdef __linux__
    /* Provide full interrupt info.
     * Under Linux, complete with /proc info
     */
    osl_int_connect(AUDIO_INT_NUM,
            AD_audio_isr,
            "HPI-Audio", (void*)IRQ_DEV_ID_AUDIO);
#else
    /* XXX Todo: Remove macro for name mangling of osl_int_connect on Vx*/
    OSL_IntConnect(AUDIO_INT_NUM, AD_InterruptServiceRoutine, 0);
#endif    

    /* clear the interrupt to the interrupt controller */
    board_int_clear (AUDIO_INTERRUPT_STATUS_BIT_MASK);

    /* enable the audio interrupt */
    osl_int_enable (AUDIO_INT_NUM);

    audioDone = 0;
    printk("Audio Frame Size: %d bytes\n", AudioFrameSize);
    while ( !audioDone )
    {

        /* if the audio hardware has not yet been initialized, wait for it */
        while (g_bAudioHardwareInitialized != TRUE)
        {
            osl_msleep (30); 
        }
        
        /* Wait for audio events */
        OSL_QGet(sAudioDriverQueue, (int *)&sAudioDriverQueueElement,
                 sizeof(sAudioDriverQueueElement_t), OS_WAIT_FOREVER);
        if (debugLevel >= DEBUG_LEVEL_PRINTFS)
        {
            printk("Audio Queue Received 0x%x\n",
                   (sAudioDriverQueueElement.messageData << 16)
                   | sAudioDriverQueueElement.messageType );
        }

        /*
	 * this message is special in that it is generated by the
	 * driver to notify this task that it should shutdown
	 * gracefully and exit
	 */
        if (sAudioDriverQueueElement.messageType == AUDIO_SHUTDOWN ) {
            audioDone = 1;
            break;
        }

    } /* end FOREVER loop */

    osl_int_disable (AUDIO_INT_NUM);
    osl_int_disconnect (AUDIO_INT_NUM, (void*) IRQ_DEV_ID_AUDIO);
    board_int_clear (AUDIO_INTERRUPT_STATUS_BIT_MASK);
    OSL_QDelete (sAudioDriverQueue);

    printf ("Audio thread exit\n");
}

