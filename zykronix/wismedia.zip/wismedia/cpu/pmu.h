#ifndef _PMU_H_
#define _PMU_H_


#ifdef __cplusplus
extern "C" {
#endif

extern unsigned int pmu0, pmu1, pmu2, pmu3;

void pmu_conf(unsigned int configure);

unsigned int pmu_read0();
unsigned int pmu_read1();
unsigned int pmu_read2();
unsigned int pmu_read3();

#ifdef __cplusplus
}
#endif

#endif    /* #ifndef _PMU_H_ */
