/**
 * @file PmuCodeForWis.c
 *
 * @author Intel Corporation
 * @date 3-Oct-2002
 *
 * @brief This file contains the implementation of the IXP425 Ethernet Access Data plane
 * Component
 *
 * Design Notes:
 *
 * -- Intel Copyright Notice --
 *
 * @par
 * INTEL CONFIDENTIAL
 *
 * @par
 * Copyright 2003 Intel Corporation All Rights Reserved.
 *
 * @par
 * The source code contained or described herein and all documents
 * related to the source code ("Material") are owned by Intel Corporation
 * or its suppliers or licensors.  Title to the Material remains with
 * Intel Corporation or its suppliers and licensors.  The Material
 * contains trade secrets and proprietary and confidential information of
 * Intel or its suppliers and licensors.  The Material is protected by
 * worldwide copyright and trade secret laws and treaty provisions. No
 * part of the Material may be used, copied, reproduced, modified,
 * published, uploaded, posted, transmitted, distributed, or disclosed in
 * any way without Intel's prior express written permission.
 *
 * @par
 * No license under any patent, copyright, trade secret or other
 * intellectual property right is granted to or conferred upon you by
 * disclosure or delivery of the Materials, either expressly, by
 * implication, inducement, estoppel or otherwise.  Any license under
 * such intellectual property rights must be express and approved by
 * Intel in writing.
 *
 * @par
 * For further details, please see the file README.TXT distributed with
 * this software.
 * -- End Intel Copyright Notice --
 */

/************************************************************************
 * The following functions are used for some timing tests for the polling
 * access layer functions. To enable function timing #define TIMING. 
 *
 * See usage instructions below.
 */

#define INLINE __inline__

#define TIMING
#ifdef TIMING

static INLINE void _Write_EVTSEL(unsigned VAL)
{
  __asm__ volatile("mcr\tp14, 0, %0, c8, c1, 0" : : "r" (VAL));
}


/* PMN Counter
 * num - PMU register number (must be 0-3)
 */

static INLINE unsigned _Read_PMN(int num)
{
  register unsigned _val_ = 0;
  switch (num)
  {
  	case 0:
  		__asm__ volatile("mrc\tp14, 0, %0, c0, c2, 0" : "=r" (_val_));
  		break;
  		
  	case 1:
  	    __asm__ volatile("mrc\tp14, 0, %0, c1, c2, 0" : "=r" (_val_));
  	    break;
  	    
  	case 2:
  	    __asm__ volatile("mrc\tp14, 0, %0, c2, c2, 0" : "=r" (_val_));
  	    break;
  	    
  	case 3:
  	    __asm__ volatile("mrc\tp14, 0, %0, c3, c2, 0" : "=r" (_val_));
  	    break;
  }
    
  return _val_;
}

/* Clock Counter (CCNT) */
static INLINE unsigned _Read_CCNT(void)
{
  register unsigned _val_;
  __asm__ volatile("mrc\tp14, 0, %0, c1, c1, 0" : "=r" (_val_));
  return _val_;
}

static INLINE void _Write_PMNC(unsigned VAL)
{
  __asm__("mcr\tp14, 0, %0, c0, c1, 0" : : "r" (VAL));
}

/************************************************************************
 * Our wrappers
 */

void pmuInit(void)
{
    /* 07 - instructions executed
       02 - data dependency stall
       0A - data cache access
       0B - data cache misses
    */

    _Write_EVTSEL(0x0B0A0207); /* Select PMU events */
    _Write_PMNC(0x7);	       /* enable and reset PMU / clock counters */
}

#define PMU_COUNT_START(counter, pmn) (counter) -= _Read_PMN(pmn)
#define PMU_COUNT_STOP(counter, pmn) (counter) += _Read_PMN(pmn)
#define COUNT_CLOCK_START(counter) (counter) -= _Read_CCNT()
#define COUNT_CLOCK_STOP(counter) (counter) += _Read_CCNT()

#else

#define PMU_COUNT_START(counter, pmn)
#define PMU_COUNT_STOP(counter, pmn)
#define COUNT_CLOCK_START(counter) 
#define COUNT_CLOCK_STOP(counter) 

#endif
/* TIMING */

/************************************************************************
 * If you have all the files of interest in one c file you could just put
 * this stuff in at the top and do something like the following.
 *
 * Run the data.
 * At the wind shell do:
 *   pmuStart
 *   then wait approx 2 seconds (wrapping counters not implemeted)
 *   pmuStop
 *   pmuPrint
 */

static unsigned pmuHpiClocks = 0;
static unsigned pmuHpiStalls = 0;
static unsigned pmuHpiCount  = 0;

static unsigned pmuDctClocks = 0;
static unsigned pmuDctStalls = 0;
static unsigned pmuDctCount  = 0;

static unsigned pmuXpotClocks = 0;
static unsigned pmuXpotStalls = 0;
static unsigned pmuXpotCount  = 0;

static unsigned pmuDcmpClocks = 0;
static unsigned pmuDcmpStalls = 0;
static unsigned pmuDcmpCount  = 0;

static unsigned pmuAllClocks = 0;
static unsigned pmuAllStalls = 0;
static int pmuRunning = 0;

void
pmuClear(void)
{
    pmuHpiClocks = 0;
    pmuHpiStalls = 0;
    pmuHpiCount  = 0;

    pmuDctClocks = 0;
    pmuDctStalls = 0;
    pmuDctCount  = 0;
    pmuXpotClocks = 0;
    pmuXpotStalls = 0;
    pmuXpotCount  = 0;
    pmuDcmpClocks = 0;
    pmuDcmpStalls = 0;
    pmuDcmpCount  = 0;
    pmuAllClocks = 0;
    pmuAllStalls = 0;
}

void
pmuStart(void)
{
    pmuClear();
    pmuRunning = 1;
    PMU_COUNT_START(pmuAllStalls, 1);
    COUNT_CLOCK_START(pmuAllClocks);
}

void
pmuStop(void)
{
    COUNT_CLOCK_STOP(pmuAllClocks);
    PMU_COUNT_STOP(pmuAllStalls, 1);
    pmuRunning = 0;
}

void
pmuPrint(void)
{
#if 0
    printf("HpiClocks=%u, Hpi Avg=%u, HpiUsage=%.0f%%, Stalled Clocks=%.0f%%\n",
	   pmuHpiClocks,
	   pmuHpiClocks / pmuHpiCount,
	   (float) (((float)pmuHpiClocks / (float)pmuAllClocks) * 100),
	   (float) (((float)pmuHpiStalls / (float)pmuHpiClocks) * 100));
#endif
    
    printf("DctClocks=%u, Dct Avg=%u, DctUsage=%.0f%%, Stalled Clocks=%.0f%%\n",
	   pmuDctClocks,
	   pmuDctClocks / pmuDctCount,
	   (float) (((float)pmuDctClocks / (float)pmuAllClocks) * 100),
	   (float) (((float)pmuDctStalls / (float)pmuDctClocks) * 100));

    printf("XpotClocks=%u, Xpot Avg=%u, XpotUsage=%.0f%%, Stalled Clocks=%.0f%%\n",
    pmuXpotClocks,
    pmuXpotClocks / pmuXpotCount,
    (float) (((float)pmuXpotClocks / (float)pmuAllClocks) * 100),
    (float) (((float)pmuXpotStalls / (float)pmuXpotClocks) * 100));

    printf("DcmpClocks=%u, Dcmp Avg=%u, DcmpUsage=%.0f%%, Stalled Clocks=%.0f%%\n",
        pmuDcmpClocks,
        pmuDcmpClocks / pmuDcmpCount,
        (float) (((float)pmuDcmpClocks / (float)pmuAllClocks) * 100),
        (float) (((float)pmuDcmpStalls / (float)pmuDcmpClocks) * 100));

    printf("AllClocks=%u, Stalled Clocks=%.0f%%\n",
	   pmuAllClocks,
	   (float) (((float)pmuAllStalls / (float)pmuAllClocks) * 100));
}

/************************************************************************
 * To put the counters into your existing code
 */

void pmuHpiStart(void)
{
    if (pmuRunning)
     {
     pmuHpiCount++;
     PMU_COUNT_START(pmuHpiStalls, 1);
     COUNT_CLOCK_START(pmuHpiClocks);
     }
}

void pmuHpiFinish(void)
{
    if (pmuRunning)
    {
	COUNT_CLOCK_STOP(pmuHpiClocks);
	PMU_COUNT_STOP(pmuHpiStalls, 1);
    }
}

void pmuXpotStart(void)
{
    if (pmuRunning)
    {
	pmuXpotCount++;
	PMU_COUNT_START(pmuXpotStalls, 1);
	COUNT_CLOCK_START(pmuXpotClocks);
    }
}
void pmuXpotFinish(void)
{
    if (pmuRunning)
    {
	COUNT_CLOCK_STOP(pmuXpotClocks);
	PMU_COUNT_STOP(pmuXpotStalls, 1);
    }
}

void pmuDcmpStart(void)
{
    if (pmuRunning)
    {
	pmuDcmpCount++;
	PMU_COUNT_START(pmuDcmpStalls, 1);
	COUNT_CLOCK_START(pmuDcmpClocks);
    }

}
void pmuDcmpFinish(void)
{
    if (pmuRunning)
    {
	COUNT_CLOCK_STOP(pmuDcmpClocks);
	PMU_COUNT_STOP(pmuDcmpStalls, 1);
    }
}
     
void pmuIdctStart(void)
{
    if (pmuRunning)
    {
	pmuDctCount++;
	PMU_COUNT_START(pmuDctStalls, 1);
	COUNT_CLOCK_START(pmuDctClocks);
    }
}

void pmuIdctFinish(void)
{
    if (pmuRunning)
    {
	COUNT_CLOCK_STOP(pmuDctClocks);
	PMU_COUNT_STOP(pmuDctStalls, 1);
    }
}




/************************************************************************/

#if 0

int
main(int argc, char**argv)
{
    pmuHpiClocks = 321;
    pmuHpiStalls = 123;
    pmuHpiCount  = 10;

    pmuDctClocks = 450;
    pmuDctStalls = 150;
    pmuDctCount  = 50;

    pmuAllClocks = 1000;
    pmuAllStalls = 100;

    pmuPrint();

    return 0;
}

#endif
