#include "wis_types.h"
#include "wsdf.h"
#include "struct.h"
#include "multimedia.h"
#include "platform.h"
#include "pacgen.h"

TVIDEOCFGFIX encoderFixedSettings;

void ED_SetInitialFixedSettings(void)
{

/* osd setting */

    encoderFixedSettings.osdcfg.DoOSD = 0;
    encoderFixedSettings.osdcfg.OSDyc0 = 0;
    encoderFixedSettings.osdcfg.OSDyc1 = 255;
    encoderFixedSettings.osdcfg.OSDuc0 = 0;
    encoderFixedSettings.osdcfg.OSDuc1 = 128;
    encoderFixedSettings.osdcfg.OSDvc0 = 0;
    encoderFixedSettings.osdcfg.OSDvc1 = 128;

/* Threshold */

    encoderFixedSettings.thcfg.THACCoeffSet0 = 0;
    encoderFixedSettings.thcfg.THACCoeffStartpoint = 1;
    encoderFixedSettings.thcfg.THedge = 20;
    encoderFixedSettings.thcfg.THmotion = 30;
    encoderFixedSettings.thcfg.THblending = 4;
    encoderFixedSettings.thcfg.THbigedge = 900;
    encoderFixedSettings.thcfg.THsmalledge = 300;
    encoderFixedSettings.thcfg.THedgestatistics = 20;
    encoderFixedSettings.thcfg.THmotionstatistics = 30;
    encoderFixedSettings.thcfg.THbigedgestatistics = 900;
    encoderFixedSettings.thcfg.THsmalledgestatistics = 300;

/* Deinterlace */

    encoderFixedSettings.deintercfg.DeInter_Always_Motion = 0;
    encoderFixedSettings.deintercfg.DeInter_Always_Blending = 1;
    encoderFixedSettings.deintercfg.DeInter_Always_Weave = 0;

/* IIP setting */

    encoderFixedSettings.iipcfg.Bit_Length = 10;
    encoderFixedSettings.iipcfg.CCM_R_0 = 0;
    encoderFixedSettings.iipcfg.CCM_R_1 = 0;
    encoderFixedSettings.iipcfg.CCM_R_2 = 256;
    encoderFixedSettings.iipcfg.CCM_R_3 = 0;
    encoderFixedSettings.iipcfg.CCM_G_0 = 128;
    encoderFixedSettings.iipcfg.CCM_G_1 = 0;
    encoderFixedSettings.iipcfg.CCM_G_2 = 0;
    encoderFixedSettings.iipcfg.CCM_G_3 = 128;
    encoderFixedSettings.iipcfg.CCM_B_0 = 0;
    encoderFixedSettings.iipcfg.CCM_B_1 = 256;
    encoderFixedSettings.iipcfg.CCM_B_2 = 0;
    encoderFixedSettings.iipcfg.CCM_B_3 = 0;
    encoderFixedSettings.iipcfg.R_Gain = 288;
    encoderFixedSettings.iipcfg.G_Gain = 256;
    encoderFixedSettings.iipcfg.B_Gain = 270;
    encoderFixedSettings.iipcfg.R_Offset = 0;
    encoderFixedSettings.iipcfg.G_Offset = 0;
    encoderFixedSettings.iipcfg.B_Offset = 0;
    encoderFixedSettings.iipcfg.Gamma_R_P0_C = 28;
    encoderFixedSettings.iipcfg.Gamma_R_P0_Y = 0;
    encoderFixedSettings.iipcfg.Gamma_R_P1_C = 32;
    encoderFixedSettings.iipcfg.Gamma_R_P1_Y = 7;
    encoderFixedSettings.iipcfg.Gamma_R_P2_C = 28;
    encoderFixedSettings.iipcfg.Gamma_R_P2_Y = 15;
    encoderFixedSettings.iipcfg.Gamma_R_P3_C = 28;
    encoderFixedSettings.iipcfg.Gamma_R_P3_Y = 29;
    encoderFixedSettings.iipcfg.Gamma_R_P4_C = 26;
    encoderFixedSettings.iipcfg.Gamma_R_P4_Y = 57;
    encoderFixedSettings.iipcfg.Gamma_R_P5_C = 27;
    encoderFixedSettings.iipcfg.Gamma_R_P5_Y = 83;
    encoderFixedSettings.iipcfg.Gamma_R_P6_C = 17;
    encoderFixedSettings.iipcfg.Gamma_R_P6_Y = 110;
    encoderFixedSettings.iipcfg.Gamma_R_P7_C = 12;
    encoderFixedSettings.iipcfg.Gamma_R_P7_Y = 178;
    encoderFixedSettings.iipcfg.Gamma_R_P8_C = 8;
    encoderFixedSettings.iipcfg.Gamma_R_P8_Y = 223;

    encoderFixedSettings.iipcfg.Gamma_B_P0_C = 28;
    encoderFixedSettings.iipcfg.Gamma_B_P0_Y = 0;
    encoderFixedSettings.iipcfg.Gamma_B_P1_C = 32;
    encoderFixedSettings.iipcfg.Gamma_B_P1_Y = 7;
    encoderFixedSettings.iipcfg.Gamma_B_P2_C = 28;
    encoderFixedSettings.iipcfg.Gamma_B_P2_Y = 15;
    encoderFixedSettings.iipcfg.Gamma_B_P3_C = 28;
    encoderFixedSettings.iipcfg.Gamma_B_P3_Y = 29;
    encoderFixedSettings.iipcfg.Gamma_B_P4_C = 26;
    encoderFixedSettings.iipcfg.Gamma_B_P4_Y = 57;
    encoderFixedSettings.iipcfg.Gamma_B_P5_C = 27;
    encoderFixedSettings.iipcfg.Gamma_B_P5_Y = 83;
    encoderFixedSettings.iipcfg.Gamma_B_P6_C = 17;
    encoderFixedSettings.iipcfg.Gamma_B_P6_Y = 110;
    encoderFixedSettings.iipcfg.Gamma_B_P7_C = 12;
    encoderFixedSettings.iipcfg.Gamma_B_P7_Y = 178;
    encoderFixedSettings.iipcfg.Gamma_B_P8_C = 8;
    encoderFixedSettings.iipcfg.Gamma_B_P8_Y = 223;

    encoderFixedSettings.iipcfg.Gamma_G_P0_C = 28;
    encoderFixedSettings.iipcfg.Gamma_G_P0_Y = 0;
    encoderFixedSettings.iipcfg.Gamma_G_P1_C = 32;
    encoderFixedSettings.iipcfg.Gamma_G_P1_Y = 7;
    encoderFixedSettings.iipcfg.Gamma_G_P2_C = 28;
    encoderFixedSettings.iipcfg.Gamma_G_P2_Y = 15;
    encoderFixedSettings.iipcfg.Gamma_G_P3_C = 28;
    encoderFixedSettings.iipcfg.Gamma_G_P3_Y = 29;
    encoderFixedSettings.iipcfg.Gamma_G_P4_C = 26;
    encoderFixedSettings.iipcfg.Gamma_G_P4_Y = 57;
    encoderFixedSettings.iipcfg.Gamma_G_P5_C = 27;
    encoderFixedSettings.iipcfg.Gamma_G_P5_Y = 83;
    encoderFixedSettings.iipcfg.Gamma_G_P6_C = 17;
    encoderFixedSettings.iipcfg.Gamma_G_P6_Y = 110;
    encoderFixedSettings.iipcfg.Gamma_G_P7_C = 12;
    encoderFixedSettings.iipcfg.Gamma_G_P7_Y = 178;
    encoderFixedSettings.iipcfg.Gamma_G_P8_C = 8;
    encoderFixedSettings.iipcfg.Gamma_G_P8_Y = 223;

    encoderFixedSettings.iipcfg.Black_P = 60;
    encoderFixedSettings.iipcfg.White_P = 200;
    encoderFixedSettings.iipcfg.AWB_WIN_L = 40;
    encoderFixedSettings.iipcfg.AWB_WIN_T = 30;
    encoderFixedSettings.iipcfg.AWB_WIN_R = 120;
    encoderFixedSettings.iipcfg.AWB_WIN_B = 90;
    encoderFixedSettings.iipcfg.SUM_R1 = 0;
    encoderFixedSettings.iipcfg.SUM_G1 = 0;
    encoderFixedSettings.iipcfg.SUM_B1 = 0;
    encoderFixedSettings.iipcfg.AWB_N_VLD_W1 = 0;
    encoderFixedSettings.iipcfg.SUM_R2 = 0;
    encoderFixedSettings.iipcfg.SUM_G2 = 0;
    encoderFixedSettings.iipcfg.SUM_B2 = 0;
    encoderFixedSettings.iipcfg.AWB_N_VLD_W2 = 0;
    encoderFixedSettings.iipcfg.SUM_R3 = 0;
    encoderFixedSettings.iipcfg.SUM_G3 = 0;
    encoderFixedSettings.iipcfg.SUM_B3 = 0;
    encoderFixedSettings.iipcfg.AWB_N_VLD_W3 = 0;
    encoderFixedSettings.iipcfg.SUM_R4 = 0;
    encoderFixedSettings.iipcfg.SUM_G4 = 0;
    encoderFixedSettings.iipcfg.SUM_B4 = 0;
    encoderFixedSettings.iipcfg.AWB_N_VLD_W4 = 0;
    encoderFixedSettings.iipcfg.SUM_R5 = 0;
    encoderFixedSettings.iipcfg.SUM_G5 = 0;
    encoderFixedSettings.iipcfg.SUM_B5 = 0;
    encoderFixedSettings.iipcfg.AWB_N_VLD_W5 = 0;
    encoderFixedSettings.iipcfg.AE_WIN_L = 40;
    encoderFixedSettings.iipcfg.AE_WIN_T = 30;
    encoderFixedSettings.iipcfg.AE_WIN_R = 120;
    encoderFixedSettings.iipcfg.AE_WIN_B = 90;
    encoderFixedSettings.iipcfg.MAX_Y_CTR = 0;
    encoderFixedSettings.iipcfg.MIN_Y_CTR = 255;
    encoderFixedSettings.iipcfg.SUM_Y_CTR = 0;
    encoderFixedSettings.iipcfg.VALID_NUM_CTR = 0;
    encoderFixedSettings.iipcfg.MAX_Y_BK = 0;
    encoderFixedSettings.iipcfg.MIN_Y_BK = 255;
    encoderFixedSettings.iipcfg.SUM_Y_BK = 0;
    encoderFixedSettings.iipcfg.VALID_NUM_BK = 0;
    encoderFixedSettings.iipcfg.B_Strgth = 0;
    encoderFixedSettings.iipcfg.B_Thrshld = 0;
    encoderFixedSettings.iipcfg.SAT = 64;
    encoderFixedSettings.iipcfg.HUE = 47;
    encoderFixedSettings.iipcfg.Y_Gain = 69;
    encoderFixedSettings.iipcfg.Y_Offset = 8;
    encoderFixedSettings.iipcfg.LPF_Switch = 0;
    encoderFixedSettings.iipcfg.LPF_COEF_Y_0 = 4;
    encoderFixedSettings.iipcfg.LPF_COEF_Y_1 = 15;
    encoderFixedSettings.iipcfg.LPF_COEF_Y_2 = 26;
    encoderFixedSettings.iipcfg.LPF_COEF_Cr_0 = 4;
    encoderFixedSettings.iipcfg.LPF_COEF_Cr_1 = 15;
    encoderFixedSettings.iipcfg.LPF_COEF_Cr_2 = 26;
    encoderFixedSettings.iipcfg.LPF_COEF_Cb_0 = 4;
    encoderFixedSettings.iipcfg.LPF_COEF_Cb_1 = 15;
    encoderFixedSettings.iipcfg.LPF_COEF_Cb_2 = 26;

/* audio setting */

    encoderFixedSettings.audiocfg.main_divider = 1;
    encoderFixedSettings.audiocfg.BCLK_divider = 0;
    encoderFixedSettings.audiocfg.OKI_mode = 0;
    encoderFixedSettings.audiocfg.OKI_short_frame_mode = 0;
    encoderFixedSettings.audiocfg.clock_generator_enable = 0;
    encoderFixedSettings.audiocfg.I2S_master_mode = 0;
    encoderFixedSettings.audiocfg.I2S_mode = 1;
    encoderFixedSettings.audiocfg.invert_phase_BCLK = 0;
    encoderFixedSettings.audiocfg.OKI_shoftframe_mode = 0;
    encoderFixedSettings.audiocfg.word_length = 16;
    encoderFixedSettings.audiocfg.auto_SOF_generation = 1;  /* HPI mode needs this! */
    encoderFixedSettings.audiocfg.left_channel_only = 0;
    encoderFixedSettings.audiocfg.higher_8_bit_combine = 0;
    encoderFixedSettings.audiocfg.AC97_enable = 0;
    encoderFixedSettings.audiocfg.signature_bit_selection = 0;
    encoderFixedSettings.audiocfg.buffer_config = 0;
    encoderFixedSettings.audiocfg.sample_mapping_reg1 = 0;
    encoderFixedSettings.audiocfg.sample_mapping_reg2 = 0;
    encoderFixedSettings.audiocfg.sample_mapping_reg3 = 0;
    encoderFixedSettings.audiocfg.sample_mapping_reg4 = 0;
    encoderFixedSettings.audiocfg.sample_mapping_reg5 = 0;
    encoderFixedSettings.audiocfg.sample_mapping_reg6 = 0;
    encoderFixedSettings.audiocfg.sample_mapping_reg7 = 0;
    encoderFixedSettings.audiocfg.adpcm_enable = 0;
    encoderFixedSettings.audiocfg.adpcm_mode = 0;
    encoderFixedSettings.audiocfg.bytes_per_block = 256;
    encoderFixedSettings.audiocfg.bpredictor = 0;
    encoderFixedSettings.audiocfg.idelta_left = 16;
    encoderFixedSettings.audiocfg.idelta_right = 16;
    encoderFixedSettings.audiocfg.icoef1_left = 256;
    encoderFixedSettings.audiocfg.icoef1_right = 256;
    encoderFixedSettings.audiocfg.icoef2_left = 0;
    encoderFixedSettings.audiocfg.icoef2_right = 0;
    encoderFixedSettings.audiocfg.reserved = 0; /* Audio SampleRate */

/* else setting */

    encoderFixedSettings.elsecfg.clockrate = 96;         
    encoderFixedSettings.elsecfg.DRAM = 2;           
    encoderFixedSettings.elsecfg.HPIBufferCapacity = 0x27;      
    encoderFixedSettings.elsecfg.ivtc_holding_time = 0;
    encoderFixedSettings.elsecfg.HasAudio = 0;
    encoderFixedSettings.elsecfg.v_sync_bitplane = 0;

}

