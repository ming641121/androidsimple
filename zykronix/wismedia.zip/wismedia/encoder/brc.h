
#define STATE_CBR                                       0
#define STATE_VBR                                       1

 typedef struct BRC_MESSAGE_S {
                                                                                                                             
    sint32 changeDirection;
    sint32 newIQScale;
    sint32 newPQScale;
    sint32 newTargetBitrate;
    sint32 newPeakBitrate;
    sint32 newVbvBuffer;
    sint32 newConvergenceSpeed;
    sint32 newLambda;
                                                                                                                             
} brc_message_t;
