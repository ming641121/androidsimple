/******************************************************************************
*
*    Copyright WIS Technologies (c) (2003)
*    All Rights Reserved
*
*******************************************************************************
*
*    FILE: 
*        osd.c
*
*    DESCRIPTION:
*        1) Parse the OSD font library.
*	 2) Implement OSD APIs
*
*    AUTHOR: Xiuli Guo
*
*    Modification: Sheng Qu
*	
*    $Id: osd.c,v 1.2 2004/06/04 18:04:28 squ Exp $
*
******************************************************************************/

#include "wis_types.h"
#include "wis_error.h"
#include "wis_encoder.h"
#include "encoder_driver.h"
#include "struct.h"
#include "os.h"
#include "osd.h"

#define MAX_CHAR_NUM 2000
#define FONT_HEAD_SIZE 3*sizeof(long)
#define CALC_FONTBITMAP_SIZE(w,h,count) (w*h*4/8*count)
#define MB_SIZE 16
#define INVALID_CHAR_INDEX 1

#define OSD_BUFFER_LOOP_REGISTER 0x3FE8

#define OSD_STRING_BUFFER1_START 0x3A00
#define OSD_STRING_BUFFER1_END 0x3A5F
#define OSD_STRING_BUFFER2_START 0x3A60
#define OSD_STRING_BUFFER2_END 0x3ABF
#define OSD_END_OF_FRAME 0xAAAA
#define OSD_END_OF_STRING 0x0000

static int CBusSafeWrite(int val,uint16 Addr, uint16 Data);
static OSD_ERROR GetOSDData(uint16 x, uint16 y, char *pString);

uint16 OSDStringStartAddr;
uint16 OSDIndexAddr;
uint16 CurrentBufAddr;
uint16 FrameIndex;
uint16 FrameBuff[96];
uint16 LastFrameBuff[96];
uint16 OSDRsvdBUFF[90];
uint16 OSDFrameWidth;
uint16 OSDFrameHeight;
uint16 EndOfStringX;
uint16 EndOfStringY;

typedef struct tagOSD_STATUS
{
    uint16 OSDStringStartAddr;
    uint16 OSDIndexAddr;
    uint16 CurrentBufAddr;
    uint16 FrameIndex;
    uint16 FrameBuff[96];
}OSD_STATUS;

OSD_STATUS OSD;

#define OSD_SUPPORT_INDEX_MAX 256
#define DISPLAY_RANGE_X 25
#define DISPLAY_RANGE_Y 25

typedef struct tagCharacterMap
{
	unsigned short WideChar;//The unicode
	unsigned short Index; 
}CharacterMap_t;

typedef struct tagOSD_t
{
	long CharWidth;
	long CharHeight;
	
	long Count;
	CharacterMap_t* pCharacterMap;

	unsigned short NextOSDStringStartAddr;
	unsigned short BufferIndex;

	long VideoFrameMBUnitWidth;
	long VideoFrameMBUnitHeight;

	unsigned short* pCharIndexMatrix;
	long lMatrixSize;
} OSD_t;

extern sint32 ReadCBusRegFW(int read_num, uint16 *addr, uint16 *data);
extern int WriteCBusRegFW(int write_num, uint16 *addr_data);

/*************************************************************************
*
*
* Init OSD to get the ubs handling for write the OSD command by USB
*
*
***************************************************************************/
OSD_ERROR InitOSD(int VideoFrameWidth, int VideoFrameHeight)
{
	/*uint16 temp, addr=OSD_BUFFER_LOOP_REGISTER;
	int Retry=5;
	//Get initial frame buffer start address
	while ((ReadCBusRegFW(1,&addr,&temp)!=0) && (Retry>0))
	{
		Retry--;
	}
	if(Retry>0)
	{
		CurrentBufAddr=temp;
	}
	else
	{
        	CurrentBufAddr=OSD_STRING_BUFFER1_START;
	}*/
	CurrentBufAddr=OSD_STRING_BUFFER2_START;
	// from current video setting get the OSD width and height
	OSDFrameWidth=VideoFrameWidth/MB_SIZE;
	OSDFrameHeight=VideoFrameHeight/MB_SIZE;
	//initialization 
	FrameIndex=0;
	EndOfStringX=0;
	EndOfStringY=0;
	return OSD_ERROR_OK;
}

/*************************************************************************
*
*
* Clean the OSD display
*
*
**************************************************************************/
OSD_ERROR CleanOSD(void)
{
	//write the EOF to the start address of current frame buffer
	if(CBusSafeWrite(5,OSD_STRING_BUFFER1_START,OSD_END_OF_FRAME)!=0)
		return OSD_ERROR_INVALIDFONTFILE;
	EndOfStringX = 0;
	EndOfStringY = 0;
	return OSD_ERROR_OK;
}

/*************************************************************************
*
*
* * Write OSD data to buffer, if the usb write failed try it again
* val:  USD send data retry number
* Addr: OSD buffer address
* Data: data to be written to OSD buffer 
*
*
***************************************************************************/
OSD_ERROR WriteOSD(uint16 x, uint16 y, char *pString)
{
	uint16 temp[OSD_STRING_LEN_MAX],i=1,temp_i,tempX,tempY;

	if((strlen(pString)+3)>OSD_STRING_LEN_MAX)
		return OSD_ERROR_INVALIDFONTFILE;

	//if the osd string start address(x,y) is out of range,return error
	if(x>OSDFrameWidth || y>OSDFrameHeight)
	{
		return OSD_ERROR_INVALIDFONTFILE;
	}
	
	//if the current new start address is less than the end of the previous address, return error
	if((y<EndOfStringY)||((y==EndOfStringY)&&(x<EndOfStringX)))
	{
		return OSD_ERROR_INVALIDFONTFILE;
	}
	
	tempX = ((x+strlen(pString))%OSDFrameWidth);
	tempY = (x+strlen(pString))/OSDFrameWidth + y;
	
	//if the osd string start address(x,y) is out of range,return error
	if(tempY>OSDFrameHeight)
	{
		return OSD_ERROR_INVALIDFONTFILE;
	}

	EndOfStringX = tempX;
	EndOfStringY = tempY;

	temp[0]=(uint16)(x+(y<<8));
	
	//put the charactor index to a temp arry
	//if the string length is larger than OSD_STRING_LEN_MAX, return error
	while(*pString != 0)
	{
		temp[i++]=(uint16)*pString++;
		if(*pString >OSD_SUPPORT_INDEX_MAX)
			return OSD_ERROR_INVALIDFONTFILE;
	}
    
	//put OSD_DOC 
	temp[i++]=0;

	temp_i=i;
	
	//switch to the next OSD frame
	if(CurrentBufAddr==OSD_STRING_BUFFER1_START)
	{
		OSDStringStartAddr=OSD_STRING_BUFFER2_START;
	}
	else
	{
		OSDStringStartAddr=OSD_STRING_BUFFER1_START;
	}
	
	i=0;
	OSDIndexAddr=OSDStringStartAddr;
	
	//write the frame structure to chip by USB 
	while(i<=temp_i)
	{
		if ( CBusSafeWrite(5,OSDIndexAddr,temp[i])!=0)
			return OSD_ERROR_INVALIDFONTFILE;

		OSDIndexAddr++;
		i++;
	}
	
	//Write EOF to the end of frame
	if ( CBusSafeWrite(5,OSDIndexAddr,OSD_END_OF_FRAME)!=0)
		return OSD_ERROR_INVALIDFONTFILE;

	//Change display addr.

	if ( CBusSafeWrite(5,OSD_BUFFER_LOOP_REGISTER,OSDStringStartAddr)!=0)
		return OSD_ERROR_INVALIDFONTFILE;
	
	//Write down current buffer address 
	CurrentBufAddr=OSDStringStartAddr;

	EndOfStringX = 0;
	EndOfStringY = 0;

	return OSD_ERROR_OK;
}


/*************************************************************************
*
*
* Write OSD data to buffer, if the usb write failed try it again
* val:  USD send data retry number
* Addr: OSD buffer address
* Data: data to be written to OSD buffer
*
*
***************************************************************************/
static int CBusSafeWrite(int val,uint16 Addr,uint16 Data)
{		
	int i,result;
	uint16 addr_data[2];

	addr_data[0]=Addr;
        addr_data[1]=Data;
	result=WriteCBusRegFW(1,addr_data);
	if(result!=0)
	{
		for(i=0;i<val;i++)
		{
		    if(WriteCBusRegFW(1,addr_data)==0)
		        return 0;
		}
        return 1;
	}
	return 0;
}

/*************************************************************************
*
*
* Clean the OSD display
* (x,y) start display location of the string
*  *pString: start address of the string stored at
*
***************************************************************************/
static OSD_ERROR GetOSDData(uint16 x, uint16 y, char *pString)
{
	uint16 tempX,tempY;
	
	//if the osd string start address(x,y) is out of range,return error
	if(x>OSDFrameWidth || y>OSDFrameHeight)
	{
		return OSD_ERROR_INVALIDFONTFILE;
	}
	
	//if the current new start address is less than the end of the previous address, return error
	if((y<EndOfStringY)||((y==EndOfStringY)&&(x<EndOfStringX)))
	{
		return OSD_ERROR_INVALIDFONTFILE;
	}
	
	tempX = ((x+strlen(pString))%OSDFrameWidth);
	tempY = (x+strlen(pString))/OSDFrameWidth + y;
	
	//if the osd string start address(x,y) is out of range,return error
	if(tempY>OSDFrameHeight)
	{
		return OSD_ERROR_INVALIDFONTFILE;
	}

	EndOfStringX = tempX;
	EndOfStringY = tempY;

	if((FrameIndex+strlen(pString)+3)>OSD_STRING_LEN_MAX)
		return OSD_ERROR_INVALIDFONTFILE;

	FrameBuff[FrameIndex++]=(uint16)(x+(y<<8));
	
	//put the charactor index to a temp arry
	//if the string length is larger than OSD_STRING_LEN_MAX, return error
	while(*pString != 0)
	{
		FrameBuff[FrameIndex]=(uint16)*pString++;
		if(*pString >OSD_SUPPORT_INDEX_MAX)
			return OSD_ERROR_INVALIDFONTFILE;
		FrameIndex++;
	}
    
	FrameIndex=FrameIndex;
	
	//put OSD_EOS 
	FrameBuff[FrameIndex++]=OSD_END_OF_STRING;
	
	return OSD_ERROR_OK;
}


/*************************************************************************
*
*
* Write the prepared OSD data to OSD buffer 
* mode : to update current buffer of write to a new buffer
*  
*
***************************************************************************/
OSD_ERROR ShowOSDFrame(OSD_DISPLAY_MODE  mode)
{

	uint16 i=0;
	
	if (mode==0)
	{
	    //switch to the next OSD frame
	    if(CurrentBufAddr==OSD_STRING_BUFFER1_START)
		{
		    OSDStringStartAddr=OSD_STRING_BUFFER2_START;
		}
	    else
		{
		    OSDStringStartAddr=OSD_STRING_BUFFER1_START;
		}
	}

	//Get start address of the OSD Framebuffer;
	OSDIndexAddr=OSDStringStartAddr ;

	//add the EOF to the buffer
	FrameBuff[FrameIndex++]=OSD_END_OF_FRAME;

	//write the frame structure to chip by USB 
	while(i<FrameIndex)
	{
		if (mode==1)
		{
			if (LastFrameBuff[i]!=FrameBuff[i])
			{
				if(CBusSafeWrite(7,OSDIndexAddr,FrameBuff[i])!=0)
					return OSD_ERROR_INVALIDFONTFILE;
			}
		}
		else
		{
			if(CBusSafeWrite(7,OSDIndexAddr,FrameBuff[i])!=0)
				return OSD_ERROR_INVALIDFONTFILE;
		}

		OSDIndexAddr++;
		LastFrameBuff[i]=FrameBuff[i];
		i++;
	}
	
	//Change display addr.

	if(CBusSafeWrite(5,OSD_BUFFER_LOOP_REGISTER,OSDStringStartAddr)!=0)
		return OSD_ERROR_INVALIDFONTFILE;

	//Write down current buffer address 
	FrameIndex=0;;
	CurrentBufAddr=OSDStringStartAddr;
	EndOfStringX = 0;
	EndOfStringY = 0;
	return OSD_ERROR_OK;

}


/*************************************************************************
*
*
* Get the OSD data to OSD buffer in the OSD frame format 
* StringNum : string number
* *pString strings start address
*  
*
***************************************************************************/
OSD_ERROR GetOSDFrame(int StringNum, void *pString)
{
	OSD_STRING_t *TempPtr = (OSD_STRING_t *)pString;
	
	while (StringNum--)
	{
		//Write a string to OSD frame buffer
		GetOSDData(TempPtr->x,TempPtr->y,TempPtr->String);
		TempPtr++;
	}
		
	return OSD_ERROR_OK;
}

/********************************************end of osd.c**********************************************************/

