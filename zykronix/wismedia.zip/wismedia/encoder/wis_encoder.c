/***WIS***********************************************************************
*
*   Copyright WIS Technologies (c) (2004)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       wis_encoder.c
*
*   DESCRIPTION:
*       These are the APIs (Application Programming Interface) for the WIS video encoder driver. NOTE: Only one instance of an encoder is allowed.
*
*   AUTHOR:
*
*   $Id: wis_encoder.c,v 1.26 2005/01/11 11:55:08 jblair Exp $
*
*****************************************************************************/

#include "wis_types.h"
#include "encoder_driver.h"
#include "wis_encoder.h"
#include "wis_error.h"
#include "os.h"
#include "tasks.h"

#ifdef VXWORKS
#include <tasks.h>
#include <stdlib.h>
#endif

/* only one instance of the encoder task allowed */
osl_thread_t encoderDriverTaskId;
osl_thread_t monitorTaskId;
osl_thread_t AVSyncTaskId;

bool_t g_bRuntime = FALSE;

/*
 * Up to 100 callbacks may be registered.
 */

encoder_handler_t   callbackHandlers[MAX_NUM_CALLBACKS];
int __n_handlers=0;
extern int brc_state;
/***WIS_API*******************************************************************
*
*  Procedure Name:
*       status_t EncoderSchedulerInit(int prio)
*
*  Description:
*       This procedure initializes the video encoder scheduler
*  
*  Arguments:
*       int prio - [in] runtime priority for task scheduler deferred procedure call mechanism
*
*  Returns:
*       status_t - always return ENCODER_SUCCESS(0)
*
*   Notes:
*       This function should be called before EncoderStart()
*
*****************************************************************************/

status_t
EncoderSchedulerInit(int prio)
{
    static int ranonce = 0;
    if ( !ranonce++ ) {
	osl_dpc_init(prio);
    }
    
    return ENCODER_SUCCESS;
}

/***WIS_API*******************************************************************
*
*  Procedure Name:
*       status_t EncoderStart(sint32 priority)
*
*  Description:
*       This procedure starts the video encoder
*  
*  Arguments:
*       sint32 priority - [in] runtime priority for task scheduler deferred procedure call mechanism
*
*  Returns:
*     + ENCODER_SUCCESS(0) on success
*     + ENCODER_FAILURE (-1) on failure if the encoder Task already exists, don't start another
*
*   Notes:
*       This function shall be called after the video driver configuration is completed.
*
*****************************************************************************/

status_t
EncoderStart(int doAVSynch, sint32 priority,int SensorType,int AudioCap)
{

    /* if the Encoder Task already exists, don't start another */
    if (encoderDriverTaskId != 0)
    {
        return(ENCODER_FAILURE);
    }

    /* create the encoder task */
    encoderDriverTaskId = OSL_CreateTask(ENCODER_DRIVER_TASK_NAME,
					 priority, ENCODER_DRIVER_TASK_OPTIONS,
					 ENCODER_DRIVER_TASK_STACK_SIZE,
					 ENCODER_DRIVER_TASK_ENTRY_POINT);

    monitorTaskId = OSL_CreateTask(MONITOR_TASK_NAME,
				   MONITOR_TASK_PRIORITY, MONITOR_TASK_OPTIONS,
				   MONITOR_TASK_STACK_SIZE,
				   MONITOR_TASK_ENTRY_POINT);

    if (doAVSynch) { 
	if( (SensorType==SENSOR_TYPE_SAA7113) && 
	    (AudioCap!=CAP_AUDIO_FORMAT_NONE)) { 

	    AVSyncTaskId = OSL_CreateTask(AV_SYNC_TASK_NAME,
					  priority, AV_SYNC_TASK_OPTIONS,
					  AV_SYNC_TASK_STACK_SIZE,
					  AV_SYNC_TASK_ENTRY_POINT);

	}
    }
    
    return(ENCODER_SUCCESS);
}

/***WIS_API*******************************************************************
*
*  Procedure Name:
*       status_t EncoderStop(void)
*
*  Description:
*       This procedure stops the video encoder
*  
*  Arguments:
*      None
*
*  Returns:
*     + ENCODER_SUCCESS(0) on success
*     + ENCODER_FAILURE (-1) on failure if there is no encoder task, you can't delete it
*
*   Notes:
*
*****************************************************************************/

status_t
EncoderStop(int do_avsync, int sensor)
{
    int result = ENCODER_SUCCESS;

    g_bRuntime = FALSE;

    /* if there is no encoder task, you can't delete it */
    if (encoderDriverTaskId == 0) {
        return ENCODER_FAILURE;
    }

    ED_Shutdown();

    OSL_DeleteTask(monitorTaskId);

    /* clear it so we can create a new task */
    encoderDriverTaskId = 0;
    monitorTaskId = 0;

    if ( do_avsync) { 
	if (sensor == SENSOR_TYPE_SAA7113){
	    result=AVSYNC_Stop();

	    if (result != ENCODER_SUCCESS) {
		printk("wis0: Error: AV-Synch  could not stop!\n");
	    }
	}
    }
    
    return result;
}

/***WIS_API*******************************************************************
*
*  Procedure Name:
*       status_t EncoderDiagTest(void)
*
*  Description:
*       This procedure executes the standard set of diagnostics.
*  
*  Arguments:
*       None
*
*  Returns:
*      + ENCODER_SUCCESS(0) on success
*      + ENCODER_FAILURE (-1) on failure
*
*   Notes:
*
*****************************************************************************/


status_t
EncoderDiagTest(void)
{
    status_t returnStatus=ENCODER_SUCCESS;

    printk("Begin Encoder Diag Test\n");
    returnStatus = ED_DiagTest();
    printk("Encoder Diag Test Result = %d\n", returnStatus);
    
    return returnStatus;
}


/***WIS_API*******************************************************************
*
*  Procedure Name:
*       encoderVersion_t EncoderGetVersionInfo(void)
*
*  Description:
*       This procedure retrieves version information of the video encoder.
*  
*  Arguments:
*       None
*
*  Returns:
*       encoderVersion_t - encoder_version_t structure
*
*   Notes:
*
*****************************************************************************/

encoderVersion_t EncoderGetVersionInfo(void)
{
    encoderVersion_t version;
    
    version.encoderDriverVersion = 0x100;
    version.encoderFirmwareVersion = 0x100;
    version.encoderHardwareVersion = 0x100;
    
    return version;
}

/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetBitrateControl(uint32 targetBitrate, uint32 peakBitrate, uint32 maxFps,
*                                                         uint32 gopSize, uint32 videoBufferSize, uint32 constQ)
* 
*   Description:
*       This procedure sets bitrate control of encoder
*
*   Arguments: 
*       uint32 targetBitrate - [in] target rate of encoder in Kbps 
*
*       uint32 peakBitrate - [in] the peak bitrate of encoder allowed in Kbps. As you approach 
*                                     this value, frame duplication becomes more likely.
*
*       uint32 maxFps - [in] the max fps of encoder allowed.
*
*       uint32 gopSize - [in] gop_size of encoder.  In IBP mode this size MUST be divisible 
*                                by 3 (since a subGOP is two B frames and an I or P frame)
*
*       uint32 videoBufferSize - [in] the size of the buffer frames reside in after they come 
*                                           from the encoder
*
*       uint32 constQ - [in] quantized scale
*
*   Returns:
*       status_t - always return ENCODER_SUCCESS(0)
*
*   Notes:
*       If a sensor input is less than 30fps (the sensor's standard input is 30 fps), the fps user 
*       got will be a ratio of this. Ffor instance, if you request a maxFps of 15 and the sensor 
*       input is 20fps, then 30:15 is 2, so 20/2 is 10, meaning that you actually get 10fps.
*
*****************************************************************************/
status_t
EncoderSetBitrateControl(uint32 targetBitrate,
			 uint32 peakBitrate,
			 uint32 maxFps,
			 uint32 gopSize,
			 uint32 videoBufferSize,
			 uint32 constQ)
{	

    status_t returnStatus=ENCODER_SUCCESS;

    returnStatus = ED_SetBitrateControl(targetBitrate,
					peakBitrate,
					maxFps, gopSize, videoBufferSize, constQ); 
        
    return returnStatus ;
}

/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderGetBitrateControl(uint32 targetBitrate, uint32 peakBitrate, uint32 maxFps, 
*                                                        uint32 gopSize, uint32 videoBufferSize, uint32 constQ)
*
*   Description:
*       This procedure gets the bitrate of video encoder
*  
*   Arguments:
*       uint32 *targetBitrate - [out] the pointer to store target rate in Kbps current in device 
*
*       uint32 *peakBitrate - [out] the pointer to store the current peak bitrate allowed
*
*       uint32 *maxFps - [out] the pointer to store the current maximum frames per second
*
*       uint32 *gopSize - [out] the pointer to store the current gop_size
*
*       uint32 *videoBufferSize - [out] the pointer to store the bytes of the video buffer in which 
*                                             frames reside until they are used
*
*       uint32 *constQ - [out] the pointer to store the quantized scale
*
*   Returns:
*       status_t - always return ENCODER_SUCCESS(0)
*
*   Notes:
*
*****************************************************************************/

status_t
EncoderGetBitrateControl(uint32 *targetBitrate,
			 uint32 *peakBitrate,
			 uint32 *maxFps,
			 uint32 *gopSize,
			 uint32 *videoBufferSize,
			 uint32 *constQ)
{
    status_t returnStatus=ENCODER_SUCCESS;
    if(*constQ!=0) 
	brc_state=STATE_CBR;
    else
	brc_state=STATE_VBR;
    returnStatus = ED_GetBitrateControl(targetBitrate,
					peakBitrate,
					maxFps, gopSize, videoBufferSize, constQ);

    return returnStatus ;
}

/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetInputFrameRate(sint32 inputFps)
*
*   Description:
*       This procedure sets input frame rate of encoder
*  
*   Arguments:
*       sint32 inputFps - [in] fps of the input device
*
*   Returns:
*       status_t - always return ENCODER_SUCCESS(0)
*
*   Notes:
*
*****************************************************************************/

status_t
EncoderSetInputFrameRate(sint32 inputFps)
{
    status_t returnStatus=ENCODER_SUCCESS;

    g_inputFrameRate = inputFps;

    return returnStatus;
}

/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderRegisterFrameCallback(encoder_callback_t *cb, void *callbackArgument)
*
*   Description:
*       This procedure hookups the callback function to encoder.  For every frame generated 
*       by the encoder, the encoder will invoke a user-defined callback routine registered 
*       via this routine.
*  
*   Arguments:
*       encoder_callback_t *cb - [in] pointer to the callback function to be called for 
*                                            each video frame
*
*       void *callbackArgument - [in] pointer to the user defined data  that the callback 
*                                              would like to use
*   
*   Returns:
*     + ENCODER_SUCCESS(0) on success
*     + ENCODER_FAILURE(-1) on failure for exceeding max number
*
*   Notes:
*     
*****************************************************************************/

status_t
EncoderRegisterFrameCallback(encoder_callback_t *cb,
				      void *callbackArgument)
{
        if (__n_handlers > MAX_NUM_CALLBACKS)
    {
        return ENCODER_FAILURE;
    }

    callbackHandlers[__n_handlers].encoderFrameCallback = cb;
    callbackHandlers[__n_handlers].encoderFrameCallbackUser = callbackArgument;
    printf("EncoderRegisterFrameCallback: "
           "Entry:0x%x, Data:0x%x (%d entries)\n",
           (sint32)callbackHandlers[__n_handlers].encoderFrameCallback,
           (sint32)callbackHandlers[__n_handlers].encoderFrameCallbackUser,
           __n_handlers+1);

    __n_handlers++;
    
    return ENCODER_SUCCESS;
}

/***WIS_API*******************************************************************
*
*   Procedure Name:
*       encoderCapabilities_t EncoderGetCapabilities(void)
*
*   Description:
*       This procedure returns the capabilities mask structure for selection  of target output 
*       mode. This routine will return a mask of supported output modes.  For the modes 
*       supported, one and only one can be enabled by calling EncoderSetMode.
*  
*   Arguments:
*       None
*
*   Returns:
*       encoderCapabilities_t - encoder capabilities structure
*
*   Notes:
*     
*****************************************************************************/

encoderCapabilities_t EncoderGetCapabilities(void)
{
    encoderCapabilities_t caps;

    caps.modesSupported = ENCODER_MODE_MPEG4 | ENCODER_MODE_MPEG2 |
	                  ENCODER_MODE_MPEG1 | ENCODER_MODE_H263 |
	                  ENCODER_MODE_PROGRESSIVE | ENCODER_MODE_352_X_288|
	                  ENCODER_MODE_IBP | ENCODER_MODE_IP_ONLY |
	                  ENCODER_MODE_I_ONLY | ENCODER_MODE_AV_SYNC;

    return caps;
}

/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetMode(encoderCapabilities_t *modeMask)
*
*   Description:
*       This procedure sets the current mode of operation for device
*  
*   Arguments:
*       encoderCapabilities_t modeMask - [in] bitmask of supported modes of encoder
*
*   Returns:
*       status_t - always return ENCODER_SUCCESS(0)
*
*   Notes:
*       EncoderGetCapabilities() must be invoked first to determine the modes supported 
*       by the device.
*****************************************************************************/

status_t
EncoderSetMode(encoderCapabilities_t modeMask)
{

    ED_SetInitialFixedSettings();

    ED_SetInitialVideoSettings();

    ED_SetMode(&modeMask);

    return ENCODER_SUCCESS;
}


/***WIS_API*******************************************************************
*
*   Procedure Name:  
*       status_t EncoderDeleteAFrame(void)
*
*   Description:
*       Delete the last frame in this GOP.
*  
*   Arguments:
*       None
*
*   Returns:
*       status_t - always return ENCODER_SUCCESS(0)
*
*   Notes:
*
*****************************************************************************/
status_t
EncoderDeleteAFrame(void)
{
    status_t retStatus;
    
    retStatus = ED_DeleteAFrame();
    
    return(retStatus);
}

/***WIS_API*******************************************************************
*
*   Procedure Name:  
*       status_t EncoderInsertAFrame(void)
*
*   Description:
*       Duplicate the last frame in this GOP.
*  
*   Arguments:
*       None
*
*   Returns:
*       status_t - always return ENCODER_SUCCESS(0)
*
*   Notes:
*
*****************************************************************************/
status_t
EncoderInsertAFrame(void)
{
    status_t retStatus=ENCODER_SUCCESS;
    
    retStatus = ED_InsertAFrame();
    
    return(retStatus);
}

/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetOsdStr(osdString_t userOsdStr)
*
*   Description:
*       This procedure sets the OSD string for the encoder
*  
*   Arguments:
*       osdString_t userOsdStr - [in] osd string and its coordinates
*
*   Returns:
*       status_t - always return ENCODER_SUCCESS(0)
*
*   Notes:
*
*****************************************************************************/

status_t EncoderSetOsdStr(osdString_t userOsdStr)
{
    status_t returnStatus=ENCODER_SUCCESS;

    ED_SetOsdStr(userOsdStr);

    return returnStatus;
}

/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetSensorType(sint32 userSensorType, sint32 userInputSource, 
*            sint32 userTvStandard, sensorControl_t userSensorCtrl, sint32 userAudioCap)
*
*   Description:
*       This procedure sets sensor type of encoder
*  
*   Arguments:
*       sint32 userSensorType - [in] sensor type of the encoder
*
*       sint32 userInputSource - [in] input source of the encoder
*
*       sint32 userTvStandard - [in] TV standard of the encoder
*
*       sensorControl_t userSensorCtrl - [in] the sensor control configuration
*
*       sint32 userAudioCap - [in] audio capability of encoder
*
*   Returns:
*       status_t - always return ENCODER_SUCCESS(0)
*
*   Notes:
*
*****************************************************************************/

status_t EncoderSetSensorType(sint32 userSensorType, sint32 userInputSource, sint32 userTvStandard, sensorControl_t userSensorCtrl, sint32 userAudioCap)
{
    status_t returnStatus=ENCODER_SUCCESS;

    ED_SetSensorType(userSensorType, userInputSource, userTvStandard, userSensorCtrl, userAudioCap);

    return returnStatus;
}

/*
 * Function: EncoderSetSensorXXX - modify sensor settings
 * Arguments: setting - new sensor setting (no range checking)
 */
#define ICM202_CONTRAST_SETTING         0x28 /* 0 to 0x3f: default 0x20 */
#define ICM202_BRIGHTNESS_SETTING       0x2b /* 0 to 255: default 0 */
#define ICM202_GAMMA_SETTING            0x2c /* 0 to 6: default 2 */
#define ICM202_SATURATION_SETTING       0x2d /* 0 to 127: default 0x30 */
#define ICM202_SHARPNESS_SETTING        0x30 /* first 3 bits 1-enable,
						0 -disable, bits 3-5
						0-7, 1 default (0x09)
					     */
#define ICM202_AWB_SETTING              0x33 /* ena/disa auto-white balance */

#define OV7648_SHARPNESS_SETTING        0x00 /* no config'able sharpness */
#define OV7648_CONTRAST_SETTING         0x00 /* no config'able contrast */
#define OV7648_GAMMA_SETTING            0x00 /* no config'able gamma correct */
#define OV7640_BLUE_SETTING             0x01 /* Range: [00] to [FF] */
#define OV7640_RED_SETTING              0x02 /* Range: [00] to [FF] */
#define OV7640_SATURATION_SETTING       0x03 /* 0 to 15 for bit[7:4] */
#define OV7640_HUE_SETTING              0x04 /* 0 to 15 for bit[4:0], bit[5]:enable */
#define OV7640_PREAMP_SETTING           0x05 /* 0 to 15 for red bit[7:4],
						0 to 15 for blue bit[3:0] */
#define OV7640_BRIGHTNESS_SETTING       0x06 /* Range: [00] to [FF] */
#define OV7640_AWB_SETTING              0x12 /* bit[2]: AWB enable */ 
#define OV7640_FRARH_SETTING            0x2A
#define OV7640_FRARL_SETTING            0x2B
/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetSensorGamma(uint16 setting)
*
*   Description:
*       This procedure sets sensor gamma of encoder
*  
*   Arguments:
*       uint16 setting - [in] sensor gamma value
*
*   Returns:
*      + WIS_SUCCESS on success
*      + WIS_FAILURE or ENCODER_INVALID_MODE_SELECTED on failure
*
*   Notes:
*       Currently only supports ICM 202B sensor
*
*****************************************************************************/
status_t
EncoderSetSensorGamma(uint16 setting)
{
    switch(sensorType)
    {
        case SENSOR_TYPE_OV7648:
            return(ENCODER_INVALID_MODE_SELECTED);
            break;

        case SENSOR_TYPE_OV7640:
            return(ENCODER_INVALID_MODE_SELECTED);
            break;
            
        case SENSOR_TYPE_ICM202B:
            icm202SensorSetXXX(ICM202_GAMMA_SETTING, setting);
            return(WIS_SUCCESS);
            break;
    }
    
    return(WIS_FAILURE);
}
/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetSensorBrightness(uint16 setting)
*
*   Description:
*       This procedure sets sensor brightness of encoder
*  
*   Arguments:
*       uint16 setting - [in] sensor brightness value
*
*   Returns:
*      + WIS_SUCCESS on success
*      + WIS_FAILURE on failure
*
*   Notes:
*       Currently only supports OV7648, OV7640, ICM 202B sensor
*
*****************************************************************************/
status_t
EncoderSetSensorBrightness(uint16 setting)
{
    switch(sensorType)
    {
        case SENSOR_TYPE_OV7648:
            ov7648SensorSetXXX(OV7640_BRIGHTNESS_SETTING, setting);
            return(WIS_SUCCESS);
            break;
            
        case SENSOR_TYPE_OV7640:
            setting = setting>100? 100:setting;
            setting = setting*255/100;
            ov7648SensorSetXXX(OV7640_BRIGHTNESS_SETTING, setting);
            return(WIS_SUCCESS);
            break;
            
        case SENSOR_TYPE_ICM202B:
            icm202SensorSetXXX(ICM202_BRIGHTNESS_SETTING, setting);
            return(WIS_SUCCESS);
            break;
    }
    
    return(WIS_FAILURE);
}
/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetSensorHue(uint16 setting)
*
*   Description:
*       This procedure sets sensor hue of encoder
*  
*   Arguments:
*       sint32 setting - [in] sensor hue value
*
*   Returns:
*      + WIS_SUCCESS on success
*      + WIS_FAILURE or ENCODER_INVALID_MODE_SELECTED on failure
*
*   Notes:
*       Currently only supports OV7640, ICM 202B sensor
*
*****************************************************************************/
status_t
EncoderSetSensorHue(sint32 setting)
{
    switch(sensorType)
    {
        case SENSOR_TYPE_OV7648:
            return(ENCODER_INVALID_MODE_SELECTED);
            break;

        case SENSOR_TYPE_OV7640:
            setting += 50;
            setting = setting<0? 0:setting;
            setting = setting>100? 100:setting;
            setting = (setting*31/100) | 0x0020;
            ov7648SensorSetXXX(OV7640_HUE_SETTING, (uint16) setting);
            return(WIS_SUCCESS);
            break;
    }

    return(WIS_FAILURE);
}
/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetSensorPLF(uint16 setting)
*
*   Description:
*       This procedure sets sensor power line frequency of encoder
*  
*   Arguments:
*       uint16 setting - [in] sensor power line frequency 
*
*   Returns:
*      + WIS_SUCCESS on success
*      + WIS_FAILURE on failure
*
*   Notes:
*       Currently only supports OV7640 sensor
*
*****************************************************************************/
status_t
EncoderSetSensorPLF(uint16 setting)
{
    uint16 frarh,frarl;

    switch(sensorType)
    {
        case SENSOR_TYPE_OV7640:
            if(setting==50)
            { /* 0x2A=0xB0, 0x2B=0x08 for 50Hz power line */
                frarh=0xB0;
                frarl=0x08;
            }
            else
            { /* 0x2A=0x91, 0x2B=0x5E for 60Hz power line */
                frarh=0x90;
                frarl=0x5E;
            }
            ov7648SensorSetXXX(OV7640_FRARH_SETTING, frarh);
            ov7648SensorSetXXX(OV7640_FRARL_SETTING, frarl);
            return(WIS_SUCCESS);
            break;
    }

    return(WIS_FAILURE);
}
/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetSensorContrast(uint16 setting)
*
*   Description:
*       This procedure sets sensor contrast of encoder
*  
*   Arguments:
*       uint16 setting - [in] sensor contrast value
*
*   Returns:
*      + WIS_SUCCESS on success
*      + WIS_FAILURE or ENCODER_INVALID_MODE_SELECTED on failure
*
*   Notes:
*       Currently only supports ICM 202B sensor
*
*****************************************************************************/
status_t
EncoderSetSensorContrast(uint16 setting)
{
    switch(sensorType)
    {
        case SENSOR_TYPE_OV7648:
            return(ENCODER_INVALID_MODE_SELECTED);
            break;

        case SENSOR_TYPE_OV7640:
            return(ENCODER_INVALID_MODE_SELECTED);
            break;
            
        case SENSOR_TYPE_ICM202B:
            icm202SensorSetXXX(ICM202_CONTRAST_SETTING, setting);
            return(WIS_SUCCESS);
            break;
    }
    
    return(WIS_FAILURE);
}
/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetSensorSaturation(uint16 setting)
*
*   Description:
*       This procedure sets sensor saturation of encoder
*  
*   Arguments:
*       uint16 setting - [in] sensor saturation value
*
*   Returns:
*      + WIS_SUCCESS on success
*      + WIS_FAILURE on failure
*
*   Notes:
*       Currently only supports OV7648, OV7640 and ICM 202B sensor
*
*****************************************************************************/
status_t
EncoderSetSensorSaturation(uint16 setting)
{
    switch(sensorType)
    {
        case SENSOR_TYPE_OV7648:
            ov7648SensorSetXXX(OV7640_SATURATION_SETTING, setting << 4);
            return(WIS_SUCCESS);
            break;

        case SENSOR_TYPE_OV7640:
            setting = setting>100? 100:setting;
            setting = ((setting*15/100)<<4) | 0x4;
            ov7648SensorSetXXX(OV7640_SATURATION_SETTING, setting);
            return(WIS_SUCCESS);
            break;
            
        case SENSOR_TYPE_ICM202B:
            icm202SensorSetXXX(ICM202_SATURATION_SETTING, setting);
            return(WIS_SUCCESS);
            break;
    }
    
    return(WIS_FAILURE);
}
/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetSensorSharpness(uint16 setting)
*
*   Description:
*       This procedure sets sensor sharpness of encoder
*  
*   Arguments:
*       uint16 setting - [in] sensor sharpness value
*
*   Returns:
*      + WIS_SUCCESS on success
*      + WIS_FAILURE or ENCODER_INVALID_MODE_SELECTED on failure
*
*   Notes:
*       Currently only supports ICM 202B sensor
*
*****************************************************************************/
status_t
EncoderSetSensorSharpness(uint16 setting)
{
    switch(sensorType)
    {
        case SENSOR_TYPE_OV7648:
            return(ENCODER_INVALID_MODE_SELECTED);
            break;

        case SENSOR_TYPE_OV7640:
            return(ENCODER_INVALID_MODE_SELECTED);
            break;
            
        case SENSOR_TYPE_ICM202B:
            icm202SensorSetXXX(ICM202_SHARPNESS_SETTING, setting);
            return(WIS_SUCCESS);
            break;
    }
    
    return(WIS_FAILURE);
}
/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetSensorWhiteBalance(sensorControl_t wb_setting)
*
*   Description:
*       This procedure sets sensor white balance of encoder
*  
*   Arguments:
*       sensorControl_t wb_setting - [in] sensor white balance setting
*
*   Returns:
*      + WIS_SUCCESS on success
*      + WIS_FAILURE or ENCODER_INVALID_MODE_SELECTED on failure
*
*   Notes:
*       Currently only supports OV7640, ICM 202B sensor
*
*****************************************************************************/
status_t
EncoderSetSensorWhiteBalance(sensorControl_t wb_setting)
{
    uint16 setting1,setting2;

    switch(sensorType)
    {
        case SENSOR_TYPE_OV7648:
            return(ENCODER_INVALID_MODE_SELECTED);
            break;

        case SENSOR_TYPE_OV7640:
            setting1 = (uint16) (0x11|(wb_setting.wb_mode<<2));
            ov7648SensorSetXXX(OV7640_AWB_SETTING,setting1);
            setting1 = wb_setting.wb_redpre>100? 100:wb_setting.wb_redpre;
            setting1 = setting1*15/100;
            setting1 = setting1<<4;
            setting2 = wb_setting.wb_bluepre>100? 100:wb_setting.wb_bluepre;
            setting2 = setting2*15/100;
            setting2 = setting2 | setting1;
            ov7648SensorSetXXX(OV7640_PREAMP_SETTING,setting2);
            if(wb_setting.wb_mode==CUSTOMIZED_WHITE_BALANCE)
            {
                setting1 = wb_setting.wb_redchl>100? 100:wb_setting.wb_redchl;
                setting1 = setting1*255/100;
                ov7648SensorSetXXX(OV7640_RED_SETTING,setting1);
                setting2 = wb_setting.wb_bluechl>100? 100:wb_setting.wb_bluechl;
                setting2 = setting2*255/100;
                ov7648SensorSetXXX(OV7640_BLUE_SETTING,setting2);
            }
            return(WIS_SUCCESS);
            break;
            
        case SENSOR_TYPE_ICM202B:
            icm202SensorSetXXX(ICM202_AWB_SETTING, (uint16) wb_setting.wb_mode);
            return(WIS_SUCCESS);
            break;
    }
    
    return(WIS_FAILURE);
}
/***WIS_API*******************************************************************
*
*   Procedure Name:
*       status_t EncoderSetSensorAutoExposure(uint16 setting)
*
*   Description:
*       This procedure sets sensor auto exposure of encoder
*  
*   Arguments:
*        uint16 setting - [in] sensor auto exposure setting
*
*   Returns:
*      + WIS_SUCCESS on success
*      + WIS_FAILURE or ENCODER_INVALID_MODE_SELECTED on failure
*
*   Notes:
*       Currently only supports ICM 202B sensor
*
*****************************************************************************/
status_t
EncoderSetSensorAutoExposure(uint16 setting)
{
    switch(sensorType)
    {
        case SENSOR_TYPE_OV7648:
            return(ENCODER_INVALID_MODE_SELECTED);
            break;

        case SENSOR_TYPE_OV7640:
            return(ENCODER_INVALID_MODE_SELECTED);
            break;
            
        case SENSOR_TYPE_ICM202B:
            icm202SensorSetAutoExposure(setting);
            return(WIS_SUCCESS);
            break;
    }
    
    return(WIS_FAILURE);
}

/***WIS_API*******************************************************************
*
*   Procedure Name:  
*       status_t EncoderSetFps(sint32 fpsRequestedRate)
*
*   Description:
*       Set the encoder output frame rate to the newly requested rate, which is a function 
*        of the input frame rate.
*  
*   Arguments:
*       sint32 fpsRequestedRate - [in] the rate at which frames should appear to come
*                                              from the encoder.
*
*   Returns:
*       status_t - status of fps setting for encoder 
*      + WIS_SUCCESS(0) on success
*      + WIS_FAILURE(-1) on failure
*
*   Notes:
*
*****************************************************************************/
status_t
EncoderSetFps(sint32 fpsRequestedRate)
{
    /* this call can only be made in runtime mode */
    if (g_bRuntime == TRUE)
    {
        /* set the current frame rate based on the
	 * previously configured input frame rate
	 */
        ED_SendDriverMessage(ENCODER_SET_FPS_RUNTIME, fpsRequestedRate);
    }
    else
    {
        return(WIS_FAILURE);
    }

    return(WIS_SUCCESS);
}


/***WIS_API*******************************************************************
*
*   Procedure Name:  
*       status_t EncoderChangeBRC(sint32 changeDirection, sint32 newIQScale, 
*                sint32 newPQScale, sint32 newTargetBitrate, sint32 newPeakBitrate, 
*               sint32 newVbvBuffer, sint32 newConvergeSpeed, sint32 newLambda);
*
*
*   Description:
*       Change the bitrate control parameters and update the configuration on the encoder 
*       while it is still running.
*  
*   Arguments:
*
*       sint32 changeDirection - argument which describes which BRC mode we are currently in and 
*                                  which BRC mode we wish to choose.
*
*       sint32 newIQScale - If in VBR mode, set the quantizer for all I frames.  This is ignored 
*                            in CBR mode.
*
*       sint32 newPQScale - If in VBR mode, set the quantizer for all P frames.  This is ignored 
*                            in CBR mode.
*
*       sint32 newTargetBitrate - in CBR mode, choose the new target average bitrate in bps 
*
*       sint32 newPeakBitrate - in CBR mode, choose the new peak average bitrate in bps.  
*                                 This setting is only used when the VBV Buffer is non-zero.
*
*       sint32 newVbvBuffer - in CBR mode, this is the size of the buffer in which you keep your 
*                               encoded stream.  This setting is used by the CBR algorithm to determine 
*                               the urgency for lowering the bitrate to prevent an overflow.  If the VBV 
*                               buffer gets too close to the limit, 'duplication frames' may be inserted 
*                               into the stream.
*
*       sint32 newConvergenceSpeed - On a scale from 1 to 100, this is the rate at which firmware 
*                                             will attempt to converge on the requested target bitrate.  For 
*                                             example, with a setting of '100', the bitrate should converge on
*                                             the target bitrate within 30 frames.  In general, the faster you 
*                                             converge, the more the overall quality of the stream will degrade.
*
*       sint32 newLambda - On a scale from 1 to 100, Lambda is the probability that a duplication frame 
*                            will be inserted to obtain the requested  target bitrate and to stay below the
*                            peak bitrate.  In general, the complexity of the stream will directly effect the 
*                            chance that a duplication frame will need to be inserted.
*
*
*   Returns:
*
*        + ENCODER_SUCCESS - the bitrate change will be performed.
*        + ENCODER_BRC_INVALID_DIRECTION_CHANGE -Invalid argument for change direction
*        + ENCODER_BRC_INVALID_IQ - IQScale out of range (2 to 31)
*        + ENCODER_BRC_INVALID_PQ - PQScale out of range (2 to 31)
*        + ENCODER_BRC_INVALID_TARGET_BITRATE - target bitrate argument invalid
*        + ENCODER_BRC_INVALID_PEAK_BITRATE - peak bitrate argument invalid
*        + ENCODER_BRC_INVALID_CONVERGENCE_SPEED - convergence speed argument 
*                                                                                   valid (1 to 100)
*        + ENCODER_BRC_INVALID_LAMBDA - lambda argument valid (1 to 100)
*
*   Notes:
*       This may only be called at runtime.  A duplication frame is a very small frame that 
*       references the previous  frame.
*
*****************************************************************************/

status_t EncoderChangeBRC(sint32 changeDirection, sint32 newIQScale,
                          sint32 newPQScale, sint32 newTargetBitrate,
                          sint32 newPeakBitrate, sint32 newVbvBuffer,
                          sint32 newConvergenceSpeed, sint32 newLambda)
{
    brc_message_t *pBrcMessage;
    status_t retStatus;

    pBrcMessage = OSL_Malloc(sizeof(brc_message_t));

    pBrcMessage->changeDirection = changeDirection;
    pBrcMessage->newIQScale = newIQScale;
    pBrcMessage->newPQScale = newPQScale;
    pBrcMessage->newTargetBitrate = newTargetBitrate;
    pBrcMessage->newPeakBitrate = newPeakBitrate;
    pBrcMessage->newVbvBuffer= newVbvBuffer;
    pBrcMessage->newConvergenceSpeed = newConvergenceSpeed;
    pBrcMessage->newLambda = newLambda;

    /* this call can only be made in runtime mode */
    if (g_bRuntime == TRUE)
    {
        /* set the current frame rate based on the previously
	 * configured input frame rate
	 */
        retStatus = ED_SendDriverMessage(ENCODER_CHANGE_BRC_RUNTIME,
                     (uint32)pBrcMessage);
    }
    else
    {
        return(WIS_FAILURE);
    }

    return(retStatus);
}

/***WIS_API*******************************************************************
*
*   Procedure Name:  
*       status_t EncoderInitMD(void)
*
*   Description:
*       Initialize and enable the motion detection function.
*  
*   Arguments:
*
*       None
*
*   Returns:
*      + ENCODER_SUCCESS - the motion detection module has been initialized.
*      + ENCODER_FAILURE - the motion detection module could not be initialized.
*
*   Notes:
*       This must be called before EncoderStart(). The motion detection feature has the 
*       side effect of making MPEG1/2 CBR frame based instead of macroblock based.
*
*****************************************************************************/

status_t EncoderInitMD(void)
{
    status_t retStatus;

    retStatus = ED_MDInit();

    return(retStatus);
}

/***WIS_API*******************************************************************
*
*   Procedure Name:  
*       status_t EncoderSetMDThresholdsAndSensitivity(sint16 thresholds[][], uint8 *sensitivity);
*
*   Description:
*       Set the thresholds and sensitivity for motion detection during  runtime. This interface 
*       only works at runtime.
*  
*   Arguments:
*
*       uint16 arrs16MotionThresholds[MAX_REGIONS_OF_INTEREST][NUM_MOTION_TYPES] - properly formatted two dimensional array of SAD and motion 
*                                             vector thresholds where the first index is the region number 
*                                             and the second index is the threshold type (0 for MV and 1 for SAD)
*
*       uint16 *arru8MotionSensitivity - array of sensitivity values for each region. Sensitivity is the 
*                                           number of macroblocks that must exceed the threshold before 
*                                           motion is reported to the host.
*
*   Returns:
*
*      + ENCODER_SUCCESS - the motion detection status has been updated.
*      + ENCODER_FAILURE - the motion detection status was not updated due to invalid arguments.
*
*   Notes:
*       If you did not call EncoderInitMD() before EncoderStart(), this call will have no effect.
*
*****************************************************************************/

status_t EncoderSetMDThresholdsAndSensitivity(uint16 arrs16MotionThresholds[MAX_REGIONS_OF_INTEREST][NUM_MOTION_TYPES],
                                              uint16 *arru8MotionSensitivity)
{

    return(ED_SetMDThresholdsAndSensitivity(arrs16MotionThresholds,
                                            arru8MotionSensitivity,
                                            NULL));
}


/***WIS_API*******************************************************************
*
*   Procedure Name:  
*       status_t EncoderSetMDRegions(uint8 *arru8MotionCoordinates,
*                                    uint32 u32MaxXCoordinate,
*                                    uint32 u32MaxYCoordinate)
*
*   Description:
*       Set the region numbers for every macroblock to watch for motion.
*  
*   Arguments:
*
*       uint8 *arru8MotionCoordinates - two dimensional array of region numbers where each 
*                                             [x][y] location contains the region number for that macroblock.  
*                                             This argument MUST be exactly the the same number of 
*                                             macroblocks as the current picture.  If there is a size mismatch 
*                                             the results are undetermined.
*
*       uint32 u32MaxXCoordinate - The maximum X coordinate for the picture size. This 
*                                                 is really just used for error checking.
*
*       uint32 u32MaxYCoordinate - The maximum Y coordinate for the picture size. This is 
*                                                 used for error checking.
*
*   Returns:
*
*      + ENCODER_SUCCESS     - the macroblock map has been set in the device.
*      + ENCODER_FAILURE     - the macroblock map had invalid regions or there was a 
*                                           mismatch in the picture size.
*
*   Notes:
*       Be careful that this array is the same size as the picture (in macroblocks) and that the 
*       caller has initialized every location in this array to ensure that the map is correctly set. 
*
*****************************************************************************/

status_t EncoderSetMDRegions(uint8 *arru8MotionCoordinates,
                             uint32 u32MaxXCoordinate,
                             uint32 u32MaxYCoordinate)
{
    return(ED_SetMDRegions(arru8MotionCoordinates, u32MaxXCoordinate,
                           u32MaxYCoordinate, NULL));
}

/***WIS_API*******************************************************************
*
*   Procedure Name:  
*      status_t EncoderSetMDDelay(uint32 u32DelayInMilliseconds)
*
*   Description:
*    Set a delay for how long to wait before reporting that additional motion has occurred.
*  
*   Arguments:
*
*    uint32 u32DelayInMilliseconds - Delay, in milliseconds, before additional motion  is reported.
*
*   Returns:
*
*    + ENCODER_SUCCESS     - the delay has been set..
*    + ENCODER_FAILURE     - TBD
*
*   Notes:
*   The encoder driver knows how many frames per second, so it will use this value to 
*   calculate the number of frames to wait before invoking the user callback every time
*   motion occurs.
*
*****************************************************************************/

status_t EncoderSetMDDelay(uint32 u32DelayInMilliseconds)
{
    return(ED_SetMDDelay(u32DelayInMilliseconds));
}

/***WIS_API*******************************************************************
*
*   Procedure Name:  
*     status_t EncoderSetMDCallback(encoder_motion_callback_t *motionCallback,
*                                   void *vptrUserCallbackArgument)
*
*   Description:
*       Register a user callback for when motion has occurred and is to be reported to the application.
*  
*   Arguments:
*
*       encoder_motion_callback_t *motionCallback - function pointer of type 
*                                                                           encoder_motion_callback_t to be called 
*                                                                           when motion is to be reported.
*
*       void *vptrUserCallbackArgument - pointer to anything the user would like to have passed 
*                                                          into the callback function as an argument.
*
*   Returns:
*
*      + ENCODER_SUCCESS     - callback has been registered.
*      + ENCODER_FAILURE     - the user has exceed the maximum number of callbacks
*
*   Notes:
*
*****************************************************************************/

status_t EncoderSetMDCallback(encoder_motion_callback_t *motionCallback,
                              void *vptrUserCallbackArgument)
{
    return(ED_SetMDCallback(motionCallback, vptrUserCallbackArgument));
}

