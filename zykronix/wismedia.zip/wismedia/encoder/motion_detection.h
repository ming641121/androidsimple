/******************************************************************************
*
*   Copyright WIS Technologies (c) (2004)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       motion_detection.h
*
*   DESCRIPTION:
*       Motion Detection header file
*
*   NOTES:
*
*   $Id: motion_detection.h,v 1.4 2004/07/15 18:42:11 squ Exp $
*
******************************************************************************/

#ifndef MOTION_DETECTION_H
#define MOTION_DETECTION_H

#include "wis_types.h"
#include "pacgen.h"

#define ENCODER_THRESHOLD_MARKER        0x0041

#define ENCODER_MACROBLOCK_MAP_MARKER   0x0042

/* NOTE:  This structure is little-endian only */
typedef struct motion_threshold_package_s {
    uint16 u16MotionThresholdMarker;        /* actual value 0x0041 */
    uint16 u16SADThresholdValues[4];        /* Give the SAD thresholds in order of region0, region1, region2, region3 */
    uint16 u16Reserved1[3];
    uint16 u16MVThresholdValues[4];         /* Give the Motion Vector thresholds in order of region0, region1, region2, region3 */
    uint16 u16Reserved2[3];
    uint16 u8SensitivityValues[4];          /* Give the motion-detected macroblock sensitivity in order of region0, region1, region2, region3 */
    uint16 u16Reserved3[13];
} motion_threshold_package_t;

typedef struct motion_macroblock_map_package_s {
    uint16 u16MotionPackageMarker;          /* actual value 0x0042 */
    uint16 u16StartingMacroblockNumber;     /* macroblock number (must be divided by 8 (ie 0, 30, 60, 90, ..., 150 (if D1)) */
    uint16 u16MacroblockMap[30];            /* bits 0-1, 2-3, 4-5, ..., 14-15 represent a macroblock, in that order. */
} motion_macroblock_map_package_t;

#define PACKAGE_LEN_WORDS                       32
#define NUM_WORDS_PER_PACKAGE                   30
#define NUM_MACROBLOCKS_PER_PACKAGE             240
#define NUM_MACROBLOCKS_PER_WORD16              8
#define MAX_MACROBLOCK_MAP_PACKAGES             (MAX_NUM_MACROBLOCKS/NUM_MACROBLOCKS_PER_PACKAGE+1)

#endif /* MOTION_DETECTION_H */

