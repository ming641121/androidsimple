/******************************************************************************
*
*    Copyright WIS Technologies (c) (2003)
*    All Rights Reserved
*
*******************************************************************************
*
*    FILE: 
*        osd.h
*
*    DESCRIPTION:
*        1) Parse the OSD font library.
*        2) Define and Implement OSD APIs
*
*    AUTHOR:Xiaoli Xiong, Xiuli Guo
*
*    Modification: Sheng Qu
*	
*    $Id: osd.h,v 1.2 2004/06/21 12:57:10 squ Exp $
*
******************************************************************************/

#ifndef __OSD_H__
#define __OSD_H__

#include "struct.h"
#define OSD_STRING_LEN_MAX 95

#ifdef __cplusplus
extern "C" {
#endif

typedef struct tagOSD_STRING_t
{
	uint16 x;
	uint16 y;
        char String[OSD_STRING_LEN_MAX];
}OSD_STRING_t;
	
typedef struct tagOSD_FRAME_t
{
	OSD_STRING_t OSD_String[31];	
} OSD_FRAME_t;

typedef enum	
{ 
	OSD_NORMAL = 0,
	OSD_REFRESH,
}OSD_DISPLAY_MODE;

typedef enum
{
	OSD_ERROR_OK =0,
	OSD_ERROR_OUTOFMEMORY =-2,
	OSD_ERROR_FAIL =-1,
	OSD_ERROR_OPENFILE =-3,
	OSD_ERROR_INVALIDFONTFILE =-4,
}OSD_ERROR;

OSD_ERROR WriteOSD(uint16 x, uint16 y, char *pString);
OSD_ERROR InitOSD(int lVideoFrameWidth,int lVideoFrameHeight);
OSD_ERROR GetOSDFrame(int StringNum, void *pString);
OSD_ERROR ShowOSDFrame(OSD_DISPLAY_MODE mode);
OSD_ERROR CleanOSD(void);

#ifdef __cplusplus
}
#endif

#endif

/********************************* end of osd.h **************************/

