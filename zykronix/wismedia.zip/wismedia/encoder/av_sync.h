/******************************************************************************
*
*   Copyright WIS Technologies (c) (2004)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*
*   wis_encoder.c
*
*   DESCRIPTION:
*
*      This is the API (Application Programming Interface) for the WIS Encoder.
*      NOTE:  Only one instance of an encoder is allowed.
*
*   $Id: av_sync.h,v 1.1 2004/09/14 14:10:13 ywang Exp $
*
******************************************************************************/

#include "wis_types.h"
#include "encoder_driver.h"
#include "wis_encoder.h"
#include "wis_error.h"
#include "os.h"
#include "tasks.h"

#ifdef VXWORKS
#include <tasks.h>
#include <stdlib.h>
#endif

//void WatchStatistic();
void Sort(sint32 Data[], sint32 Size);
status_t WatchStatistic(void);
void AVSYNC_Task(void);
status_t AVSYNC_Start(sint32 priority);
status_t AVSYNC_Stop(void);
