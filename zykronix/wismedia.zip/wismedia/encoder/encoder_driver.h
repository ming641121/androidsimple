/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       encoder_driver.h
*
*   DESCRIPTION:
*       Encoder Driver header file (with API)
*
*   $Id: encoder_driver.h,v 1.27 2005/03/20 18:57:48 squ Exp $
*
******************************************************************************/
#ifndef ENCODER_DRIVER_H
#define ENCODER_DRIVER_H

#include "wis_types.h"
#include "wis_encoder.h"
#include "platform.h"
#include "wsdf.h"
#include "multimedia.h"
#include "struct.h"
#include "pacgen.h"
#include "motion_detection_api.h"
#include "brc.h"

/* prototypes section */
status_t ED_SetBitrateControl(uint32 targetBitrate, uint32 peakBitrate, uint32 maxFps, uint32 gopSize, uint32 videoBufferSize, uint32 constQ);
status_t ED_GetBitrateControl(uint32 *targetBitrate, uint32 *peakBitrate, uint32 *maxFps, uint32 *gopSize, uint32 *videoBufferSize, uint32 *constQ);
status_t ED_DeleteAFrame(void);
status_t ED_InsertAFrame(void);
void ED_SetInitialFixedSettings(void);
void ED_SetInitialVideoSettings(void);
status_t ED_Shutdown(void);
status_t ED_SetOsdStr(osdString_t userOsdStr);
status_t ED_SetSensorType(sint32 userSensorType, sint32 userInputSource, sint32 userTvStandard, sensorControl_t userSensorCtrl, sint32 userAudioCap);
status_t ED_DiagTest(void);
status_t ED_SetMode(encoderCapabilities_t *modeMask);
status_t ED_Init(bool_t bQuickResetFlag);

/* runtime prototypes */
void ED_SetFps(sint32 fpsInputRate, sint32 fpsRequestedRate);
void ED_UpdateBRCMem(APRIL *brc);
status_t ED_ChangeBRC(sint32 changeDirection, sint32 newIQScale,
                      sint32 newPQScale, sint32 newTargetBitrate,
                      sint32 newPeakBitrate, sint32 newVbvBuffer,
                      sint32 newConvergeSpeed, sint32 newLambda);

status_t  ED_fps_otf(sint32 new_fps);
status_t ED_ChangeResolution(int new_resolution);
status_t ED_QuickResetChip(void);
int get_brc_state(void);

#define ENCODER_BRC_INVALID_DIRECTION_CHANGE (-3)
#define ENCODER_BRC_INVALID_IQ               (-4)
#define ENCODER_BRC_INVALID_PQ               (-5)
#define ENCODER_BRC_INVALID_TARGET_BITRATE   (-6)
#define ENCODER_BRC_INVALID_PEAK_BITRATE     (-7)
#define ENCODER_BRC_INVALID_CONVERGENCE_SPEED (-8)
#define ENCODER_BRC_INVALID_LAMBDA           (-9)

#undef  DEBUG_REGS
/* #define  DEBUG_REGS  1 */

/* ENCODER register offsets */
#define ENCODER_PORT_INITIAL            0xFFEA
#define ENCODER_PORT_STREAM             0xFFE4
#define ENCODER_RETURN_DATA             0xFFEC
#define ENCODER_RETURN_VALUE            0xFFEE
#define ENCODER_INT_PARM                0xFFF6
#define ENCODER_INT_INDEX               0xFFF8
#define ENCODER_STATUS                  0xFFF4

#define ENCODER_STREAM_BUFFER_FULL_MASK           1


#define ENCODER_STATUS_STREAM_BUFFER_FULL_INTERRUPT         0x01
#define ENCODER_STATUS_INITIALIZATION_BUFFER_LOCKED_MASK    0x02 
#define ENCODER_STATUS_EXTERNAL_INTERRUPT_MASK              0x08
#define ENCODER_STATUS_INTERRUPT_IN_PROCESS_MASK            0x10

#define ENCODER_INT_VALUE                                   0x55AA
#define ENCODER_FIRMWARE_DOWNLOAD_CONFIRMATION              0x5A5A
/* return value from setting the motion detection thresholds at runtime */
#define ENCODER_THRESHOLD_RETURN                            0x0040
/* return value from setting the motion detection map at runtime */
#define ENCODER_MACROBLOCK_MAP_RETURN                       0x0040

/* miscellaneous driver defined messages: */
/* bit 31 means that it didn't come from the encoder itself */
/* bit 1 means that the stream buffer was full */
#define ENCODER_SHUTDOWN                                    0x80000002
#define ENCODER_CHANGE_RESOLUTION                           0x80000004
#define ENCODER_SET_FPS_RUNTIME                             0x80000006
#define ENCODER_CHANGE_BRC_RUNTIME                          0x80000008

/* if we get this signal, a read interrupt has been completed */
#define ENCODER_INITC1_COMPLETE                     0xa000
#define ENCODER_INT_RETURN_COMPLETE                 0xa000

#define ENCODER_WRITE_INTERRUPT_MASK                0x8000
#define ENCODER_READ_INTERRUPT_SIGNAL               0x0010
#define ENCODER_DROP_FRAME_SIGNAL                   0x0020
#define ENCODER_INSERT_FRAME_SIGNAL                 0x0021
#define ENCODER_FORCE_I_FRAME_SIGNAL                0x0040
#define ENCODER_FORCE_NEW_SEQUENCE_SIGNAL           0x0041
#define ENCODER_CHANGE_PFRAME_RATE_SIGNAL           0x0081
#define ENCODER_CHANGE_I_Q_SCALE_SIGNAL             0x0082
#define ENCODER_CHANGE_P_Q_SCALE_SIGNAL             0x0084
#define ENCODER_SET_FPS_SIGNAL                      0x0088
#define ENCODER_CBR_TO_VBR_1_SIGNAL                 0x0101
#define ENCODER_CBR_TO_VBR_2_SIGNAL                 0x0102
#define ENCODER_CBR_TO_CBR_1_SIGNAL                 0x0104
#define ENCODER_CBR_TO_CBR_2_SIGNAL                 0x0108
#define ENCODER_VBR_TO_CBR_SIGNAL                   0x0200

#if 0
/* BRC message for ENCODER_CHANGE_BRC_RUNTIME message */
typedef struct BRC_MESSAGE_S {

    sint32 changeDirection;
    sint32 newIQScale;
    sint32 newPQScale;
    sint32 newTargetBitrate;
    sint32 newPeakBitrate;
    sint32 newVbvBuffer;
    sint32 newConvergenceSpeed;
    sint32 newLambda;

} brc_message_t;

#endif

/* package values */
#define DOWNLOAD_TRY_NUMBER                         0x1000000
#define RESET_TRY_NUMBER                            0x1000000
#define ENCODER_MBIST                               0x0001

#define ENCODER_MBIST_RETURN_VALUE                  0x0A50
#define ENCODER_MBIST_RESULT1                       0x0000
#define ENCODER_MBIST_RESULT2                       0xFF7F
#define ENCODER_MBIST_RESULT3                       0x0000
#define ENCODER_MBIST_RESULT4                       0xFFFF
#define ENCODER_MBIST_RESULT5                       0x0000
#define ENCODER_MBIST_RESULT6                       0x0003

#define ENCODER_SELF_IO_CHECK                       0xBE22
#define ENCODER_SELF_IO_CHECK_RETURN_ODD            0xAA55
#define ENCODER_SELF_IO_CHECK_RETURN_EVEN           0x55AA

#define ENCODER_ADDR(offset)            \
            (ENCODER_BASE_ADDR + offset)
            
#define MAX_DUPLICATION_FRAME_SIZE              1650
/*
 * Todo: Read/Write HPI Register abstraction
 */

    #define ENCODER_READ_REG16(offset)      \
    *(volatile uint16 *) (ENCODER_BASE_ADDR + offset)

    #define ENCODER_WRITE_REG16(offset, dataToWrite)            \
    *(volatile uint16 *) (ENCODER_BASE_ADDR + offset) = dataToWrite

#define ENCODER_STREAM_BUFFER_FULL_EVENT        1
#define ENCODER_RESET_COMPLETE_EVENT            4

#define ENCODER_ISSUE_RESET                     \
            ENCODER_WRITE_REG16(ENCODER_INT_INDEX, 1)

#define ENCODER_EVENT_MASK                      (ENCODER_STREAM_BUFFER_FULL_EVENT   \
                                                 | ENCODER_RESET_COMPLETE_EVENT)

#if defined(_BIG_ENDIAN_)
#define LITTLE_ENDIAN_TO_CPU_ENDIAN16(dest, source)             \
          dest = ((source << 8) | (source >> 8))
#else /* it's little endian */
#define LITTLE_ENDIAN_TO_CPU_ENDIAN16(dest, source)         \
          dest = source
#endif

/* Encoder Queue definitions */
typedef struct
{

    uint32 messageType;
    uint32 messageData;

} encoderDriverQueueElement_t;


#define PACKAGE_LEN_BYTES           64
#define PACKAGE_LEN_WORDS           32

/* give a two dimensional array where the second index is PACKAGE_LEN_WORDS */
#define ENCODER_SEND_PACKAGE(packageArray, index)       \
        while (ENCODER_READ_REG16(ENCODER_STATUS) & ENCODER_STATUS_INITIALIZATION_BUFFER_LOCKED_MASK) { ; } \
        for (index=0; index < PACKAGE_LEN_WORDS; index++)   \
		ENCODER_WRITE_REG16(ENCODER_PORT_INITIAL, packageArray[index]);



extern sint32 g_encoderBufferSize;
/* the buffer size is variable to accomodate low bitrates, so use a global */
/* which is configured at initialization time */
#define ENCODER_PACKET_LENGTH_WORDS g_encoderBufferSize
#define ENCODER_PACKET_LENGTH_BYTES (ENCODER_PACKET_LENGTH_WORDS*2)

void sensorInit(sint32 mode, sint32 sensorType, sensorControl_t sensorCtrl);

#ifndef NO_SENSOR_INIT
#define EncoderInitializeSensor(mode, sensorType, sensorCtrl)       sensorInit(mode, sensorType, sensorCtrl)
#else
#define EncoderInitializeSensor(mode, sensorType, sensorCtrl)
#endif

/* Encoder Signals */

#define ENCODER_SIGNAL(index, parm)         \
            while (ENCODER_READ_REG16(ENCODER_STATUS) & ENCODER_STATUS_INTERRUPT_IN_PROCESS_MASK) { ; } \
            ENCODER_WRITE_REG16(ENCODER_INT_PARM, parm);        \
            ENCODER_WRITE_REG16(ENCODER_INT_INDEX, index)

/* issue a write to the encoder's internal bus */
#define ENCODER_WRITE_INTERRUPT(addr, data) ENCODER_SIGNAL((addr|ENCODER_WRITE_INTERRUPT_MASK), data)

/* issue a read from the encoder's internal bus */
#define ENCODER_READ_INTERRUPT(addr)        ENCODER_SIGNAL(ENCODER_READ_INTERRUPT_SIGNAL, addr)

/* drop the last VIP frame in this GOP */
#define ENCODER_DROP_FRAME_INTERRUPT        ENCODER_SIGNAL(ENCODER_DROP_FRAME_SIGNAL, 0) 

/* insert a duplicate P Frame at the end of this GOP */
#define ENCODER_INSERT_FRAME_INTERRUPT      ENCODER_SIGNAL(ENCODER_INSERT_FRAME_SIGNAL, 0) 

/* change the current frames per second by telling the encoder to drop VIP frames */
#define ENCODER_SET_FPS(numFps)             ENCODER_SIGNAL(ENCODER_SET_FPS_SIGNAL, numFps)

/* change the current frames per second by telling the encoder to drop VIP frames */
#define ENCODER_FORCE_I_FRAME               ENCODER_SIGNAL(ENCODER_FORCE_I_FRAME_SIGNAL)

/* force the next I frame to contain the sequence header */
#define ENCODER_FORCE_NEW_SEQUENCE          ENCODER_SIGNAL(ENCODER_FORCE_NEW_SEQUENCE_SIGNAL)

/* change the GOP size to a different number of P Frame per GOP */
#define ENCODER_CHANGE_PFRAME_RATE(PFrameRate) ENCODER_SIGNAL(ENCODER_CHANGE_PFRAME_RATE_SIGNAL, PFrameRate)

/* Change the quantizer for all I frames to this value when in this BRC mode (VBR) */
#define ENCODER_CHANGE_I_Q_SCALE(IQScale)   ENCODER_SIGNAL(ENCODER_CHANGE_I_Q_SCALE_SIGNAL, IQScale)

/* Change the quantizer for all I frames to this value when in this BRC mode (VBR) */
#define ENCODER_CHANGE_P_Q_SCALE(PQScale)   ENCODER_SIGNAL(ENCODER_CHANGE_P_Q_SCALE_SIGNAL, PQScale)

/* changing the bitrate control settings during runtime support */
#define ENCODER_BRC_CBR_TO_VBR_1(IQScale)   ENCODER_SIGNAL(ENCODER_CBR_TO_VBR_1_SIGNAL, IQScale)
#define ENCODER_BRC_CBR_TO_VBR_2(PQScale)   ENCODER_SIGNAL(ENCODER_CBR_TO_VBR_2_SIGNAL, PQScale)
#define ENCODER_BRC_CBR_TO_CBR_1(targetBrc) ENCODER_SIGNAL(ENCODER_CBR_TO_CBR_1_SIGNAL, targetBrc)
#define ENCODER_BRC_CBR_TO_CBR_2(targetBrc) ENCODER_SIGNAL(ENCODER_CBR_TO_CBR_2_SIGNAL, targetBrc)
#define ENCODER_BRC_VBR_TO_CBR              ENCODER_SIGNAL(ENCODER_VBR_TO_CBR_SIGNAL, 0)

#define WriteInterrupt(addr, data)          ENCODER_WRITE_INTERRUPT(addr, data)
#define ReadInterrupt(addr)                 ENCODER_READ_INTERRUPT(addr)

/* sensor modes */
#define QQVGA_MODE               0 /* 160x112 */
#define QCIF_MODE                1 /* 176x144 */
#define QVGA_MODE                2 /* 320x240 */
#define CIF_MODE                 3 /* 352x288 */
#define VGA_MODE                 4 /* 640x480 */
#define D1_MODE                  5 /* 720x480 */
#define FULL_D1_MODE             6 /* 720x576 */
#define FOUR_CIF_MODE            7 /* 704x576 */
#define TWO_CIF_MODE             8 /* 704x288 */
#define SIF_MODE                 9 /* 352x240 */
#define TWO_SIF_MODE            10 /* 704x240 */
#define FOUR_SIF_MODE           11 /* 704x480 */
#define QSIF_MODE               12 /* 176x112 */

#define MAX_ENCODER_INITIALIZATION_PACKAGE_SIZE_PACKAGES    (2560)

#define CPU_ENDIAN_TO_ENCODER_ENDIAN16(dest, source)     \
          dest = source

extern sensorControl_t sensorCtrl;
extern osdString_t osdStr;
extern TVIDEOCFGFIX encoderFixedSettings;
extern TCFGVIDEOEX encoderVariableSettings;
extern sint32 g_inputFrameRate;
extern bool_t g_bRuntime;
extern encoderCapabilities_t g_currentEncoderMode;
extern uint16  initializationPackage[MAX_ENCODER_INITIALIZATION_PACKAGE_SIZE_PACKAGES][PACKAGE_LEN_WORDS];
extern sint32  initializationPackageSize;
extern void ED_InterruptServiceRoutine(void *);
extern sint32 icm202SensorSetXXX(UINT8 regAddr, UINT16 setting);
extern sint32 ov7648SensorSetXXX(UINT8 regAddr, UINT16 setting);
extern SINT32 icm202SensorSetAutoExposure(UINT16 aeSetting);
extern status_t ED_SendDriverMessage(uint32 driverMessage, uint32 messageData);


status_t fps_otf(int new_fps);
status_t brc_otf( brc_message_t brcMessage);
status_t resolution_otf(int new_resolution);
#if 0
#define STATE_CBR                                       0
#define STATE_VBR                                       1
#endif

#endif /* ENCODER_DRIVER_H */

