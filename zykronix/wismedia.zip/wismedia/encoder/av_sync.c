/******************************************************************************
*
*   Copyright WIS Technologies (c) (2004)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*
*   av_sync.c
*
*   DESCRIPTION:
*
*      This is the API (Application Programming Interface) for av sync.
*      NOTE:  Only one instance  is allowed.
*
*   $Id: av_sync.c, 2004/06/22  xguo
*
******************************************************************************/

#include "wis_types.h"
#include "encoder_driver.h"
#include "wis_encoder.h"
#include "wis_error.h"
#include "os.h"
#include "tasks.h"
#include "struct.h"
#include "av_sync.h"
#include "wis_error.h"

#ifdef VXWORKS
#include <tasks.h>
#include <stdlib.h>
#endif

extern osl_thread_t AVSyncTaskId;
UINT32 AVSyncDone = 0;
int	   AVOffset[128];
int	   InitAVOffset;
UINT32 AVSyncCorrectionTime = 30;
int AVSyncCorrectionDelayTime = 100;//70;
UINT32 TimerCount=0;
UINT32 VideoFrameRate;
extern sint32 avsync_audio_frame; 
extern int AudioFrameSize;
extern sint32 __n_encoder_frames_total;
extern TVIDEOCFGFIX encoderFixedSettings;
extern sint32 debugLevel;
extern int WriteCBusRegFW(int write_num, uint16 *addr_data);

status_t AVSYNC_Stop()
{
    if (AVSyncTaskId == 0) {
        return FAILURE;
    }

    AVSyncTaskId = 0;
    AVSyncDone=1;

    return ENCODER_SUCCESS;
}
 
void AVSYNC_Task(void)
{
	AVSyncDone = 0;
	TimerCount = 0;

	VideoFrameRate=encoderVariableSettings.fpscfg.frame_rate;
	printk(" video frame rate: %d, audio sampling rate=%d\n",
	       VideoFrameRate,encoderFixedSettings.audiocfg.reserved);

	while(!AVSyncDone)
	{
	  osl_msleep (1000);
	  WatchStatistic();
	}
}

status_t WatchStatistic()
{
	SINT32 i,temp;
        SINT32 MedValue;

	UINT32 temp1,temp2,temp3,AudioTime,
	    VideoTime,SampleSizeTimesTwoChannels;
	SampleSizeTimesTwoChannels = 
	    (encoderFixedSettings.audiocfg.adpcm_enable==1)?1:4;

	if(VideoFrameRate  != 0)
	{
		temp1 = __n_encoder_frames_total/VideoFrameRate;
		temp2 = __n_encoder_frames_total%VideoFrameRate;
		temp3=(temp2*1000)%VideoFrameRate;
		VideoTime = temp1 *1000*1000 + (temp2*1000/VideoFrameRate)*1000
				+(temp3*1000)/VideoFrameRate;
	}
 	
	if(encoderFixedSettings.audiocfg.reserved != 0)
	{
		temp1 = (encoderFixedSettings.audiocfg.reserved*SampleSizeTimesTwoChannels)/1000;
		temp2 = avsync_audio_frame/temp1;

 		temp3 =avsync_audio_frame% temp1;
                AudioTime = temp2*AudioFrameSize+(temp3*AudioFrameSize)/temp1;
	}

	if ((TimerCount%60)==0)
	{
             printk("\nAudioTime: %d VideoTime: %d\n",AudioTime,VideoTime);
	}
	MedValue = MediumValue(AVOffset, AVSyncCorrectionTime);
	
	if(TimerCount == 0)
	{
	    for(i=0; i< AVSyncCorrectionTime; i++)
		AVOffset[i] = VideoTime - AudioTime;
	}
	else
	{
	    for( i = 0; i<AVSyncCorrectionTime-1; i++)
		AVOffset[i] = AVOffset[i+1];
	    AVOffset[AVSyncCorrectionTime-1] = VideoTime - AudioTime;
	}

	
	 MedValue = MediumValue(AVOffset, AVSyncCorrectionTime);

	if(TimerCount == AVSyncCorrectionTime)
	{
		InitAVOffset = MedValue;

	}
	else if( (TimerCount%(AVSyncCorrectionTime)) == 0 )		
	{
		int Offset1 = MedValue;// - InitAVOffset;

		printk("AV Sync: audio medium delay %d(ms),time %d:%d:%d\n",
			Offset1, 
		       TimerCount/3600,
		       (TimerCount%3600)/60,
		       (TimerCount%3600)%60);

		/* 
		 * if A/V offset is larger than the setting threshold, 
		 * do adjustment
		 */
		if((Offset1 >= AVSyncCorrectionDelayTime) ||
		   (Offset1 < ( 0 - AVSyncCorrectionDelayTime ) ))
		{
		    temp = Offset1*encoderFixedSettings.audiocfg.reserved/1000;
		    if (Offset1 <0)
		    {
			Offset1= -Offset1; 
			temp = -(Offset1 * 
				 encoderFixedSettings.audiocfg.reserved/1000);
		    }
		    NotifyAVOffset(temp);			
		}
	}

	TimerCount ++;

    return SUCCESS;
}

sint32 MediumValue(sint32 Data[], int Size)
{
	SINT32 Data1[128];
	int i;
	int Sum=0;

	if(Size>128)
		return 0;

	for(i=0;i<Size;i++)
		Sum += Data[i];

	return Sum/Size;

}

/*
 * offset - difference between audio and video time (in millis).
 */
void 
NotifyAVOffset( int Offset)
{
	if(Offset == 0)
		return;


	printk("NotifyAVOffset : %d\n", Offset);
	ENCODER_DROP_FRAME_INTERRUPT;
	
	/*send the drop or insert video singal to FW*/
	ENCODER_SIGNAL( 0x0020, Offset&0xffff );

	/*WriteInterrupt*/
	ENCODER_SIGNAL(  0x0021, (Offset>>16)&0xffff );
}
