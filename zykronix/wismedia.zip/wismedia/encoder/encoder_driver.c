/******************************************************************************
*
*   Copyright WIS Technologies (c) (2004)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       encoder_driver.c
*
*   DESCRIPTION:
*   This is the driver for the Go7007SB Video Encoder device. ED means
*   Encoder Driver.
*
*  AUTHOR:
*   Daniel Meyer
*
*   $Id: encoder_driver.c,v 1.64 2005/05/11 20:02:52 txiang Exp $ 
*
******************************************************************************/

#include <linux/slab.h>
#include <asm/system.h>
#include "wis_types.h"
#include "wis_error.h"
#include "os.h"
#include "tasks.h"
#include "encoder_driver.h"
#include "motion_detection_api.h"
#include "decoder_driver.h"
#include "struct.h"
#include "wis_encoder.h"
#include "queue_api.h"
#include "sal_api.h"
#include "dma_api.h"

#include "go7007fw.c"

 
/* since the encoder must be initialized, that is handled here */
bool_t g_bAudioHardwareInitialized = FALSE;

#define FRAME_HEADER_LEN    4
#define MB_MAP_LEN          208           /* length in bytes of MB map */ 

#define FRAME_SYNC_BYTE0        0x00
#define FRAME_SYNC_BYTE1        0x00
#define MPEG_FRAME_SYNC_BYTE2   0x01
#define H263_FRAME_SYNC_BYTE2   0x80      /* don't care for bits 22-32 */
#define MPEG12_SEQUENCE_SYNC_BYTE3  0xB3
#define MPEG4_FRAME_SYNC_BYTE3 0xB6
#define MPEG4_SEQUENCE_SYNC_BYTE3  0xB0
#define MPEG2_FRAME_SYNC_BYTE3  0x00
#define H263_FRAME_SYNC_BYTE3   0x00      /* don't care for bits 22-32 */
#define JPEG_FRAME_SYNC_BYTE0   0xFF
#define JPEG_FRAME_SYNC_BYTE1   0xD8
#define MB_MAP_SYNC_BYTE3       0xF8
#define MB_MAP_ENB               1



#define H263_FRAME_SYNC_BYTE2_MASK 0xFC   /* don't care for bits 22-32 */


#define MPEG2_STREAM_SYNC_WORD_UPPER    0x0000
#define MPEG2_STREAM_SYNC_WORD_LOWER    0x01B3

#define MPEG4_FRAME_SYNC_WORD_UPPER     0x0000
#define MPEG4_FRAME_SYNC_WORD_LOWER     0x01B6

extern sint32 encoderMode;
sint32 encoderDone = 0;
sint32 buffersReceived=0; /* for debug prints */
sint32 md_ips = 0;
char mb_map_present=0;

bool_t bDecoderIsPrimed=FALSE;  /* only initialize the decoder ONCE */
uint32 g_encoderDataValue=0;
uint32 g_encoderReturnValue=0;
brc_message_t  brc_msg;
/* qualified by debugLevel being greater than DEBUG_LEVEL_STATISTICS */
#undef  TERMINAL_LOGGING
#define TERMINAL_LOGGING

/* Additional info to go along with the frame (MD map, etc) */
wis_frame_info_t *pFrameInfo;

/*
 * When FALSE, we have not reset the chip yet.  When TRUE, reset has
 * complete
 */
bool_t boEncoderReset;

int encoderDriverQueue;

#define ENCODER_DRIVER_QUEUE_SIZE       60  /* 2 seconds worth */

#undef ENCODER_DMA_ENABLED
/* #define  ENCODER_DMA_ENABLED  */


#ifdef ENCODER_DMA_ENABLED
#else
    #define ENCODER_GET_STREAM_WORD(index)          \
                ENCODER_READ_REG16(ENCODER_PORT_STREAM)
#endif


/* Callback support */
/* XXX: Add mutexes */
extern encoder_handler_t   callbackHandlers[];
extern sint32 __n_handlers;
sint32 __n_encoder_frames_total; 
sint32 __n_md_ints_total;

encoder_callback_t *encoderFrameCallback;
void *encoderFrameCallbackUser;

sint32 debugLevel = 0;

TCFGSYSTEM      syscfg;     // configuration for system setting

sint32 printFlag = FALSE;


extern sint32    sensorMode;
extern sint32    sensorType;

uint16  initializationPackage[MAX_ENCODER_INITIALIZATION_PACKAGE_SIZE_PACKAGES][PACKAGE_LEN_WORDS];
sint32  initializationPackageSize;

#include "init_buffer.c"

#include "wsdf.h"
#include "multimedia.h"
#include "platform.h"
#ifdef VXWORKS
#include "stdLib.h"
#endif
#include "pacgen.h"
#include "osd.h"

#define MAX_ERROR_STRING_SIZE   160

/******************************************************************************
*
*   PROCEDURE:  
*       status_t ED_SendDriverMessage(uint32 driverMessage, uint32 messageData)
*
*   DESCRIPTION:
*       This is a generic interface which enables any application to request
*   that the encoder driver task perform work on its behalf.
*  
*   ARGUMENTS:
*
*       driverMessage - a defined driver message (in encoder_driver.h).
*       messageData - this is message dependent.
*
*   RETURNS:
*
*    ENCODER_SUCCESS or ENCODER_FAILURE
*
*   NOTES:
*
******************************************************************************/

status_t ED_SendDriverMessage(uint32 driverMessage, uint32 messageData)
{

    encoderDriverQueueElement_t element;

    element.messageType = driverMessage;
    element.messageData = messageData;

    OSL_QPut(encoderDriverQueue, (sint32 *)&element,
         sizeof(encoderDriverQueueElement_t), OS_WAIT_FOREVER);

    return(ENCODER_SUCCESS);

}

int bEncoderDmaCallbackDone = TRUE;

/******************************************************************************
*
*   PROCEDURE:  
*       ED_SelfIoCheck(void)
*
*   DESCRIPTION:
*       Perform the Encoder Self IO check diagnostic.
*  
*   ARGUMENTS:
*
*    NONE
*
*   RETURNS:
*
*    ENCODER_SUCCESS or ENCODER_FAILURE
*
*   NOTES:
*   THIS TEST WILL ALWAYS FAIL ON GO7007SB BECAUSE THE SDRAM CONTROLLER WAS
*   NOT INITIALIZED IN THE BOOTROM.  This test will actually pass if you start
*   encoding first, but this isn't useful as a diagnostic tool, only as a debug
*   tool.
*
******************************************************************************/

status_t ED_SelfIoCheck(void)
{
    sint32 index;
    status_t returnStatus = ENCODER_SUCCESS;
    uint16 streamData;
    uint16 bootDPackage[32];
    uint16 testResult[64];

    /* configure the HPI bus for our device */
    board_bus_timing_set (ENCODER_BUS_INIT_MODE);
    
    /* reset the chip */
    ENCODER_ISSUE_RESET;

    /* wait for the chip to come out of reset */
    while (ENCODER_READ_REG16(ENCODER_RETURN_VALUE) != ENCODER_INT_VALUE)
    {
        osl_msleep (1);
    }

    bootDPackage[0] = 0xdead;               /* any value will work */
    bootDPackage[1] = ENCODER_SELF_IO_CHECK;

    ENCODER_SEND_PACKAGE(bootDPackage, index);

    /* poll for the interrupt */
    while (!(ENCODER_READ_REG16(ENCODER_STATUS) & ENCODER_STATUS_STREAM_BUFFER_FULL_INTERRUPT))
    {
        osl_msleep (1);
    }

    /* wait for the test to complete */
    if (!(ENCODER_READ_REG16(ENCODER_RETURN_VALUE) & ENCODER_STREAM_BUFFER_FULL_MASK))
    {
        returnStatus = ENCODER_FAILURE;
    }

    /* read the results from the buffer and compare them with the expected values */
    for (index = 0; index < 32; index += 2)
    {
        streamData = ENCODER_READ_REG16(ENCODER_PORT_STREAM);
        LITTLE_ENDIAN_TO_CPU_ENDIAN16(testResult[index], streamData);
        streamData = ENCODER_READ_REG16(ENCODER_PORT_STREAM);
        LITTLE_ENDIAN_TO_CPU_ENDIAN16(testResult[index+1], streamData);

        if ( (testResult[index] != ENCODER_SELF_IO_CHECK_RETURN_EVEN)
             || (testResult[index+1] != ENCODER_SELF_IO_CHECK_RETURN_ODD) )
        {
            returnStatus = ENCODER_FAILURE;
        }
    }

    /* the current state of the chip is reset,
     * so no additional reset is required
     */

    return(returnStatus);
}


/******************************************************************************
*
*   PROCEDURE:  
*       ED_MBIST(void)
*
*   DESCRIPTION:
*       Perform the Encoder Memory BIST.
*  
*   ARGUMENTS:
*
*    NONE
*
*   RETURNS:
*
*    ENCODER_SUCCESS or ENCODER_FAILURE
*
******************************************************************************/

status_t ED_MBIST(void)
{
    uint16 bootCPackage[32];
    status_t returnStatus = ENCODER_SUCCESS;
    sint32  index;

    /* configure the HPI bus for our device */
    board_bus_timing_set (ENCODER_BUS_INIT_MODE);
    
    /* reset the chip */
    ENCODER_ISSUE_RESET;
    
    /* sleep for 100 ms after the reset before polling */
    osl_msleep (100);

    /* wait for the chip to come out of reset */
    while (ENCODER_READ_REG16(ENCODER_RETURN_VALUE) != ENCODER_INT_VALUE)
    {
        osl_msleep (1);
    }

    bootCPackage[0] = 0x0000;
    bootCPackage[1] = ENCODER_MBIST;

    ENCODER_SEND_PACKAGE(bootCPackage, index);

    /* poll for the interrupt */
    while (!(ENCODER_READ_REG16(ENCODER_STATUS) & ENCODER_STATUS_EXTERNAL_INTERRUPT_MASK))
    {
        osl_msleep (1);
    }

    /* wait for the test to complete */
    if (ENCODER_READ_REG16(ENCODER_RETURN_DATA) != ENCODER_MBIST_RESULT1)
        return(ENCODER_FAILURE);
    if (ENCODER_READ_REG16(ENCODER_RETURN_VALUE) != ENCODER_MBIST_RETURN_VALUE)
        return(ENCODER_FAILURE);

    /* poll for the interrupt */
    while (!(ENCODER_READ_REG16(ENCODER_STATUS) & ENCODER_STATUS_EXTERNAL_INTERRUPT_MASK))
    {
        osl_msleep (1);
    }

    /* wait for the test to complete */
    if (ENCODER_READ_REG16(ENCODER_RETURN_DATA) != ENCODER_MBIST_RESULT2)
        return(ENCODER_FAILURE);
    if (ENCODER_READ_REG16(ENCODER_RETURN_VALUE) != ENCODER_MBIST_RETURN_VALUE)
        return(ENCODER_FAILURE);

    /* poll for the interrupt */
    while (!(ENCODER_READ_REG16(ENCODER_STATUS) & ENCODER_STATUS_EXTERNAL_INTERRUPT_MASK))
    {
        osl_msleep (1);
    }

    /* wait for the test to complete */
    if (ENCODER_READ_REG16(ENCODER_RETURN_DATA) != ENCODER_MBIST_RESULT3)
        return(ENCODER_FAILURE);
    if (ENCODER_READ_REG16(ENCODER_RETURN_VALUE) != ENCODER_MBIST_RETURN_VALUE)
        return(ENCODER_FAILURE);

    /* poll for the interrupt */
    while (!(ENCODER_READ_REG16(ENCODER_STATUS) & ENCODER_STATUS_EXTERNAL_INTERRUPT_MASK))
    {
        osl_msleep (1);
    }

    /* wait for the test to complete */
    if (ENCODER_READ_REG16(ENCODER_RETURN_DATA) != ENCODER_MBIST_RESULT4)
        return(ENCODER_FAILURE);
    if (ENCODER_READ_REG16(ENCODER_RETURN_VALUE) != ENCODER_MBIST_RETURN_VALUE)
        return(ENCODER_FAILURE);

    /* poll for the interrupt */
    while (!(ENCODER_READ_REG16(ENCODER_STATUS) & ENCODER_STATUS_EXTERNAL_INTERRUPT_MASK))
    {
        osl_msleep (1);
    }

    /* wait for the test to complete */
    if (ENCODER_READ_REG16(ENCODER_RETURN_DATA) != ENCODER_MBIST_RESULT5)
        return(ENCODER_FAILURE);
    if (ENCODER_READ_REG16(ENCODER_RETURN_VALUE) != ENCODER_MBIST_RETURN_VALUE)
        return(ENCODER_FAILURE);

    /* poll for the interrupt */
    while (!(ENCODER_READ_REG16(ENCODER_STATUS) & ENCODER_STATUS_EXTERNAL_INTERRUPT_MASK))
    {
        osl_msleep (1);
    }

    /* wait for the test to complete */
    if (ENCODER_READ_REG16(ENCODER_RETURN_DATA) != ENCODER_MBIST_RESULT6)
        return(ENCODER_FAILURE);
    if (ENCODER_READ_REG16(ENCODER_RETURN_VALUE) != ENCODER_MBIST_RETURN_VALUE)
        return(ENCODER_FAILURE);

    /* the current state of the chip is unknown.
     * A hardware reset is required
     * so reset the chip
     */
    return(returnStatus);
}

/******************************************************************************
*
*   PROCEDURE:  
*       ED_InitPackage(uint8 *initializationPackage, sint32 *initPackageSize)
*
*   DESCRIPTION:
*       Generate the Encoder's initialization package based on the
*           current configuration settings.
*  
*   ARGUMENTS:
*
*    uint8 *initializationPackage - pointer to the buffer where
*                                  the initialization package should go
*        sint32 *initPackageSize - pointer to the memory location
*                                  containing the size of the init pack
*
*   RETURNS:
*
*    return information from generating the initialization package
*
******************************************************************************/

sint8    errorInfo[MAX_ERROR_STRING_SIZE];

status_t ED_InitPackage(uint8 *initializationPackage, sint32 *initPackageSize,
                        bool_t bQuickResetFlag)
{
    status_t initPackStatus;
    uint8    *iniBuffer;
    sint32   bufLen;
    uint8    *pu8DuplicationFrame;
    /* set to the start of the initialization buffer */
    iniBuffer = initializationBuffer;
    bufLen = initializationBufferSizeDwords*sizeof(sint32);

    pu8DuplicationFrame = osl_alloc(MAX_DUPLICATION_FRAME_SIZE,"dupframe");
    
    /* the buffer size may be modified when the bitrate is set, so */
    /* calculate the hardware buffer setting to ensure that they match */
    encoderFixedSettings.elsecfg.HPIBufferCapacity = ((g_encoderBufferSize/64)-1) | 0x20;

    initPackStatus = gen_init_packages_7007SB(iniBuffer, bufLen,
					      &encoderVariableSettings,
					      &encoderFixedSettings,
					      errorInfo,
					      initializationPackage,
					      initPackageSize,
					      NULL, 0, /* no OSD font */
					      pu8DuplicationFrame, bQuickResetFlag);
    
    osl_free(pu8DuplicationFrame);

    if (initPackStatus == 0)
        return(initPackStatus);
    else
    {
        printf("EncoderPackageFailure %s\n", errorInfo);

        return(initPackStatus);
    }
}

status_t ED_DiagTest(void)
{
    return(ED_MBIST());
}



status_t fps_otf(int new_fps)
{
    status_t returnValue;
    encoderDriverQueueElement_t element;
    element.messageType = ENCODER_SET_FPS_RUNTIME;
    element.messageData = new_fps;

    returnValue=OSL_QPut(encoderDriverQueue, (sint32 *)&element,
			 sizeof(encoderDriverQueueElement_t), OS_NO_WAIT);

    return returnValue;
}

status_t brc_otf( brc_message_t brcMessage)
{
    status_t returnValue;
    encoderDriverQueueElement_t element;
    memcpy(&brc_msg,&brcMessage,sizeof(brc_message_t));
    
    element.messageType = ENCODER_CHANGE_BRC_RUNTIME;
    (brc_message_t *)element.messageData=&brc_msg;

   returnValue=OSL_QPut(encoderDriverQueue, (sint32 *)&element,
			sizeof(encoderDriverQueueElement_t), OS_NO_WAIT);
    return returnValue;
}


status_t resolution_otf(int new_resolution)
{
    status_t returnValue;
   
    encoderDriverQueueElement_t element;
    element.messageType = ENCODER_CHANGE_RESOLUTION;
    element.messageData=new_resolution;  

    /* fix bug #1498 */
    if ((encoderMode == ENCODER_MODE_H263) && 
        (new_resolution != ENCODER_MODE_352_X_288 && new_resolution != ENCODER_MODE_176_X_144)) {
        printk("H263 unsupport resolution %s\n", 
            (new_resolution==ENCODER_MODE_720_X_480) ? "720x480" : 
             ((new_resolution==ENCODER_MODE_640_X_480) ? "640x480" : 
              ((new_resolution==ENCODER_MODE_320_X_240) ? "320x240" : "160x112")));
        return 0;        
    }
    /* fix bug #1498 end */

    printk("About to OSL_QPut\n");
    
    returnValue=OSL_QPut(encoderDriverQueue, (sint32 *)&element,
			 sizeof(encoderDriverQueueElement_t), OS_NO_WAIT);
    printk("Ok\n");
    return returnValue;
}


status_t ED_Shutdown(void)
{
    status_t returnValue = ENCODER_SUCCESS;
    encoderDriverQueueElement_t element;

    printf("Encoder Shutdown \n");
    /* if we shutdown the system,the audio hardware is no longer initialized */
    g_bAudioHardwareInitialized = FALSE;
    element.messageType = ENCODER_SHUTDOWN;

    OSL_QPut(encoderDriverQueue, (sint32 *)&element,
         sizeof(encoderDriverQueueElement_t), OS_NO_WAIT);

    return returnValue;
}

status_t EncoderResetHW(void)
{
    ENCODER_ISSUE_RESET;
    return (ENCODER_SUCCESS);
}

status_t ED_DeleteAFrame(void)
{
    ENCODER_DROP_FRAME_INTERRUPT;
    return(ENCODER_SUCCESS);
}

status_t ED_InsertAFrame(void)
{
    ENCODER_INSERT_FRAME_INTERRUPT;
    return(ENCODER_SUCCESS);
}


/******************************************************************************
*
*   PROCEDURE:  
*       ED_Init(void)
*
*   DESCRIPTION:
*       Initialize the audio device and driver
*  
*   ARGUMENTS:
*
*     bQuickResetFlag - if TRUE, the initial package will generate a 'fast'
*                       reset package.
*
*   RETURNS:
*
*    NONE
*
******************************************************************************/

/* we make these globals to ensure that we will always have room for the */
/* init package when the driver is called */

sint32  frameSignal = 0;

status_t ED_Init(bool_t bQuickResetFlag)
{
    uint32   index;
    uint32   packageIndex;
    uint32   downloadWaitCycles=0;
    OSD_STRING_t osd[1] = {1, 1, ""};
    frameSignal = 0;

    /* we have come out of reset, so download the firmware */

    /* prep the device for firmware download */
    ENCODER_SEND_PACKAGE(bootBPackage, index);

    /* download the firmware */
    for (packageIndex = 0; packageIndex < numberOfBootB1Packages; packageIndex++)
    {
        ENCODER_SEND_PACKAGE(bootB1Package[packageIndex], index);
    }

    // FIXUP: DAN fix this - no magic numbers
    while (!(ENCODER_READ_REG16(ENCODER_STATUS) & 0x8))
    {
	
        if(downloadWaitCycles++>DOWNLOAD_TRY_NUMBER){
                printk("status checking error\n");
		return(ENCODER_FAILURE);
	}
    }
    downloadWaitCycles=0;

    /* wait for the download confirmation */
    while (ENCODER_READ_REG16(ENCODER_RETURN_VALUE) != ENCODER_FIRMWARE_DOWNLOAD_CONFIRMATION)
    {
        if(downloadWaitCycles++>DOWNLOAD_TRY_NUMBER){
		printk("FW download error\n");
		return(ENCODER_FAILURE);
	}
    }
    /* we are now in the init phase.
     *  Initialize the sensor then download the initialization package
     */
     if(bQuickResetFlag==FALSE)
    	EncoderInitializeSensor(sensorMode, sensorType, sensorCtrl);

        ED_InitPackage((uint8 *) initializationPackage[0],
                       &initializationPackageSize, bQuickResetFlag);

    /* download the initialization package */
    for (packageIndex = 0;
        packageIndex < initializationPackageSize/PACKAGE_LEN_BYTES;
        packageIndex++)
    {
      ENCODER_SEND_PACKAGE(initializationPackage[packageIndex], index);
    }

    /* OSD initialization */
    if(osdStr.osd_ena==1)
    {
        InitOSD(encoderVariableSettings.rescfg.width,
		encoderVariableSettings.rescfg.height);
        osd[0].x = (uint16) osdStr.osd_x;
        osd[0].y = (uint16) osdStr.osd_y;
        strcpy(osd[0].String,osdStr.osd_txt);
        GetOSDFrame(1,&osd);
        ShowOSDFrame(OSD_NORMAL);
    }

    /* initialization complete.   The Encoder should already be encoding */
    if (debugLevel >= DEBUG_LEVEL_PRINTFS)
        printk("EncoderInitComplete %d\n", downloadWaitCycles);

    /* configure the HPI bus for fast timings now that the device is configured */
    if (ENCODER_BUS_RUNTIME_MODE != ENCODER_BUS_INIT_MODE)
        board_bus_timing_set (ENCODER_BUS_RUNTIME_MODE);

    g_bAudioHardwareInitialized = TRUE;
    return(ENCODER_SUCCESS);
}

void
wis_fcb(int buffer, int unused, void *user, wis_frame_info_t * pframe_info);

void do_eb_callbacks(int buffer)
{
    sint32 cb;

    /* Invoke callbacks .. */
    for (cb = 0; cb < __n_handlers; cb++)
    {
        /* if this is the last callback, set the last callback flag */
        if (cb == __n_handlers-1)
        {
            pFrameInfo->flags |= ENCODER_FLAG_LAST_CALLBACK;
        }

        /* Execute callback in a lower priority task */
	wis_fcb(buffer, 0, callbackHandlers[cb].encoderFrameCallbackUser,
			pFrameInfo);
    }
}

enum { PARSER_DATA, 
       PARSER_00, 
       PARSER_0000, 
       PARSER_000001, 
       PARSER_FF } 
parser_state = PARSER_DATA;

unsigned char *frame_start;
int frame_pos, max_frame_pos, seen_frame = 0, cur_frame = -1;

extern wis_frame_buffer_t frame_buffer[MAX_FRAME_BUFFERS];
int readybuf[MAX_FRAME_BUFFERS + 1], fb_in = 0, fb_out = 0;
spinlock_t wis_lock = SPIN_LOCK_UNLOCKED;

void make_buffer_ready( int buffer )
{
	unsigned long flags;

	spin_lock_irqsave( &wis_lock, flags );
	if( buffer < 0 )
	{
		fb_in = fb_out = 0;
		cur_frame = -1;
	} else
	{
		readybuf[fb_in++] = buffer;
		if( fb_in == MAX_FRAME_BUFFERS + 1 ) fb_in = 0;
	}
	spin_unlock_irqrestore( &wis_lock, flags );
}

static void frame_begin(void)
{
	if( fb_in == fb_out ) return;
	cur_frame = readybuf[fb_out];
	/* Reserve four bytes at frame start to store the frame length */
	frame_start = frame_buffer[cur_frame].ptr + 4;
	frame_pos = 0;
	seen_frame = 0;
	max_frame_pos = frame_buffer[cur_frame].len - 4;
}

static void frame_end(void)
{
	/* Store the frame length in the first four bytes of the buffer */
	*((unsigned int *)(frame_buffer[cur_frame].ptr)) = frame_pos;
	if( ++fb_out == MAX_FRAME_BUFFERS + 1 ) fb_out = 0;
	do_eb_callbacks( cur_frame );
	cur_frame = -1;
}

static void read_mpeg_frame_data( int seq_sync_char, int frame_sync_char )
{
	int gop_sync_char = 0xB8;
	int i, x, word = 0;

	for( i = 0; i < ENCODER_PACKET_LENGTH_WORDS * 2; ++i )
	{
		if( i & 1 ) x = word >> 8;
		else x = ( word = ENCODER_GET_STREAM_WORD(i >> 1) ) & 0xff;
		if( cur_frame >= 0 && frame_pos >= max_frame_pos - 4 )
		{
			cur_frame = -1;
			printk( "Frame is too large for buffer of size %d\n",
					max_frame_pos );
		}
		switch( parser_state )
		{
		case PARSER_DATA:
			if( x == 0x00 ) parser_state = PARSER_00;
			else if( cur_frame >= 0 ) frame_start[frame_pos++] = x;
			break;
		case PARSER_00:
			if( x == 0x00 ) parser_state = PARSER_0000;
			else
			{
				if( cur_frame >= 0 )
				{
					frame_start[frame_pos++] = 0;
					frame_start[frame_pos++] = x;
				}
				parser_state = PARSER_DATA;
			}
			break;
		case PARSER_0000:
			if( x == 0x01 ) parser_state = PARSER_000001;
			else if( x == 0x00 )
			{
				if( cur_frame >= 0 )
					frame_start[frame_pos++] = 0;
				parser_state = PARSER_0000;
			} else
			{
				if( cur_frame >= 0 )
				{
					frame_start[frame_pos++] = 0;
					frame_start[frame_pos++] = 0;
					frame_start[frame_pos++] = x;
				}
				parser_state = PARSER_DATA;
			}
			break;
		case PARSER_000001:
			if( x == seq_sync_char || 
			    x == gop_sync_char ||
			    x == frame_sync_char )
			{
				if( cur_frame >= 0 && seen_frame ) frame_end();
				if( cur_frame < 0 ) frame_begin();
			}

			if( x == frame_sync_char )
			{
				seen_frame = 1;
				__n_encoder_frames_total++;
			}

			if( cur_frame >= 0 )
			{
				frame_start[frame_pos++] = 0;
				frame_start[frame_pos++] = 0;
				frame_start[frame_pos++] = 1;
				frame_start[frame_pos++] = x;
			}
			parser_state = PARSER_DATA;
			break;
		}
	}
}


static void read_h263_frame_data(void)
{
	int i, x, word = 0;

	for( i = 0; i < ENCODER_PACKET_LENGTH_WORDS * 2; ++i )
	{
		if( i & 1 ) x = word >> 8;
		else x = ( word = ENCODER_GET_STREAM_WORD(i >> 1) ) & 0xff;
		if( cur_frame >= 0 && frame_pos >= max_frame_pos )
		{
			cur_frame = -1;
			printk( "Frame is too large for buffer of size %d\n",
					max_frame_pos );
		}
		switch( parser_state )
		{
		case PARSER_DATA:
			if( x == 0x00 ) parser_state = PARSER_00;
			else if( cur_frame >= 0 ) frame_start[frame_pos++] = x;
			break;
		case PARSER_00:
			if( x == 0x00 ) parser_state = PARSER_0000;
			else
			{
				if( cur_frame >= 0 )
				{
					frame_start[frame_pos++] = 0;
					frame_start[frame_pos++] = x;
				}
				parser_state = PARSER_DATA;
			}
			break;
		case PARSER_0000:
			if( x == 0x00 )
			{
				if( cur_frame >= 0 )
					frame_start[frame_pos++] = 0;
				parser_state = PARSER_0000;
			} else
			{
				if( (x&0xfc) == 0x80 )
				{
					if( cur_frame >= 0 ) frame_end();
					if( cur_frame < 0 ) frame_begin();
					__n_encoder_frames_total++;
				}
				if( cur_frame >= 0 )
				{
					frame_start[frame_pos++] = 0;
					frame_start[frame_pos++] = 0;
					frame_start[frame_pos++] = x;
				}
				parser_state = PARSER_DATA;
			}
			break;
		}
	}
}


static void read_mjpeg_frame_data(void)
{
	int i, x, word = 0;

	for( i = 0; i < ENCODER_PACKET_LENGTH_WORDS * 2; ++i )
	{
		if( i & 1 ) x = word >> 8;
		else x = ( word = ENCODER_GET_STREAM_WORD(i >> 1) ) & 0xff;
		if( cur_frame >= 0 && frame_pos >= max_frame_pos )
		{
			cur_frame = -1;
			printk( "Frame is too large for buffer of size %d\n",
					max_frame_pos );
		}
		switch( parser_state )
		{
		case PARSER_DATA:
			if( x == 0xFF ) parser_state = PARSER_FF;
			else if( cur_frame >= 0 ) frame_start[frame_pos++] = x;
			break;
		case PARSER_FF:
			switch( x )
			{
			case 0xFF:
				if( cur_frame >= 0 )
					frame_start[frame_pos++] = 0xFF;
				parser_state = PARSER_FF;
				break;
			case 0xD8:
				if( cur_frame >= 0 ) frame_end();
				if( cur_frame < 0 ) frame_begin();
				__n_encoder_frames_total++;
				/* fall-through */
			default:
				if( cur_frame >= 0 )
				{
					frame_start[frame_pos++] = 0xFF;
					frame_start[frame_pos++] = x;
				}
				parser_state = PARSER_DATA;
				break;
			}
			break;
		}
	}
}


void ED_video_isr(int irq, void* isrData, struct pt_regs* regs)
{
    encoderDriverQueueElement_t encoderDriverQueueElement;
   
    /* ENCODER Interrupt was received, so
     * signal the Driver Task if there is stream data
    */
    encoderDriverQueueElement.messageData = ENCODER_READ_REG16(ENCODER_RETURN_DATA);
    /* read ENCODER_STATUS to prevent missing stream buffer full event */
    encoderDriverQueueElement.messageType = (ENCODER_READ_REG16(ENCODER_RETURN_VALUE)) |
        (((ENCODER_READ_REG16(ENCODER_STATUS)) & ENCODER_STATUS_STREAM_BUFFER_FULL_INTERRUPT) ? 
         (ENCODER_STREAM_BUFFER_FULL_MASK) : (0));
 
    /* clear the interrupt to the interrupt controller */
    board_int_clear (ENCODER_INTERRUPT_STATUS_BIT_MASK);

    for(;;)
    {
	if (encoderDriverQueueElement.messageType == 0) break;

	if (encoderDriverQueueElement.messageType & ENCODER_STREAM_BUFFER_FULL_MASK)
	{
	    switch (encoderMode)
	    {
	    case ENCODER_MODE_MPEG1:
	    case ENCODER_MODE_MPEG2:
		read_mpeg_frame_data( 0xB3, 0x00 );
		break;
	    case ENCODER_MODE_MPEG4:
		read_mpeg_frame_data( 0xB0, 0xB6 );
		break;
	    case ENCODER_MODE_H263:
		read_h263_frame_data();
		break;
	    case ENCODER_MODE_MJPEG:
		read_mjpeg_frame_data();
		break;
	    default:
		{
		    int i;

		    /* Drain the FIFO */
		    for( i = 0; i < ENCODER_PACKET_LENGTH_WORDS; ++i )
			    ENCODER_GET_STREAM_WORD(i);
		}
	    }
	    buffersReceived++;
	    encoderDriverQueueElement.messageType &= ~ENCODER_STREAM_BUFFER_FULL_MASK;
	}
	if (encoderDriverQueueElement.messageType != 0)
	    OSL_QPut(encoderDriverQueue, (sint32 *)&encoderDriverQueueElement,
		     sizeof(encoderDriverQueueElement_t), OS_NO_WAIT);

        /* read again to see if the stream buffer is full. */
        encoderDriverQueueElement.messageData = ENCODER_READ_REG16(ENCODER_RETURN_DATA);
        /* read ENCODER_STATUS to prevent missing stream buffer full event */
        encoderDriverQueueElement.messageType = (ENCODER_READ_REG16(ENCODER_RETURN_VALUE)) |
            (((ENCODER_READ_REG16(ENCODER_STATUS)) & ENCODER_STATUS_STREAM_BUFFER_FULL_INTERRUPT) ?
             (ENCODER_STREAM_BUFFER_FULL_MASK) : (0));

    }
}


/*************************************************************************
*
*  Procedure Name:
*       ED_Task(void)
*
*  Description:
*       This task is responsible for initializing and servicing the
*       encoder device;
*  
*  Arguments:
*
*     NONE
*
*  Returns:
*
*    NONE
*
*   Notes:
*
******************************************************************************/

#define UNROLL_SIZE     1

#define CURRENT_WORD    0
#define NEXT_WORD   1

void ED_Task(void)
{
    encoderDriverQueueElement_t encoderDriverQueueElement;
    
    /* configure the HPI bus for our device */
    board_bus_timing_set (ENCODER_BUS_INIT_MODE);

    /* clear any interrupt to the interrupt controller */
    board_int_clear (ENCODER_INTERRUPT_STATUS_BIT_MASK);
    
    boEncoderReset = FALSE;

    encoderDone = 0;

    if (debugLevel >= DEBUG_LEVEL_PRINTFS)
    {
        printf("Begin EncoderDriverTask\n");
    }

    /* Create message queue. The ISR uses it to signal the stream task */
    encoderDriverQueue = OSL_QInit(OSL_Q_TYPE_ISR_TO_TASK,
				   sizeof(encoderDriverQueueElement_t),
				   ENCODER_DRIVER_QUEUE_SIZE);

#ifdef __linux__
    /*
     * Provide full interrupt info.
     * Under Linux, complete with /proc info
     */    
    osl_int_connect(ENCODER_INT_NUM,
            (irq_handler_t)ED_video_isr,
            "HPI-Video", (void*)IRQ_DEV_ID);
#else   
    OSL_IntConnect(ENCODER_INT_NUM, ED_InterruptServiceRoutine, 0);
#endif

    /* disable the encoder interrupt */
    osl_int_disable (ENCODER_INT_NUM);

    /* reset the chip */
    ENCODER_ISSUE_RESET;

    /* re-enable the encoder interrupt */
    osl_int_enable (ENCODER_INT_NUM);

    /* ensure that the decoder is primed whenever the encoder is started */
    bDecoderIsPrimed = FALSE;
    
    /* this always gets freed on the last callback */
    pFrameInfo = osl_alloc(sizeof(wis_frame_info_t),"frameinfo");
    if (pFrameInfo == NULL)
    {
        printf("Frame info allocation failure.  Encoder exiting.\n");
        return;
    }

    pFrameInfo->flags = 0;
    pFrameInfo->regionMap = 0;

    while(!encoderDone)
    {

        /* Wait for encoder events */
        OSL_QGet(encoderDriverQueue, (sint32 *)&encoderDriverQueueElement,
                 sizeof(encoderDriverQueueElement_t), OS_WAIT_FOREVER);

        if (debugLevel >= DEBUG_LEVEL_PRINTFS)
        {
            printf("Encoder Queue Received 0x%x\n",
           (encoderDriverQueueElement.messageData << 16)
                   | encoderDriverQueueElement.messageType );
        }

        /* if the reset is complete, initialize the chip (i.e. start encoding) */
        if ( (boEncoderReset == FALSE)
             && (encoderDriverQueueElement.messageType == ENCODER_INT_VALUE) )
        {
            /* disable the encoder interrupt */
            osl_int_disable (ENCODER_INT_NUM);

            ED_Init(FALSE);

            boEncoderReset = TRUE;

            /* inform the rest of the system that we are in runtime now */
            g_bRuntime = TRUE;

            /* re-enable the encoder interrupt */
            osl_int_enable (ENCODER_INT_NUM);

            continue;                   /* if a match is found (other than reading the stream), get the next */
        }

        if (encoderDriverQueueElement.messageType == ENCODER_INITC1_COMPLETE)
        {
            g_encoderDataValue = (uint16) encoderDriverQueueElement.messageData;
            g_encoderReturnValue = (uint16) encoderDriverQueueElement.messageType;

            continue;
        }

        if ( encoderDriverQueueElement.messageType == ENCODER_CHANGE_RESOLUTION)
        {
            ED_ChangeResolution(encoderDriverQueueElement.messageData);
            continue;
        }
             
        if ( encoderDriverQueueElement.messageType == ENCODER_SET_FPS_RUNTIME)
        {
            /* change the frame rate
            ED_SetFps(g_inputFrameRate, encoderDriverQueueElement.messageData);
            */
              ED_fps_otf(encoderDriverQueueElement.messageData);
            continue;
        }
             
        if ( encoderDriverQueueElement.messageType == ENCODER_CHANGE_BRC_RUNTIME)
        {
            /* Change the bitrate control within the chip*/
            brc_message_t *brcMessage = (brc_message_t *) encoderDriverQueueElement.messageData;
            ED_ChangeBRC(brcMessage->changeDirection, brcMessage->newIQScale,
                         brcMessage->newPQScale, brcMessage->newTargetBitrate,
                         brcMessage->newPeakBitrate, brcMessage->newVbvBuffer,
                         brcMessage->newConvergenceSpeed, brcMessage->newLambda);
            

           
            continue;
        }
             
        if(encoderDriverQueueElement.messageType == MOTION_DETECTION_INTERRUPT)
        {
	printf("md interrupt\n");
            pFrameInfo->regionMap = encoderDriverQueueElement.messageData;
            //printf("\nMD regionmap fired: %d\n", pFrameInfo->regionMap);
	    __n_md_ints_total++;
            continue;
        }

             
        /* The encoder has signaled that it has received the message */
	if (encoderDriverQueueElement.messageType == ENCODER_MACROBLOCK_MAP_RETURN)
        {
            //printf("Motion Detection MB Map or Threshold set return.\n");
            continue;
        }

        /* this message is special in that it is generated by the driver */
        /* to notify this task that it should shutdown gracefully and exit */
        if ( encoderDriverQueueElement.messageType == ENCODER_SHUTDOWN)
        {
            encoderDone = 1;
            osl_int_disable (ENCODER_INT_NUM);
            printf("Video irq disabled\n");
            OSL_QDelete(encoderDriverQueue);
            printf("Video queue deleted\n");        
            osl_int_disconnect(ENCODER_INT_NUM, (void*)IRQ_DEV_ID);
            osl_free(pFrameInfo);
            break;
        }

        /* Fatal Error */
        printf("ERROR: Encoder interrupt match not found data=0x%04x val=0x%04x\n",
               encoderDriverQueueElement.messageData,
               encoderDriverQueueElement.messageType);

        encoderDone = 1;
    }

    printf("Encoder thread exit\n");
}

/*
 * Report Video CODEC stats via logMsg.
 */


#ifdef VXWORKS
extern void pmuStart(void);
extern void pmuStop(void);
extern void pmuPrint(void);

extern sint32 __n_decoder_frames_total;
extern sint32 __n_decoders;

#endif

/* Print encoder info every "MONITOR_PERIOD" seconds */
#define MONITOR_PERIOD 10

extern sint32 __n_audio_frames_total;

void
VideoMonitorTask(void)
{
    sint32 encoder_fps;
    sint32 audio_fps;
    
    sint32 last_e = 0;
    sint32 last_a = 0;
    sint32 last_m = 0;
#ifdef VXWORKS /* only the VxWorks code has a decoder */
    sint32 decoder_fps;
    sint32 last_d = 0;
    uint8  buf[125];
#endif
    sint32 tick = 0;
    sint32 bitsReceived;

    /* pre-initialize the global totals variables */
    __n_encoder_frames_total=0;
   __n_audio_frames_total=0;
    __n_md_ints_total = 0;
    
#ifdef VXWORKS
    __n_decoder_frames_total=0;
    __n_audio_frames_total=0;
#endif
    while (!encoderDone)
    {
        osl_msleep (1000 * MONITOR_PERIOD); /* Sleep one second, 1000ms */
        
        /* calculate the number of encoded frames in the past second */
        encoder_fps = (__n_encoder_frames_total - last_e)/MONITOR_PERIOD;
        last_e = __n_encoder_frames_total;

	/* calculate the number of MD interrupts/second */
	md_ips = (__n_md_ints_total - last_m)/MONITOR_PERIOD;
	last_m = __n_md_ints_total;
	
#ifndef __linux__
        /* calculate the number of decoded frames in the past second */
        decoder_fps = (__n_decoder_frames_total/__n_decoders) - last_d;
        last_d = __n_decoder_frames_total;

#endif
        /* calculate the number of audio frames in the past second */
        audio_fps = (__n_audio_frames_total - last_a)/MONITOR_PERIOD;
        last_a = __n_audio_frames_total;

        /* calculate  number of encoded bits received in the past second */
        bitsReceived =
        ((buffersReceived * ENCODER_PACKET_LENGTH_WORDS * 2) * 8)/MONITOR_PERIOD;

        buffersReceived=0;
        
#ifdef VXWORKS
#ifdef TERMINAL_LOGGING
        if (debugLevel >= DEBUG_LEVEL_STATISTICS)
        logMsg("Time: %d, E: %d fps, D: %d fps, "
               "A: %d fps, V Kbps: %d\n",
               tick++, encoder_fps, decoder_fps,
               audio_fps, bitsReceived/1000,0,0);
#else /* log to the video display device */
        memset(buf, 0x0, 125);
        sprintf(buf, "Time: %d, Encoder: %d fps, "
            "Decoder: %d fps  ", tick++, encoder_fps, decoder_fps);
        video_drawstring(0,300,buf);
#endif  
#else
	tick++;
        printf("Time: %d, E: %d fps, V Kbps: %d, A: %d fps, MD: %d IPS\n",
               MONITOR_PERIOD*tick, encoder_fps, bitsReceived/1000, audio_fps, md_ips);
#endif      
    } /* end FOREVER loop */
}
