/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       sensor_init.c
*
*   DESCRIPTION:
*       This is the sensor initialization driver.
*
*  AUTHOR:
*   Daniel Meyer
*
*   $Id: sensor_init.c,v 1.18 2005/01/12 16:18:54 jblair Exp $ 
*
******************************************************************************/

#define SPI_I2C_ADDR_BASE           0x1400

#define STATUS_REG_ADDR             (SPI_I2C_ADDR_BASE + 0x2)

#define I2C_CTRL_REG_ADDR           (SPI_I2C_ADDR_BASE + 0x6)
#define I2C_DEV_UP_ADDR_REG_ADDR    (SPI_I2C_ADDR_BASE + 0x7)
#define I2C_LO_ADDR_REG_ADDR        (SPI_I2C_ADDR_BASE + 0x8)
#define I2C_DATA_REG_ADDR           (SPI_I2C_ADDR_BASE + 0x9)
#define I2C_CLKFREQ_REG_ADDR        (SPI_I2C_ADDR_BASE + 0xa)

#define I2C_STATE_MASK              0x0007
#define I2C_READ_READY_MASK         0x0008

#define SPI_CTRL_REG_ADDR           (SPI_I2C_ADDR_BASE + 0x0)
#define SPI_OPLEN_REG_ADDR          (SPI_I2C_ADDR_BASE + 0x1)
#define SPI_OPC_REG_ADDR            (SPI_I2C_ADDR_BASE + 0x3)
#define SPI_ADDR_REG_ADDR           (SPI_I2C_ADDR_BASE + 0x4)
#define SPI_DATA_REG_ADDR           (SPI_I2C_ADDR_BASE + 0x5)

#define SPI_STATE_MASK              0x0E00
#define SPI_READ_READY_MASK         0x0010

enum I2C_STATE
{
    IS_IDLE = 0
              // there are other states, but driver doesn't care
};

#include "wis_types.h"
#include "wis_error.h"
#include "wis_encoder.h"
#include "encoder_driver.h"
#include "struct.h"
#include "os.h"

#define I2C_MODE_NORMAL     0
#define I2C_MODE_SCCB       1

#define SPI_MODE_0          0
#define SPI_MODE_1          1
#define SPI_MODE_2          2
#define SPI_MODE_3          275

sint32 i2cMode = I2C_MODE_NORMAL;
sint32 spiMode = SPI_MODE_3;

/* this variable tells us if the encoder has come out of reset and has been initialized */
extern bool_t boEncoderReset;

/* when the driver gets certain values (such as completion of a read interrupt) */
/* it fills them in here, which we may then clear */
extern uint32 g_encoderDataValue;
extern uint32 g_encoderReturnValue;

/* local prototypes */
SINT32 ov7648SensorSetVga(sint32 vgaOrQvga);

uint32 EncoderGetInterruptReturn(void)
{
    uint16 encoderIntValue;
    uint16 retVal;

    /* if the encoder is still being initialized */
    if (boEncoderReset == FALSE)
    {
        while (!(ENCODER_READ_REG16(ENCODER_STATUS) & 0x8))
        {
            ;
        }

        retVal = ENCODER_READ_REG16(ENCODER_RETURN_DATA);
        encoderIntValue = ENCODER_READ_REG16(ENCODER_RETURN_VALUE);

        /* keep reading until we can get the return data.  This is the polling method */
        while ((encoderIntValue & ~ENCODER_STREAM_BUFFER_FULL_MASK)
               != ENCODER_INITC1_COMPLETE)
        {
            retVal = ENCODER_READ_REG16(ENCODER_RETURN_DATA);
            encoderIntValue = ENCODER_READ_REG16(ENCODER_RETURN_VALUE);
        }
    }
    else /* the encoder has been initialized and all information comes from real interrupts */
    {
        while (g_encoderReturnValue != ENCODER_INITC1_COMPLETE)
        {
            osl_msleep (100);
            /* give up priority briefly until this occurs */
        }
        retVal = g_encoderDataValue;
        g_encoderDataValue = 0;
        g_encoderReturnValue = 0;
    }
    return(retVal);
}

void GenWriteCBusRegPacket(UINT16 *pPacket, int RegNum, UINT16 *AddrData)
{
    int i;

    for (i=0;i<32;i++)
        pPacket[i] = 0;

    pPacket[0] = 0x2000 + RegNum;       

    for (i=0;i<RegNum;i++)
    {
        pPacket[2+2*i] = 0x8000 | AddrData[i*2];    // address
        pPacket[2+2*i+1] = AddrData[i*2+1];         // data
    }
}

void GenReadCBusRegPacket(UINT16 *pPacket, int RegNum, UINT16 *Addr)
{
    int i;

    for (i=0;i<32;i++)
        pPacket[i] = 0;

    pPacket[0] = 0x0100 + RegNum;       

    for (i=0;i<RegNum;i++)
        pPacket[2+i] = Addr[i];     // address
}

// return   0 -- success
//          1 -- download buffer error

int WriteCBusRegFW(int write_num, UINT16 *addr_data)
{
    int ad_index=0;

    for (ad_index = 0; ad_index<write_num; ad_index++)
    {
        WriteInterrupt((UINT16)(addr_data[2*ad_index]),
                       addr_data[2*ad_index+1]);
    }

    return 0;
}

// return   0 -- success
//          1 -- download buffer error
//          2 -- read interrupt error
//          3 -- error interrupt type

sint32 ReadCBusRegFW(int read_num, uint16 *addr, uint16 *data)
{
    int ad_index=0;
    int RetData;

    for (ad_index = 0; ad_index<read_num; ad_index++)
    {
        ReadInterrupt(addr[ad_index]);

        RetData = EncoderGetInterruptReturn();

        if (RetData >= 0)
        {
            data[ad_index] = RetData;
        }
        else
        {
            return 2;
        }
    }

    return 0;
}

// write an I2c Register 
SINT32 I2C_WriteReg_7007SB(UINT8 dev_addr, SINT32 addr_len,
                           UINT16 reg_addr, UINT8 reg_data)
{
    uint16 addr, data, addr_data[32];
    int r,i;

    // 1) Wait until i2c_state of spi_i2c_status_reg is IDLE;
#if 0
    logMsg("I2C_WriteReg: slave=0x%x len=%d reg_addr=0x%x reg_data=0x%x\n", 
           dev_addr, addr_len, reg_addr, reg_data,0);
#endif
    for (i=0;i<10;i++)
    {
        addr = STATUS_REG_ADDR;
        r = ReadCBusRegFW(1, &addr, &data);
        if (r != 0)
        {
            return 1;
        }

        if ( (data & I2C_STATE_MASK) == IS_IDLE )
            break;

        osl_msleep (50);
    }

    if (i==10)
    {
        return 1;
    }

    // 2) Write i2c_ctrl_reg if needed;
    addr_data[0] = I2C_CTRL_REG_ADDR;

    addr_data[1] = 0x0000; 
    if (addr_len==16)
        addr_data[1] |= 0x0001;

    // 3) Write i2c_loaddr_reg if needed;
    addr_data[2] = I2C_LO_ADDR_REG_ADDR;
    addr_data[3] = reg_addr;

    // 4) Write i2c_data_reg
    addr_data[4] = I2C_DATA_REG_ADDR;
    addr_data[5] = reg_data;

    // 5) Write i2c_devaddr_upaddr_reg. 
    dev_addr /= 2;
    addr_data[6] = I2C_DEV_UP_ADDR_REG_ADDR;
    addr_data[7] = (((UINT16)dev_addr)<<9);
    if (addr_len==16)
        addr_data[7] |= (reg_addr>>8) & 0x00ff;

    r = WriteCBusRegFW(4, addr_data);

    if (r != 0)
    {
        return 5;
    }

    osl_msleep (25);
    return 0;
}


// read an i2c Register 

// NOTE:  Omnivision sensor uses SCCB mode.  In this mode, when performing a read, you must
//        | 0x0010 in the data field here.  See Windows SDK
SINT32 I2C_ReadReg_7007SB(UINT8 dev_addr, SINT32 addr_len,
                          UINT16 reg_addr, UINT8 *reg_data)
{

        uint16 addr, data, addr_data[32];
    int r,i;

    // please refer to Specification for Module spi_i2c_master
    // 1) Wait until i2c_state of spi_i2c_status_reg is IDLE;

    for (i=0;i<10;i++)
    {

        addr = STATUS_REG_ADDR;
        r = ReadCBusRegFW(1, &addr, &data);
        if (r != 0)
        {
            return 1;
        }

        if ( (data & I2C_STATE_MASK) == IS_IDLE )
            break;
        osl_msleep (50);
    }

    if (i==10)
    {
        return 1;
    }

    // 2) Write i2c_ctrl_reg if needed;
    addr_data[0] = I2C_CTRL_REG_ADDR;
    addr_data[1] = 0x0000; 

    if (i2cMode==I2C_MODE_SCCB)
        addr_data[1] |= 0x0010;

    if (addr_len==16)
        addr_data[1] |= 0x0001;

    // 3) Write i2c_loaddr_reg if needed;
    addr_data[2] = I2C_LO_ADDR_REG_ADDR;
    addr_data[3] = reg_addr;

    r = WriteCBusRegFW(2, addr_data);

    if (r != 0)
    {
        return 3;
    }
    // 4) read i2c_data_reg to clear i2c_rx_data_rdy;
    addr = I2C_DATA_REG_ADDR;
    r = ReadCBusRegFW(1, &addr, &data);

    if (r != 0)
    {

        return 4;
    }
    // 5) Write i2c_devaddr_upaddr_reg. 
    dev_addr /= 2;
    addr_data[0] = I2C_DEV_UP_ADDR_REG_ADDR;
    addr_data[1] = (((UINT16)dev_addr)<<9) | 0x0100;

    if (addr_len==16)
        addr_data[1] |= (reg_addr>>8) & 0x00ff;

    r = WriteCBusRegFW(1, addr_data);

    if (r != 0)
    {
        return 5;
    }
    // 6) check if i2c_rx_data_rdy is set

    for (i=0;i<10;i++)
    {
        addr = STATUS_REG_ADDR;
        r = ReadCBusRegFW(1, &addr, &data);
        if (r != 0)
        {
            return 6;
        }
        if ( (data &  I2C_READ_READY_MASK) != 0 )
            break;
        osl_msleep (50);
    }

    if (i==10)
    {
        return 6;
    }

    // 7) read i2c_data_reg for result
    addr = I2C_DATA_REG_ADDR;
    r = ReadCBusRegFW(1, &addr, &data);
    if (r != 0)
    {
        return 7;
    }
    *reg_data = (UINT8)data;

    return 0;
}



SINT32  SPI_WriteRegister(SINT32 op_len, UINT8 op_code, SINT32 addr_len,
                          UINT16 reg_addr, SINT32 data_len, UINT16 reg_data)
{
    uint16 addr_data[32];
    uint16 addr, data;
    int r,i;

    // 1) Wait until spi_state of spi_i2c_status_reg is IDLE;

    for(i=0;i<10;i++)
    {
        addr = STATUS_REG_ADDR;
        r = ReadCBusRegFW(1, &addr, &data);
        if(r != 0)
            return 1;

        if( ((data & SPI_STATE_MASK)>>9) == IS_IDLE )
            break;
    
        osl_msleep (50);
    }
    if(i==10)
        return 1;

    // 2) Write spi_ctrl_reg if needed;

    addr_data[0] = SPI_CTRL_REG_ADDR;
    addr_data[1] = spiMode;
    r = WriteCBusRegFW(1, addr_data);
    if(r != 0)
        return 2;

    // 3) Write spi_oplen_reg if needed;

    addr_data[1] = ( (data_len & 0x001F) << 7 ) | ( ((addr_len-1) & 0x000F) << 3 ) | ( (op_len-1) & 0x0007 ) ;
    addr_data[0] = SPI_OPLEN_REG_ADDR;
    r = WriteCBusRegFW(1, addr_data);
    if(r != 0)
        return 3;

    // 4) Write spi_opc_reg if needed;

    addr_data[1] = op_code << (8-op_len);
    addr_data[0] = SPI_OPC_REG_ADDR;
    r = WriteCBusRegFW(1, addr_data);
    if(r != 0)
        return 4;

    // 5) Write spi_data_reg for write operation if the write data is different from spi_data_reg or need to clear spi_clear_to_send; or read spi_data_reg if need to clear spi_rx_data_rdy;

    addr_data[1] = reg_data << (16-data_len);
    addr_data[0] = SPI_DATA_REG_ADDR;
    r = WriteCBusRegFW(1, addr_data);
    if(r != 0)
        return 5;

    // 6) Write spi_addr_reg. 

    addr_data[1] = reg_addr << (16-addr_len);
    addr_data[0] = SPI_ADDR_REG_ADDR;
    r = WriteCBusRegFW(1, addr_data);
    if(r != 0)
        return 6;

    osl_msleep (25);

    return 0;
}

SINT32  SPI_ReadRegister(SINT32 op_len, UINT8 op_code, SINT32 addr_len,
                         UINT16 reg_addr, SINT32 data_len, UINT16 *reg_data)
{
    uint16 addr_data[32];
    uint16 addr, data;
    int r,i;

    // 1) Wait until spi_state of spi_i2c_status_reg is IDLE;

    for(i=0;i<10;i++)
    {
        addr = STATUS_REG_ADDR;
        r = ReadCBusRegFW(1, &addr, &data);
        if(r != 0)
            return 1;

        if( ((data & SPI_STATE_MASK)>>9) == IS_IDLE )
            break;
    
        osl_msleep (50);
    }
    if(i==10)
        return 1;

    // 2) Write spi_ctrl_reg if needed;

    addr_data[1] = spiMode;
    addr_data[0] = SPI_CTRL_REG_ADDR;
    r = WriteCBusRegFW(1, addr_data);
    if(r != 0)
        return 2;

    // 3) Write spi_oplen_reg if needed;

    addr_data[1] = ( (data_len & 0x001F) << 7 ) | ( ((addr_len-1) & 0x000F) << 3 ) | ( (op_len-1) & 0x0007 ) ;
    addr_data[0] = SPI_OPLEN_REG_ADDR;
    r = WriteCBusRegFW(1, addr_data);
    if(r != 0)
        return 3;

    // 4) Write spi_opc_reg if needed;

    addr_data[1] = op_code << (8-op_len);
    addr_data[0] = SPI_OPC_REG_ADDR;
    r = WriteCBusRegFW(1, addr_data);
    if(r != 0)
        return 4;

    // 5) read spi_data_reg to clear spi_rx_data_rdy;

    addr = SPI_DATA_REG_ADDR;
    r = ReadCBusRegFW(1, &addr, &data);
    if(r != 0)
        return 5;

    // 6) Write spi_addr_reg. 

    addr_data[0] = SPI_ADDR_REG_ADDR;
    addr_data[1] = reg_addr << (16-addr_len);
    r = WriteCBusRegFW(1, addr_data);
    if(r != 0)
        return 6;

    // 7) check if spi_rx_data_rdy is set

    for(i=0;i<10;i++)
    {
        addr = STATUS_REG_ADDR;
        r = ReadCBusRegFW(1, &addr, &data);
        if(r != 0)
            return 7;

        if( (data & SPI_READ_READY_MASK) != 0 )
            break;

        osl_msleep (50);
    }
    if(i==10)
        return 7;

    // 8) read spi_data_reg for result

    addr = SPI_DATA_REG_ADDR;
    r = ReadCBusRegFW(1, &addr, &data);
    if(r != 0)
        return 8;

    *reg_data = data & ((1<<data_len)-1);

    return 0;
}


#define REG_ADDR    0
#define REG_DATA    1
// sensor config data

uint8 deviceAddress = 0x42;

/* Ambit J18V035T0x */

#define NUMBER_OF_REG_WRITES    112
uint16 icm202bInitSequence[NUMBER_OF_REG_WRITES][2] = 
{
    0x3a, 0x00,
    0x1d, 0x00,
    0x1c, 0x01,
    0x00, 0x04,

//rem disable column count
    0x01, 0x30,      //5
//rem vector: 0     change position : 2
    0x03, 0x00,
    0x04, 0x01,
    0x05, 0x00,
    0x06, 0x01,
    0x08, 0x00,     //10
//rem vector: 1     change position : 18
    0x03, 0x01,
    0x04, 0x28,
    0x05, 0x80,
    0x06, 0x01,
    0x08, 0x00,     //15
//rem vector: 2     change position : 20
    0x03, 0x02,
    0x04, 0x2c,
    0x05, 0x00,
    0x06, 0x01,
    0x08, 0x00,    //20
//rem vector: 3     change position : 22
    0x03, 0x03,
    0x04, 0x30,
    0x05, 0x00,
    0x06, 0x05,
    0x08, 0x00,    //25
//rem vector: 4     change position : 24
    0x03, 0x04,
    0x04, 0x34,
    0x05, 0x00,
    0x06, 0x0d,
    0x08, 0x00,    //30
//rem vector: 5     change position : 26
    0x03, 0x05,
    0x04, 0x38,
    0x05, 0x00,
    0x06, 0x05,
    0x08, 0x00,    //35
//rem vector: 6     change position : 280
    0x03, 0x06,
    0x04, 0x37,
    0x05, 0x05,
    0x06, 0x05,
    0x08, 0x00,   //40
//rem vector: 7     change position : 282
    0x03, 0x07,
    0x04, 0x39,
    0x05, 0x01,
    0x06, 0x05,
    0x08, 0x00,   //45
//rem vector: 8     change position : 298
    0x03, 0x08,
    0x04, 0x60,
    0x05, 0x89,
    0x06, 0x05,
    0x08, 0x00,   //50
//rem vector: 9     change position : 302
    0x03, 0x09,
    0x04, 0x64,
    0x05, 0x09,
    0x06, 0x0d,
    0x08, 0x00,    //55
//rem vector: 10     change position : 306
    0x03, 0x0a,
    0x04, 0x68,
    0x05, 0x09,
    0x06, 0x05,
    0x08, 0x00,   //60
//rem vector: 11     change position : 440
    0x03, 0x0b,
    0x04, 0xe8,
    0x05, 0x0d,
    0x06, 0x05,
    0x08, 0x00,//65
//rem vector: 12     change position : 499
    0x03, 0x0c,
    0x04, 0xf1,
    0x05, 0x09,
    0x06, 0x05,
    0x08, 0x00,//70
//rem vector: 13     change position : 499
    0x03, 0x0d,
    0x04, 0xf3,
    0x05, 0x01,
    0x06, 0x05,
    0x08, 0x00,//75
//rem wave table length
    0x07, 0x0e,
    0x9b, 0xe9,
    0x9c, 0x01,
    0x0e, 0x90,
    0x0f, 0x01,//80 

    0x01, 0x29,
    0x02, 0xca,
    0x20, 0x00,
    0x21, 0x01,
    0x22, 0x00,//85 

    0x23, 0x01,
    0x24, 0x00,
    0x25, 0x01,
    0x26, 0x00,
    0x27, 0x01,//90

    0x57, 0x01,
    0x56, 0xfe,
    0x55, 0x01,
    0x54, 0x00,
    0x00, 0x80,//95

    0x3d, 0x55,
    0x3e, 0x05,
    0x45, 0xeb,
    0x94, 0x00,
    0x91, 0x06,//100
//rem muximum frame rate 20-30fps 
    0x3f, 0x58,
    0x40, 0x02,    //Set Max frame height (Min. frame rate = 20 fps) .
    0x41, 0x90,
    0x42, 0x01,   //Set Min. frame height (Max. frame rate = 30 fps).
    0x1c, 0x8f, //105

    0x1d, 0x01, // Set exposure time less than frame height .
//SENSOR COMMAND use 202B_20020321T 
//rem set YCbCr sequence
    0x52, 0x6d,
    0x3b, 0x78,   //AE Height
    0x3c, 0x66,
//rem turn on AE without slope-rate adjustable
    0x3a, 0x07, //110
//rem set gamma 0
    0x2c, 0x01,
    0x00, 0x84,
};


SINT32 I2C_InitSensor_7007SB(UINT8 dev_addr, SINT32 reg_num, UINT16 *reg_data)
{
    SINT32 r,i;

    for (i=0;i<reg_num;i++)
    {
        r = I2C_WriteReg_7007SB(dev_addr, 8, (UINT16)(reg_data[i*2]),
                                (UINT8)(reg_data[i*2+1]));
	/* printf("\ti2c_reg[%02x]=%02x\n",reg_data[i*2],reg_data[i*2+1]);*/
        if (r != 0)
        {
            printf("Error Writing I2c: %d, %d\n", r, i);
            return r;
        }
    }

    return SUCCESS;
}

SINT32 SPI_InitSensor_7007SB(SINT32 reg_num, UINT16 *reg_data)
{
    SINT32 r,i;

    for (i=0; i<reg_num; i++)
    {
        r = SPI_WriteRegister(8, reg_data[i*3], 2,
                              reg_data[i*3+1], 6, reg_data[i*3+2]);
#if 0
        printf("O: %x, A: %x, D: %x, s: %d\n", reg_data[i*3],
               reg_data[i*3+1], reg_data[i*3+2], r);
#endif
        if (r != 0)
        {
            printf("Error Writing SPI: %d, %d\n", r, i);
            return r;
        }
    }

    return SUCCESS;
}

SINT32 icm202SensorSetAutoExposure(UINT16 aeSetting)
{
    SINT32 returnStatus;
    uint16 icm202RegArray[5][2] = {

        0x3a, 0x00, // disable AE
        0x3b, 0x58, // set target value high
        0x3c, 0x50, // set target value low
        0x3a, 0x07, // enable AE, anti-flickering, and digital gain
        0x00, 0x84
    };

    icm202RegArray[1][1] = (aeSetting >> 8) & 0xff;
    icm202RegArray[2][1] = (aeSetting) & 0xff;

    returnStatus = I2C_InitSensor_7007SB(deviceAddress, 9, *icm202RegArray);

    return(returnStatus);
}

SINT32 icm202SensorSetFrameRate15fps(void)
{

    SINT32 returnStatus;
    uint16 icm202RegArray[9][2] = {

        0x3a, 0x00, // disable AE
        0x0e, 0x40, // frame height - 30fps
        0x0f, 0x03,
        0x1c, 0x3F,
        0x1d, 0x03,
        0x3b, 0x78,
        0x3c, 0x66,
        0x3a, 0x0f,
        0x00, 0x84
    };

    returnStatus = I2C_InitSensor_7007SB(deviceAddress, 9, *icm202RegArray);

    return(returnStatus);

}


SINT32 icm202SensorSetFrameRate24fps(void)
{
    SINT32 returnStatus;
    uint16 icm202RegArray[9][2] = {

        0x3a, 0x00, // disable AE
        0x0e, 0x0a, // frame height - 24fps
        0x0f, 0x02,
        0x1c, 0x09,
        0x1d, 0x02,
        0x3b, 0x70,
        0x3c, 0x60,
        0x3a, 0x0f,
        0x00, 0x84
    };

    returnStatus = I2C_InitSensor_7007SB(deviceAddress, 9, *icm202RegArray);

    return(returnStatus);
}


SINT32 icm202SensorSetXXX(UINT8 regAddr, UINT16 setting)
{
    SINT32 returnStatus;
    uint16 icm202RegArray[2][2] = {

        0x2c, 0x05, // gamma  0 to 6
        0x00, 0x84
    };

    icm202RegArray[0][0] = regAddr;
    icm202RegArray[0][1] = setting;

    returnStatus = I2C_InitSensor_7007SB(deviceAddress, 2, *icm202RegArray);

    return(returnStatus);
}


/* Diags test, written onsite at WIS 08/07/03
 * with Harry Chien (harry.chien@ic-media.com)
 */

/* Stop the DSP in ICM202B, read some known values in the chip */
SINT32 ICM202B_DiagTest(UINT8 dev_addr) 
{
    SINT32 r;
    UINT8 tmp;
    /* Disable auto-functions in address 0x3a so that the DSP does not update
         * this register with a value.
         */
    r = I2C_WriteReg_7007SB(dev_addr, 8, 0x3a, 0x00);   
    r = I2C_WriteReg_7007SB(dev_addr, 8, 0x00, 0x84);   

    /* Peek: 0xa5 to register 20, while DSP has been stopped */
    r = I2C_WriteReg_7007SB(dev_addr, 8, 0x20, 0xa5);   
    r = I2C_WriteReg_7007SB(dev_addr, 8, 0x00, 0x84);   

    /* Wait until next frame */
    osl_msleep (5);

    /* Try to read-back */
    r = I2C_ReadReg_7007SB(dev_addr, 8, 0x20,&tmp);
    if (tmp == 0xa5)
    {
#ifdef VXWORKS      
        logMsg("ICM202B: Diag test passed.\n");
#else
        printf("ICM202B: Diag test passed.\n");
#endif      
    }
    else
    {
#ifdef VXWORKS      
        logMsg("NOTICE: ICM202B Diag test failed - check I2C bus, or replace ICM202B\n");
#else
        printf("NOTICE: ICM202B Diag test failed - check I2C bus, or replace ICM202B\n");
#endif      
        return -1;
    }
    /* Restart DSP */
    r = I2C_WriteReg_7007SB(dev_addr, 8, 0x3a, 0x07);   
    return 0;        
}


void icm202SensorInit(sint32 mode)
{
    SINT32 returnStatus;
    returnStatus = I2C_InitSensor_7007SB(deviceAddress, NUMBER_OF_REG_WRITES, *icm202bInitSequence);

    if (mode == QCIF_MODE)
    {
        icm202SensorSetXXX(0x51, 0x01);
    }

    if (returnStatus != 0)
    {
        printf("Error in I2C call: %d\n", returnStatus);
    }
#if 0
    ICM202B_DiagTest(deviceAddress);
#endif
}

#define OVT_NUMBER_OF_REG_WRITES    40

uint16 ovt7648InitSequence[OVT_NUMBER_OF_REG_WRITES][2] = 
{
    0x12, 0x80,
    0x03, 0xa4,
    0x04, 0x30,
    0x05, 0x88,
    0x06, 0x60,
    0x11, 0x00, /* 1 for 15 fps */
    0x12, 0x15,
    0x13, 0xa3,
    0x14, 0x24, /* bit 5 is QVGA if 1, VGA if 0 */
    0x15, 0x05, /* XXX Todo - modifications from Ruby for green-line bug:  0x17 <= 0x1C, 0x18 <= 0xBC */
    0x1f, 0x40,
    0x20, 0xd0,
    0x23, 0xde,
    0x24, 0xa0,
    0x25, 0x80,
    0x26, 0x32,
    0x27, 0xe2,
    0x28, 0x20,
    0x2a, 0x11, /* was 0x11 */
    0x2b, 0x00,
    0x2d, 0x05,
    0x2f, 0x9c,
    0x30, 0x00,
    0x31, 0xc4,
    0x60, 0x86,
    0x61, 0xe0,
    0x62, 0x88,
    0x63, 0x11,
    0x64, 0x89,
    0x65, 0x00,
    0x67, 0x94,
    0x68, 0x7a,
    0x69, 0x04,
    0x6c, 0x11,
    0x6d, 0x33,
    0x6e, 0x22,
    0x6f, 0x00,
    0x74, 0x20,
    0x75, 0x0e,
    0x77, 0xc4
};

uint16 ovt7640InitSequence[OVT_NUMBER_OF_REG_WRITES+2][2] = 
{
    0x12, 0x80, /* Reset all registers to default values */
    0x03, 0xa4, /* bit[7:4]: saturation */
    0x04, 0x2f, /* bit[5]: hue enable, bit[4:0]: hue */
    0x05, 0x3e, /* Red/Blue Pre-Amplifier gain setting */
    0x06, 0x60, /* bit[7:0]: brightness */
    0x11, 0x00, /* 1 for 15 fps */
    0x12, 0x54, /* bit[4]: YUV format, bit[2]: AWB enable */
    0x13, 0xa3,
    0x14, 0x04, /* bit 5 is QVGA if 1, VGA if 0 */
    0x15, 0x00, /* XXX Todo: - modifications from Ruby for green-line bug:  0x17 <= 0x1C, 0x18 <= 0xBC */
    0x1f, 0x40,
    0x20, 0xd0,
    0x23, 0xde,
    0x24, 0x42,
    0x25, 0x80,
    0x26, 0xa2,
    0x27, 0xe2,
    0x28, 0x20,
    0x2a, 0x90,
    0x2b, 0x5e,
    0x2d, 0x01,
    0x2f, 0x94,
    0x30, 0x40,
    0x31, 0xa0,
    0x60, 0x06,
    0x61, 0xe0,
    0x62, 0x88,
    0x63, 0x11,
    0x64, 0x89,
    0x65, 0x00,
    0x67, 0x94,
    0x68, 0x7a,
    0x69, 0x08,
    0x6c, 0x11,
    0x6d, 0x33,
    0x6e, 0x22,
    0x6f, 0x00,
    0x74, 0x20,
    0x75, 0x86,
    0x77, 0xa6,
    0x01, 0x80,
    0x02, 0x80
};

#define OV7648_CHOOSE_VGA       0
#define OV7648_CHOOSE_QVGA      1

void ovtSensorInit(sint32 s32Mode, uint16 *pu16OvtInitSequence_org, uint32 u32NumWrites, sensorControl_t sensorCtrl)
{

    status_t returnStatus;

    sint32 setting,tmp;

    uint16 pu16OvtInitSequence[2*(OVT_NUMBER_OF_REG_WRITES+2)];

    memcpy(pu16OvtInitSequence,pu16OvtInitSequence_org,sizeof(uint16)*2*OVT_NUMBER_OF_REG_WRITES);

    i2cMode = I2C_MODE_SCCB;

    if (s32Mode > VGA_MODE)
    {                                   
        printf("ERROR: Invalid setting:  Maximum size for an OVT sensor is VGA\n");
        returnStatus = ENCODER_FAILURE;
        return;
    }

    if(pu16OvtInitSequence_org==(*ovt7640InitSequence))
    {
        /* EncoderSetSensorPLF((uint16) sensorCtrl.power_line_freq);
         * power_line_freq is 60 by default
         */
        if(sensorCtrl.power_line_freq==50)
        {
            pu16OvtInitSequence[2*18+1] = 0xB0;
            pu16OvtInitSequence[2*19+1] = 0x08;
        }
        /* EncoderSetSensorBrightness((uint16) sensorCtrl.brightness); */
        setting = sensorCtrl.brightness>100? 100:sensorCtrl.brightness;
        setting = setting*255/100;
        pu16OvtInitSequence[2*4+1] = (uint16) setting;

        /* EncoderSetSensorHue(sensorCtrl.hue); */
        setting = sensorCtrl.hue + 50;
        setting = setting<0? 0:setting;
        setting = setting>100? 100:setting;
        setting = (setting*31/100) | 0x0020;
        pu16OvtInitSequence[2*2+1] = (uint16) setting;
 
        /* EncoderSetSensorSaturation((uint16) sensorCtrl.saturation); */
        setting = sensorCtrl.saturation>100? 100:sensorCtrl.saturation;
        setting = ((setting*15/100)<<4) | 0x4;
        pu16OvtInitSequence[2*1+1] = (uint16) setting;
 
        /* EncoderSetSensorWhiteBalance(sensorCtrl);
         * AWB is enabled by default
         */
        setting = sensorCtrl.wb_redpre>100? 100:sensorCtrl.wb_redpre;
        setting = setting*15/100;
        setting = setting<<4;
        tmp = sensorCtrl.wb_bluepre>100? 100:sensorCtrl.wb_bluepre;
        tmp = tmp*15/100;
        setting = tmp | setting;
        pu16OvtInitSequence[2*3+1] = (uint16) setting;
        if(sensorCtrl.wb_mode==CUSTOMIZED_WHITE_BALANCE)
        {
            u32NumWrites += 2;
            pu16OvtInitSequence[2*6+1] = 0x50;
            setting = sensorCtrl.wb_redchl>100? 100:sensorCtrl.wb_redchl;
            setting = setting*255/100;
            pu16OvtInitSequence[2*41+1] = (uint16) setting;
            setting = sensorCtrl.wb_bluechl>100? 100:sensorCtrl.wb_bluechl;
            setting = setting*255/100;
            pu16OvtInitSequence[2*40+1] = (uint16) setting;
        }
    }

    returnStatus = I2C_InitSensor_7007SB(deviceAddress, u32NumWrites, pu16OvtInitSequence);

    /* we disable ov7640 qvga mode to avoid potential problem
    if (s32Mode > QVGA_MODE)
        ov7648SensorSetVga(OV7648_CHOOSE_VGA);
    */

    if (returnStatus != 0)
    {
        printf("Error in I2C call: %d\n", returnStatus);
    }

    /* XXX Todo: - should return status here */
}


void sensorOvtTestReads(sint32 numReads)
{
    uint8 reg_data;
    sint32 retStatus, i;

    for (i=0; i < numReads; i++)
    {
        retStatus = I2C_ReadReg_7007SB(0x42, 8,
                                       ovt7648InitSequence[i][0], &reg_data);
        printf("retStatus = 0x%x, reg_data = 0x%x\n", retStatus, reg_data);
        osl_msleep (50);
    }
}

void sensorIcmTestReads(sint32 numReads)
{
    uint8 reg_data;
    sint32 retStatus, i;

    for (i=0; i < numReads; i++)
    {
        retStatus = I2C_ReadReg_7007SB(0x42, 8,
                                       icm202bInitSequence[i][0], &reg_data);
        printf("retStatus = 0x%x, reg_data = 0x%x\n", retStatus, reg_data);
        osl_msleep (50);
    }
}

SINT32 ov7648SensorSetXXX(UINT8 regAddr, UINT16 setting)
{
    SINT32 returnStatus;
    uint16 ovt7648RegArray[1][2] = {
        0x03, 0x84   /* saturation to 0x84 */
    };

    ovt7648RegArray[0][0] = regAddr;
    ovt7648RegArray[0][1] = setting;

    returnStatus = I2C_InitSensor_7007SB(deviceAddress, 1, *ovt7648RegArray);

    return(returnStatus);
}

SINT32 ov7648SensorSetVga(sint32 vgaOrQvga)
{
    SINT32 returnStatus=SUCCESS;
    
    if (vgaOrQvga == OV7648_CHOOSE_VGA)
    {
        returnStatus = ov7648SensorSetXXX(0x14, 0x04);
        returnStatus = ov7648SensorSetXXX(0x15, 0x04);
    }
    
    if (vgaOrQvga == OV7648_CHOOSE_QVGA)
    {
        returnStatus = ov7648SensorSetXXX(0x14, 0x24);
        returnStatus = ov7648SensorSetXXX(0x15, 0x05);
    }
    
    return(returnStatus);
}

#define SAA7113_DEVICE_ADDR                 0x4A
#define SAA7113_NUMBER_OF_REG_WRITES        67
uint16 saa7113InitSequence[SAA7113_NUMBER_OF_REG_WRITES][2] = 
{
    { 0x00, 0x20 },
    { 0x01, 0x08 },
    { 0x02, 0xc9 },
    { 0x03, 0x33 },
    { 0x04, 0x00 },
    { 0x05, 0x00 },
    { 0x06, 0xe9 },
    { 0x07, 0x0d },
    { 0x08, 0xd8 },
    { 0x09, 0x81 },
    { 0x0a, 0x80 },
    { 0x0b, 0x47 },
    { 0x0c, 0x40 },
    { 0x0d, 0x00 },
    { 0x0e, 0x01 },
    { 0x0f, 0x2a },
    { 0x10, 0x48 }, //from USB_LINUX_SDK, was { 0x10, 0x00 },
    { 0x11, 0x0c },
    { 0x12, 0xfe }, //from USB_LINUX_SDK, was { 0x12, 0xa7 },
    { 0x13, 0x00 },
    { 0x14, 0x00 },
    { 0x15, 0x04 }, //from USB_LINUX_SDK, was { 0x15, 0x00 },
    { 0x16, 0x00 },
    { 0x17, 0x00 },
    { 0x18, 0x00 },
    { 0x19, 0x00 },
    { 0x1a, 0x00 },
    { 0x1b, 0x00 },
    { 0x1c, 0x00 },
    { 0x1d, 0x00 },
    { 0x1e, 0x00 },
    { 0x1f, 0xc8 },
    { 0x40, 0x00 },
    { 0x41, 0xff },
    { 0x42, 0xff },
    { 0x43, 0xff },
    { 0x44, 0xff },
    { 0x45, 0xff },
    { 0x46, 0xff },
    { 0x47, 0xff },
    { 0x48, 0xff },
    { 0x49, 0xff },
    { 0x4a, 0xff },
    { 0x4b, 0xff },
    { 0x4c, 0xff },
    { 0x4d, 0xff },
    { 0x4e, 0xff },
    { 0x4f, 0xff },
    { 0x50, 0xff },
    { 0x51, 0xff },
    { 0x52, 0xff },
    { 0x53, 0xff },
    { 0x54, 0xff },
    { 0x55, 0xff },
    { 0x56, 0xff },
    { 0x57, 0xff },
    { 0x58, 0x00 },
    { 0x59, 0x54 },
    { 0x5a, 0x07 },
    { 0x5b, 0x83 },
    { 0x5c, 0x00 },
    { 0x5d, 0x00 },
    { 0x5e, 0x00 },
    { 0x5f, 0x00 },
    { 0x60, 0x00 },
    { 0x61, 0x00 },
    { 0x63, 0x00 },
};


extern sint32 videoInputSource;
void saa7113Init(sint32 mode)
{
    SINT32 returnStatus;

    if (videoInputSource == INPUT_SOURCE_COMPOSITE)
    {
        saa7113InitSequence[2][1] = 0xC0;
        saa7113InitSequence[9][1] = 0x40;
    }

    if (videoInputSource == INPUT_SOURCE_SVIDEO)
    {
        saa7113InitSequence[2][1] = 0xC9;
        saa7113InitSequence[9][1] = 0x81;
    }
        
    returnStatus = I2C_InitSensor_7007SB(SAA7113_DEVICE_ADDR,
                                         SAA7113_NUMBER_OF_REG_WRITES,
                                         *saa7113InitSequence);

    if (returnStatus != 0)
    {
        printf("Error in I2C call: %d\n", returnStatus);
    }
}

#define LZ24BP_NUMBER_OF_REG_WRITES     156
uint16 lz24bpInitSequence[LZ24BP_NUMBER_OF_REG_WRITES][3] = 
{
#if 1
    { 0xe8, 0x00, 0x20 },
    { 0xe8, 0x00, 0x00 },
    { 0xd4, 0x00, 0x2b },
    { 0x08, 0x00, 0x08 },
    { 0xd7, 0x00, 0x20 },
    { 0x94, 0x00, 0x20 },
    { 0xd8, 0x00, 0x20 },
    { 0x24, 0x00, 0x20 },
    { 0x64, 0x00, 0x20 },
    { 0xa4, 0x00, 0x00 },
    { 0x37, 0x00, 0x00 },
    { 0xb7, 0x00, 0x24 },
    { 0x77, 0x00, 0x2c },
    { 0xf7, 0x00, 0x04 },
    { 0x0f, 0x00, 0x1c },
    { 0x8f, 0x00, 0x20 },
    { 0x4f, 0x00, 0x0c },
    { 0xcf, 0x00, 0x0c },
    { 0x2f, 0x00, 0x20 },
    { 0xaf, 0x00, 0x31 },
    { 0x6f, 0x00, 0x00 },
    { 0xef, 0x00, 0x0c },
    { 0x1f, 0x00, 0x0c },
    { 0xdf, 0x00, 0x0c },
    { 0x3f, 0x00, 0x0c },
    { 0xbf, 0x00, 0x00 },
    { 0x7f, 0x00, 0x00 },
    { 0xff, 0x00, 0x00 },
    { 0x00, 0x02, 0x37 },
    { 0x80, 0x02, 0x00 },
    { 0x40, 0x02, 0x00 },
    { 0xc0, 0x02, 0x24 },
    { 0x60, 0x02, 0x0c },
    { 0xe0, 0x02, 0x0c },
    { 0x10, 0x02, 0x20 },
    { 0x90, 0x02, 0x00 },
    { 0x3a, 0x02, 0x00 },
    { 0xba, 0x02, 0x31 },
    { 0x7a, 0x02, 0x00 },
    { 0xfa, 0x02, 0x38 },
    { 0x06, 0x02, 0x20 },
    { 0x86, 0x02, 0x0c },
    { 0x46, 0x02, 0x0c },
    { 0xc6, 0x02, 0x20 },
    { 0x31, 0x02, 0x00 },
    { 0xb1, 0x02, 0x00 },
    { 0x49, 0x02, 0x0c },
    { 0xc9, 0x02, 0x00 },
    { 0x19, 0x02, 0x06 },
    { 0x99, 0x02, 0x00 },
    { 0x79, 0x02, 0x06 },
    { 0xf9, 0x02, 0x00 },
    { 0xe1, 0x02, 0x00 },
    { 0x11, 0x02, 0x14 },
    { 0x71, 0x02, 0x14 },
    { 0x29, 0x02, 0x14 },
    { 0x59, 0x02, 0x14 },
    { 0x91, 0x02, 0x20 },
    { 0xf1, 0x02, 0x00 },
    { 0xa9, 0x02, 0x20 },
    { 0xd9, 0x02, 0x00 },
    { 0x61, 0x02, 0x00 },
    { 0x4d, 0x02, 0x00 },
    { 0xcd, 0x02, 0x00 },
    { 0x1d, 0x02, 0x0c },
    { 0x9d, 0x02, 0x00 },
    { 0x7d, 0x02, 0x00 },
    { 0xfd, 0x02, 0x00 },
    { 0x23, 0x02, 0x08 },
    { 0xa3, 0x02, 0x10 },
    { 0x75, 0x02, 0x14 },
    { 0x2d, 0x02, 0x14 },
    { 0x5d, 0x02, 0x20 },
    { 0x03, 0x02, 0x20 },
    { 0xf5, 0x02, 0x20 },
    { 0xad, 0x02, 0x00 },
    { 0xdd, 0x02, 0x20 },
    { 0x83, 0x02, 0x00 },
    { 0x35, 0x02, 0x00 },
    { 0x21, 0x02, 0x0c },
    { 0xa1, 0x02, 0x0c },
    { 0x55, 0x02, 0x0c },
    { 0xd5, 0x02, 0x0c },
    { 0x02, 0x01, 0x00 },
    { 0x36, 0x02, 0x00 },
    { 0xb6, 0x02, 0x12 },
    { 0x76, 0x02, 0x00 },
    { 0xf6, 0x02, 0x20 },
    { 0x0e, 0x02, 0x32 },
    { 0x8e, 0x02, 0x00 },
    { 0x4e, 0x02, 0x00 },
    { 0x8a, 0x01, 0x20 },
    { 0x4a, 0x01, 0x25 },
    { 0xca, 0x01, 0x38 },
    { 0x2a, 0x01, 0x39 },
    { 0xaa, 0x01, 0x04 },
    { 0x6a, 0x01, 0x00 },
    { 0xea, 0x01, 0x0e },
    { 0x1a, 0x01, 0x02 },
    { 0x9a, 0x01, 0x0a },
    { 0x5a, 0x01, 0x12 },
    { 0xa6, 0x01, 0x12 },
    { 0x66, 0x01, 0x00 },
    { 0xe6, 0x01, 0x00 },
    { 0x16, 0x01, 0x00 },
    { 0x96, 0x01, 0x00 },
    { 0x56, 0x01, 0x20 },
    { 0xf6, 0x01, 0x0f },
    { 0x0e, 0x01, 0x3f },
    { 0x44, 0x00, 0x20 },
    { 0xc4, 0x00, 0x20 },
    { 0xa5, 0x00, 0x00 },
    { 0x65, 0x00, 0x00 },
    { 0xe5, 0x00, 0x31 },
    { 0x15, 0x00, 0x00 },
    { 0x95, 0x00, 0x35 },
    { 0x55, 0x00, 0x20 },
    { 0xbd, 0x00, 0x20 },
    { 0x7d, 0x00, 0x35 },
    { 0xfd, 0x00, 0x20 },
    { 0x03, 0x00, 0x37 },
    { 0x83, 0x00, 0x20 },
    { 0x8e, 0x01, 0x20 },
    { 0x4e, 0x01, 0x04 },
    { 0xce, 0x01, 0x20 },
    { 0x2e, 0x01, 0x3e },
    { 0xae, 0x01, 0x20 },
    { 0x6e, 0x01, 0x04 },
    { 0xee, 0x01, 0x20 },
    { 0x1e, 0x01, 0x3e },
    { 0x9e, 0x01, 0x20 },
    { 0x5e, 0x01, 0x28 },
    { 0xde, 0x01, 0x10 },
    { 0x60, 0x00, 0x24 },
    { 0x87, 0x00, 0x20 },
    { 0x47, 0x00, 0x20 },
    { 0x17, 0x00, 0x20 },
    { 0xe0, 0x00, 0x01 },
    { 0x10, 0x00, 0x03 },
    { 0x90, 0x00, 0x04 },
    { 0x50, 0x00, 0x01 },
    { 0x40, 0x00, 0x03 },
    { 0xc0, 0x00, 0x18 },
    { 0x97, 0x00, 0x01 },
    { 0x57, 0x00, 0x37 },
    { 0xb1, 0x00, 0x20 },
    { 0x71, 0x00, 0x14 },
    { 0xf1, 0x00, 0x00 },
    { 0x09, 0x00, 0x1e },
    { 0x89, 0x00, 0x00 },
    { 0x20, 0x00, 0x00 },
    { 0xa0, 0x00, 0x10 },
    { 0x78, 0x00, 0x20 },
    { 0x18, 0x00, 0x20 },
    { 0xd8, 0x00, 0x00 },
    { 0x04, 0x00, 0x00 },
#else
    0x17, 0, 0x1,       // software_reset 1
    0x17, 0, 0x0,       //  software_reset 1
    0x2b, 0, 0x35,      //  initial1 1
    0x10, 0, 0x4,       //  initial2 1
    0xeb, 0, 0x1,       //  vd/hd_slave0/master1 1
    0x29, 0, 0x1,       //  TG_core_reset 1
    0x1b, 0, 0x1,       //  VD_update_2nd_rank 1
    0x24, 0, 0x1,       //  sync_enable 1
    0x26, 0, 0x1,       //  sync_suspend 1
    0x25, 0, 0x0,       // sync_polarity 1
    0xec, 0, 0x0,       //  vd/hd_pol 1
    0xed, 0, 0x9,       // vd_rise_edge 1
    0xee, 0, 0xd,       //  vd_field_length_l 1
    0xef, 0, 0x8,       //  vd_field_length_h 1
    0xf0, 0, 0xe,       //  hd_rise_edge_l 1
    0xf1, 0, 0x1,       //  hd_rise_edge_h 1
    0xf2, 0, 0xc,       //  hd_line_length_l 1
    0xf3, 0, 0xc,       //  hd_line_length_h 1
    0xf4, 0, 0x1,       //  seq0_strt_pol 1
    0xf5, 0, 0x23,      //  seq0_tog1_l 1
    0xf6, 0, 0x0,       //  seq0_tog1_h 1
    0xf7, 0, 0xc,       //  seq0_tog2_l 1
    0xf8, 0, 0xc,       //  seq0_tog2_h 1
    0xfb, 0, 0xc,       //  seq0_length_l 1
    0xfc, 0, 0xc,       //  seq0_length_h 1
    0xfd, 0, 0x0,       //  seq0_reps_l 1
    0xfe, 0, 0x0,       //  seq0_reps_h 1
    0xff, 0, 0x0,       //  seq1_strt_pol 1
    0x0, 1, 0x3b,       //  seq1_tog1_l 1
    0x1, 1, 0x0,        // seq1_tog1_h 1
    0x2, 1, 0x0,        //  seq1_tog2_l 1
    0x3, 1, 0x9,        //  seq1_tog2_h 1
    0x6, 1, 0xc,        //  seq1_length_l 1
    0x7, 1, 0xc,        //  seq1_length_l 1
    0x8, 1, 0x1,        //  seq1_reps_l 1
    0x9, 1, 0x0,        //  seq1_reps_h 1
    0x5c, 1, 0x0,       //  seq10_strt_pol 1
    0x5d, 1, 0x23,      //  seq10_tog1_l 1
    0x5e, 1, 0x0,       //  seq10_tog1_h 1
    0x5f, 1, 0x7,       //  seq10_tog2_l 1
    0x60, 1, 0x1,       //  seq10_tog2_h 1
    0x61, 1, 0xc,       //  seq10_length_l 1
    0x62, 1, 0xc,       //  seq10_length_l 1
    0x63, 1, 0x1,       //  seq10_reps_l 1
    0x8c, 1, 0x0,       //  reg0_v1_strt_l 1
    0x8d, 1, 0x0,       //  reg0_v1_strt_h 1
    0x92, 1, 0xc,       //  reg0_v2_strt_l 1
    0x93, 1, 0x0,       //  reg0_v2_strt_h 1
    0x98, 1, 0x18,      //  reg0_v3_strt_l 1
    0x99, 1, 0x0,       //  reg0_v3_strt_h 1
    0x9e, 1, 0x18,      //  reg0_v4_strt_l 1
    0x9f, 1, 0x0,       //  reg0_v4_strt_h 1
    0x87, 1, 0x0,       //  vtp_seq_alt_reg0 1
    0x88, 1, 0xa,       //  reg0_v1_seq_ptr 1
    0x8e, 1, 0xa,       //  reg0_v2_seq_ptr 1
    0x94, 1, 0xa,       //  reg0_v3_seq_ptr 1
    0x9a, 1, 0xa,       //  reg0_v4_seq_ptr 1
    0x89, 1, 0x1,       //  V1_invert 1
    0x8f, 1, 0x0,       //  V2_invert 1
    0x95, 1, 0x1,       //  V3_invert 1
    0x9b, 1, 0x0,       //  V4_invert 1
    0x86, 1, 0x0,       //  hblk_seq_ptr_reg0 1
    0xb2, 1, 0x0,       //  reg1_v1_strt_l 1
    0xb3, 1, 0x0,       //  reg1_v1_strt_h 1
    0xb8, 1, 0xc,       //  reg1_v2_strt_l 1
    0xb9, 1, 0x0,       //  reg1_v2_strt_h 1
    0xbe, 1, 0x0,       //  reg1_v3_strt_l 1
    0xbf, 1, 0x0,       //  reg1_v3_strt_h 1
    0xc4, 1, 0x4,       //  reg1_v4_strt_l 1
    0xc5, 1, 0x2,       //  reg1_v4_strt_h 1
    0xae, 1, 0xa,       //  reg1_v1_seq_ptr 1
    0xb4, 1, 0xa,       //  reg1_v2_seq_ptr 1
    0xba, 1, 0x1,       //  reg1_v3_seq_ptr 1
    0xc0, 1, 0x1,       //  reg1_v4_seq_ptr 1
    0xaf, 1, 0x1,       //  v1_seq_invert 1
    0xb5, 1, 0x0,       //  v2_seq_invert 1
    0xbb, 1, 0x1,       //  v3_seq_invert 1
    0xc1, 1, 0x0,       //  v4_seq_invert 1
    0xac, 1, 0x0,       //  hblk_seq_ptr_reg1 1
    0x84, 1, 0xc,       //  reg0_hd_length_l 1
    0x85, 1, 0xc,       //  reg0_hd_length_h 1
    0xaa, 1, 0xc,       //  reg1_hd_length_l 1
    0xab, 1, 0xc,       //  reg1_hd_length_h 1
    0x40, 2, 0x0,       //  vtp_2nd_seq_out_en 1
    0x6c, 1, 0x0,       //  v_reg_chng_ptr0 1
    0x6d, 1, 0x12,      //  v_reg_chng_pos1_l 1
    0x6e, 1, 0x0,       //  v_reg_chng_pos1_h 1
    0x6f, 1, 0x1,       //  v_reg_chng_ptr1 1
    0x70, 1, 0x13,      //  v_reg_chng_pos2_l 1
    0x71, 1, 0x0,       //  v_reg_chng_pos2_h 1
    0x72, 1, 0x0,       //  v_reg_chng_ptr2 1
    0x51, 2, 0x1,       // vsg_seq0_strt_pol 1
    0x52, 2, 0x29,      //  vsg_seq0_tog1_l 1
    0x53, 2, 0x7,       //  vsg_seq0_tog1_h 1
    0x54, 2, 0x27,      //  vsg_seq0_tog2_l 1
    0x55, 2, 0x8,       //  vsg_seq0_tog2_h 1
    0x56, 2, 0x0,       //  vsg_seq1_strt_pol 1
    0x57, 2, 0x1c,      //  vsg_seq1_tog1_l 1
    0x58, 2, 0x10,      //  vsg_seq1_tog1_h 1
    0x59, 2, 0x14,      //  vsg_seq1_tog2_l 1
    0x5a, 2, 0x12,      //  vsg_seq1_tog2_h 1
    0x65, 2, 0x12,      //  vsg_active_l 1
    0x66, 2, 0x0,       // vsg_active_h 1
    0x67, 2, 0x0,       //  vsg1_sel 1
    0x68, 2, 0x0,       //  vsg2_sel 1
    0x69, 2, 0x0,       //  vsg3_sel 1
    0x6a, 2, 0x1,       //  vsg4_sel 1
    0x6f, 2, 0x3c,      //  vsg_mask_l 1
    0x70, 2, 0x3f,      //  vsg_mask_h 1
    0x22, 0, 0x1,       //  retime_h1/h2 1
    0x23, 0, 0x1,       //  retime_h3/h4 1
    0xa5, 0, 0x0,       // hblk_seq0_h1_mask_pol 1
    0xa6, 0, 0x0,       //  hblk_seq0_h3_mask_pol 1
    0xa7, 0, 0x23,      //  hblk_seq0_togh_l 1
    0xa8, 0, 0x0,       //  hblk_seq0_togh_h 1
    0xa9, 0, 0x2b,      //  hblk_seq0_togl_l 1
    0xaa, 0, 0x1,       //  hblk_seq0_togl_h 1
    0xbd, 0, 0x1,       //  pblk_seq0_strt_pol 1
    0xbe, 0, 0x2b,      //  pblk_seq0_tog1_l 1
    0xbf, 0, 0x1,       //  pblk_seq0_tog1_l 1
    0xc0, 0, 0x3b,      //  pblk_seq0_tog2_l 1
    0xc1, 0, 0x1,       //  pblk_seq0_tog2_l 1
    0x71, 2, 0x1,       //  subck_strt_pol 1
    0x72, 2, 0x8,       // subck_1_tog1_l 1
    0x73, 2, 0x1,       //  subck_1_tog1_h 1
    0x74, 2, 0x1f,      //  subck_1_tog2_l 1
    0x75, 2, 0x1,       //  subck_1_tog2_h 1
    0x76, 2, 0x8,       //  subck_2_tog1_l 1
    0x77, 2, 0x1,       //  subck_2_tog1_h 1
    0x78, 2, 0x1f,      //  subck_2_tog2_l 1
    0x79, 2, 0x1,       //  subck_2_tog2_h 1
    0x7a, 2, 0x30,      //  subck_num_l 1
    0x7b, 2, 0x5,       //  subck_num_h 1
    0x6,  0, 0x9,       //  CTLMODE 1
    0xe1, 0, 0x1,       //  h1_drive 1
    0xe2, 0, 0x1,       //  h2_drive 1
    0xe8, 0, 0x1,       //  rg_drive 1
    0x7,  0, 0x20,      //  gain0 1
    0x8,  0, 0x30,      //  gain1 1
    0x9,  0, 0x8,       //  gain2 1
    0xa,  0, 0x20,      //  gain3 1
    0x2,  0, 0x30,      //  ccdgain_l 1
    0x3,  0, 0x6,       //  ccdgain_h 1
    0xe9, 0, 0x20,      //  shploc 1
    0xea, 0, 0x3b,      //  shdloc 1
    0x8d, 0, 0x1,       //  clpOB_pol 1
    0x8e, 0, 0xa,       //  clpOB_tog1_l 1
    0x8f, 0, 0x0,       //  clpOB_tog1_h 1
    0x90, 0, 0x1e,      //  clpOB_tog2_l 1
    0x91, 0, 0x0,       //  clpOB_tog2_h 1
    0x4,  0, 0x0,       //  ref_black_l 1
    0x5,  0, 0x2,       // ref_black_h 1
    0x1e, 0, 0x1,       //  dclk_mode 1
    0x18, 0, 0x1,       //  out_cont 1
    0x1b, 0, 0x0,       // VD_update_2nd_rank 1
    0x20, 0, 0x0        //  DC-RST 1
#endif
};         


void sharpSensorInit(sint32 s32Mode, uint16 *pu16SharpInitSequence,
                     uint32 u32NumWrites)
{
    status_t returnStatus;

    spiMode = SPI_MODE_3;

    /* the sharp sensor requires that the bus be configured before */
    /* you can actually program it */
    WriteInterrupt(0x4007, 2);

    returnStatus = SPI_InitSensor_7007SB(u32NumWrites,
                                         pu16SharpInitSequence);
    
    if (returnStatus != 0)
    {
        printf("Error in I2C call: %d\n", returnStatus);
    }
}

/******************************************************************************
*
*   PROCEDURE:  
*       void sensorInit(sint32 mode, sint32 sensorType, sensorControl_t sensorCtrl)
*
*   DESCRIPTION:
*       Initialize the sensor given the sensor type and the mode.
*  
*   ARGUMENTS:
*
*       mode - sensor output mode (ie VGA, D1, etc.)
*       sensorType - the exact sensor type to initialize
*       sensorCtrl - 
*
*   RETURNS:
*
*       NONE
*
*   NOTES:
*
******************************************************************************/

void sensorInit(sint32 mode, sint32 sensorType, sensorControl_t sensorCtrl)
{
    switch(sensorType)
    {
        case SENSOR_TYPE_OV7648:
            ovtSensorInit(mode, *ovt7648InitSequence, OVT_NUMBER_OF_REG_WRITES, sensorCtrl);
            break;
            
        case SENSOR_TYPE_OV7640:
            ovtSensorInit(mode, *ovt7640InitSequence, OVT_NUMBER_OF_REG_WRITES, sensorCtrl);
            /*EncoderSetSensorPLF((uint16) sensorCtrl.power_line_freq);
            EncoderSetSensorBrightness((uint16) sensorCtrl.brightness);
            EncoderSetSensorHue(sensorCtrl.hue);
            EncoderSetSensorSaturation((uint16) sensorCtrl.saturation);
            EncoderSetSensorWhiteBalance(sensorCtrl);*/
            break;
            
        case SENSOR_TYPE_LZ24BP:
            printf("Sharp Sensor Init\n");
            sharpSensorInit(mode, *lz24bpInitSequence, LZ24BP_NUMBER_OF_REG_WRITES);
            break;

        case SENSOR_TYPE_ICM202B:
            icm202SensorInit(mode);
            break;
            
        case SENSOR_TYPE_SAA7113:
	    printf("Init 7113 input device %d\n", videoInputSource);
            saa7113Init(mode);
            break;
            
        default:
            printf("*** Unknown Sensor Type ***\n");
    }
}

/************************ end of sensor_init.c ******************************/
