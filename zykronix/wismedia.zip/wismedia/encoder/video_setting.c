#include "wis_types.h"
#include "wis_error.h"
#include "wsdf.h"
#include "struct.h"
#include "wis_encoder.h"
#include "encoder_driver.h"
#include "multimedia.h"
#include "platform.h"
#include "os.h"

#ifdef VXWORKS
#include "stdLib.h"
#endif
#include "pacgen.h"

/* the default buffer size is the max size of 512 words */
sint32 g_encoderBufferSize=512;

TCFGVIDEOEX encoderVariableSettings;
extern TVIDEOCFGFIX encoderFixedSettings;

sint32 encoderMode;
sint32 sensorMode;
sint32 sensorType=SENSOR_TYPE_UNINITIALIZED;
sint32 videoInputSource = INPUT_SOURCE_SVIDEO;
osdString_t osdStr={0, OSD_LANGUAGE_ENGLISH, "", 1, 1, 255};
sensorControl_t sensorCtrl={60, 38, 50, 50, 68, AUTO_WHITE_BALANCE, 55, 55, 50, 50};

encoderCapabilities_t g_currentEncoderMode;

/* the default input frame rate is 30fps */
sint32 g_inputFrameRate = 30;

int sample2timestamp(int sample_per_sec, int audiocap)
{
    int BlockSize = 256;
    int channels = encoderFixedSettings.audiocfg.left_channel_only? 1:2;
    int BitsPerSample = 4;
    int BlockHead, sample_per_block;
    int timestamp_per_block = BlockSize*8/16;
    if((audiocap&CAP_AUDIO_FORMAT_Mask)==CAP_AUDIO_FORMAT_ADPCM_MS)
    {
        /* M$_ADPCM */
        encoderFixedSettings.audiocfg.word_length = 4;
        encoderFixedSettings.audiocfg.adpcm_enable = 1;
        encoderFixedSettings.audiocfg.adpcm_mode = 1;
        BlockHead = 7;
        sample_per_block = (BlockSize-BlockHead*channels)*8/BitsPerSample/channels+2;
    }
    else if((audiocap&CAP_AUDIO_FORMAT_Mask)==CAP_AUDIO_FORMAT_ADPCM_IMA)
    {
        /* IMA_ADPCM */
        encoderFixedSettings.audiocfg.word_length = 4;
        encoderFixedSettings.audiocfg.adpcm_enable = 1;
        encoderFixedSettings.audiocfg.adpcm_mode = 0;
        BlockHead = 4;
        sample_per_block = (BlockSize-BlockHead*channels)*8/BitsPerSample/channels+1;
    }
    else
    {
        /* by default is PCM */
        sample_per_block = 1;
        timestamp_per_block = 1;
    }
    return sample_per_sec*timestamp_per_block/sample_per_block;
}

void ED_SetInitialVideoSettings(void)
{
    encoderMode = ENCODER_MODE_MPEG4;

    encoderVariableSettings.syscfg.tv_standard = TVStandard_None; 
    encoderVariableSettings.syscfg.sensor_h = 640; // for ICM (436)sensor (greater than 352)
    encoderVariableSettings.syscfg.sensor_v = 480; // for ICM (400)sensor (greater than 288)
    encoderVariableSettings.syscfg.format = 0; // 0: progressive, 1: interlaced, 2: RGB bayer
    encoderVariableSettings.syscfg.sensor_656_mode = 0;
    encoderVariableSettings.syscfg.framerate = 30000;
    encoderVariableSettings.syscfg.hv_resync_enable = 0;
    encoderVariableSettings.syscfg.vref_polar = 1; // 1 for OVT, 0 for ICM

    encoderVariableSettings.strcfg.sequence = IPONLY;       // 'MultiMedia.h': ESequenceMode
    encoderVariableSettings.strcfg.compress_mode = MPEG4;   // 'MultiMedia.h': EVideoFormat
    encoderVariableSettings.strcfg.gop_mode = 0;            // 0: open GOP, 1: closed GOP
    encoderVariableSettings.strcfg.deinterlace_mode = 0;    // 0: use one field, 1: deinterlace, 2: interlace coding
    encoderVariableSettings.strcfg.search_range = 128;      // motion search range, should be 16,32,64 or 128
    encoderVariableSettings.strcfg.gop_head_enable = 1;     // 0: disable, 1: enable
    encoderVariableSettings.strcfg.seq_head_enable = 1;     // 0: disable, 1: enable
    encoderVariableSettings.strcfg.aspect_ratio = 1;        // 1= 1:1, 2= 4:3, 3= 16:9
    encoderVariableSettings.strcfg.DVD_compliant = 0;       // 0: disable, 1: enable
    encoderVariableSettings.strcfg.mpeg4_mode = DIVX_MPEG4;
    
    encoderVariableSettings.misccfg.av_sync_enable = 1;     // 0: disable, 1: enable
    encoderVariableSettings.misccfg.iip_enable = 0;         // 0: disable, 1: enable
    encoderVariableSettings.misccfg.vbi_enable = 0;         // 0: disable, 1: enable
    encoderVariableSettings.misccfg.four_channel_enable = 0;// 0: disable, 1: enable
    encoderVariableSettings.misccfg.filter_nAX = 0;         // if(h_filter_mode>0)
    encoderVariableSettings.misccfg.filter_nBX = 0;         //   nAX+nBX+nCX = 16;
    encoderVariableSettings.misccfg.filter_nCX = 0;
    encoderVariableSettings.misccfg.filter_nAY = 0;         // if(v_filter_mode>0)
    encoderVariableSettings.misccfg.filter_nBY = 0;         //   nAY+nBY+nCY = 16;
    encoderVariableSettings.misccfg.filter_nCY = 0;
    encoderVariableSettings.misccfg.h_filter_mode = 0;      // 0: disable, 1: median, 2: LPF
    encoderVariableSettings.misccfg.v_filter_mode = 0;      // 0: disable, 1: median, 2: LPF
    encoderVariableSettings.misccfg.reserved = 0;           // no motion detection

    encoderVariableSettings.fpscfg.tv_standard = TVStandard_None; 
    encoderVariableSettings.fpscfg.frame_rate = 30000; 
    encoderVariableSettings.fpscfg.drop_frame = 0; 
    encoderVariableSettings.fpscfg.ivtc_enable = 0; 
    
    encoderVariableSettings.rescfg.width = 320;             // output stream resolution: horizontal size
    encoderVariableSettings.rescfg.height = 240;            // output stream resolution: vertical size
    encoderVariableSettings.rescfg.h_sub_window = 1;
    encoderVariableSettings.rescfg.v_sub_window = 1;
    encoderVariableSettings.rescfg.h_sub_offset = 0;
    encoderVariableSettings.rescfg.v_sub_offset = 0;
    encoderVariableSettings.rescfg.h_scale_enb = 0;
    encoderVariableSettings.rescfg.v_scale_enb = 0;
    encoderVariableSettings.rescfg.sub_sample = 0;

    encoderVariableSettings.ctlcfg.vbv_buffer = 0;      
    encoderVariableSettings.ctlcfg.converge_speed = 50;     // [0, 100],
    encoderVariableSettings.ctlcfg.lambda = 100;            // [0, 100], from best picture quality to largest framerate
    encoderVariableSettings.ctlcfg.Q = 0;                   // initial quantizer, will devided by 4, for exmaple, 7 represents 1.75
    encoderVariableSettings.ctlcfg.IQ = 0;                  // fixed quantize scale of I frames, only valid for target_rate==0 and Q==0
    encoderVariableSettings.ctlcfg.PQ = 0;                  // fixed quantize scale of P frames
    encoderVariableSettings.ctlcfg.BQ = 0;                  // fixed quantize scale of B frames
    encoderVariableSettings.ctlcfg.reserved = 0x003C1F02;   // more BRC settings
    /*reserved[6:0]  : QMIN=2
     *reserved[7]    : DUP_EN=0
     *reserved[14:8] : QMAX=31
     *reserved[15]   : MB_BRC=0
     *reserved[31:16]: window_size=60 frames
     */
}

/*
 * Function:  EncoderDriverSetBitrateControl - set bitrate of encoder
 * Arguments: targetBitrate - target rate in Kbps 
 *            peakBitrate - the peak bitrate allowed.  As you approach this value, frame duplication becomes more likely.
 *            maxFps - given a sensor input of 30fps, how many frames per second would you like?  If the sensor input is less
 *                     than 30fps, the result will be a ratio  of this (for instance if you request a maxFps of 15 and the sensor
 *                     input is 20fps, then 30:15 is 2, so 20/2 is 10, meaning that you actually get 10fps.
 *            gopSize - allows you to choose your gop_size.  In IBP mode this size MUST be divisible by 3 (since a subGOP is two B frames and an I or P frame)
 *            videoBufferSize - the size of the buffer frames reside in after they come from the encoder
 * Return: ENCODER_XXXX - (SUCCESS/FAIL status code)
 */
status_t ED_SetBitrateControl(uint32 targetBitrate, uint32 peakBitrate, uint32 maxFps, uint32 gopSize, uint32 videoBufferSize, uint32 constQ)
{
  int n = encoderVariableSettings.syscfg.framerate/1000/maxFps - 1;
  n = (n<0)? 0:n;
  encoderVariableSettings.fpscfg.drop_frame = n;
  if(encoderVariableSettings.syscfg.format==1 &&
     encoderVariableSettings.strcfg.deinterlace_mode==0)
  {
     encoderVariableSettings.fpscfg.drop_frame = 2 * encoderVariableSettings.fpscfg.drop_frame + 1;
  }
  encoderVariableSettings.fpscfg.frame_rate = encoderVariableSettings.syscfg.framerate/1000/(n+1)*1001;

  /* Fix from Imoto-san */
  g_encoderBufferSize = 512;

  if(encoderVariableSettings.fpscfg.frame_rate>30000)
  {
    encoderVariableSettings.fpscfg.frame_rate = 30000;
  }
  encoderVariableSettings.strcfg.gop_size = gopSize;           // maximum count of pictures in a group of picture
  encoderVariableSettings.ctlcfg.IQ = constQ;
  encoderVariableSettings.ctlcfg.PQ = constQ;
  encoderVariableSettings.ctlcfg.BQ = constQ;
  if(constQ==0)
  {
    /* non-zero target bitrate (bps) enables WIS adaptive bitrate control */
    encoderVariableSettings.ctlcfg.target_bitrate = targetBitrate*1000;
    if(targetBitrate<4000)
    { 
        encoderVariableSettings.ctlcfg.peak_bitrate = targetBitrate*10000;
        encoderVariableSettings.ctlcfg.vbv_buffer = targetBitrate*10000;
    }
    else
    { 
        encoderVariableSettings.ctlcfg.peak_bitrate = targetBitrate*1200;
        encoderVariableSettings.ctlcfg.vbv_buffer = targetBitrate*1200;
    }
    encoderVariableSettings.ctlcfg.Q = 64;
    if(targetBitrate<=200)
    {
        /* if the bitrate is less than 200kbps, make the buffer smaller */
        /* to prevent frames from getting stuck in the buffer */
        g_encoderBufferSize = 64;
    }
    else if(targetBitrate<700)
    {
        g_encoderBufferSize = 128;
    }
  }
  else
  {
    /* zero target bitrate disables WIS adaptive bitrate control */
    encoderVariableSettings.ctlcfg.target_bitrate = 0;
    encoderVariableSettings.ctlcfg.peak_bitrate = 0;
    encoderVariableSettings.ctlcfg.vbv_buffer = 0;
    encoderVariableSettings.ctlcfg.converge_speed = 0;
    encoderVariableSettings.ctlcfg.lambda = 0;
    encoderVariableSettings.ctlcfg.Q = 0;
  }
  return ENCODER_SUCCESS;
}

/*
 * Function:  EncoderDriverGetBitrateControl - get bitrate of encoder
 * Arguments: targetBitRate - pointer to target rate in Kbps current in device.
 *            peakBitrate - pointer to the current peak bitrate allowed.
 *            maxFps - pointer to the current maximum frames per second.
 *            gopSize - pointer to the current gop_size.
 *            videoBufferSize - size of the video buffer in which frames reside until they are used
 * Return: ENCODER_XXXX - (SUCCESS/FAIL status code)
 */
status_t ED_GetBitrateControl(uint32 *targetBitrate, uint32 *peakBitrate, uint32 *maxFps, uint32 *gopSize, uint32 *videoBufferSize, uint32 *constQ)
{
    int n = encoderVariableSettings.fpscfg.drop_frame;
    if(encoderVariableSettings.syscfg.format==1 &&
       encoderVariableSettings.strcfg.deinterlace_mode==0) n = (n - 1) / 2;
    *gopSize = encoderVariableSettings.strcfg.gop_size;
    *maxFps = encoderVariableSettings.syscfg.framerate/(n + 1);
    *targetBitrate = encoderVariableSettings.ctlcfg.target_bitrate/1000;
    *peakBitrate = encoderVariableSettings.ctlcfg.peak_bitrate/1000;
    *videoBufferSize = encoderVariableSettings.ctlcfg.vbv_buffer;      
    *constQ = encoderVariableSettings.ctlcfg.IQ;      

    return ENCODER_SUCCESS;
}

status_t ED_SetMode(encoderCapabilities_t *modeMask)
{
    status_t returnStatus = ENCODER_SUCCESS;

    /* save the current mode for reference later */
    memcpy(&g_currentEncoderMode, modeMask, sizeof(encoderCapabilities_t));

    /* check for invalid modes */
    if (modeMask->modesSupported & ENCODER_MODE_H264)
        returnStatus = ENCODER_INVALID_MODE_SELECTED; 

    if (modeMask->modesSupported & ENCODER_MODE_AV_SYNC)
    {
        encoderVariableSettings.misccfg.av_sync_enable = 1;      // 0: disable, 1: enable
    }

    /* set the encode mode */
    if (modeMask->modesSupported & ENCODER_MODE_MPEG2)
    {
        encoderVariableSettings.strcfg.compress_mode = MPEG2;       // 'MultiMedia.h': EVideoFormat
        encoderVariableSettings.strcfg.reserved = 0x1; //repeated seqhead 
        encoderMode = ENCODER_MODE_MPEG2;
    }

    if (modeMask->modesSupported & ENCODER_MODE_MPEG4)
    {
        encoderVariableSettings.strcfg.compress_mode = MPEG4;       // 'MultiMedia.h': EVideoFormat
        encoderVariableSettings.strcfg.reserved = 0x1; //repeated seqhead 
        encoderMode = ENCODER_MODE_MPEG4;
    }

    if (modeMask->modesSupported & ENCODER_MODE_MPEG1)
    {
        encoderVariableSettings.strcfg.compress_mode = MPEG1;       // 'MultiMedia.h': EVideoFormat
        encoderVariableSettings.strcfg.reserved = 0x1; //repeated seqhead 
        encoderMode = ENCODER_MODE_MPEG1;
    }

    if (modeMask->modesSupported & ENCODER_MODE_MJPEG)
    {
        encoderVariableSettings.strcfg.compress_mode = MOTIONJPEG;  
        encoderMode = ENCODER_MODE_MJPEG;
        encoderVariableSettings.misccfg.av_sync_enable = 0;
    }

    if (modeMask->modesSupported & ENCODER_MODE_H263)
    {
        encoderVariableSettings.strcfg.compress_mode = H263;       // 'MultiMedia.h': EVideoFormat
        encoderMode = ENCODER_MODE_H263;
	encoderVariableSettings.strcfg.search_range = 32;
        encoderVariableSettings.strcfg.gop_mode = 0;
        encoderVariableSettings.strcfg.gop_head_enable = 0;
        encoderVariableSettings.strcfg.seq_head_enable = 0;
        encoderVariableSettings.strcfg.mpeg4_mode = 0;
        encoderVariableSettings.misccfg.av_sync_enable = 0;
    }

    if (modeMask->modesSupported & ENCODER_MODE_IBP)
    {
        encoderVariableSettings.strcfg.sequence = IPB;            // 'MultiMedia.h': ESequenceMode
    }

    if (modeMask->modesSupported & ENCODER_MODE_IP_ONLY)
    {
        encoderVariableSettings.strcfg.sequence = IPONLY;            // 'MultiMedia.h': ESequenceMode
    }

    if (modeMask->modesSupported & ENCODER_MODE_I_ONLY)
    {
        encoderVariableSettings.strcfg.sequence = IONLY;            // 'MultiMedia.h': ESequenceMode
    }

    if (modeMask->modesSupported & ENCODER_MODE_704_X_576)
    {
        sensorMode = FOUR_CIF_MODE;
        encoderVariableSettings.rescfg.h_sub_offset = 8;
        encoderVariableSettings.rescfg.width = 704;
       	encoderVariableSettings.rescfg.height = 576;
    }

    if (modeMask->modesSupported & ENCODER_MODE_704_X_480)
    {
        sensorMode = FOUR_SIF_MODE;
        encoderVariableSettings.rescfg.h_sub_offset = 8;
        encoderVariableSettings.rescfg.width = 704;
       	encoderVariableSettings.rescfg.height = 480;
    }

    if (modeMask->modesSupported & ENCODER_MODE_704_X_288)
    {
        sensorMode = TWO_CIF_MODE;
        encoderVariableSettings.rescfg.h_sub_offset = 8;
        encoderVariableSettings.rescfg.width = 704;
       	encoderVariableSettings.rescfg.height = 288;
        encoderVariableSettings.rescfg.v_scale_enb = 1;
    }

    if (modeMask->modesSupported & ENCODER_MODE_704_X_240)
    {
        sensorMode = TWO_SIF_MODE;
        encoderVariableSettings.rescfg.h_sub_offset = 8;
        encoderVariableSettings.rescfg.width = 704;
       	encoderVariableSettings.rescfg.height = 240;
        encoderVariableSettings.rescfg.v_scale_enb = 1;
    }

    if (modeMask->modesSupported & ENCODER_MODE_352_X_288)
    {
        sensorMode = CIF_MODE;
        encoderVariableSettings.rescfg.h_sub_offset = 8;
        encoderVariableSettings.rescfg.width = 352;
	encoderVariableSettings.rescfg.height = 288;
        encoderVariableSettings.rescfg.h_scale_enb = 1;
        encoderVariableSettings.rescfg.v_scale_enb = 1;
    }

    if (modeMask->modesSupported & ENCODER_MODE_352_X_240)
    {
        sensorMode = SIF_MODE;
        encoderVariableSettings.rescfg.h_sub_offset = 8;
        encoderVariableSettings.rescfg.width = 352;
       	encoderVariableSettings.rescfg.height = 240;
        encoderVariableSettings.rescfg.h_scale_enb = 1;
        encoderVariableSettings.rescfg.v_scale_enb = 1;
    }

    if (modeMask->modesSupported & ENCODER_MODE_176_X_144)
    {
        sensorMode = QCIF_MODE;
        encoderVariableSettings.rescfg.h_sub_offset = 4;
        encoderVariableSettings.rescfg.width = 176;
	encoderVariableSettings.rescfg.height = 144;
        encoderVariableSettings.rescfg.h_scale_enb = 1;
        encoderVariableSettings.rescfg.v_scale_enb = 1;
        encoderVariableSettings.rescfg.sub_sample = 1;
    }
 
    if (modeMask->modesSupported & ENCODER_MODE_176_X_112)
    {
        sensorMode = QSIF_MODE;
        encoderVariableSettings.rescfg.h_sub_offset = 4;
        encoderVariableSettings.rescfg.v_sub_offset = 8;
        encoderVariableSettings.rescfg.width = 176;
	encoderVariableSettings.rescfg.height = 112;
        encoderVariableSettings.rescfg.h_scale_enb = 1;
        encoderVariableSettings.rescfg.v_scale_enb = 1;
        encoderVariableSettings.rescfg.sub_sample = 1;
    }
 
    if (modeMask->modesSupported & ENCODER_MODE_720_X_480)
    {
        sensorMode = D1_MODE;
        encoderVariableSettings.rescfg.width = 720;
       	encoderVariableSettings.rescfg.height = 480;
    }

    if (modeMask->modesSupported & ENCODER_MODE_720_X_576)
    {
        sensorMode = FULL_D1_MODE;
        encoderVariableSettings.rescfg.width = 720;
       	encoderVariableSettings.rescfg.height = 576;
    }

    if (modeMask->modesSupported & ENCODER_MODE_640_X_480)
    {
        sensorMode = VGA_MODE;
        encoderVariableSettings.rescfg.width = 640;
        encoderVariableSettings.rescfg.height = 480;
    }

    if (modeMask->modesSupported & ENCODER_MODE_320_X_240)
    {
        sensorMode = QVGA_MODE;
        encoderVariableSettings.rescfg.h_scale_enb = 1;
        encoderVariableSettings.rescfg.v_scale_enb = 1;
    }

    if (modeMask->modesSupported & ENCODER_MODE_160_X_112)
    {
        sensorMode = QQVGA_MODE;
        encoderVariableSettings.rescfg.v_sub_offset = 8;
        encoderVariableSettings.rescfg.width = 160;
        encoderVariableSettings.rescfg.height = 112;
        encoderVariableSettings.rescfg.h_scale_enb = 1;
        encoderVariableSettings.rescfg.v_scale_enb = 1;
        encoderVariableSettings.rescfg.sub_sample = 1;
    }

    return(returnStatus);
}

status_t ED_SetOsdStr(osdString_t userOsdStr)
{
    status_t returnStatus = ENCODER_SUCCESS;
    osdStr.osd_ena = 1;
    osdStr.osd_x = userOsdStr.osd_x;
    osdStr.osd_y = userOsdStr.osd_y;
    osdStr.osd_grey = userOsdStr.osd_grey;
    strcpy(osdStr.osd_txt, userOsdStr.osd_txt);
    encoderFixedSettings.osdcfg.DoOSD = 1;
    encoderFixedSettings.osdcfg.OSDyc1 = userOsdStr.osd_grey;
    return(returnStatus);
}

status_t ED_SetSensorType(sint32 userSensorType, sint32 userInputSource, sint32 userTvStandard, sensorControl_t userSensorCtrl, sint32 userAudioCap)
{
    status_t returnStatus = ENCODER_SUCCESS;
    sensorType = userSensorType;
    videoInputSource = userInputSource;
    
    switch (sensorType)
    {
        case SENSOR_TYPE_OV7648:
            break;

        case SENSOR_TYPE_OV7640:
            sensorCtrl.power_line_freq = userSensorCtrl.power_line_freq;
            if(sensorCtrl.power_line_freq == 50)
            {
                encoderVariableSettings.syscfg.framerate = 25025;
                g_inputFrameRate = 25;
            }

           sensorCtrl.brightness = userSensorCtrl.brightness;
            sensorCtrl.contrast = userSensorCtrl.contrast;
            sensorCtrl.hue = userSensorCtrl.hue;
            sensorCtrl.saturation = userSensorCtrl.saturation;
            sensorCtrl.wb_redpre = userSensorCtrl.wb_redpre;
            sensorCtrl.wb_bluepre = userSensorCtrl.wb_bluepre;
            sensorCtrl.wb_mode = userSensorCtrl.wb_mode;
            if(sensorCtrl.wb_mode==CUSTOMIZED_WHITE_BALANCE)
            {
                sensorCtrl.wb_redchl = userSensorCtrl.wb_redchl;
                sensorCtrl.wb_bluechl = userSensorCtrl.wb_bluechl;
            }
            /* settings from Huy for this module's audio */
            if((userAudioCap&CAP_AUDIO_FORMAT_Mask)!=0)
            { //currently only support PCM Mono 8kHz
                encoderFixedSettings.audiocfg.main_divider = 1;
                encoderFixedSettings.audiocfg.BCLK_divider = 48;
                encoderFixedSettings.audiocfg.OKI_mode = 1;
                encoderFixedSettings.audiocfg.OKI_short_frame_mode = 0;
                encoderFixedSettings.audiocfg.clock_generator_enable = 1;
                encoderFixedSettings.audiocfg.I2S_master_mode = 1;
                encoderFixedSettings.audiocfg.I2S_mode = 3;
                encoderFixedSettings.audiocfg.invert_phase_BCLK = 1;
                encoderFixedSettings.audiocfg.OKI_shoftframe_mode = 0;
                encoderFixedSettings.audiocfg.word_length = 14;
                encoderFixedSettings.audiocfg.auto_SOF_generation = 1;  /* HPI mode needs this! */
                encoderFixedSettings.audiocfg.left_channel_only = 1;
                encoderFixedSettings.audiocfg.higher_8_bit_combine = 0;
                encoderFixedSettings.audiocfg.AC97_enable = 0;
                encoderFixedSettings.audiocfg.reserved = 8000;
                encoderFixedSettings.elsecfg.HasAudio = 2;
            }
            break;
            
        case SENSOR_TYPE_ICM202B:
            encoderVariableSettings.syscfg.vref_polar = 0; // 1 for OVT, 0 for ICM
            break;

        case SENSOR_TYPE_LZ24BP:
            encoderVariableSettings.misccfg.iip_enable = 1;   // 0: disable, 1: enable
            encoderVariableSettings.syscfg.sensor_656_mode = 0;
            encoderVariableSettings.syscfg.vref_polar = 0; // 1 for OVT
            encoderVariableSettings.syscfg.format = 2;
            /* cropping offset settings from Qifan for Sharp CCD sensor */
            encoderVariableSettings.rescfg.h_sub_offset = 58;
            encoderVariableSettings.rescfg.v_sub_offset = 20;
            if(sensorMode==QQVGA_MODE)
            {
                /* For QVGA, we don't change sub_offset, because scaleing is after cropping */
                /* For QQVGA, we change sub_offset, because subsampling is before cropping */
                encoderVariableSettings.rescfg.h_sub_offset = 24;
                encoderVariableSettings.rescfg.v_sub_offset = 8;
            }
            /* settings from Huy for this module's audio */
            if((userAudioCap&CAP_AUDIO_FORMAT_Mask)!=0)
            { //currently only support PCM Mono 8kHz
                encoderFixedSettings.audiocfg.main_divider = 1;
                encoderFixedSettings.audiocfg.BCLK_divider = 48;
                encoderFixedSettings.audiocfg.OKI_mode = 1;
                encoderFixedSettings.audiocfg.OKI_short_frame_mode = 0;
                encoderFixedSettings.audiocfg.clock_generator_enable = 1;
                encoderFixedSettings.audiocfg.I2S_master_mode = 1;
                encoderFixedSettings.audiocfg.I2S_mode = 3;
                encoderFixedSettings.audiocfg.invert_phase_BCLK = 1;
                encoderFixedSettings.audiocfg.OKI_shoftframe_mode = 0;
                encoderFixedSettings.audiocfg.word_length = 14;
                encoderFixedSettings.audiocfg.auto_SOF_generation = 1;  /* HPI mode needs this! */
                encoderFixedSettings.audiocfg.left_channel_only = 1;
                encoderFixedSettings.audiocfg.higher_8_bit_combine = 0;
                encoderFixedSettings.audiocfg.AC97_enable = 0;
                encoderFixedSettings.audiocfg.reserved = 8000;
                encoderFixedSettings.elsecfg.HasAudio = 2;
            }
            break;
            
        case SENSOR_TYPE_SAA7113:     /* set for 48K stereo */
            if(userTvStandard==TVStandard_NTSC_Mask)
            { //NTSC mode
                encoderVariableSettings.syscfg.tv_standard = TVStandard_NTSC_Mask;
                encoderVariableSettings.syscfg.sensor_h = 720;
                encoderVariableSettings.syscfg.sensor_v = 480;
                encoderVariableSettings.syscfg.framerate = 30000;
                g_inputFrameRate = 30;
                if(encoderVariableSettings.rescfg.v_sub_offset==0)
                { //keep it identical with USB_LINUX_SDK's 7113 board_module
                    encoderVariableSettings.rescfg.v_sub_offset = 4;
                }
            }
            else
            { //PAL or SECAM mode
                encoderVariableSettings.syscfg.tv_standard = TVStandard_PAL_Mask;
                encoderVariableSettings.syscfg.sensor_h = 720;
                encoderVariableSettings.syscfg.sensor_v = 576;
                encoderVariableSettings.syscfg.framerate = 25025;
                g_inputFrameRate = 25;
            }
            if(sensorMode==VGA_MODE || sensorMode==QVGA_MODE || sensorMode==QQVGA_MODE)
            {
                encoderVariableSettings.rescfg.h_sub_offset = 40;
                if(userTvStandard!=TVStandard_NTSC_Mask)
                    encoderVariableSettings.rescfg.v_sub_offset = 48;
                if(sensorMode==QVGA_MODE)
                {
                    if(userTvStandard==TVStandard_NTSC_Mask)
                        encoderVariableSettings.rescfg.v_sub_offset = 4;
                    else
                        encoderVariableSettings.rescfg.v_sub_offset = 48;
                }
                if(sensorMode==QQVGA_MODE)
                {
                    encoderVariableSettings.rescfg.h_sub_offset = 20;
                    if(userTvStandard==TVStandard_NTSC_Mask)
                        encoderVariableSettings.rescfg.v_sub_offset = 8;
                    else
                        encoderVariableSettings.rescfg.v_sub_offset = 32;
                }
            }

            encoderVariableSettings.syscfg.vref_polar = 0; // 1 for OVT, 0 for ICM
            encoderVariableSettings.strcfg.deinterlace_mode = 1;    // 0: use one field, 1: deinterlace, 2: interlace coding
            encoderVariableSettings.syscfg.sensor_656_mode = 1;
            encoderVariableSettings.syscfg.format = 1;
            if((userAudioCap&CAP_AUDIO_FORMAT_Mask)!=0)
            {
                if((userAudioCap&CAP_AUDIO_SAMPLERATE_Mask)
		   == CAP_AUDIO_SAMPLERATE_44100)
                {
                    /* we should NOT get in here, because saa7113
                     * daughter card doesn't support 44.1kHz audio.
                     */
                    encoderFixedSettings.audiocfg.main_divider = 1;
                    encoderFixedSettings.audiocfg.BCLK_divider = 4;
                    encoderFixedSettings.audiocfg.reserved = 44100;
                }
                else
                { // default Sample Rate is 48kHz
                    encoderFixedSettings.audiocfg.main_divider = 2;
                    encoderFixedSettings.audiocfg.BCLK_divider = 8;
                    encoderFixedSettings.audiocfg.reserved = 48000;
                }
                encoderFixedSettings.audiocfg.OKI_mode = 0;
                encoderFixedSettings.audiocfg.OKI_short_frame_mode = 0;
                encoderFixedSettings.audiocfg.clock_generator_enable = 1;
                //encoderFixedSettings.audiocfg.I2S_master_mode = 1;
		/* NOTE: for SAA7113 boards, please jumper 1-2 and 2-3 */
		encoderFixedSettings.audiocfg.I2S_master_mode = 0;
                encoderFixedSettings.audiocfg.I2S_mode = 1;
                encoderFixedSettings.audiocfg.invert_phase_BCLK = 0;
                encoderFixedSettings.audiocfg.OKI_shoftframe_mode = 0;
                encoderFixedSettings.audiocfg.word_length = 16;
                encoderFixedSettings.audiocfg.auto_SOF_generation = 1;  /* HPI mode needs this! */
                encoderFixedSettings.audiocfg.left_channel_only = 0;
                encoderFixedSettings.audiocfg.higher_8_bit_combine = 0;
                encoderFixedSettings.audiocfg.AC97_enable = 0;
                /* ADPCM adjustment comes here */
                encoderFixedSettings.audiocfg.reserved = sample2timestamp(encoderFixedSettings.audiocfg.reserved, userAudioCap);
                encoderFixedSettings.elsecfg.HasAudio = 1;
            }
            encoderFixedSettings.elsecfg.v_sync_bitplane = 0xF060; /* Vertical sync patch enable */
            if((sensorMode==VGA_MODE||sensorMode==QVGA_MODE) && userTvStandard!=TVStandard_NTSC_Mask)
            {
                encoderFixedSettings.elsecfg.v_sync_bitplane &= 0x7FFF;
            }
            else if(sensorMode==QQVGA_MODE)
            {
                encoderFixedSettings.elsecfg.v_sync_bitplane &= 0x7FFF;
            }
            /* if vertical scaler is on, we use single field mode to improve video quality */
            if(encoderVariableSettings.rescfg.v_scale_enb==1)
            {
                encoderVariableSettings.strcfg.deinterlace_mode = 0;
            }
            break;

        default:
            returnStatus = ENCODER_FAILURE;
    }
 
    if(encoderMode == ENCODER_MODE_H263)
    {
        if((sensorMode == FOUR_CIF_MODE) ||(sensorMode == FOUR_SIF_MODE))
            return(returnStatus);
        encoderVariableSettings.rescfg.h_sub_window = 1;
        encoderVariableSettings.rescfg.v_sub_window = 1;
        if(encoderVariableSettings.rescfg.width <= encoderVariableSettings.syscfg.sensor_h/4 
            && encoderVariableSettings.rescfg.height <= encoderVariableSettings.syscfg.sensor_v/4)
        {
            encoderVariableSettings.rescfg.sub_sample = 1;
            encoderVariableSettings.rescfg.h_scale_enb = 1;
            encoderVariableSettings.rescfg.v_scale_enb = 1;
            encoderVariableSettings.rescfg.h_sub_offset = (encoderVariableSettings.syscfg.sensor_h/4 
                      - encoderVariableSettings.rescfg.width)/2;
            if(encoderVariableSettings.rescfg.height == encoderVariableSettings.syscfg.sensor_v/4)
	        encoderVariableSettings.rescfg.v_sub_offset = (encoderVariableSettings.syscfg.sensor_v/4
                            - encoderVariableSettings.rescfg.height)/2;
            else
                encoderVariableSettings.rescfg.v_sub_offset = (encoderVariableSettings.syscfg.sensor_v/4
                            - encoderVariableSettings.rescfg.height)/2 + 12;
         }
         else
         {
             encoderVariableSettings.rescfg.sub_sample = 0;
             encoderVariableSettings.rescfg.h_scale_enb = (encoderVariableSettings.rescfg.width 
                            <= encoderVariableSettings.syscfg.sensor_h/2)? 1:0;
             encoderVariableSettings.rescfg.v_scale_enb = (encoderVariableSettings.rescfg.height
                            <= encoderVariableSettings.syscfg.sensor_v/2)? 1:0;
             encoderVariableSettings.rescfg.h_sub_offset = (encoderVariableSettings.syscfg.sensor_h
                           /(encoderVariableSettings.rescfg.h_scale_enb?
                           2:1) - encoderVariableSettings.rescfg.width)/2;
             encoderVariableSettings.rescfg.v_sub_offset = (encoderVariableSettings.syscfg.sensor_v
                           /(encoderVariableSettings.rescfg.v_scale_enb?
                           2:1) - encoderVariableSettings.rescfg.height)/2;
          }
    }
    
    return(returnStatus);
}

/************************* end of video_setting.c ***************************/

