/***WIS***********************************************************************
*
*  Copyright WIS Technologies (c) (2003)
*  All Rights Reserved
*
******************************************************************************
*
*  FILE: 
*    aviwriter.c
*
*  DESCRIPTION:
*
*  This file provides the aviwriter application, it can be used to get AV from driver and write
*  the AV data into specified AVI file. The wrote auido format can be PCM or MP2, the wrote
*  video format is MPEG4.
*
* AUTHOR:
*	Max song
*
*
*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/wait.h>
#include <linux/videodev.h>

#include "avformat.h"
#include "avcodec.h"

#include "v4l.h"
#include "wis_types.h"
#include "wsdf.h"

#define DEFAULT_DEVICE "/dev/video0"
#define DEFAULT_FILE_NAME	"/mnt/capture.avi"
#define FILE_NAME_LENGTH	100

#define AUDIO_FRAME 1
#define VIDEO_FRAME 2

#define AUDIO_FORMAT_8K_PCM	1
#define AUDIO_FORMAT_48K_PCM	2
#define AUDIO_FORMAT_48K_MS_ADPCM	3
#define AUDIO_FORMAT_48K_IMA_ADPCM	4
#define AUDIO_FORMAT_32K_MS_ADPCM	5
#define AUDIO_FORMAT_32K_IMA_ADPCM	6

#define VIDEO_INPUT_MODE_NTSC	1
#define VIDEO_INPUT_MODE_PAL	2

static AVFormatContext *pOutputContext = NULL;
static char outputFile[FILE_NAME_LENGTH];
static int audioIsPCM;
static int aformat;
static int audioSampleRate;
static int audioSampleBits;
static int audioChannel;
static int videoHeight;
static int videoWidth;
static int videoFps;
static int videoBitRate;
static int videoGopSize;
static int videoMode;
static int stopWrite;
static int dev;

extern AVCodec ms_adpcm;
extern AVCodec ima_adpcm;

#define MIN_VIDEO_BUF_SIZE 	350000      /*2M / 15 (fps) */
#define MAX_AUDIO_BUF_SIZE      19200       /* 48000 * 2 * 2 / 10*/

/*****************************************************************************
* Procedure Name:
*  print_usage()
*
* Description: 
*  This function is used to print the usage of aviwriter application.
*
* Arguments:
*	none.
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void print_usage()
{
    char strBuf[1000];
    sprintf(strBuf,
	    "Usage:\n"
	    "aviwriter [fileName] [audioSampleMode] [audioEncodeMode]"
	    " [videoMode] [videoResolution] [videoFps] [videoBitRate] [videoGopSize]\n"
	    "filename: the wrote file nane, include the directory path\n"
	    "audioSampleMode: monopcm, 48kpcm, 32kadpcm_ms, 32kadpcm_ima, 48kadpcm_ms or 48kadpcm_ima, default is monopcm\n"
	    "audioEncodeMode: 0 or 1, 0 means mp2, 1 means pcm, default is 1\n"
	    "videoMode: pal, ntsc or secam, default is ntsc\n"
	    "videoResolution: d1, vga, qvga, cif, qcif or qqvga, default is vga\n"
	    "videoFps: current frame per second,default is 30\n"
	    "videoBitRate: current bitrate, default is 1000000 (1Mbps)\n"
	    "videoGopSize: current GOP size, default is 15\n");
    printf(strBuf);
}

/*****************************************************************************
* Procedure Name:
*  set_default_config()
*
* Description: 
*  This function is used to set default value for the necessary variables.
*
* Arguments:
*	none.
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void set_default_config()
{
    stopWrite = 0;

    strcpy(outputFile, DEFAULT_FILE_NAME);

    aformat = AUDIO_FORMAT_8K_PCM;
    audioIsPCM = 1;
    audioSampleRate = 8000;
    audioChannel = 1;
    audioSampleBits = 16;

    videoHeight = 480;
    videoWidth = 640;
    videoFps = 30;
    videoBitRate = 1000000;
    videoGopSize = 15;
    videoMode = VIDEO_INPUT_MODE_NTSC;
}

/*****************************************************************************
* Procedure Name:
*  init_audio_config()
*
* Description: 
*  This function is used to set audio sample rate, channe and sample bits 
*  according to the user configuration.
*
* Arguments:
*	none.
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void init_audio_config()
{
    if (aformat == AUDIO_FORMAT_8K_PCM) {
	audioSampleRate = 8000;
	audioChannel = 1;
	audioSampleBits = 16;
    } else if (aformat == AUDIO_FORMAT_48K_PCM) {
	audioSampleRate = 48000;
	audioChannel = 2;
	audioSampleBits = 16;
    } else if ((aformat == AUDIO_FORMAT_48K_MS_ADPCM)
	       || (aformat == AUDIO_FORMAT_48K_IMA_ADPCM)) {
	audioSampleRate = 48000;
	audioChannel = 2;
	audioSampleBits = 4;
    } else if ((aformat == AUDIO_FORMAT_32K_MS_ADPCM)
	       || (aformat == AUDIO_FORMAT_32K_IMA_ADPCM)) {
	audioSampleRate = 32000;
	audioChannel = 2;
	audioSampleBits = 4;
    }
}

/*****************************************************************************
* Procedure Name:
*  init_video_config()
*
* Description: 
*  This function is used to set video resolution according to the user configuration.
*
* Arguments:
*	none.
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void init_video_config(char *pVideoRes)
{
    /*Current only support NTSC and PAL */
    if (strncmp(pVideoRes, "d1", 2) == 0) {
	videoWidth = 720;
	if (videoMode == VIDEO_INPUT_MODE_NTSC)
	    videoHeight = 480;
	else if (videoMode == VIDEO_INPUT_MODE_PAL)
	    videoHeight = 576;
    } else if (strncmp(pVideoRes, "vga", 3) == 0) {
	videoWidth = 640;
	videoHeight = 480;
    } else if (strncmp(pVideoRes, "qvga", 4) == 0) {
	videoWidth = 320;
	videoHeight = 240;
    } else if (strncmp(pVideoRes, "cif", 3) == 0) {
	videoWidth = 352;
	if (videoMode == VIDEO_INPUT_MODE_NTSC)
	    videoHeight = 240;
	else if (videoMode == VIDEO_INPUT_MODE_PAL)
	    videoHeight = 288;
    } else if (strncmp(pVideoRes, "qcif", 4) == 0) {
	videoWidth = 176;
	if (videoMode == VIDEO_INPUT_MODE_NTSC)
	    videoHeight = 112;
	else if (videoMode == VIDEO_INPUT_MODE_PAL)
	    videoHeight = 144;
    } else if (strncmp(pVideoRes, "qqvga", 5) == 0) {
	videoWidth = 160;
	videoHeight = 112;
    }
}

/*****************************************************************************
* Procedure Name:
*  parse_argumet(int argc, char *argv[])
*
* Description: 
*  This function is used to parse the user configuration.
*
* Arguments:
*	int argc - argument count.
*	char *argv[] -  argument list.
*
* Returns:
*	int - 0 means the user configuration is right, -1 means the configuration has error.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static int parse_argumet(int argc, char *argv[])
{
    /*if the first argument is "-h" or "?", print the usage and return */
    if ((strcmp(argv[1], "-h") == 0) || (strcmp(argv[1], "?") == 0)
        || (strcmp(argv[1], "-help") == 0) || (strcmp(argv[1], "h") == 0)) {
/*	print_usage();*/
	return -1;
    }

    /*otherwise, the first argument is the filename */
    if (strlen(argv[1]) > FILE_NAME_LENGTH) {
#ifdef DEBUG
	printf("The max length of file name is %d\n", FILE_NAME_LENGTH);
#endif
	return -1;
    } else {
	strcpy(outputFile, argv[1]);
    }

    /*the second argument is the audio format */
    if (argc > 2) {
	if (strcmp(argv[2], "monopcm") == 0) {
	    aformat = AUDIO_FORMAT_8K_PCM;
	} else if (strcmp(argv[2], "48kpcm") == 0) {
	    aformat = AUDIO_FORMAT_48K_PCM;
	} else if (strcmp(argv[2], "48kadpcm_ms") == 0) {
	    aformat = AUDIO_FORMAT_48K_MS_ADPCM;
	} else if (strcmp(argv[2], "48kadpcm_ima") == 0) {
	    aformat = AUDIO_FORMAT_48K_IMA_ADPCM;
	} else if (strcmp(argv[2], "32kadpcm_ms") == 0) {
	    aformat = AUDIO_FORMAT_32K_MS_ADPCM;
	} else if (strcmp(argv[2], "32kadpcm_ima") == 0) {
	    aformat = AUDIO_FORMAT_32K_IMA_ADPCM;
	} else {
#ifdef DEBUG
	    printf
		("aformat must be monopcm, 48kpcm, 48kadpcm_ms or 48kadpcm_ima\n");
#endif
	    return -1;
	}
	init_audio_config();
    }

    /*the third argument is audio encoder mode, pcm or mp2 */
    if (argc > 3) {
	audioIsPCM = atoi(argv[3]);
	if ((audioIsPCM != 0) && (audioIsPCM != 1)) {
#ifdef DEBUG
	    printf("AudioEncodeMode must be 0 or 1\n");
#endif
	    return -1;
	}
    }

    /*the fourth is the video mode */
    if (argc > 4) {
	if (strncmp(argv[4], "ntsc", 4) == 0)
	    videoMode = VIDEO_INPUT_MODE_NTSC;
	else if ((strncmp(argv[4], "pal", 3) == 0) ||
		 (strncmp(argv[4], "secam", 5) == 0))
	    videoMode = VIDEO_INPUT_MODE_PAL;
	else {
#ifdef DEBUG
	    printf("video mode must be PAL, NTSC or SECAM\n");
#endif
	    return -1;
	}
    }

    /*the fifth is the video resolution */
    if (argc > 5) {
	if ((strncmp(argv[5], "d1", 2) == 0)
	    || (strncmp(argv[5], "vga", 3) == 0)
	    || (strncmp(argv[5], "qvga", 4) == 0)
	    || (strncmp(argv[5], "cif", 3) == 0)
	    || (strncmp(argv[5], "qcif", 4) == 0)
	    || (strncmp(argv[5], "qqvga", 5) == 0)) {
	    init_video_config(argv[5]);
	} else {
#ifdef DEBUG
	    printf
		("VideoResulotion must be d1, vga, qvga, cif, qcif or qqvga\n");
#endif
	    return -1;
	}
    }

    /*the sixth argument is video fps */
    if (argc > 6) {
	int maxFps;
	videoFps = atoi(argv[6]);
	if (videoMode == VIDEO_INPUT_MODE_NTSC)
	    maxFps = 30;
	else
	    maxFps = 25;
	if ((videoFps < 0) || (videoFps > maxFps)) {
#ifdef DEBUG
	    printf("VideoFps must be between 0 and %d\n", maxFps);
#endif
	    return -1;
	}
    }


    /*the seventh is the bitrate */
    if (argc > 7) {
	videoBitRate = atoi(argv[7]);
    }

    /*the eighth is the GOP size */
    if (argc > 8) {
	videoGopSize = atoi(argv[8]);
    }

    return 0;
}

/*****************************************************************************
* Procedure Name:
*  ffmpeg_lib_init()
*
* Description: 
*  This function is used to Initialize the formats, codecs, and file types to use from
*  ffmpeg libraries.
*
* Arguments:
*	none.
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void ffmpeg_lib_init()
{
    avienc_init();

#if 0
    raw_init();


    register_avcodec(&mp2_encoder);
    register_avcodec(&ms_adpcm);

    wav_init();
#endif
    register_avcodec(&ms_adpcm);
    register_avcodec(&ima_adpcm);
    wav_init();

    register_avcodec(&pcm_s16le_encoder);
    register_protocol(&file_protocol);
}

/*****************************************************************************
* Procedure Name:
*  ffmpeg_output_context_init(AVOutputFormat * pFileOFormat)
*
* Description: 
*  This function is used to Initialize the context structure, which contains file I/O functions, 
*  output format info, etc.
*
* Arguments:
*	AVOutputFormat * pFileOFormat - the AV related format.
*
* Returns:
*	int - 0 means the initialization is ok, -1 means there is error.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static int ffmpeg_output_context_init(AVOutputFormat * pFileOFormat)
{
    AVFormatContext *oc;
    AVCodecContext *videoEnc;
    AVStream *st;
    AVFormatParameters params;
    AVFormatParameters *ap = &params;
    int nb_streams = 0;

    oc = (AVFormatContext *) av_mallocz(sizeof(AVFormatContext));
    st = (AVStream *) av_mallocz(sizeof(AVStream));

    if (oc == NULL || st == NULL) {
	printf("error: allocation of output context failed\n");
	return (-1);
    }

    avcodec_get_context_defaults(&st->codec);
    videoEnc = &st->codec;
    videoEnc->coded_frame = (AVFrame *) av_mallocz(sizeof(AVFrame));
    videoEnc->codec_type = CODEC_TYPE_VIDEO;

    oc->oformat = pFileOFormat;
    oc->streams[nb_streams++] = st;
    oc->nb_streams = nb_streams;

    memset(ap, 0, sizeof(*ap));
    if (av_set_parameters(oc, ap) < 0) {
	printf("error: av_set_parameters\n");
	return (-1);
    }

    strcpy(oc->filename, outputFile);
    pOutputContext = oc;
    if (url_fopen(&oc->pb, outputFile, URL_WRONLY) < 0) {
	printf("error: unable to open output file %s\n", outputFile);
	return (-1);
    }

    /* Add audio stream */
    st = (AVStream *) av_mallocz(sizeof(AVStream));
    oc->streams[nb_streams++] = st;
    oc->nb_streams = nb_streams;
    videoEnc = &st->codec;
    videoEnc->codec_type = CODEC_TYPE_AUDIO;

    return (0);
}

/*****************************************************************************
* Procedure Name:
*  init_ffmpeg_context()
*
* Description: 
*  This function is used to Initialize the formats, codecs, context structure,  etc.
*
* Arguments:
*	none.
*
* Returns:
*	int - 0 means the initialization is ok, -1 means there is error.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static int init_ffmpeg_context()
{
    AVOutputFormat *pFileOFormat;

    ffmpeg_lib_init();

    pFileOFormat = guess_format("avi", NULL, NULL);
    if (pFileOFormat == NULL) {
#ifdef DEBUG
	printf("Can find the AVOutputFormat for avi\n");
#endif
	return -1;
    }

    if (ffmpeg_output_context_init(pFileOFormat) != 0) {
#ifdef DEBUG
	printf("ffmpeg_output_context_init failed\n");
#endif
	return -1;
    }

    if (audioIsPCM == 1) {
	if ((aformat == AUDIO_FORMAT_48K_MS_ADPCM) ||
		(aformat == AUDIO_FORMAT_32K_MS_ADPCM))
	    pFileOFormat->audio_codec = CODEC_ID_ADPCM_MS;
	else if ((aformat == AUDIO_FORMAT_48K_IMA_ADPCM) ||
		(aformat == AUDIO_FORMAT_32K_IMA_ADPCM))
	    pFileOFormat->audio_codec = CODEC_ID_ADPCM_IMA_WAV;
	else
	    pFileOFormat->audio_codec = CODEC_ID_PCM_S16LE;
    } else
	pFileOFormat->audio_codec = CODEC_ID_MP2;

    return 0;
}

/*****************************************************************************
* Procedure Name:
*  update_key_frame(AVFormatContext * oc, int key_frame)
*
* Description: 
*  This function is used to update video codec key frame for ffmpeg file writer.
*
* Arguments:
*	AVFormatContext * oc - AV format related context.
*	int key_frame - the flag of key frame, 1 means key frame, 0 means not
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
void update_key_frame(AVFormatContext * oc, int key_frame)
{
    int i;
    AVCodecContext *enc;

    /* Find the video stream in this context */
    for (i = 0; i < oc->nb_streams; i++) {
	enc = &oc->streams[i]->codec;
	if (enc->codec_type == CODEC_TYPE_VIDEO)
	    break;
    }
    enc->coded_frame->key_frame = key_frame;
}

/*****************************************************************************
* Procedure Name:
*  update_video_codec(AVFormatContext * oc)
*
* Description: 
*  This function is used to update video codec parameters for ffmpeg file writer.
*
* Arguments:
*	AVFormatContext * oc - AV format related context.
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void update_video_codec(AVFormatContext * oc)
{
    int i;
    AVCodecContext *enc;

    /* Find the video stream in this context */
    for (i = 0; i < oc->nb_streams; i++) {
	enc = &oc->streams[i]->codec;
	if (enc->codec_type == CODEC_TYPE_VIDEO)
	    break;
    }

    enc->bit_rate = videoBitRate;
    if(videoMode == VIDEO_INPUT_MODE_NTSC)
        enc->frame_rate = videoFps * 1000;
    else
        enc->frame_rate = videoFps * 1001;
    enc->frame_rate_base = 1001;

    enc->height = videoHeight;
    enc->width = videoWidth;
    enc->gop_size = videoGopSize;

    enc->sub_id = 4;		/* MPEG-4 */
    enc->codec_id = CODEC_ID_MPEG4;
    enc->coded_frame->key_frame = 0;
}

/*****************************************************************************
* Procedure Name:
*  update_audio_codec(AVFormatContext * oc)
*
* Description: 
*  This function is used to update audio codec parameters for ffmpeg file writer.
*
* Arguments:
*	AVFormatContext * oc - AV format related context.
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void update_audio_codec(AVFormatContext * oc)
{
    int i;
    AVCodecContext *enc;
    AVCodec *codec;

    /* Find the audio stream in this context */
    for (i = 0; i < oc->nb_streams; i++) {
	enc = &oc->streams[i]->codec;
	if (enc->codec_type == CODEC_TYPE_AUDIO)
	    break;
    }

    codec = avcodec_find_encoder(oc->oformat->audio_codec);
    enc->sample_rate = audioSampleRate;
    enc->channels = audioChannel;

    if (codec->id == CODEC_ID_MP2) {
	enc->bit_rate = 64000;
	enc->codec_id = CODEC_ID_MP2;
    } else if (codec->id == CODEC_ID_MP3) {
	enc->bit_rate = 64000;
	enc->codec_id = CODEC_ID_MP3;
    } 

    if (avcodec_open(enc, codec) < 0)
	printf("could not open codec\n");

    if (codec->id == CODEC_ID_ADPCM_MS) {
	enc->codec_id = CODEC_ID_ADPCM_MS;
	enc->block_align = 256;
	enc->bit_rate = enc->sample_rate * 256 / 244 * 8;
	enc->frame_size = 1024;
    } else if (codec->id == CODEC_ID_ADPCM_IMA_WAV) {
	enc->codec_id = CODEC_ID_ADPCM_IMA_WAV;
	enc->block_align = 256;
	enc->bit_rate = enc->sample_rate * 256 / 249 * 8;
	enc->frame_size = 1024;
    }

    /* Hack for PCM output */
    if ((codec->id != CODEC_ID_MP2) && (codec->id != CODEC_ID_MP3)
	&& (codec->id != CODEC_ID_ADPCM_MS)
	&& (codec->id != CODEC_ID_ADPCM_IMA_WAV)) {
	enc->bit_rate = enc->sample_rate * enc->channels * audioSampleBits;
	enc->frame_size = 1024;
    }
}
/*****************************************************************************
* Procedure Name:
*  write_frame_into_file(char *pframe, int frameLen, int frameType, int keyframe)
*
* Description: 
*  This function is used to write specified length frame into file.
*
* Arguments:
*	char *pframe - frame pointer.
*	int frameLen - frame length
*	int frameType - the frame is audio or video
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void write_frame_into_file(char *pframe, int frameLen, int frameType)
{
    static int firstCall = 1;
    static AVCodecContext *enc;
    static int asindex;

    if (stopWrite == 1)
	return;

    if (firstCall) {
	for (asindex = 0; asindex < pOutputContext->nb_streams; asindex++) {
	    enc = &pOutputContext->streams[asindex]->codec;
	    if (enc->codec_type == CODEC_TYPE_AUDIO)
		break;
	}
	firstCall = 0;
    }

    /* Write to audio or video file */
    switch (frameType) {
    case AUDIO_FRAME:
	{
	    unsigned char *pAudioBuf = pframe;
	    int audioLen;

	    if (audioIsPCM) {
		audioLen = frameLen;
	    } else {
		audioLen =
		    avcodec_encode_audio(enc, (unsigned char *) pAudioBuf,
					 frameLen, (short *) pframe);
	    }
	    av_write_frame(pOutputContext, asindex,
			   (unsigned char *) pAudioBuf, audioLen);
	}
	break;

    case VIDEO_FRAME:
	{
	    unsigned int *keyflag = (unsigned int *) pframe;
	    int flag = 0;

#ifndef BIG_ENDIAN
	    if (*keyflag == 0xb0010000)
#else
	    if (*keyflag == 0x000001b0)
#endif
		flag = 1;
#ifndef BIG_ENDIAN
	    else if (*keyflag == 0xb6010000) {
#else
	    else if (*keyflag == 0x000001b6) {
#endif
		char *next_byte = pframe + 4;

		if (((*next_byte) >> 6) == 0)	//"I" frame
		    flag = 1;
	    }
	    update_key_frame(pOutputContext, flag);

	    av_write_frame(pOutputContext, 0, (unsigned char *) pframe,
			   frameLen);
	}
	break;
    }
}

/*****************************************************************************
* Procedure Name:
*  do_loop()
*
* Description: 
*  This function is the main loop function, it will read AV from driver and write into file.
*
* Arguments:
*	none.
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void do_loop()
{
    /* video buffer pointer and length */
    int videoLen;
#ifndef NO_MM
    char video_buf[MIN_VIDEO_BUF_SIZE];
    char audio_buf[MAX_AUDIO_BUF_SIZE];
#endif
    char *pVideoBuffer = NULL;
    char *pAudioBuffer = NULL;

    /* audio buffer pointer and length */
    int audioLen;
    
    wis_frame_info_t frameInfo;

    AVStream *st = pOutputContext->streams[0];

    if (av_write_header(pOutputContext) < 0) {
	printf("error: could not write header for output file\n");
	return;
    }

    while (stopWrite == 0) {

#ifdef NO_MM
        pVideoBuffer = v4l_get_frame(dev, DEF_WIDTH, DEF_HEIGHT,
				     IN_DEFAULT, NORM_DEFAULT,
				     VIDEO_PALETTE_RGB24, &videoLen,
				     &frameInfo);
#else
        videoLen = MIN_VIDEO_BUF_SIZE;
        pVideoBuffer = v4l_get_frame_copy (dev, DEF_WIDTH, DEF_HEIGHT,
				     IN_DEFAULT, NORM_DEFAULT,
				     VIDEO_PALETTE_RGB24, &videoLen,
				     video_buf);
#endif


#ifdef NO_MM
        pAudioBuffer = audio_get_frame(dev, AUDIO_SAMPLE_RATE_44_1KHZ,
				       AUDIO_CHANNELS_STEREO, &audioLen);
#else
        audioLen = audio_get_frame_copy (dev, audio_buf, MAX_AUDIO_BUF_SIZE);
#endif
              
        if ((pVideoBuffer != NULL) && (videoLen > 0)) {
            st->codec.frame_number++;
	    write_frame_into_file(video_buf, videoLen, VIDEO_FRAME);
	}

	if (audioLen > 0) {
            write_frame_into_file(audio_buf, audioLen, AUDIO_FRAME);
	}

    }
}

/*****************************************************************************
* Procedure Name:
*  stop_write()
*
* Description: 
*  This function is used to stop capture AV.
*
* Arguments:
*	none.
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void stop_write()
{
    stopWrite = 1;

    if (v4l_stop(dev) < 0) {
	printf("Error: could not stop capture device!\n");
    }

    v4l_close(dev);

    av_write_trailer(pOutputContext);
}

/*****************************************************************************
* Procedure Name:
*  sig_handler(int signal)
*
* Description: 
*  This function is the signal handler
*
* Arguments:
*	int signal - signal type.
*
* Returns:
*	none.  
*
*  Notes:
*	none.
*
*****************************************************************************/
static void sig_handler(int signal)
{
    psignal(signal, "Signal:");

    stop_write();

    exit(0);
}

/*****************************************************************************
* Procedure Name:
*  main(int argc, char *argv[])
*
* Description: 
*  This function is the main entry port of aviwriter.
*
* Arguments:
*	int argc - argument count.
*	char *argv[] -  argument list.
*
* Returns:
*	int - 0 means it's ok, otherwise there is some error.  
*
*  Notes:
*	none.
*
*****************************************************************************/
int main(int argc, char *argv[])
{
    int big_endian = 0;
    set_default_config();

    if (argc >= 2) {
	if (parse_argumet(argc, argv) != 0) {
	    print_usage();
	    return -1;
	}
    }

    if (init_ffmpeg_context() < 0) {
#ifdef DEBUG
	printf("init_ffmpeg_context() failed\n");
#endif
	return -1;
    }

    update_video_codec(pOutputContext);
    update_audio_codec(pOutputContext);

    dev = v4l_open(DEFAULT_DEVICE);
    if (dev < 0) {
#ifdef DEBUG
	printf("v4l_open() failed\n");
#endif
        return -2;
    }

    v4l_set_blocking(dev, 1, 1);
    v4l_avsynch(dev, 0);

    /*For adpcm, disable avsync*/
    if ((aformat == AUDIO_FORMAT_48K_MS_ADPCM) ||
	(aformat == AUDIO_FORMAT_32K_MS_ADPCM) ||
	(aformat == AUDIO_FORMAT_48K_IMA_ADPCM) ||
	(aformat == AUDIO_FORMAT_32K_IMA_ADPCM))
        v4l_avsynch(dev, 0);

    if (v4l_start(dev) < 0) {
#ifdef DEBUG
	printf("Error: could not start capture device!\n");
#endif
	v4l_close(dev);
	return -3;
    }

#ifdef BIG_ENDIAN
    if(ioctl(dev, SET_AUDIO_BIG_ENDIAN, &big_endian) == -1)
    {
        printf("v4l_start: SET_AUDIO_BIG_ENDIAN failed\n");
        return -1;
    }
#endif
    
    signal(SIGTERM, sig_handler);

#ifdef DEBUG
    printf("Captured file name is %s\n", outputFile);
    printf("Audio Sample rate is %d\n", audioSampleRate);
    printf("Audio Sample bits is %d\n", audioSampleBits);
    printf("Audio channel is %d\n", audioChannel);
    printf("Audio encode type is %s\n", audioIsPCM ? "PCM" : "mp2");
    printf("Video mode is %s\n",
	   (videoMode == VIDEO_INPUT_MODE_NTSC) ? "NTSC" : "PAL");
    printf("Video resolution is %d X %d\n", videoWidth, videoHeight);
    printf("Video FPS is %d\n", videoFps);
    printf("Video bit rate is %dbps\n", videoBitRate);
    printf("Video GOP size is %d\n", videoGopSize);
#endif

    do_loop();

    if (v4l_stop(dev) < 0) {
#ifdef DEBUG
	printf("Error: could not stop capture device!\n");
#endif
	return -5;
    }

    v4l_close(dev);

    return 0;
}
