/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*		audio_driver.c
*
*   DESCRIPTION:
*		This is the driver for DMA support.
*               Currently, only IXP425 platforms are supported.
*
*  AUTHOR:
*	Daniel Meyer
*
*   $Id: dma_driver.c,v 1.5 2004/04/26 10:53:30 jfd Exp $ 
*
******************************************************************************/

#include "wis_types.h"
#include "wis_error.h"
#include "os.h"
#include "tasks.h"
#include "platform.h"
#include "struct.h"
#include "queue_api.h"
#include "sal_api.h"
#include "dma_api.h"

/* task variables local to this file */
static uint32   thisTaskId=0;
static uint8    thisTaskName[MAX_TASK_NAME_LENGTH];

extern sint32 debugLevel; /* debug level for print statements in WisMedia library */

#define	DMA_DRIVER_QUEUE_SIZE				30

#define	DMA_DRIVER_COUNTING_SEM_MAX_OUTSTANDING	1

OSL_SEM_t semDmaDriver;

int sDmaDriverQueue;

/*******************************************************************************
*
*   PROCEDURE:  
*       DMAD_Callback(sint32 s32Status)
*
*   DESCRIPTION:
*       This is the callback from the DMA function.  When the DMA is complete
*     it will send status to this function.
*  
*   ARGUMENTS:
*
*	  s32Status - completion status of the DMA.
*
*   RETURNS:
*
*    NONE
*
*   NOTES:
*
*******************************************************************************/

void DMAD_Callback(sint32 s32Status)
{
	/* as each DMA is completed, give the semaphore once to control the queue depth */
	OSL_SemCountGive(semDmaDriver);
	
	if (debugLevel >= DEBUG_LEVEL_PRINTFS)
		printf("DMAD dma callback %d\n", s32Status);
}

/**************************** end of DMAD_Callback ******************************/

/******************************************************************************
*
*  Procedure Name:
*       DMAD_Task(void)
*
*  Description:
*       This task is responsible for managing DMAs.
*  
*  Arguments:
*
*	  NONE
*
*  Returns:
*
*    NONE
*
*   Notes:
*
******************************************************************************/

void DMAD_Task()
{

	DMA_DRIVER_QUEUE_ELEMENT_t sDmaDriverQueueElement;
    
	if (debugLevel >= DEBUG_LEVEL_PRINTFS)
	{
		printf("Begin Dma Driver Task\n");
	}

	/* setup local task information */
	strncpy(thisTaskName, DMA_DRIVER_TASK_NAME, MAX_TASK_NAME_LENGTH);

	sDmaDriverQueue = OSL_QInit(OSL_Q_TYPE_TASK_TO_TASK, sizeof(DMA_DRIVER_QUEUE_ELEMENT_t),
								DMA_DRIVER_QUEUE_SIZE);
	
	OSL_CreateCountingSemaphore("DMA Driver Semaphore", semDmaDriver,
								DMA_DRIVER_COUNTING_SEM_MAX_OUTSTANDING);

	FOREVER
	{
		
		/* Wait for audio events */
		OSL_QGet(sDmaDriverQueue, (sint32 *)&sDmaDriverQueueElement,
				 sizeof(DMA_DRIVER_QUEUE_ELEMENT_t), OS_WAIT_FOREVER);

		if (debugLevel >= DEBUG_LEVEL_PRINTFS)
		{
			printf("Dma Queue Received 0x%x\n",
			       (uint32)
			       (sDmaDriverQueueElement.pu32SourceAddress));
		}

		/* if there is work to do, get the semaphore to ensure that there is space in */
		/* the queue to do the work */
		OSL_SemCountTake(semDmaDriver, OS_WAIT_FOREVER);
		
#if defined(IXDP425) && !defined(HW_J18V035T00) /* Ambit platform uses Coyote BSP */
		/*Code for Data Transfer*/
		ixDmaAccDmaTransfer(sDmaDriverQueueElement.dmaDriverCallback,
							(uint32) sDmaDriverQueueElement.pu32SourceAddress,
							(uint32) sDmaDriverQueueElement.pu32DestAddress,
							sDmaDriverQueueElement.u32DmaLen,
							IX_DMA_COPY, IX_DMA_FIX_SRC_INC_DST,
							IX_DMA_16_SRC_16_DST);
#endif
		
	} /* end FOREVER loop */

}

/***************************** end of AD_DriverTask ***************************/

/***************************** end of audio_driver.c ***************************/

