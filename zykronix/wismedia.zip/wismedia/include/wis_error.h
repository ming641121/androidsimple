/******************************************************************************
 *
 *   Copyright WIS Technologies (c) (2004)
 *   All Rights Reserved
 *
 ******************************************************************************
 *
 *   FILE: 
 *     wis_error.h
 *
 *   DESCRIPTION:
 *     Error codes for the WIS Encoder/Decoder API's.
 *
 *   $Id: wis_error.h,v 1.3 2004/02/13 17:45:18 dmeyer Exp $
 *
 *****************************************************************************/

#ifndef WIS_ERROR_H
#define WIS_ERROR_H

/* general interface */
#define WIS_SUCCESS                         0
#define WIS_FAILURE                         (-1)

/* Encoder error codes */
#define ENCODER_SUCCESS                     WIS_SUCCESS
#define ENCODER_FAILURE                     WIS_FAILURE
#define ENCODER_INVALID_ARGUMENT            (-2)
#define ENCODER_MAX_WATERMARK_EXCEEDED      (-2)
#define ENCODER_FAIL_MEMORY                 (-2)
#define ENCODER_FAIL_CONFLICTING_MODES      (-3) 
#define ENCODER_NOT_IMPLEMENTED_YET         (-100)

#define ENCODER_INVALID_MODE_SELECTED       (-2)

/* Decoder error codes */
#define DECODER_SUCCESS                     WIS_SUCCESS
#define DECODER_FAILURE                     WIS_FAILURE
#define DECODER_NOT_IMPLEMENTED_YET         (-100)

#endif /* WIS_ERROR_H */

