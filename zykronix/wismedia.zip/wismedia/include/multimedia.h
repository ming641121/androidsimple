/**	HEADERFILE: "WSDF/WISInclude/MultiMedia.H"
 *	Description: MultiMedia related definitions.
 *	History:
 *		04-29-2002 - Alpha, file created
 * $Id: multimedia.h,v 1.1 2003/11/04 15:42:35 dmeyer Exp $
 *
 */
#ifndef	_MULTIMEDIA_H_
#define	_MULTIMEDIA_H_



#include "wis_types.h"
#include "wsdf.h"


/**	SECTION - constants
 */
	typedef enum
	{
		MMSF_RAW		= 0,
		MMSF_AVI_WIS	= 1,
		MMSF_AVI_DIVX	= 2,
		MMSF_AVI_SIGMA	= 3,
		MMSF_AVI_MSFT	= 4,
		MMSF_MPEG1		= 5,
		MMSF_MPEG2		= 6,
		MMSF_WMV		= 7,
		MMSF_WMA		= 8,
		MMSF_MP2		= 9,
		MMSF_MP3		= 10,
		MMSF_NONE		= -1
	} EMMStrFormat;

	typedef enum
	{
		AUDIO_MP1	= 0x01,
		AUDIO_MP2	= 0x02,
		AUDIO_MP3	= 0x03,
		VOICE_G7231	= 0x14
	} EAudioFormat;

	typedef enum
	{
		MPEG1		= 0x00,
		MPEG2		= 0x01,
		H261		= 0x02,
		H263		= 0x03,
		MPEG4		= 0x04,
		MPEG4XGO	= 0x05,
		MPEG2X4		= 0x06,
		MOTIONJPEG	= 0x08,
		DV			= 0x09,
		H26L		= 0x20,
		GO			= 0x40
	} EVideoFormat;

	typedef enum
	{
		UYVYP		= 0,
		UYVYI		= 1,
		BAYER_GB	= 2,
		BAYER_GR	= 3,
		BAYER_BG	= 4,
		BAYER_RG	= 5
	} EPixelMode;

	typedef enum
	{
		DDRAW_YUY2	= 0x01,
		DDRAW_UYVY	= 0x02,
		DDRAW_YV12	= 0x08,
		DDRAW_RGB24	= 0x03,
		DDRAW_RGB32	= 0x04,
		DDRAW_RGB555= 0x05,
		DDRAW_RGB565= 0x06,
		DDRAW_DIB24	= 0x13,
		DDRAW_DIB32	= 0x14,
		DDRAW_DIB555= 0x15,
		DDRAW_DIB565= 0x16,
		DDRAW_NULL	= 0
	} EDDrawMode;

	typedef enum
	{
		IONLY		= 1,
		IPONLY		= 2,
		IPB			= 3,
		IPBDROP		= 4
	} ESequenceMode;

	typedef enum
	{
		I_FRAME		= 0,
		P_FRAME		= 1,
		B_FRAME		= 2,
		D_FRAME		= 3
	} EFrameType;

	typedef enum
	{
		MB_INTRA	= 0x01,
		MB_PATTERN	= 0x02,
		MB_BACKWARD	= 0x04,
		MB_FORWARD	= 0x08,
		MB_QUANT	= 0x10,
		MB_4V		= 0x20,
		MB_DIRECT	= 0x40
	} EMBType;

	typedef enum
	{
		PIXEL_XI_YI	= 0x00,
		PIXEL_XH_YI	= 0x01,
		PIXEL_XI_YH	= 0x10,
		PIXEL_XH_YH	= 0x11
	} EFractionPixel;

	typedef enum
	{
		FLHALF		= 1,
		FLQUATER	= 2,
		FLEIGHTH	= 3,
		FLINTEGER	= 0
	} EFractionLevel;

	typedef enum
	{
		NOSEQUENCE_HEADER	= 0x0001,
		NOGOP_HEADER		= 0x0002,
		NOFRAME_HEADER		= 0x0004,
		NOFRAME_TAIL		= 0x0008,
		NOSEQUENCE_TAIL		= 0x0010,
		NOIFRAME			= 0x0020,
		NOPFRAME			= 0x0040,
		NOBFRAME			= 0x0080
	} ETranscodeOption;

	#define	FPS_N30				(30000. / 1001)
	#define	FPS_P25				25.
	#define	FPS_N24				(24000. / 1001)
	#define	FPS_P24				24.

	#define RC_MIN_Q			1
	#define RC_MAX_Q			31

	#define	DPP_NULL			0
	#define	DPP_DBLKLUM			3
	#define	DPP_DBLK			5
	#define	DPP_DBLKDRNGLUM		6
	#define	DPP_DBLKDRNG		9

	#define	RCTP_CBR			30
	#define	RCTP_DEFAULT		60
	#define	RCTP_HIQUALITY		300

	#define	RCLAMBDA_HQPIC		0.25
	#define	RCLAMBDA_LESSDROP	0.5
	#define	RCLAMBDA_CFR		1.

/**	ENDOFSECTION
 */



/**	SECTION - data structures
 */
	typedef struct
	{
		SINT8	interlace;		// 0 for progressive or 1 for interlace orignal input
		SINT8	mode;			// 'MultiMedia.H': EVideoFormat
		SINT8	seq;			// see ESequenceMode (IONLY, IPONLY or IPB)
		SINT32	cols;			// count of macroblocks in horizontal
		SINT32	rows;			// count of macroblocks in vertical
		REAL64	fps;			// frame rate of current stream
		SINT8	uvmode;			// see EVideoFormat (for uv motion vectors)
		SINT8	dqmode;			// see EVideoFormat (for DCTQ mismatch control)
								//   GO (0x40) indicates no iQ-mismatch-control and use JDCT
		SINT8	fpmode;			// see EFractionLevel
								//   by default we only use FLHALF
		SINT8	wismode;		// Is it WIS proprietary MPEG4 mode? Yes(1) : No(0)
		SINT8	acpred;			// If do AC prediction in intra macro-block
		SINT8	userq;			// if use user customized quantization table(1: Yes, 0: No)
		UINT8	intraq[64];		// quantization table for intra block
		UINT8	interq[64];		// quantization table for inter block
	} TMP_StrInfo;

	typedef struct {
		REAL64	timeStamp;		// return time stamp of current frame, in second
		SINT32	nGOP;			// serial number of current GOP
		SINT32	nSubGOP;		// serial number of current SubGOP in GOP
		SINT32	nPicture;		// serial number of current Picture in SubGOP
		REAL64	fno;			// serial number of current frame (dropt frames counted)
		SINT8	ftype;			// see EFrameType
		REAL64	fq;				// equivalent frame quantize scale
	} TMP_FrmInfo;

	typedef struct
	{
		SINT32	col;			// macroblock index in horizontal
		SINT32	row;			// macroblock index in vertical
		SINT32	dc[6];			// DC coefficients of each 8x8 block
		SINT32	vx[6];			// motion vector (horizontal) of each 8x8 block
		SINT32	vy[6];			// motion vector (vertical) of each 8x8 block
		SINT8	mbtype;			// see EMBType
		SINT8	Q;				// quantize scale of current macroblock
		SINT8	cbp;			// CBP of current macroblock
		SINT32	ach[6][7];		// first row AC coefficients of each 8x8 block in current MB
		SINT32	acv[6][7];		// first column AC coefficients of each 8x8 block in current MB
	} TMP_BlkInfo;

	typedef struct
	{
		SINT8	run[6][64];		// run values
		SINT32	lvl[6][64];		// level values
		SINT32	pair[6];		// count of pairs
	} TMP_BlkPair;

	typedef struct {
		SINT8	pproc;			// postprocess level, see 'WSDF.H'
		SINT32	rcLeft;			// postprocess area position: left boundary
		SINT32	rcTop;			// postprocess area position: top boundary
		SINT32	rcWidth;		// postprocess area size: horizontal
		SINT32	rcHeight;		// postprocess area size: vertical
	} TMP_PPrcSet;

	typedef struct
	{
		SINT32	SBYT;			// macroblock head byte of frame stream
		SINT32	EBYT;			// macroblock tail byte of frame stream

		SINT8	SBIT;			// position of head bit in SBYT
		SINT8	EBIT;			// position of tail bit in EBYT

		SINT8	Q;				// quantizer
		SINT8	I;				// 0 for intra MB, 1 for inter MB

		SINT16	GOBN;			// GOB index
		SINT16	MBA;			// MB index of current GOB

		SINT16	hmvp00;			// X-direction motion vector predictor of blk00
		SINT16	vmvp00;			// Y-direction motion vector predictor of blk00
		SINT16	hmvp10;			// X-direction motion vector predictor of blk10
		SINT16	vmvp10;			// Y-direction motion vector predictor of blk10
	} TMP_StrMBInfo;

/**	ENDOFSECTION
 */



#endif
/**	ENDOFHEADERFILE: "MultiMedia.H"
 */
