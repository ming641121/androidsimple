/******************************************************************************
*
*   Copyright WIS Technologies (c) (2004)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       wis_encoder.h
*
*   DESCRIPTION:
*   This is the API (Application Programming Interface) for the WIS Encoder.
*   NOTE:  Only one instance of an encoder is allowed.
*
*   $Id: wis_encoder.h,v 1.21 2005/03/20 18:34:16 squ Exp $
*
******************************************************************************/

#ifndef WIS_ENCODER_H
#define WIS_ENCODER_H

#include "wis_types.h"
#include "motion_detection_api.h"

/* tell us what sensor type we are using */
#define SENSOR_TYPE_UNINITIALIZED   0
#define SENSOR_TYPE_ICM202B         1
#define SENSOR_TYPE_OV7648          2
#define SENSOR_TYPE_OV7640          3
#define SENSOR_TYPE_LZ24BP          4   /* this is the "Sharp CCD" */
#define SENSOR_TYPE_SAA7113         5
extern sint32 sensorType;

#define CUSTOMIZED_WHITE_BALANCE    0
#define AUTO_WHITE_BALANCE          1
typedef struct sensor_control_s{
    sint32 power_line_freq;
    sint32 brightness;
    sint32 contrast;
    sint32 hue;
    sint32 saturation;
    sint32 wb_mode;
    sint32 wb_redpre;
    sint32 wb_bluepre;
    sint32 wb_redchl;
    sint32 wb_bluechl;
} sensorControl_t;

#define INPUT_SOURCE_COMPOSITE      0
#define INPUT_SOURCE_SVIDEO         1
extern sint32 videoInputSource;

#define OSD_LANGUAGE_ENGLISH        0
#define OSD_LANGUAGE_CHINESE        1
typedef struct osd_string_s{
    sint32 osd_ena;
    sint32 osd_lang;
    char osd_txt[255];
    sint32 osd_x;
    sint32 osd_y;
    sint32 osd_grey;
} osdString_t;
/*
 * Function: EncoderSetOsdStr - set the osd string for the encoder.
 * Arguments: userOsdStr - OSD string and its coordinates
 * Return: ENCODER_XXX - status code (SUCCESS/FAIL)
 */
status_t EncoderSetOsdStr(osdString_t userOsdStr);

#define MAX_NUM_CALLBACKS           100
#define MAX_FRAME_SIZE              75*1024 /* 75K frame packet */

#define AVSYNC_AUDIO_FINGERPRINT_OFFSET         4
#define AVSYNC_AUDIO_REFERENCE_COUNT_OFFSET     8
#define AVSYNC_VIP_OFFSET                       12

#define MPEG4_FRAME_TYPE_OFFSET     4
#define MPEG4_FRAME_TYPE_BIT        6
#define MPEG4_FRAME_TYPE_MASK       (0x3 << MPEG4_FRAME_TYPE_BIT)

#define MPEG2_FRAME_TYPE_OFFSET     5
#define MPEG2_FRAME_TYPE_BIT        3
#define MPEG2_FRAME_TYPE_MASK       (0x7 << MPEG4_FRAME_TYPE_BIT)

/*
 * Function: EncoderSchedulerInit
 * Arguments: prio -runtime priority for task scheduler
 *                  deferred procedure call mechanism.
 * NOTE: must be the first call before initializing the encoder 
 *       when your application starts. This task schedules callbacks
 *       made by the encoder.
 */
status_t EncoderSchedulerInit(int prio);


/* 
 * Function: EncoderStart - start the encoder 
 * Return:  ENCODER_XXX - status code (SUCCESS/FAIL)
 */
status_t EncoderStart(int doAVSync,sint32 priority,int Sensor,int AudioCap);

/* 
 * Function: EncoderStop - stop the encoder 
 * Return:  ENCODER_XXX - status code (SUCCESS/FAIL)
 */
status_t EncoderStop(int doAVSync, int sensor );

/* 
 * Function: EncoderReset - stop/reset the encoder 
 * Return:  ENCODER_XXX - status code (SUCCESS/FAIL)
 */
status_t EncoderReset(void);

/* 
 * Function: EncoderDiagTest- execute the standard set of diagnostics.  
 * Return: ENCODER_XXX - status code (SUCCESS/FAIL)
 */
status_t EncoderDiagTest(void);

/*
 * Version information structure.
 */
typedef struct encoder_version_s{

    uint32 encoderFirmwareVersion;
    uint32 encoderHardwareVersion;
    uint32 encoderDriverVersion;

} encoderVersion_t;

/*
 * Function: EncoderGetVersionInfo - retrieve version info on Encoder revision
 * Return: encoder_version_t structure 
 */
encoderVersion_t EncoderGetVersionInfo(void);

/*
 * Function:  EncoderSetBitrateControl - set bitrate of encoder
 * Arguments: targetBitrate - target rate in Kbps 
 *        peakBitrate - the peak bitrate allowed.  As you approach
 *                          this value, frame duplication becomes more likely.
 *        maxFps - given a sensor input of 30fps, how many frames
 *                 per second would you like?  If the sensor input is less
 *                 than 30fps, the result will be a ratio  of this
 *                    (for instance if you request a maxFps of 15 and
 *                    the sensor input is 20fps, then 30:15 is 2,
 *                    so 20/2 is 10, meaning that you actually get 10fps.
 *        gopSize - allows you to choose your GOPSize.
 *                      In IBP mode this size MUST be divisible by 3
 *                     (since a subGOP is two B frames and an I or P frame)
 * 
 * Return: ENCODER_XXXX - (SUCCESS/FAIL status code)
 */
status_t EncoderSetBitrateControl(uint32 targetBitrate,
				  uint32 peakBitrate,
				  uint32 maxFps,
				  uint32 gopSize,
				  uint32 videoBufferSize,
				  uint32 constQ);

/*
 * Function:  EncoderGetBitrateControl - get bitrate of encoder
 * Arguments: targetBitRate - pointer to target rate in Kbps current in device.
 * Return: ENCODER_XXXX - (SUCCESS/FAIL status code)
 */
status_t EncoderGetBitrateControl(uint32 *targetBitrate,
				  uint32 *peakBitrate,
				  uint32 *maxFps,
				  uint32 *gopSize,
				  uint32 *videoBufferSize,
				  uint32 *constQ);

/*
 * Function:EncoderSetInputFrameRate - inform the driver of the input
 *                                     device's frame rate
 * Arguments: inputFps - fps of the input device.
 * Return: ENCODER_XXXX - (SUCCESS/FAIL status code)
 * NOTE: Use this to adjust the input frame rate.  The default is 30fps.
 */
status_t EncoderSetInputFrameRate(sint32 inputFps);

/*
 * Encoder frame reception callback.
 * 
 * A user will create a function with the following prototype and then
 * register their function to be called whenever there is a frame
 * generated by the encoder.
 *
 * NOTE: When you get called, frame will contain address of len bytes
 *       of data, to be used by the application.
 * NOTE: The memory should NOT be freed, as this memory is maintained
 *       by the encoder driver.
 * 
 */
typedef struct frameInfo_s {
    uint32 regionMap;
    uint32 flags;
} wis_frame_info_t;

#define MAX_FRAME_BUFFERS	32

typedef struct wis_frame_buffer_s {
	unsigned char *ptr;
	int len;
	enum { FB_IDLE, FB_READY, FB_FULL } state;
} wis_frame_buffer_t;

void make_buffer_ready( int buffer );

typedef void (*encoder_callback_t)(void* pFrame, sint32 len, void* userdata,
                                   wis_frame_info_t *pFrameInfo);

/*
 * Type: encoder_handler_t
 * Use: callback management structure used by the driver 
 */

typedef struct encoder_handler_s{
    sint32 fps;
    encoder_callback_t* encoderFrameCallback;
    void *encoderFrameCallbackUser;
} encoder_handler_t;

#define ENCODER_FLAG_FRAME_IS_STREAM_HEADER     1
#define ENCODER_FLAG_LAST_CALLBACK              2
#define ENCODER_FLAG_MPEG4                      4
#define ENCODER_FLAG_MPEG2                      8
#define ENCODER_FLAG_MPEG1                      16
#define ENCODER_FLAG_H263                       32
#define ENCODER_FLAG_H261                       64
#define ENCODER_FLAG_MJPEG                      128


/* 
 * Function:EncoderRegisterFrameCallback - hookup callback function to encoder.
 * Purpose: For every frame generated by the encoder, the encoder will invoke
 *           a user-defined callback routine registered via this routine.
 * Return: ENCODER_XXXX - (SUCCESS/FAIL status code)
 */
status_t EncoderRegisterFrameCallback(encoder_callback_t *cb,
				      void *callbackArgument);

/* Encoder capabilities mask */
#define ENCODER_MODE_MPEG4      (1<<0)
#define ENCODER_MODE_MPEG2      (1<<1)
#define ENCODER_MODE_MPEG1      (1<<2)
#define ENCODER_MODE_H263       (1<<3)
#define ENCODER_MODE_H264       (1<<4)
#define ENCODER_MODE_MJPEG      (1<<5)
#define ENCODER_MODE_INTERLACED     (1<<6)
#define ENCODER_MODE_PROGRESSIVE    (1<<7)
#define ENCODER_MODE_160_X_112      (1<<8)  /* QQVGA */
#define ENCODER_MODE_176_X_144      (1<<9)  /* QCIF */
#define ENCODER_MODE_320_X_240      (1<<10) /* QVGA */
#define ENCODER_MODE_352_X_288      (1<<11) /* CIF */
#define ENCODER_MODE_640_X_480      (1<<12) /* VGA */
#define ENCODER_MODE_720_X_480      (1<<13) /* D1 */
#define ENCODER_MODE_720_X_576      (1<<14) /* Full D1 */
#define ENCODER_MODE_704_X_576      (1<<15) /* 4CIF */
#define ENCODER_MODE_704_X_288      (1<<16) /* 2CIF */
#define ENCODER_MODE_352_X_240      (1<<17) /* SIF */
#define ENCODER_MODE_704_X_240      (1<<18) /* 2SIF */
#define ENCODER_MODE_704_X_480      (1<<19) /* 4SIF */
#define ENCODER_MODE_176_X_112      (1<<20) /* QSIF */
#define ENCODER_MODE_AV_SYNC        (1<<21) /* AV Sync supported */
#define ENCODER_MODE_IBP            (1<<24)
#define ENCODER_MODE_IP_ONLY        (1<<25)
#define ENCODER_MODE_I_ONLY         (1<<26)

#define ENCODER_MODE_RESOLUTION_MASK    (ENCODER_MODE_160_X_112         \
                                         | ENCODER_MODE_176_X_144       \
                                         | ENCODER_MODE_320_X_240       \
                                         | ENCODER_MODE_352_X_288       \
                                         | ENCODER_MODE_640_X_480       \
                                         | ENCODER_MODE_720_X_480       \
                                         | ENCODER_MODE_720_X_576       \
                                         | ENCODER_MODE_704_X_576       \
                                         | ENCODER_MODE_704_X_288       \
                                         | ENCODER_MODE_352_X_240       \
                                         | ENCODER_MODE_704_X_240       \
                                         | ENCODER_MODE_704_X_480       \
                                         | ENCODER_MODE_176_X_112)

typedef struct encoder_cap_s{
    uint32 modesSupported; /* Bitmask of supported modes */
} encoderCapabilities_t;

/*
 * Function: EncoderGetCapabilities - return capabilities mask structure for
 *        selection of target output mode. This routine will return a mask
 *        of supported output modes. Of the modes supported, one and only one
 *        can be enabled by calling encoderSetMode
 * Return: encoder_cap_t - encoder capabilities structure
 */
encoderCapabilities_t EncoderGetCapabilities(void);

/* 
 * Function: EncoderSetMode - set the current mode of operaticn for the device.
 * Arguments: mode - bitmap of the supported modes 
 * Return: ENCODER_XXX - status code (SUCCESS/FAIL)
 * Notes: encoderGetCapabilities() must be invoked first to determine the modes
 *        supported by the device.
 */
status_t EncoderSetMode(encoderCapabilities_t modemask);

/******************************************************************************
*
*   PROCEDURE:  
*       status_t EncoderDeleteAFrame(void)
*
*   DESCRIPTION:
*       Delete the last frame in this GOP.
*  
*   ARGUMENTS:
*
*       NONE
*
*   RETURNS:
*
*       ENCODER_SUCCESS or ENCODER_FAILURE
*
*   NOTES:
*
******************************************************************************/
status_t EncoderDeleteAFrame(void);

/******************************************************************************
*
*   PROCEDURE:  
*       status_t EncoderInsertAFrame(void)
*
*   DESCRIPTION:
*       Duplicate the last frame in this GOP.
*  
*   ARGUMENTS:
*
*       NONE
*
*   RETURNS:
*
*       ENCODER_SUCCESS or ENCODER_FAILURE
*
*   NOTES:
*
******************************************************************************/
status_t EncoderInsertAFrame(void);

/* 
 * Function: EncoderSetSensorType - set the input sensor for the encoder.
 * Arguments: userSensorType - sensor type
 * Return: ENCODER_XXX - status code (SUCCESS/FAIL)
 */
status_t EncoderSetSensorType(sint32 userSensorType, sint32 userInputSource, sint32 userTvStandard, sensorControl_t userSensorCtrl, sint32 userAudioCap);

/* 
 * Function: EncoderSetSensorXXX - modify sensor settings
 * Arguments: setting - new sensor setting (no range checking)
 */
status_t EncoderSetSensorAutoExposure(uint16 setting);
status_t EncoderSetSensorContrast(uint16 setting);
status_t EncoderSetSensorWhiteBalance(sensorControl_t wb_setting);
status_t EncoderSetSensorBrightness(uint16 setting);
status_t EncoderSetSensorGamma(uint16 setting);
status_t EncoderSetSensorHue(sint32 setting);
status_t EncoderSetSensorPLF(uint16 setting);
status_t EncoderSetSensorSaturation(uint16 setting);
status_t EncoderSetSensorSharpness(uint16 setting);

/******************************************************************************
*
*   PROCEDURE:  
*       status_t EncoderSetFps(sint32 fpsRequestedRate)
*
*   DESCRIPTION:
*       Set the encoder output frame rate to the newly requested rate, which
*   is a function of the input frame rate.
*  
*   ARGUMENTS:
*
*       fpsInputRate - the rate at which frames appear to the input of the
*                      encoder.
*       fpsRequestedRate - the rate at which frames should appear to come from
*                          the encoder.
*
*   RETURNS:
*
*       NONE
*
*   NOTES:
*       This may only be called at runtime
*
******************************************************************************/

status_t EncoderSetFps(sint32 fpsRequestedRate);


/******************************************************************************
*
*   PROCEDURE:  
*       status_t EncoderChangeBRC(sint32 changeDirection, sint32 newIQScale,
*                                 sint32 newPQScale, sint32 newTargetBitrate,
*                                 sint32 newPeakBitrate, sint32 newVbvBuffer,
*                                 sint32 newConvergeSpeed, sint32 newLambda);
*
*
*   DESCRIPTION:
*       Change the bitrate control parameters and update the configuration on
*   the encoder while it is still running.
*  
*   ARGUMENTS:
*
*       changeDirection - argument which describes which BRC mode we are
*                         currently in and which BRC mode we wish to choose.
*       newIQScale - If in VBR mode, set the quantizer for all I frames.  This
*                    is ignored in CBR mode.
*       newPQScale - If in VBR mode, set the quantizer for all P frames.  This
*                    is ignored in CBR mode.
*       newTargetBitrate - in CBR mode, choose the new target average bitrate
*                          in bps (bits per second).
*       newPeakBitrate - in CBR mode, choose the new peak average bitrate in
*                        bps.  This setting is only used when the VBV Buffer
*                        is non-zero.
*       newVbvBuffer - in CBR mode, this is the size of the buffer in which
*                      you keep your encoded stream.  This setting is used by
*                      the CBR algorithm to determine the urgency for lowering
*                      the bitrate to prevent an overflow.  If the VBV buffer
*                      gets too close to the limit, 'duplication frames' may
*                      be inserted into the stream.
*       newConvergenceSpeed - On a scale from 1 to 100, this is the rate at
*                             which firmware will attempt to converge on the
*                             requested target bitrate.  For example, with a
*                             setting of '100', the bitrate should converge on
*                             the target bitrate within 30 frames.  In general,
*                             the faster you converge, the more the overall
*                             quality of the stream will degrade.
*       newLambda - On a scale from 1 to 100, Lambda is the probability that
*                 a duplication frame will be inserted to obtain the requested
*                 target bitrate and to stay below the peak bitrate.  In
*                 general, the complexity of the stream will directly
*                 effect the chance that a duplication frame will need to be
*                 inserted.
*
*
*   RETURNS:
*
*  ENCODER_SUCCESS - the bitrate change will be performed.
*  ENCODER_BRC_INVALID_DIRECTION_CHANGE - Invalid argument for change direction
*  ENCODER_BRC_INVALID_IQ - IQScale out of range (2 to 31)
*  ENCODER_BRC_INVALID_PQ - PQScale out of range (2 to 31)
*  ENCODER_BRC_INVALID_TARGET_BITRATE - target bitrate argument invalid
*  ENCODER_BRC_INVALID_PEAK_BITRATE - peak bitrate argument invalid
*  ENCODER_BRC_INVALID_CONVERGENCE_SPEED - convergence speed argument
*                                          invalid (1 to 100)
*  ENCODER_BRC_INVALID_LAMBDA - lambda argument invalid (1 to 100)
*
*   NOTES:
*       This may only be called at runtime
*
*       A duplication frame is a very small frame that references the previous
*   frame.
*
******************************************************************************/

/* API for BRC OTF change */
/* VBR is Variable Bit Rate (ie constant quantizer) */
/* CBR is Constant Bit Rate (ie variable quantizer) */
#define ENCODER_BRC_DIRECTION_VBR_TO_VBR            0
#define ENCODER_BRC_DIRECTION_CBR_TO_VBR            1
#define ENCODER_BRC_DIRECTION_VBR_TO_CBR            2
#define ENCODER_BRC_DIRECTION_CBR_TO_CBR            3

status_t EncoderChangeBRC(sint32 changeDirection, sint32 newIQScale,
                          sint32 newPQScale, sint32 newTargetBitrate,
                          sint32 newPeakBitrate, sint32 newVbvBuffer,
                          sint32 newConvergeSpeed, sint32 newLambda);

/******************************************************************************
*
*   PROCEDURE:  
*       status_t EncoderInitMD(void)
*
*   DESCRIPTION:
*       Initialize and enable the motion detection function.
*  
*   ARGUMENTS:
*
*       NONE
*
*   RETURNS:
*
*       ENCODER_SUCCESS - the motion detection module has been initialized.
*       ENCODER_FAILURE - the motion detection module could not be initialized.
*
*   NOTES:
*       This must be called before EncoderStart().
*       The motion detection feature has the side effect of making MPEG1/2
*   CBR frame based instead of macroblock based.
*
******************************************************************************/

status_t EncoderInitMD(void);

/******************************************************************************
*
*   PROCEDURE:  
*       status_t EncoderSetMDThresholdsAndSensitivity(uint16 thresholds[][],
*                                                     uint16 *Sensitivity);
*
*   DESCRIPTION:
*       Set the thresholds and sensitivity for motion detection during runtime,
*   This interface only works at runtime.
*  
*   ARGUMENTS:
*
*       arrs16MotionThresholds - properly formatted two dimensional array of
*                                SAD and motion vector thresholds where the
*                                first index is the region number and the
*                                second index is the threshold type (0 for MV
*                                and 1 for SAD)
*       arru8MotionSensitivity - array of sensitivity values for each region.
*                                Sensitivity is the number of macroblocks that
*                                must exceed the threshold before motion is
*                                reported to the host.
*
*   RETURNS:
*
*       ENCODER_SUCCESS - the motion detection status has been updated.
*       ENCODER_FAILURE - the motion detection status was not updated due to
*                         invalid arguments.
*
*   NOTES:
*       If you did not call EncoderInitMD() before EncoderStart(), this call
*   will have no effect.
*
******************************************************************************/

status_t EncoderSetMDThresholdsAndSensitivity(uint16 arrs16MotionThresholds[MAX_REGIONS_OF_INTEREST][NUM_MOTION_TYPES],
                                              uint16 *arru8MotionSensitivity);

/******************************************************************************
*
*   PROCEDURE:  
*       status_t EncoderSetMDRegions(uint8 *arru8MotionCoordinates,
*                                    uint32 u32MaxXCoordinate,
*                                    uint32 u32MaxYCoordinate)
*
*   DESCRIPTION:
*       Set the region numbers for every macroblock to watch for motion.
*  
*   ARGUMENTS:
*
*       arru8MotionCoordinates - two dimensional array of region numbers where
*                             each [x][y] location contains the region number
*                            for that macroblock.  This argument MUST be
*                            exactly the the same number of macroblocks as
*                            the current picture.  If there is a size mismatch
*                            the results are undetermined.
*   u32MaxXCoordinate - The maximum X coordinate for the picture size.  This is
*                       really just used for error checking.
*   u32MaxYCoordinate - The maximum Y coordinate for the picture size.  This is
*                       really just used for error checking.
*
*   RETURNS:
*
*       ENCODER_SUCCESS  - the macroblock map has been set in the device.
*       ENCODER_FAILURE  - the macroblock map had invalid regions or there was
*                          a mismatch in the picture size.
*
*   NOTES:
*   Be careful that this array is the same size as the picture (in macroblocks)
*   and that the caller has initialized every location in this array to ensure
*   that the map is correctly set. 
*
*****************************************************************************/

status_t EncoderSetMDRegions(uint8 *arru8MotionCoordinates,
                             uint32 u32MaxXCoordinate,
                             uint32 u32MaxYCoordinate);

/******************************************************************************
*
*   PROCEDURE:  
*       status_t EncoderSetMDDelay(uint32 u32DelayInMilliseconds)
*
*   DESCRIPTION:
*   Set a delay for how long to wait before reporting that additional motion
*   has occurred.
*  
*   ARGUMENTS:
*
*    u32DelayInMilliseconds - Delay, in milliseconds, before additional motion
*                             is reported.
*
*   RETURNS:
*
*       ENCODER_SUCCESS     - the delay has been set..
*       ENCODER_FAILURE     - TBD
*
*   NOTES:
*   The encoder driver knows how many frames per second, so it will use this
*   value to calculate the number of frames to wait before invoking the user
*   callback every time motion occurs.
*
******************************************************************************/

status_t EncoderSetMDDelay(uint32 u32DelayInMilliseconds);

/******************************************************************************
*
*   PROCEDURE:  
*     status_t EncoderSetMDCallback(encoder_motion_callback_t *motionCallback,
*    	                            void *vptrUserCallbackArgument)
*
*   DESCRIPTION:
*       Register a user callback for when motion has occurred and is
*       to be reported to the application.
*  
*   ARGUMENTS:
*
*       motionCallback - function pointer of type encoder_motion_callback_t to
*                        be called when motion is to be reported.
*       vptrUserCallbackArgument - pointer to anything the user would like to
*                                   have passed into the callback function as
*                                   an argument.
*
*   RETURNS:
*
*       ENCODER_SUCCESS  - callback has been registered.
*       ENCODER_FAILURE  - the user has exceed the maximum number of callbacks
*
*   NOTES:
*
******************************************************************************/

status_t EncoderSetMDCallback(encoder_motion_callback_t *motionCallback,
                              void *vptrUserCallbackArgument);

#endif /* WIS_ENCODER_H */

/********************* end of wis_encoder.h **********************************/
