/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*
*		compiler.h
*
*   DESCRIPTION:
*		Compiler specific options and defines.
*
*   $Id: compiler.h,v 1.2 2003/12/12 18:37:46 dmeyer Exp $
*
******************************************************************************/

#ifndef _OSL_COMPILER_H
#define _OSL_COMPILER_H

#if defined(__GNUC__)

/* Following are defined for GNU C Compiler */

#define COMPILER_ATTRIBUTE(_a)	__attribute__ (_a)
#define	COMPILER_INLINE		inline

#else

/* Following for non GNU compiler, currently only Diab Data */

#define COMPILER_ATTRIBUTE(_a)
#define	COMPILER_INLINE		

#endif

/* Some Common short forms */

#define COMPILER_REFERENCE(x) ((void)x)
#endif /* _OSL_COMPILER_H */
