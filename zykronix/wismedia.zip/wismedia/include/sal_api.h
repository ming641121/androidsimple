/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*       sal_api.h
*
*   DESCRIPTION:
*       Standard API for board/architecture dependent functions
*
*   $Id: sal_api.h,v 1.4 2005/01/11 11:55:55 jblair Exp $
*
******************************************************************************/

#ifndef SAL_API_H
#define SAL_API_H

/* 
*  Every architecture needs to supply these functions. 
*  They configure the HPI bus and interrupt lines on the host.
*  For examples see:
*      wismedia/common/board_daredevil.c 
*      wismedia/common/board_zao.c 
*/
int board_int_clear (unsigned int mask);
int board_bus_timing_set (unsigned int bus_param);
int board_int_config (int num, int type);

#endif /* SAL_API_H */

