/*
 * Tasks known by the system - VxWorks specific.
 *
 * $Id: tasks.h,v 1.4 2004/09/14 13:54:23 ywang Exp $
 */
#ifndef TASKS_H
#define TASKS_H
#include "os.h"

extern void	ED_Task(void);
extern void VideoMonitorTask(void);
extern void	idleTask(void);
extern void AD_Task(void);
extern void DMAD_Task(void);
extern void AVSYNC_Task(void);
#define DD_AV_SYNC                     1   

#define	IDLE_TASK_PRIORITY			250
#define	IDLE_TASK_ENTRY_POINT			(funcptr_t) idleTask
#define	IDLE_TASK_STACK_SIZE			1024

#define	IDLE_TASK_OPTIONS		0

#define	ENCODER_DRIVER_TASK_NAME			"tWISEncoder"
#define	ENCODER_DRIVER_TASK_PRIORITY		146 
#define	ENCODER_DRIVER_TASK_ENTRY_POINT		ED_Task
#define	ENCODER_DRIVER_TASK_STACK_SIZE		(10 * 1024)
#define	ENCODER_DRIVER_TASK_OPTIONS			0

#define	AUDIO_DRIVER_TASK_NAME				"tAudio"
#define	AUDIO_DRIVER_TASK_PRIORITY			70
#define	AUDIO_DRIVER_TASK_ENTRY_POINT		AD_Task
#define	AUDIO_DRIVER_TASK_STACK_SIZE		(10 * 1024)
#define	AUDIO_DRIVER_TASK_OPTIONS			0

#define	DMA_DRIVER_TASK_NAME				"tDma"
#define	DMA_DRIVER_TASK_PRIORITY			65
#define	DMA_DRIVER_TASK_ENTRY_POINT			DMAD_Task
#define	DMA_DRIVER_TASK_STACK_SIZE			(10 * 1024)
#define	DMA_DRIVER_TASK_OPTIONS				0

#define	DECODER_DRIVER_TASK_NAME			"tWISDecoder"
#define	DECODER_DRIVER_TASK_PRIORITY		147
#define	DECODER_DRIVER_TASK_ENTRY_POINT		DecoderDriverTask
#define	DECODER_DRIVER_TASK_STACK_SIZE		(10 * 1024)
#define	DECODER_DRIVER_TASK_OPTIONS			0

#define	MONITOR_TASK_NAME			        "tMonitor"
#define	MONITOR_TASK_PRIORITY		        49
#define	MONITOR_TASK_OPTIONS    	        0
#define	MONITOR_TASK_ENTRY_POINT	        VideoMonitorTask
#define	MONITOR_TASK_STACK_SIZE		        (10 * 1024)
#define	MONITOR_TASK_OPTIONS		        0

#define	AV_SYNC_TASK_NAME			        "tAVSync"
#define	AV_SYNC_TASK_PRIORITY		        148 
#define	AV_SYNC_TASK_ENTRY_POINT	        AVSYNC_Task
#define	AV_SYNC_TASK_STACK_SIZE		        (2 * 1024)
#define	AV_SYNC_TASK_OPTIONS			0


#endif /* TASKS_H */

