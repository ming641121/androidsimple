/******************************************************************************
*
*   FILE: 
*		osl_vx.h
*
*   DESCRIPTION:
*		Abstraction layer for the VxWorks 5.5 RTOS
* 
*   $Id: osl_vx.h,v 1.8 2004/02/19 21:14:54 jfd Exp $
*
******************************************************************************/

#ifndef _OSL_VX_H_
#define _OSL_VX_H_

/* Generic Includes */
#include "wis_types.h"
#include <compiler.h>
/* OS Dependent includes */
#ifdef VXWORKS
#include <vxWorks.h>
#include <msgQLib.h>
#include <semLib.h>
#include <eventLib.h>
#include <taskLib.h>
#include <intLib.h>	/* For INT_CONTEXT */
#include <cacheLib.h>
#include <vxWorks.h>
#include <semLib.h>
#endif
#if defined(UNIX)
#include <thread.h>
#endif

#define	MAX_TASK_NAME_LENGTH	80

extern int scale;


#define	OS_SUCCESS	OK
#define	OS_FAILURE	ERROR

/* Sleep in Milliseconds on XScale */
/* NOTE: vxWorks taskDelay() is in clock-ticks */
#define OS_SLEEP(sleepTime) 											\
				osl_msleep(sleepTime)

#define OSL_Sleep(sleepTime) 											\
				osl_msleep(sleepTime)

#define	OS_INT_CONNECT(intVector, isrName, intArgument)		\
			intConnect((VOIDFUNCPTR *) intVector, (VOIDFUNCPTR) isrName, intArgument)
#define	OSL_IntConnect		OS_INT_CONNECT

#define	OS_INT_ENABLE(intLevel)										\
			intEnable(intLevel)
			
#define	OS_INT_DISABLE(intLevel)										\
			intDisable(intLevel)

#define	OS_QUEUE				MSG_Q_ID
#define	OS_EVENT				SEM_ID
#define	OS_COUNTING_SEMAPHORE	SEM_ID
#define	OS_MUTEX_SEMAPHORE		SEM_ID

#define	OS_EVENT_CREATE(eventName, eventList) 						\
			eventName = semBCreate(SEM_Q_FIFO, SEM_EMPTY);			\
			semEvStart(eventName, eventList, EVENTS_OPTIONS_NONE);	\
			thisTaskId = taskNameToId(thisTaskName)

#define	OS_EVENT_DELETE(eventName)									\
			semEvStop(eventName);									\
			semDelete(eventName)
			
			
	/* events are auto-cleared */
#define	OS_EVENT_WAIT(eventName, eventsReceived, eventWaitList, timeout)	\
			eventReceive(eventWaitList, EVENTS_WAIT_ANY | EVENTS_RETURN_ALL, timeout, eventsReceived)

#define	OS_EVENT_SIGNAL(eventName, eventMask)		\
			eventSend(thisTaskId, eventMask)

#define OS_EVENT_CLEAR(eventToClear)		\
			eventClear()


/* Mutex semaphore section */
#define	OS_CREATE_MUTEX_SEMAPHORE(mutexSemaphore)	\
			mutexSemaphore = semMCreate(SEM_Q_FIFO)

#define	OS_SEM_MUTEX_TAKE(mutexSemaphore, wait)		\
			semTake(mutexSemaphore, wait)

#define	OS_SEM_MUTEX_GIVE(mutexSemaphore)			\
			semGive(mutexSemaphore)
			
/* Counting semaphore section */
#define	OSL_CreateCountingSemaphore(description, countingSemaphore, initialCount)	\
			countingSemaphore = osl_sem_create(description, FALSE, initialCount)

#define	OSL_SemCountTake(countingSemaphore, wait)		\
			osl_sem_take(countingSemaphore, wait)

#define	OSL_SemCountGive(countingSemaphore)			\
			osl_sem_give(countingSemaphore)
			
#define	OSL_SemCountDelete(countingSemaphore)		\
			osl_sem_destroy(countingSemaphore)

#define	OS_APPLICATION_INIT							videoPhoneInit

#define	OS_CREATE_TASK(taskName, taskPriority, options, stackSize, taskEntryPoint)	\
			osl_thread_create(taskName, stackSize, taskPriority, (void *)taskEntryPoint, 0)
							 
#define	OS_DELETE_TASK(taskId)	\
			osl_thread_destroy(taskId)
					  
#define	OSL_CreateTask(taskName, taskPriority, options, stackSize, taskEntryPoint)	\
			osl_thread_create(taskName, stackSize, taskPriority, (void *)taskEntryPoint, 0)
			
#define OSL_DeleteTask(taskId)				\
			osl_thread_destroy(taskId);
			
#define	OS_QUEUE_CREATE(queueName, numberOfQueueElements, queueElementSize)   			\
			queueName = msgQCreate(numberOfQueueElements, queueElementSize, SEM_Q_FIFO)

	/* events are auto-cleared */
#define	OS_QUEUE_RECEIVE(queueName, queueElement, queueElementSize, timeout)	\
			msgQReceive(queueName, (char *)&queueElement, queueElementSize, timeout)

#define	OS_QUEUE_SEND(queueName, queueElement, queueElementSize, timeout)		\
			msgQSend(queueName, (char *)&queueElement, queueElementSize, timeout, MSG_PRI_NORMAL)

#define OS_QUEUE_CLEAR(queueToClear, queueEntry, queueElementSize)		\
			while (msgQReceive(queueToClear, &queueEntry, queueElementSize, OS_NO_WAIT) != ERROR) { ; }

#define	OS_QUEUE_DELETE(queueToDelete)									\
			msgQDelete(queueToDelete)

#define	OSL_Malloc(bytesToAllocate)										\
			osl_alloc(bytesToAllocate, NULL)
			
#define	OSL_Calloc(numElementsToAllocate, elementSize)					\
			osl_calloc(numElementsToAllocate, elementSize)
			
#define	OSL_Free(memToFree)												\
			osl_free(memToFree);
/*
 * OSL Initialization
 */
int	osl_init(void);
void	osl_set_ctrl_c_thread(osl_thread_t thread);

/*
 * OSL Utility Routines
 */

#ifdef VXWORKS
#define osl_int_context() INT_CONTEXT()
#else /* !VXWORKS */
int	osl_int_context(void);
#endif /* !VXWORKS */

/*
 * OSL Memory and Cache Support
 *
 */

void	*osl_dma_alloc(size_t size, char *);
void	osl_dma_free(void *);

void	*osl_alloc(unsigned int, char *);
void	*osl_calloc(unsigned int, unsigned int);
void 	osl_free(void *);

#if defined(VXWORKS)
extern CACHE_FUNCS osl_cacheFuncs;
#define osl_dma_flush(addr, len) \
	CACHE_DMA_FLUSH(addr, len)
#define osl_dma_inval(addr, len) \
	CACHE_DRV_INVALIDATE(&osl_cacheFuncs, (addr), (len))
#define osl_dma_vtop(addr) \
	CACHE_DRV_VIRT_TO_PHYS(&osl_cacheFuncs, (addr))
#define osl_dma_ptov(addr) \
	CACHE_DRV_PHYS_TO_VIRT(&osl_cacheFuncs, (addr))
#else /* UNIX */
#define osl_dma_flush(addr, len)	((void) 0)
#define osl_dma_inval(addr, len)	((void) 0)
#define osl_dma_vtop(addr)		(addr)
#define osl_dma_ptov(addr)		(addr)
#endif /* ! VXWORKS */

/*
 * OSL Thread support Routines.
 */
#define OSL_THREAD_ERROR	((osl_thread_t) -1)
#define	OSL_THREAD_STKSZ	8192	/* Default Stack Size */

osl_thread_t	osl_thread_create(char *, int, int, 
                				  void (f)(void *), void *);
int		osl_thread_destroy(osl_thread_t);
void	osl_thread_exit(int);
osl_thread_t	osl_thread_self(void);

/* Interrupt/Pre-Emption Control */
int osl_spl(int level);
int osl_splhi(void);

/* Interrupt handling */
typedef void (*irq_handler_t)(int, void *, void *); /* See also: sched.h */
int osl_int_connect(unsigned int irq,
		    irq_handler_t service,
		    const char *name, void *data);
void osl_int_disconnect(int i, void* data);
void osl_int_enable(int irq);
void osl_int_disable(int irq);
                                                
/* Deferred procedure calls */
int osl_dpc_init(int prio); /* NOTE: must call at least once at init to launch task */
void osl_dpc_term(void);
int osl_dpc(osl_dpc_fn_t f, void *owner, void *p2, void *p3, void *p4, void *p5);
int osl_dpc_net(void (f)(int, int, int, int, int), int p1, int p2, int p3, int p4, int p5);



/*
 * OSL Synchronization primitive support.
 * Semaphores and Mutexes
 */
typedef SEM_ID 		osl_mutex_t;
typedef SEM_ID 		osl_sem_t;
typedef SEM_ID 		OSL_SEM_t;

/* Synch Types */
#define osl_mutex_FOREVER	(-1)
#define osl_sem_FOREVER		(-1)
#define osl_mutex_NOWAIT        0
#define osl_sem_NOWAIT          0
#define osl_sem_BINARY		1
#define osl_sem_COUNTING	0


#define	OS_NO_WAIT	osl_sem_NOWAIT
#define	OS_WAIT_FOREVER	osl_sem_FOREVER



/*
 * NOTE:
 * To avoid internal overflow, usec must be less than (2^32-1)/clockTickHz,
 * or about 42,000,000 @ 100 Hz.
 */

/* Binary (Mutual Exclusion) semaphore */
osl_mutex_t 	osl_mutex_create(char *desc);
void		osl_mutex_destroy(osl_mutex_t m);
int		osl_mutex_take(osl_mutex_t m, int usec);
int		osl_mutex_give(osl_mutex_t m);

/* Counting semaphore */
osl_sem_t	osl_sem_create(char *desc, int binary, int initial_count);
void		osl_sem_destroy(osl_sem_t b);
int		osl_sem_take(osl_sem_t b, int usec);
int		osl_sem_give(osl_sem_t b);
int		osl_sem_reset(osl_sem_t b);



/*
 * Byteorder routines.
 */

/*
 * Macro:
 *	osl_htonl_store
 * Purpose:
 *	Store 32-bit value in network byte order at arbitrary 
 *	byte alignment.
 */
#define	osl_htonl_store(_a, _v) 	\
    do {				\
	uint8 	*a = (uint8 *)(_a);	\
	uint32	v = (_v);		\
					\
	a[0] = (uint8)(v >> 24);	\
	a[1] = (uint8)(v >> 16);	\
	a[2] = (uint8)(v >> 8);		\
	a[3] = (uint8)(v >> 0);		\
    } while (0)

/*
 * Macro:
 *	osl_htonl_store
 * Purpose:
 *	Store 16-bit value in network byte order at arbitrary 
 *	byte alignment.
 */
#define osl_htons_store(_a, _v)		\
    do {				\
	uint8 	*a = (uint8 *)(_a);	\
	uint16	v = (_v);		\
					\
	a[0] = (uint8)(v >> 8);		\
	a[1] = (uint8)(v >> 0);		\
    } while (0)


/*
 * Macro:
 *	osl_ntohl_load
 * Purpose:
 *	Load 32-bit value in network byte order at arbitrary 
 *	byte alignment into host byte order.
 */
extern	uint32	osl_ntohl_load(void *);
extern	uint16	osl_ntohs_load(void *);

#if defined(LE_HOST)
extern	uint32	osl_htonl(uint32);
extern	uint16	osl_htons(uint16);
extern	uint32	osl_ntohl(uint32);
extern	uint16	osl_htons(uint16);
#else
#define	osl_htonl(_l)	(_l)
#define	osl_htons(_s)	(_s)
#define	osl_ntohl(_l)	(_l)
#define	osl_ntohs(_s)	(_s)
#endif



/*
 * OSL Miscellaneous Utility Routines
 *
 *  osl_time() returns relative time in seconds and must be
 *  interrupt-safe, unlike the standard time() call.
 *
 *  osl_double_time() returns relative time in seconds as a floating
 *  point number.  Resolution is platform-dependent and may be limited
 *  to scheduler clock rate.  On a Mousse card at 200 MHz, the
 *  resolution is 0.00000008 (80 ns).
 */

void	osl_sleep(int sec);
void	osl_usleep(uint32 usec);
void	osl_msleep(uint32 msec);

int	osl_date_set(time_t *val);
int	osl_date_get(time_t *val);

time_t	osl_time(void);
uint32  osl_time_usecs(void);
double	osl_double_time(void);
#define OSL_USECS_SUB(x,y) ((int) ((x) - (y)))
#define OSL_USECS_ADD(x,y) ((int) ((x) + (y)))
uint32 osl_usec_diff_time(uint32 timeStamp);

/*
 * OSL Booting/Rebooting routines.
 */
void	osl_reboot(void);
/*
 * OSL Shell routine - to escape to shell on whatever platform.
 * On UNIX, this runs a shell, on VxWorks, WindShell.
 */
void	osl_shell(void);
void    osl_native_shell(void);

/*
 * Routine to safely probe R/W accessibility of an address.
 */
int	osl_memory_check(uint32 addr);

/*
 * OSL Network Interface Configuration Routines.
 */
extern int osl_if_deconfig(char *pfx, char *if_name, int if_unit);
extern void *osl_if_config(char *pfx, int u, char *if_name, 
			   int if_unit, char *if_host, 
			   mac_addr_t if_mac, int if_vlan, 
			   ip_addr_t if_ip, ip_addr_t if_netmask);
/* 
 * LED Support, platform specific routine to set led value.
 */
extern uint32 osl_led(uint32 led);

/*
 * Watchdog timer, platform specific
 */
extern int osl_watchdog_arm(uint32 usec);

/*
 * Recover boot flags.
 */
extern uint32 osl_boot_flags(void);

/*
 * Utilities
 */
void format_long_integer(char *buf, uint32 *val, int nval);
int parse_macaddr(char *str, mac_addr_t macaddr);
const char *strcaseindex(const char *s, const char *sub);
char *strrepl(char *s, int start, int len, const char *repstr);
uint32 swap32(uint32 i);
int floorlg2(uint32 x);
int popcount(uint32 n);
int i2xdigit(int digit);
int xdigit2i(int digit);
int isint(char *s);
uint32 parse_binary(char *str);
uint32 parse_integer(char *str);
void parse_long_integer(uint32 *val, int nval, char *str);
void add_long_integer(uint32 *dst, uint32 *src, int nval);
void sub_long_integer(uint32 *dst, uint32 *src, int nval);
void neg_long_integer(uint32 *dst, int nval);
uint32 crc32(uint32 crc, uint8 *data, int len);
int parse_macaddr(char *str, mac_addr_t macaddr);
void format_macaddr(char buf[MACADDR_STR_LEN], mac_addr_t macaddr);
void increment_macaddr(mac_addr_t macaddr, int amount);
int parse_ipaddr(char *s, ip_addr_t *ipaddr);
void format_ipaddr(char buf[IPADDR_STR_LEN], ip_addr_t ipaddr);
uint32 packet_load(uint8 *addr, int size);
uint32 packet_store(uint8 *buf, int size, uint32 pat, uint32 inc);
int packet_compare(uint8 *p1, uint8 *p2, int size);



#endif /* !_OSL_VX_H_ */
