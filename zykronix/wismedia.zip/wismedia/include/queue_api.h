/******************************************************************************
*
*   FILE: 
*       queue_api.h
*
*   DESCRIPTION:
*
*   $Id: queue_api.h,v 1.6 2004/04/26 10:54:25 jfd Exp $
*
******************************************************************************/

#include "wis_types.h"
#include "os.h"

#ifndef QUEUE_API_H
#define QUEUE_API_H

/* potential queue type definitions */
#define OSL_Q_TYPE_NO_TYPE      0
#define OSL_Q_TYPE_ISR_TO_TASK  1
#define OSL_Q_TYPE_TASK_TO_TASK 2

#define OSL_Q_MAX_NUM_QUEUES    10

typedef struct osl_queue_s {
    
    sint32      *ps32Buffer;
    osl_sem_t   queueSemaphore;
    sint32      s32HeadIndex;
    sint32      s32TailIndex;
    sint32      s32QueueSize;             /* size of queue in bytes */
    sint32      s32NumQueueElements;     /* number of elements in the queue */
    sint32      s32ElementSize;          /* element size in bytes */
} osl_queue_t;

#define QUEUE_INITIAL_COUNT             0

#define OSL_NO_Q_AVAILABLE              (-2)
#define OSL_QUEUE_IS_FULL               (-3)
#define OSL_QUEUE_GET_TIMEOUT           (-4)

#define OSL_SUCCESS                     SUCCESS
#define OSL_FAILURE                     FAILURE



#define QUEUE_EMPTY(queue)              \
            (queue.s32HeadIndex == queue.s32TailIndex)

#define QUEUE_FULL(queue)               \
            ( (queue.s32TailIndex > queue.s32HeadIndex) ?           \
               (queue.s32TailIndex == (queue.s32HeadIndex + queue.s32ElementSize)) :        \
               ((queue.s32TailIndex == 0) && (queue.s32HeadIndex == queue.s32QueueSize - queue.s32ElementSize)) )

int OSL_QInit(sint32 s32QType, sint32 s32QElementSize, sint32 s32QNumElements);
status_t OSL_QDelete(int sQueueId);
status_t OSL_QPut(int queueId, void *pvQueueElement,
                  sint32 s32QueueElementSize, sint32 s32Timeout);
status_t OSL_QGet(int queueId, void *pvQueueElement,
                  sint32 s32QueueElementSize, sint32 s32Timeout);



#endif /* QUEUE_API_H */

