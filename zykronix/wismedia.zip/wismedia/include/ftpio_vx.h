#ifndef _FTP_IO_H
#define _FTP_IO_H
/*
 *
 * FTPIO module for VxWorks
 *
 *   Abstracts FTP or RSH to look like ordinary file I/O.
 * 
 * $Id: ftpio_vx.h,v 1.1 2003/11/04 15:42:34 dmeyer Exp $
 */

#include <stdio.h>

void	ftpio_defaults(char *user, char *pass, char *host);
FILE	*ftpio_open(char *filespec, char *fmode);
int	ftpio_close(FILE *fp);
int	ftpio_valid_fp(FILE *fp);
int	ftpio_ls(char *filename, char *flags);
int	ftpio_remove(char *filename);
int	ftpio_rename(char *oldname, char *newname);

STATUS FTPXfer(char *host, char *user, char *passwd, char *acct,
	       char *cmd, char *dirname, char *filename,
	       int *pCtrlSock, int *pDataSock);

#endif /* _FTP_IO_H */
