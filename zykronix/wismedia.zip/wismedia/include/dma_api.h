/******************************************************************************
*
*   FILE: 
*		dma_api.h
*
*   DESCRIPTION:
*
*   $Id: dma_api.h,v 1.5 2004/10/29 15:15:32 jfd Exp $
*
******************************************************************************/

#ifndef DMA_API_H
#define DMA_API_H

#include "wis_types.h"

#if defined(IXDP425) && !defined(HW_J18V035T00) && !defined(ZAO) /* Ambit platform uses Coyote BSP */
#include "IxDmaAcc.h"
#endif /* IXDP425 */

typedef struct
{
	
	uint32 *pu32SourceAddress;
	uint32 *pu32DestAddress;
	uint32 u32DmaLen;	
#if defined(IXDP425) && !defined(HW_J18V035T00) && !defined(ZAO) /* Ambit platform uses Coyote BSP */
	IxDmaAccDmaCompleteCallback dmaDriverCallback; /* when the DMA is complete, call this function */
#endif /* IXDP425 */
	
} DMA_DRIVER_QUEUE_ELEMENT_t;

extern int sDmaDriverQueue;

/* prototypes section */

/* all callbacks must call this callback */
void DMAD_Callback(sint32 s32Status);

#endif /* DMA_API_H */

/********************************* end of dma_api.h ***************************/

