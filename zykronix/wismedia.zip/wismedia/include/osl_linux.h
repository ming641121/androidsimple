/******************************************************************************
*
* WIS Technologies, Inc.
* Copyright (C) 2004 WIS Technologies, Inc.
*
* OS Abstraction Layer API
* Linux KERNEL mode.
*
* See also, osl_posix.c for Linux/SVR4 user mode OSL.
*
* $Id: osl_linux.h,v 1.8 2005/01/12 16:18:54 jblair Exp $
*
******************************************************************************/
/*
 *

 *
 */
#ifndef _OSL_LINUX_H
#define _OSL_LINUX_H

#include "wis_types.h"
#include "compiler.h"
#include <linux/kernel.h>
#include <linux/string.h>
#include <linux/sched.h>
#include <asm/system.h>

#define	MAX_TASK_NAME_LENGTH	80

typedef struct osl_thread_s{
    char thread_opaque_type;
} *osl_thread_t;

typedef void (*vfptr)(void*);

typedef struct osl_mutex_s{
    char mutex_opaque_type;
} *osl_mutex_t;

typedef struct osl_sem_s{
    char osl_opaque_type;
} *osl_sem_t, *OSL_SEM_t;

#define osl_mutex_FOREVER       (-1)
#define osl_mutex_NOWAIT        0

#define osl_sem_FOREVER         (-1)
#define osl_sem_NOWAIT          0

#define osl_sem_BINARY          1
#define osl_sem_COUNTING        0

#define OSL_THREAD_ERROR        ((osl_thread_t) -1)
#define OSL_THREAD_STKSZ        16384   /* Default Stack Size */


#define ASSERT(x)\
if(!(x)){\
   printk("ERROR: assertion failed: %s:%d\n", __FILE__,__LINE__);\
   panic(0);\
} 

/* Memory allocation */
extern void *osl_calloc(unsigned int num_elements, unsigned int sz);
extern void *osl_alloc(unsigned int, char *);
extern void osl_free(void *);

/* Synchronization Primitives */
osl_mutex_t     osl_mutex_create(char *desc);
void            osl_mutex_destroy(osl_mutex_t m);
int             osl_mutex_take(osl_mutex_t m, int usec);
int             osl_mutex_give(osl_mutex_t m);

osl_sem_t       osl_sem_create(char *desc, int binary, int initial_count);
void            osl_sem_destroy(osl_sem_t b);
int             osl_sem_take(osl_sem_t b, int usec);
int             osl_sem_give(osl_sem_t b);

/* Thread Primitives */
osl_thread_t    osl_thread_create(char *, int, int,void (f)(void *), void *);
int             osl_thread_destroy(osl_thread_t);
osl_thread_t    osl_thread_self(void);
char            *osl_thread_name(osl_thread_t thread,
                                 char *thread_name, int thread_name_size);
void            osl_thread_exit(int);
void            osl_thread_yield(void);
void            osl_thread_main_set(osl_thread_t thread);
osl_thread_t    osl_thread_main_get(void);

/* Irq support */
typedef void (*irq_handler_t)(int, void *, void *); /* See also: sched.h */

int osl_int_connect(unsigned int irq,
		    irq_handler_t service,
		    const char *name, void *data);
void osl_int_disconnect(int i, void* data);
void osl_int_enable(int irq);
void osl_int_disable(int irq);


#define OSL_USECS_SUB(x,y) ((int) ((x) - (y)))
#define OSL_USECS_ADD(x,y) ((int) ((x) + (y)))
uint32 osl_usec_diff_time(uint32 timeStamp);

/* Interrupt/Pre-Emption Control */
int osl_spl(int level);
int osl_splhi(void);
                                                
/* Deferred procedure calls */
int osl_dpc_init(int prio);
/* NOTE: must call at least once at init to launch task */
void osl_dpc_term(void);
int osl_dpc(osl_dpc_fn_t f,
	    void *owner, void *p2, void *p3, void *p4, void *p5);

/* Time support */
#define MILLISECOND_USEC              (1000)
#define SECOND_USEC                   (1000000)
#define MINUTE_USEC                   (60 * SECOND_USEC)

time_t	osl_time(void);
uint32  osl_time_usecs(void);
double	osl_double_time(void);
#define OSL_USECS_SUB(x,y) ((int) ((x) - (y)))
#define OSL_USECS_ADD(x,y) ((int) ((x) + (y)))
uint32 osl_usec_diff_time(uint32 timeStamp);

/* Delay support */
void osl_sleep(int sec);
void osl_msleep(unsigned int msec);
void osl_usleep(unsigned int usec);

/* Interrupt locking */

#define osl_splhi(x) \
   do { \
        save_flags (x); \
        cli ();} \
   while (0)

#define osl_spl(x) restore_flags(x);

/* Initialize/Shutdown OSL library */
void osl_init(void);
void osl_shutdown(void);

/* Legacy & VxWorks'isms ... */
#define printf printk
#define FOREVER for(;;)
#define OS_NO_WAIT osl_sem_NOWAIT
#define OS_WAIT_FOREVER osl_sem_FOREVER

#define	OSL_IntConnect(i, isr, intArgument)				\
		      osl_int_connect(i, isr, "ISR", intArgument)

#define	OSL_CreateTask(taskName, taskPriority, options, stackSize, taskEntryPoint)	\
			osl_thread_create(taskName, stackSize, taskPriority, (void *)taskEntryPoint, 0)
			
#define OSL_DeleteTask(taskId)				\
			osl_thread_destroy(taskId);
			
/* Counting semaphore section */
#define	OSL_CreateCountingSemaphore(description, countingSemaphore, initialCount)	\
			countingSemaphore = osl_sem_create(description, FALSE, initialCount)

#define	OSL_SemCountTake(countingSemaphore, wait)		\
			osl_sem_take(countingSemaphore, wait)

#define	OSL_SemCountGive(countingSemaphore)			\
			osl_sem_give(countingSemaphore)
			
#define	OSL_SemCountDelete(countingSemaphore)		\
			osl_sem_destroy(countingSemaphore)

#define	OSL_Malloc(bytesToAllocate)										\
			osl_alloc(bytesToAllocate, NULL)
			
#define	OSL_Calloc(numElementsToAllocate, elementSize)					\
			osl_calloc(numElementsToAllocate, elementSize)
			
#define	OSL_Free(memToFree)												\
			osl_free(memToFree);

int strncasecmp (char *s1, char *s2, int length);
int atoi (char s[]);

#endif /* !_OSL_LINUX_H */
