#ifndef VERSION_H
#define VERSION_H

#define VERSION_STRING "1.1a"

#endif /* VERSION_H */
