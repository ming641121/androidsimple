/********************************************************************************
*
*   FILE: 
*		os.h
*
*   DESCRIPTION:
*	OS Abstraction layer
*   
*   $Id: os.h,v 1.2 2003/12/12 18:38:42 dmeyer Exp $
*
*********************************************************************************/

#ifndef OS_H
#define	OS_H

#ifdef VXWORKS
#include "osl_vx.h"
#elif __linux__
#include "osl_linux.h"
/* Linux */
#endif
#endif /* OS_H */

