/******************************************************************************
*
*   Copyright WIS Technologies (c) (2003)
*   All Rights Reserved
*
*******************************************************************************
*
*   FILE: 
*
*	ringbuf.h
*
*   DESCRIPTION:
*		Header file for ringbuffers
*
*   AUTHOR:
*               Jimmy Blair
*   $Id: ringbuf.h,v 1.2 2004/09/07 13:25:48 jfd Exp $
*
******************************************************************************/
#ifndef _RINGBUF_H
#define _RINGBUF_H

typedef struct _ringbuffer {
    void ** ppArray;
    int iRead;          /* points at next location to read */
    int iWrite;         /* points at next location to write */
    int iLen;           /* length of ring buffer */
}ringbuf_t;

#define RING_FULL 1
#define RING_EMPTY 0

/* 
*  The length of the array of pointers pointed to by ppArray must be
*  1 element greater than the maximum number of pointers in the array.
*  By having 1 extra unused element it's possible to make the
*  put and get functions independent.
*/

extern void ringbuf_init (ringbuf_t * pRing, 
			  void ** ppArray, int len, int full);
extern void * ringbuf_get (ringbuf_t * pRing);
extern void * ringbuf_put (ringbuf_t * pRing, void * pData);

#endif /* _RINGBUF_H */
