/*
 * Platform specific initialization and defines.
 *
 * $Id: platform.h,v 1.20 2005/05/22 01:09:46 jfd Exp $
 */

#ifndef PLATFORM_H
#define PLATFORM_H

#ifdef __KERNEL__
#include <linux/kernel.h>
#include <linux/string.h>
#include <asm/hardware.h>  
#ifdef ZAO
#include <asm/irq.h>
#endif
#endif /* __KERNEL__ */

/* debug configuration/information */

#define DEBUG_LEVEL_PRINTFS         3
#define ENCODER_PRINT_DEBUG_LEVEL   2
#define DEBUG_LEVEL_STATISTICS      1

/* Common definitions */

#define INT_TYPE_LEVEL_LOW          1
#define INT_TYPE_LEVEL_HIGH         2
#define INT_TYPE_EDGE_FALLING       3
#define INT_TYPE_EDGE_RISING        4


/*****************************************************************************
*  IXP425 ZAO/Predator board
*****************************************************************************/
/* Predator IPTV IXP Platform variant */
#define PREDATOR 1 

#ifdef ZAO
#ifdef PREDATOR
#define ENCODER_BASE_ADDR       IXP425_EXP_BUS_CS4_BASE_VIRT 
#else
#define ENCODER_BASE_ADDR       IXP425_EXP_BUS_CS5_BASE_VIRT 
#endif
#define AUDIO_INT_GPIO          IXP425_GPIO_PIN_1
#define AUDIO_INT_NUM           IRQ_IXP425_GPIO1  
#define ENCODER_INT_GPIO        IXP425_GPIO_PIN_3
#define ENCODER_INT_NUM         IRQ_IXP425_GPIO3        
#define AUDIO_INT_TYPE          INT_TYPE_LEVEL_LOW
#define ENCODER_INT_TYPE        INT_TYPE_LEVEL_LOW

/* IRQ's not shared for audio/video */
#define SA_FLAGS                SA_INTERRUPT
#define IRQ_DEV_ID              0
#define IRQ_DEV_ID_AUDIO        0

/* Kernel interrupt clear routine uses int num, not mask */
#define AUDIO_INTERRUPT_STATUS_BIT_MASK     AUDIO_INT_GPIO
#define ENCODER_INTERRUPT_STATUS_BIT_MASK   ENCODER_INT_GPIO

#ifdef PREDATOR /* TV-Tuner w/ 128MB */
#define PHYSMEM_SIZE            0x600000 /* 4MB VRAM, 2MB ARAM */
#define VIDEO_MEM_SIZE          0x400000
#else
#define PHYSMEM_SIZE            0x300000 /* 2MB VRAM, 1MB ARAM */
#define VIDEO_MEM_SIZE          0x200000
#endif
#define AUDIO_MEM_SIZE          (PHYSMEM_SIZE - VIDEO_MEM_SIZE)

/* HPI bus configuration */
#if 0  
/* Intel 16-bit Multiplexed mode with max wait states */
#define ENCODER_BUS_INIT_MODE       0xbfff3c12 
#define ENCODER_BUS_RUNTIME_MODE    0xbfff3c12 
#else
/* Intel 16-bit Multiplexed mode with 2 cycles added to data strobe timing  */
#define ENCODER_BUS_INIT_MODE       0x80803c12      
#define ENCODER_BUS_RUNTIME_MODE    0x80803c12
#define AUDIO_HARDWARE_ENABLED
#endif

#endif /* ZAO */


/*****************************************************************************
 *  S3C2510 Daredevil board
 *****************************************************************************/
#ifdef DAREDEVIL

#define ENCODER_BASE_ADDR           MAP_MEM_BANK2
/*
 * use the general interrupt because the encoder task currently
 * handles non-video interrupts as well
 */
#define ENCODER_INT_NUM                   EXT_IRQ_0 
#define AUDIO_INT_NUM                     EXT_IRQ_2
#define ENCODER_INTERRUPT_STATUS_BIT_MASK MASK_IRQ_0
#define AUDIO_INTERRUPT_STATUS_BIT_MASK   MASK_IRQ_2
#define AUDIO_INT_TYPE                    INT_TYPE_LEVEL_HIGH
#define ENCODER_INT_TYPE                  INT_TYPE_LEVEL_HIGH
#define SA_FLAGS                          SA_INTERRUPT
#define IRQ_DEV_ID                        0
#define IRQ_DEV_ID_AUDIO                  0

/* Intel 16-bit Multiplexed mode with 1 wait state for the data cycle */
#define ENCODER_BUS_INIT_MODE       0
/* Intel 16-bit Multiplexed mode with 0 wait states */
#define ENCODER_BUS_RUNTIME_MODE    1

/* PHYSMEM_SIZE is the amount of memory to malloc for driver's a/v buffers */
#define PHYSMEM_SIZE                0x300000 /* 3MB (A+V) */
#define VIDEO_MEM_SIZE              0x200000
#define AUDIO_MEM_SIZE              (PHYSMEM_SIZE - VIDEO_MEM_SIZE)
#define AUDIO_HARDWARE_ENABLED

#endif /* DAREDEVIL */

#endif /* PLATFORM_H */

