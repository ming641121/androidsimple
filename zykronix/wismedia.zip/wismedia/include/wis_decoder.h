/******************************************************************************
 *
 *   Copyright WIS Technologies (c) (2003)
 *   All Rights Reserved
 *
 ******************************************************************************
 *
 *   FILE: 
 *      wis_decoder.h
 *
 *   DESCRIPTION:
 *   This is the API (Application Programming Interface) for the WIS Decoder.
 *
 *   $Id: wis_decoder.h,v 1.4 2004/03/01 15:42:28 jfd Exp $
 *
 *****************************************************************************/

#ifndef DECODER_API_H
#define DECODER_API_H

#include "wis_types.h"

#ifdef __cplusplus
extern "C" { 
#endif

/*
 * Decoder info structure 
 */
typedef struct decoderVersion_s
{
    uint32 decoderVersion;
} decoderVersion_t;

/* Frame type */
#define IFRAME          0
#define PFRAME          1
#define BFRAME          2
#define NOTIFY          4
#define ANYFRAME        0xf
#define ALLFRAMES       ANYFRAME

/*
 * Frame info structure.
 */
typedef struct d_frameInfo_s
{
    sint32 timestamp; /* Sequence number */
    sint32 type;       /* One of below */

} d_frameInfo_t;

extern sint32 drv_video_init (void);
extern void *video_fb_address;          /* frame buffer address */

/*  User defined data to be used by Callback */
typedef struct sequence_info_s
{
    sint32       timestamp;
} sequenceInfo_t;

/* Structure for local display */
typedef struct display_info_s
{
    sint32     width;
    sint32     height;
    REAL32     bpp;
    void       *frameBufferRam;
} displayInfo_t;

/* Input types for decoderSetMode */
    /* from multimedia.h */
#define DECODER_INPUT_MODE_MPEG4        MPEG4
#define DECODER_INPUT_MODE_MPEG2        MPEG2
#define DECODER_INPUT_MODE_MPEG1        MPEG1
#define DECODER_INPUT_MODE_H263         H263
#define DECODER_INPUT_MODE_H261         2
#define DECODER_INPUT_MODE_H26L         5
#define DECODER_INPUT_MODE_MPEG4XGO     6
#define DECODER_INPUT_MODE_MPEG2X4  7
#define DECODER_INPUT_MODE_MJPEG    8
#define DECODER_INPUT_MODE_DV       9
#define DECODER_INPUT_MODE_GO       10


/* Output types for decoderSetMode */
#define DECODER_OUTPUT_MODE_RGB24   0
#define DECODER_OUTPUT_MODE_RGB32   1
#define DECODER_OUTPUT_MODE_YUV     2
#define DECODER_OUTPUT_MODE_YCBCR   3
#define DECODER_OUTPUT_MODE_UYVY        4
#define DECODER_OUTPUT_MODE_DIB24   5
#define DECODER_OUTPUT_MODE_DIB32   6
#define DECODER_OUTPUT_MODE_RGB565  7

/* Function: DecoderInit
 * Arguments: pFrame - first frame from GO7007SB device after
 *            EncoderStart is called. This frame includes the stream header
 *         frameLen - length of first frame.
 * 
 * Returns: SUCCESS or FAILURE, if FAILURE, more detailed info may be provided.
 */
sint32 DecoderInit(uint8 *pFrame, uint32 frameLen);

/* Function: DecoderStop
 * Arguments: 
 *      NONE.
 * 
 * Returns:
 *      NONE
 */
void DecoderStop(void);


/*
 * Function: DecoderSetNumStreams
 * Arguments: 
 *          ndecoders - number of decoder streams to be run by the system.
 */
sint32 DecoderSetNumStreams(int ndecoders);

/*
 * Function: DecoderSetMode - set decoder operating mode
 * Arguments:
 *           inputtype - one of  DECODER_INPUT_XXX constants (above)
 *           output - one of DECODER_OUTPUT_XXX constants (above)
 *           width  -  output width of display (pitch) - has nothing
 *                     todo with frame.
 *                     For example, on 800x600 display, width is 800
 *
 *           height - output height of display (number of scan lines)
 *                    For example, on 800x600 display, height is 600
 *
 * Returns: SUCCESS or FAILURE, if FAILURE, more detailed info may be provided.
 *           
 */
status_t DecoderSetMode(int stream, sint32 inputtype, sint32 output, sint32 width, sint32 height);

/* 
 * Function: DecoderGetMode - get current decoder operating mode
 * Arguments:
 *           inputtype - one of  DECODER_INPUT_XXX constants (above)
 *           output - one of DECODER_OUTPUT_XXX constants (above)
 *           width  -  output width of display (pitch) - has nothing
 *                     todo with frame
 *                     For example, on 800x600 display, width is 800
 *
 *           height - output height of display (number of scan lines)
 *                    For example, on 800x600 display, height is 600
 *
 * Returns: SUCCESS or FAILURE, if FAILURE, more detailed info may be provided.
 */
status_t DecoderGetMode(int stream, sint32* input, sint32* output, sint32 *width, sint32 *height);

/* 
 * Function: DecoderGetVersionInfo
 * Purpose:  return information about current decoder engine.
 * Return:   decoderVersion info structure.
 */
decoderVersion_t DecoderGetVersionInfo(void); 

/* 
 * Function: DecoderGetSnapshot - Take a snapshot of the current screen.
 * Arguments: decoderInstance - decoder Instance number
 *            bufferPtr - pointer to the buffer to place the image
 * Return: address of frame buffer for output image. NULL indicates failure.
 */
status_t DecoderGetSnapshot(sint32 stream, uint8* bufferPtr);

/* 
 * Function:  DecodeOneFrame
 * Purpose:   Decode a single frame, as in when we receive one off the network 
 * Arguments: frame -  Elementary Stream frame received from Encoder
 *            len - length of frame received from encoder
 *            destFrame - pointer to output buffer (must be allocated
 *                        >= width*height*bpp)
 *            dlen - pointer to length of new RGB decoded frame, we
 *                   fill this in for you.
 *            type - The encoder updates this structure to provide
 *                   additional info about the frame, updated after call
 */
status_t DecodeOneFrame(int stream, void *frame, sint32 len, void *destFrame, sint32 *dlen, d_frameInfo_t *type);

#ifdef __cplusplus
};
#endif

#endif /* DECODER_API_H */

/********************* end of wis_decoder.h **********************************/

