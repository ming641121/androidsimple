/*
 * File: 	vx_io.h
 * Purpose: 	OSL I/O definitions
 *
 * $Id: io_vx.h,v 1.1 2003/11/04 15:42:35 dmeyer Exp $
 *
 */

#ifndef _IO_VX_H
#define _IO_VX_H

#include <stdio.h>
#include <wis_types.h>

#ifndef va_copy
#if defined(MOUSSE)
#  define va_copy(to, from)	((to)[0] = (from)[0])
#elif defined(GENERICPC) || defined(UNIX) || defined(IXDP425)
#  define va_copy(to, from)	((to) = (from))
# else
#  error va_copy?
# endif
#endif

#include <types.h>
#include <compiler.h>

#define OSL_VT100_SO		"\033[7m"	/* Stand-out begin */
#define OSL_VT100_SE		"\033[m"	/* Stand-out end */
#define OSL_VT100_CE		"\033[K"	/* Kill to end of line */

int	osl_printf(const char *fmt, ...)
			COMPILER_ATTRIBUTE ((format (printf, 1, 2)));
int	osl_vprintf(const char *fmt, va_list varg);

FILE 	*osl_fopen(char *name, char *mode);

int 	osl_fclose(FILE *fp);

char	*osl_getcwd(char *buf, size_t size);
int	osl_ls(char *filename, char *flags);
int	osl_cd(char *filename);
int	osl_remove(char *filename);
int	osl_rename(char *file_old, char *file_new);

void	osl_readline_init(void);
void	osl_readline_term(void);
char	*osl_readline(char *prompt, char *buf, int bufsize, char *defl);
void	osl_readline_config(char *(*complete)(char *pathname, int *unique),
			    int (*list_possib)(char *pathname, char ***avp));
int	osl_readchar(const char *prompt);

int	osl_flash_init(int format);
int	osl_flash_boot(char *file);

/*
 * printk
 *
 *  Synchronized printing facility which allows multiplexing output
 *  to console and/or file.
 */

int 	printk(const char *, ...)		/* To console and/or file */
		COMPILER_ATTRIBUTE ((format (printf, 1, 2)));
int 	vprintk(const char *, va_list ap);

int 	printk_cons_enable(int enable);		/* Set console output on/off */
int	printk_cons_is_enabled(void);
int 	printk_cons(const char *, ...)		/* To console only */
		COMPILER_ATTRIBUTE ((format (printf, 1, 2)));

int 	printk_file_enable(int enable);		/* Set file output on/off */
int	printk_file_is_enabled(void);
int 	printk_file_open(char *filename, int append);
						/* Initiate output to file */
int 	printk_file_close(void);		/* Terminate output to file */
int 	printk_file(const char *, ...)		/* To log file only */
		COMPILER_ATTRIBUTE ((format (printf, 1, 2)));
int	vprintk_file(const char *, va_list ap);
char *	printk_file_name(void);			/* Return current file name */

/*
 * debugk
 *
 *  Debug printing facility (also synchronized with locks like printk).
 *  Specify one or more debug message classes in the call.  The message is
 *  displayed only if the message class is enabled via debugk_select().
 *
 *  Use debugk_select to activate selected debug message classes.
 *  Use debugk_check to check if specified class(es) are currently active.
 *
 *  NOTE!! When adding here, add matching entry to dk_map[] in system.c.
 */

#define DK_INIT			(1 << 0)	/* Initialization */
#define DK_INTR			(1 << 1)	/* Interrupt processing */
#define DK_DMA			(1 << 2)	/* DMA operations */
#define DK_VERBOSE		(1 << 3)	/* General verbose output */
#define	DK_ERR			(1 << 4)	/* Print errors */
#define DK_PCI			(1 << 5)	/* PCI Drivers */
#define DK_END			(1 << 6) 	/* END drivers */

int 	debugk_select(uint32 dk);
int 	debugk_check(uint32 dk);

int 	debugk(uint32 dk, const char *, ...)
		COMPILER_ATTRIBUTE ((format (printf, 2, 3)));

/*
 * Some of our BSPs have routines have a sysSerialPrintf routine that
 * allows the console serial port to be written directly in polled mode
 * with interrupts turned off.  When this is available, it is preferred
 * over logMsg.
 */

#if defined(MOUSSE) || defined(ZT6501) || \
	defined(GENERICPC) || defined(JUPITER)
#define HAVE_DIRECT_SERIAL
#endif

#ifdef HAVE_DIRECT_SERIAL
void 	sysSerialPutc(int c);
int  	sysSerialGetc(void);
void 	sysSerialPrintString(char *s);
void 	sysSerialPrintHex(UINT32 value, int cr);
int	osl_vprintf_direct(const char *fmt, va_list varg);
#endif /* HAVE_DIRECT_SERIAL */

#endif /* _IO_VX_H */
